@echo off
"C:\Program Files\OpenModelica\bin\omc.exe" -d=initialization runtest.mos
