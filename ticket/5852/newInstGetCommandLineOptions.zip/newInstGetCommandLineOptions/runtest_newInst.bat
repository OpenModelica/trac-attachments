@echo off
"C:\Program Files\OpenModelica\bin\omc.exe" -d=newInst,initialization runtest.mos
