#define ID_LEN 16

struct Request {
    double Q_a[4];
    double Q_b[4];
    double r_a[3];
    double r_b[3];
    char id_a[ID_LEN];
    char id_b[ID_LEN];
};

struct Response {
    double cp[3];
    double normal[3];
    double depth;
};
