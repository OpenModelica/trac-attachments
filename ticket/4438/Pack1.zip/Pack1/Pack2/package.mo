within Pack1;

package Pack2
end Pack2;