within Pack1.Pack2;

model Mod4
end Mod4;