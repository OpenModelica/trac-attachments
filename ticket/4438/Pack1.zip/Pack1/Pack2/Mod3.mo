within Pack1.Pack2;

model Mod3
end Mod3;