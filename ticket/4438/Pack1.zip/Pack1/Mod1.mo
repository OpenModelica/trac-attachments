within Pack1;

model Mod1
end Mod1;