within Pack1;

model Mod2
end Mod2;