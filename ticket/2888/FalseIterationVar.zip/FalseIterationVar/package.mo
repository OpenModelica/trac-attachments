package FalseIterationVar
  annotation(uses(Modelica(version = "3.2"), TILMedia(version = "3.2.3")));
end FalseIterationVar;