type NativeInterface
extends ExternalObject;

function constructor
	input String param;
	output NativeInterface interface;

	external "C" interface = ctor(param) annotation(Include = "#include \"ExtObj.h\"");
end constructor;

function destructor
	input NativeInterface interface;

	external "C" dtor(interface) annotation(Include = "#include \"ExtObj.h\"");
end destructor;
end NativeInterface;

model Test
NativeInterface iface(param = "test parameter");
end Test;
