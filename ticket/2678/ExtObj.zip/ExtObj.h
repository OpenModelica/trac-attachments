
#include <stdio.h>
#include <string.h>
#include <assert.h>

//Note: this relies in stderr being displayed as errors,
//as an alternative, it is possible to print using ModelicaError
//which however has the side effect to terminate the simulation

void *ctor(const char *param)
{
	fprintf(stderr,"Ctor called\n");

	assert(strcmp(param,"test parameter")==0);
	return (void*)0xdeadbeef;
}

void dtor(void *obj)
{
	fprintf(stderr,"Dtor called (obj=%p)\n",obj);

	assert(obj==(void*)0xdeadbeef);
}