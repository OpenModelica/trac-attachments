package SafetyValveDimensions  
  model ProportionalSafetyValve  
    extends Modelica.Fluid.Valves.ValveCompressible;
    parameter Real setPressure = 19.0e5;
  equation
    opening = min(1.0, max(0.0, (port_a.p - setPressure) / (1.1 * setPressure - setPressure)));
  end ProportionalSafetyValve;

  partial model SIS100SafetyValveBaseModel  
    parameter Real heatingPowerPerArea = 10.0e3;
    inner Modelica.Fluid.System system(allowFlowReversal = true, m_flow_start = 0.0, p_start = 1.3e5, T_start = 4.49, momentumDynamics = Modelica.Fluid.Types.Dynamics.DynamicFreeInitial);
    replaceable package Medium = ExternalMedia.Media.HeliumMedium;
    replaceable model SafetyValve = Modelica.Fluid.Valves.ValveCompressible;
    parameter Modelica.SIunits.Length D_VCS = 0.028;
    parameter Modelica.SIunits.Length l_pipe_VCS = 30.0;
    Modelica.Fluid.Pipes.DynamicPipe pipe_VCS(redeclare package Medium = Medium, redeclare model HeatTransfer = Modelica.Fluid.Pipes.BaseClasses.HeatTransfer.LocalPipeFlowHeatTransfer, use_HeatTransfer = true, use_T_start = true, length = l_pipe_VCS, diameter = D_VCS, roughness = 2.0e-6, nNodes = 6, p_a_start = 1.3e5, p_b_start = 1.3e5, T_start = 4.49);
    parameter Real surfaceArea_pipe_VCS = Modelica.Constants.pi * D_VCS * l_pipe_VCS;
    Modelica.Thermal.HeatTransfer.Sources.FixedHeatFlow[pipe_VCS.nNodes] fixedheatflow_VCS(Q_flow = heatingPowerPerArea * surfaceArea_pipe_VCS * pipe_VCS.dxs, each T_ref = 0, each alpha = 0.0);
    parameter Modelica.SIunits.Length d_VCS = 0.008;
    parameter Modelica.SIunits.Length l_pipeWithRecooler_VCS = 60.0;
    Modelica.Fluid.Pipes.DynamicPipe pipeWithRecooler_VCS(redeclare package Medium = Medium, redeclare model HeatTransfer = Modelica.Fluid.Pipes.BaseClasses.HeatTransfer.LocalPipeFlowHeatTransfer, use_HeatTransfer = true, use_T_start = true, length = l_pipeWithRecooler_VCS, diameter = D_VCS, roughness = 2.0e-6, nNodes = 12, p_a_start = 1.3e5, p_b_start = 1.3e5, T_start = 4.49, isCircular = false, crossArea = Modelica.Constants.pi * (D_VCS * D_VCS - d_VCS * d_VCS) / 4, perimeter = Modelica.Constants.pi * (D_VCS + d_VCS));
    parameter Real surfaceArea_pipeWithRecooler_VCS = Modelica.Constants.pi * D_VCS * l_pipeWithRecooler_VCS;
    Modelica.Thermal.HeatTransfer.Sources.FixedHeatFlow[pipeWithRecooler_VCS.nNodes] fixedheatflow_VCS_A(Q_flow = heatingPowerPerArea * surfaceArea_pipeWithRecooler_VCS * pipeWithRecooler_VCS.dxs, each T_ref = 0, each alpha = 0.0);
    SafetyValve valve_VCS(redeclare package Medium = Medium, CvData = Modelica.Fluid.Types.CvTypes.Av, Av = 560e-6, p_nominal = 19e5, dp_nominal = 18e5, m_flow_nominal = 5.3, m_flow_start = 0.0, rho_nominal = 119.0);
    Modelica.Fluid.Sources.Boundary_pT boundary_pt_VCS(redeclare package Medium = Medium, nPorts = 1, p = 1.0e5, T = 300.0);
    parameter Modelica.SIunits.Length D_CR = 0.102;
    parameter Modelica.SIunits.Length l_CR = 90.0;
    Modelica.Fluid.Pipes.DynamicPipe pipe_CR(redeclare package Medium = Medium, redeclare model HeatTransfer = Modelica.Fluid.Pipes.BaseClasses.HeatTransfer.LocalPipeFlowHeatTransfer, use_HeatTransfer = true, use_T_start = true, length = l_CR, diameter = D_CR, roughness = 2.0e-6, nNodes = 18, p_a_start = 1.3e5, p_b_start = 1.3e5, T_start = 4.49);
    parameter Real surfaceArea_CR = Modelica.Constants.pi * D_CR * l_CR;
    Modelica.Thermal.HeatTransfer.Sources.FixedHeatFlow[pipe_CR.nNodes] fixedheatflow_CR(Q_flow = heatingPowerPerArea * surfaceArea_CR * pipe_CR.dxs, each T_ref = 0, each alpha = 0.0);
    SafetyValve valve_CR(redeclare package Medium = Medium, CvData = Modelica.Fluid.Types.CvTypes.Av, Av = 1888e-6, p_nominal = 19e5, dp_nominal = 18e5, m_flow_nominal = 18.0, m_flow_start = 0.0, rho_nominal = 119.0);
    Modelica.Fluid.Sources.Boundary_pT boundary_pt_CR(redeclare package Medium = Medium, nPorts = 1, p = 1.0e5, T = 300.0);
    parameter Modelica.SIunits.Length D_MS = 0.050;
    parameter Modelica.SIunits.Length l_MS_1 = 90.0;
    Modelica.Fluid.Pipes.DynamicPipe pipe_MS(redeclare package Medium = Medium, redeclare model HeatTransfer = Modelica.Fluid.Pipes.BaseClasses.HeatTransfer.LocalPipeFlowHeatTransfer, use_HeatTransfer = true, use_T_start = true, length = l_MS_1, diameter = D_MS, roughness = 2.0e-6, nNodes = 18, p_a_start = 1.3e5, p_b_start = 1.3e5, T_start = 4.49);
    parameter Real surfaceArea_MS = Modelica.Constants.pi * D_MS * l_MS_1;
    Modelica.Thermal.HeatTransfer.Sources.FixedHeatFlow[pipe_MS.nNodes] fixedheatflow_MS(Q_flow = heatingPowerPerArea * surfaceArea_MS * pipe_MS.dxs, each T_ref = 0, each alpha = 0.0);
    SafetyValve valve_MS(redeclare package Medium = Medium, CvData = Modelica.Fluid.Types.CvTypes.Av, Av = 944e-6, p_nominal = 19e5, dp_nominal = 18e5, m_flow_nominal = 9.0, m_flow_start = 0.0, rho_nominal = 119.0);
    Modelica.Fluid.Sources.Boundary_pT boundary_pt_MS(redeclare package Medium = Medium, nPorts = 1, p = 1.0e5, T = 300.0);
  equation
    connect(fixedheatflow_VCS.port, pipe_VCS.heatPorts);
    connect(pipe_VCS.port_b, pipeWithRecooler_VCS.port_a);
    connect(fixedheatflow_VCS_A.port, pipeWithRecooler_VCS.heatPorts);
    connect(pipeWithRecooler_VCS.port_b, valve_VCS.port_a);
    connect(valve_VCS.port_b, boundary_pt_VCS.ports[1]);
    connect(fixedheatflow_CR.port, pipe_CR.heatPorts);
    connect(pipe_CR.port_b, valve_CR.port_a);
    connect(boundary_pt_CR.ports[1], valve_CR.port_b);
    connect(fixedheatflow_MS.port, pipe_MS.heatPorts);
    connect(pipe_MS.port_b, valve_MS.port_a);
    connect(boundary_pt_MS.ports[1], valve_MS.port_b);
    annotation(experiment(StartTime = 0, StopTime = 20, Tolerance = 1e-06, Interval = 0.01)); 
  end SIS100SafetyValveBaseModel;

  model SIS100ProportionalSafetyValveLowPressure  
    extends SIS100SafetyValveBaseModel(redeclare model SafetyValve = ProportionalSafetyValve(setPressure = 16.0e5));
    annotation(experiment(StartTime = 0, StopTime = 20, Tolerance = 1e-06, Interval = 0.01)); 
  end SIS100ProportionalSafetyValveLowPressure;
end SafetyValveDimensions;

package ExternalMedia  
  extends Modelica.Icons.Package;

  package Common  "Package with common definitions" 
    extends Modelica.Icons.Package;
    type InputChoice = enumeration(dT "(d,T) as inputs", hs "(h,s) as inputs", ph "(p,h) as inputs", ps "(p,s) as inputs", pT "(p,T) as inputs");
  end Common;

  package Media  "Medium packages compatible with Modelica.Media" 
    extends Modelica.Icons.Package;

    package HeliumMedium  "CoolProp model of He" 
      extends Modelica.Media.Interfaces.PartialTwoPhaseMedium(mediumName = "Helium", singleState = false, onePhase = false, smoothModel = false, fluidConstants = {externalFluidConstants}, ThermoStates = Modelica.Media.Interfaces.Choices.IndependentVariables.ph, SpecificEnthalpy(start = 2e3));
      constant String libraryName = "CoolProp" "Name of the external fluid property computation library";
      constant String substanceName = "He" "Only one substance can be specified";
      constant FluidConstants externalFluidConstants = FluidConstants(iupacName = "Helium", casRegistryNumber = "7440-59-7", chemicalFormula = "He", structureFormula = "He", molarMass = 0.004002602, criticalTemperature = 5.1953, criticalPressure = 227600.0, criticalMolarVolume = 5.515719801434088e-5, acentricFactor = -0.385, triplePointTemperature = 0, triplePointPressure = 0, meltingPoint = 0.95, normalBoilingPoint = 4.230, dipoleMoment = 2.0);
      constant .ExternalMedia.Common.InputChoice inputChoice = .ExternalMedia.Common.InputChoice.ph "Default choice of input variables for property computations";

      redeclare replaceable record ThermodynamicState  
        Temperature T(start = 300) "temperature";
        VelocityOfSound a "velocity of sound";
        Modelica.SIunits.CubicExpansionCoefficient beta "isobaric expansion coefficient";
        SpecificHeatCapacity cp "specific heat capacity cp";
        SpecificHeatCapacity cv "specific heat capacity cv";
        Density d "density";
        DerDensityByEnthalpy ddhp "derivative of density wrt enthalpy at constant pressure";
        DerDensityByPressure ddph "derivative of density wrt pressure at constant enthalpy";
        DynamicViscosity eta "dynamic viscosity";
        SpecificEnthalpy h "specific enthalpy";
        Modelica.SIunits.Compressibility kappa "compressibility";
        ThermalConductivity lambda "thermal conductivity";
        AbsolutePressure p "pressure";
        FixedPhase phase(min = 0, max = 2) "phase flag: 2 for two-phase, 1 for one-phase";
        SpecificEntropy s "specific entropy";
      end ThermodynamicState;

      redeclare record SaturationProperties  
        Temperature Tsat "saturation temperature";
        Real dTp "derivative of Ts wrt pressure";
        DerDensityByPressure ddldp "derivative of dls wrt pressure";
        DerDensityByPressure ddvdp "derivative of dvs wrt pressure";
        DerEnthalpyByPressure dhldp "derivative of hls wrt pressure";
        DerEnthalpyByPressure dhvdp "derivative of hvs wrt pressure";
        Density dl "density at bubble line (for pressure ps)";
        Density dv "density at dew line (for pressure ps)";
        SpecificEnthalpy hl "specific enthalpy at bubble line (for pressure ps)";
        SpecificEnthalpy hv "specific enthalpy at dew line (for pressure ps)";
        AbsolutePressure psat "saturation pressure";
        SurfaceTension sigma "surface tension";
        SpecificEntropy sl "specific entropy at bubble line (for pressure ps)";
        SpecificEntropy sv "specific entropy at dew line (for pressure ps)";
      end SaturationProperties;

      redeclare replaceable model extends BaseProperties(p(stateSelect = if preferredMediumStates then StateSelect.prefer else StateSelect.default), T(stateSelect = StateSelect.default), h(stateSelect = if preferredMediumStates then StateSelect.prefer else StateSelect.default), d(stateSelect = StateSelect.default))  
        parameter .ExternalMedia.Common.InputChoice basePropertiesInputChoice = inputChoice "Choice of input variables for property computations";
        FixedPhase phaseInput "Phase input for property computation functions, 2 for two-phase, 1 for one-phase, 0 if not known";
        Integer phaseOutput "Phase output for medium, 2 for two-phase, 1 for one-phase";
        SpecificEntropy s(stateSelect = StateSelect.default) "Specific entropy";
        SaturationProperties sat "saturation property record";
      equation
        MM = externalFluidConstants.molarMass;
        R = Modelica.Constants.R / MM;
        if onePhase then
          phaseInput = 1 "Force one-phase property computation";
        else
          phaseInput = 0 "Unknown phase";
        end if;
        state = setState_ph(p, h, phaseInput);
        d = density_ph(p, h, phaseInput);
        s = specificEntropy_ph(p, h, phaseInput);
        T = temperature_ph(p, h, phaseInput);
        u = h - p / d;
        sat = setSat_p_state(state);
        if smoothModel then
          phaseOutput = state.phase;
        else
          phaseOutput = if h > bubbleEnthalpy(sat) and h < dewEnthalpy(sat) and p < fluidConstants[1].criticalPressure then 2 else 1;
        end if;
      end BaseProperties;

      redeclare function molarMass  "Return the molar mass of the medium" 
        input ThermodynamicState state;
        output MolarMass MM "Mixture molar mass";
      algorithm
        MM := fluidConstants[1].molarMass;
      end molarMass;

      redeclare replaceable function setState_ph  "Return thermodynamic state record from p and h" 
        extends Modelica.Icons.Function;
        input AbsolutePressure p "pressure";
        input SpecificEnthalpy h "specific enthalpy";
        input FixedPhase phase = 0 "2 for two-phase, 1 for one-phase, 0 if not known";
        output ThermodynamicState state;
        external "C" TwoPhaseMedium_setState_ph_C_impl(p, h, phase, state, mediumName, libraryName, substanceName) annotation(Include = "#include \"externalmedialib.h\"", Library = "ExternalMediaLib", IncludeDirectory = "modelica://ExternalMedia/Resources/Include", LibraryDirectory = "modelica://ExternalMedia/Resources/Library");
      end setState_ph;

      redeclare replaceable function setState_pT  "Return thermodynamic state record from p and T" 
        extends Modelica.Icons.Function;
        input AbsolutePressure p "pressure";
        input Temperature T "temperature";
        input FixedPhase phase = 0 "2 for two-phase, 1 for one-phase, 0 if not known" annotation(__OpenModelica_UnusedVariable = true);
        output ThermodynamicState state;
        external "C" TwoPhaseMedium_setState_pT_C_impl(p, T, state, mediumName, libraryName, substanceName) annotation(Include = "#include \"externalmedialib.h\"", Library = "ExternalMediaLib", IncludeDirectory = "modelica://ExternalMedia/Resources/Include", LibraryDirectory = "modelica://ExternalMedia/Resources/Library");
      end setState_pT;

      redeclare replaceable function setState_dT  "Return thermodynamic state record from d and T" 
        extends Modelica.Icons.Function;
        input Density d "density";
        input Temperature T "temperature";
        input FixedPhase phase = 0 "2 for two-phase, 1 for one-phase, 0 if not known";
        output ThermodynamicState state;
        external "C" TwoPhaseMedium_setState_dT_C_impl(d, T, phase, state, mediumName, libraryName, substanceName) annotation(Include = "#include \"externalmedialib.h\"", Library = "ExternalMediaLib", IncludeDirectory = "modelica://ExternalMedia/Resources/Include", LibraryDirectory = "modelica://ExternalMedia/Resources/Library");
      end setState_dT;

      redeclare replaceable function setState_ps  "Return thermodynamic state record from p and s" 
        extends Modelica.Icons.Function;
        input AbsolutePressure p "pressure";
        input SpecificEntropy s "specific entropy";
        input FixedPhase phase = 0 "2 for two-phase, 1 for one-phase, 0 if not known";
        output ThermodynamicState state;
        external "C" TwoPhaseMedium_setState_ps_C_impl(p, s, phase, state, mediumName, libraryName, substanceName) annotation(Include = "#include \"externalmedialib.h\"", Library = "ExternalMediaLib", IncludeDirectory = "modelica://ExternalMedia/Resources/Include", LibraryDirectory = "modelica://ExternalMedia/Resources/Library");
      end setState_ps;

      redeclare function extends setState_phX  
      algorithm
        state := setState_ph(p, h, phase);
      end setState_phX;

      redeclare function extends setState_pTX  
      algorithm
        state := setState_pT(p, T, phase);
      end setState_pTX;

      redeclare function extends setState_dTX  
      algorithm
        state := setState_dT(d, T, phase);
      end setState_dTX;

      redeclare function extends setState_psX  
      algorithm
        state := setState_ps(p, s, phase);
      end setState_psX;

      redeclare replaceable function density_ph  "Return density from p and h" 
        extends Modelica.Icons.Function;
        input AbsolutePressure p "Pressure";
        input SpecificEnthalpy h "Specific enthalpy";
        input FixedPhase phase = 0 "2 for two-phase, 1 for one-phase, 0 if not known";
        output Density d "Density";
      algorithm
        d := density_ph_state(p = p, h = h, state = setState_ph(p = p, h = h, phase = phase));
        annotation(Inline = true); 
      end density_ph;

      function density_ph_state  "returns density for given p and h" 
        extends Modelica.Icons.Function;
        input AbsolutePressure p "Pressure";
        input SpecificEnthalpy h "Enthalpy";
        input ThermodynamicState state;
        output Density d "density";
      algorithm
        d := density(state);
        annotation(Inline = false, LateInline = true, derivative(noDerivative = state) = density_ph_der); 
      end density_ph_state;

      replaceable function density_ph_der  "Total derivative of density_ph" 
        extends Modelica.Icons.Function;
        input AbsolutePressure p "Pressure";
        input SpecificEnthalpy h "Specific enthalpy";
        input ThermodynamicState state;
        input Real p_der "time derivative of pressure";
        input Real h_der "time derivative of specific enthalpy";
        output Real d_der "time derivative of density";
      algorithm
        d_der := p_der * density_derp_h(state = state) + h_der * density_derh_p(state = state);
        annotation(Inline = true); 
      end density_ph_der;

      redeclare replaceable function temperature_ph  "Return temperature from p and h" 
        extends Modelica.Icons.Function;
        input AbsolutePressure p "Pressure";
        input SpecificEnthalpy h "Specific enthalpy";
        input FixedPhase phase = 0 "2 for two-phase, 1 for one-phase, 0 if not known";
        output Temperature T "Temperature";
      algorithm
        T := temperature_ph_state(p = p, h = h, state = setState_ph(p = p, h = h, phase = phase));
        annotation(Inline = true, inverse(h = specificEnthalpy_pT(p = p, T = T, phase = phase))); 
      end temperature_ph;

      function temperature_ph_state  "returns temperature for given p and h" 
        extends Modelica.Icons.Function;
        input AbsolutePressure p "Pressure";
        input SpecificEnthalpy h "Enthalpy";
        input ThermodynamicState state;
        output Temperature T "Temperature";
      algorithm
        T := temperature(state);
        annotation(Inline = false, LateInline = true, inverse(h = specificEnthalpy_pT_state(p = p, T = T, state = state))); 
      end temperature_ph_state;

      replaceable function specificEntropy_ph  "Return specific entropy from p and h" 
        extends Modelica.Icons.Function;
        input AbsolutePressure p "Pressure";
        input SpecificEnthalpy h "Specific enthalpy";
        input FixedPhase phase = 0 "2 for two-phase, 1 for one-phase, 0 if not known";
        output SpecificEntropy s "specific entropy";
      algorithm
        s := specificEntropy_ph_state(p = p, h = h, state = setState_ph(p = p, h = h, phase = phase));
        annotation(Inline = true, inverse(h = specificEnthalpy_ps(p = p, s = s, phase = phase))); 
      end specificEntropy_ph;

      function specificEntropy_ph_state  "returns specific entropy for a given p and h" 
        extends Modelica.Icons.Function;
        input AbsolutePressure p "Pressure";
        input SpecificEnthalpy h "Specific Enthalpy";
        input ThermodynamicState state;
        output SpecificEntropy s "Specific Entropy";
      algorithm
        s := specificEntropy(state);
        annotation(Inline = false, LateInline = true, derivative(noDerivative = state) = specificEntropy_ph_der); 
      end specificEntropy_ph_state;

      function specificEntropy_ph_der  "time derivative of specificEntropy_ph" 
        extends Modelica.Icons.Function;
        input AbsolutePressure p;
        input SpecificEnthalpy h;
        input ThermodynamicState state;
        input Real p_der "time derivative of pressure";
        input Real h_der "time derivative of specific enthalpy";
        output Real s_der "time derivative of specific entropy";
      algorithm
        s_der := p_der * (-1.0 / (state.d * state.T)) + h_der * (1.0 / state.T);
        annotation(Inline = true); 
      end specificEntropy_ph_der;

      redeclare function extends prandtlNumber  "Returns Prandtl number"  annotation(Inline = true); end prandtlNumber;

      redeclare replaceable function extends temperature  "Return temperature from state" 
      algorithm
        T := state.T;
        annotation(Inline = true); 
      end temperature;

      redeclare replaceable function extends velocityOfSound  "Return velocity of sound from state" 
      algorithm
        a := state.a;
        annotation(Inline = true); 
      end velocityOfSound;

      redeclare replaceable function extends isobaricExpansionCoefficient  "Return isobaric expansion coefficient from state" 
      algorithm
        beta := state.beta;
        annotation(Inline = true); 
      end isobaricExpansionCoefficient;

      redeclare replaceable function extends isentropicExponent  "Return isentropic exponent" 
        extends Modelica.Icons.Function;
      algorithm
        gamma := density(state) / pressure(state) * velocityOfSound(state) * velocityOfSound(state);
      end isentropicExponent;

      redeclare replaceable function extends specificHeatCapacityCp  "Return specific heat capacity cp from state" 
      algorithm
        cp := state.cp;
        annotation(Inline = true); 
      end specificHeatCapacityCp;

      redeclare replaceable function extends specificHeatCapacityCv  "Return specific heat capacity cv from state" 
      algorithm
        cv := state.cv;
        annotation(Inline = true); 
      end specificHeatCapacityCv;

      redeclare replaceable function extends density  "Return density from state" 
      algorithm
        d := state.d;
        annotation(Inline = true); 
      end density;

      redeclare replaceable function extends density_derh_p  "Return derivative of density wrt enthalpy at constant pressure from state" 
      algorithm
        ddhp := state.ddhp;
        annotation(Inline = true); 
      end density_derh_p;

      redeclare replaceable function extends density_derp_h  "Return derivative of density wrt pressure at constant enthalpy from state" 
      algorithm
        ddph := state.ddph;
        annotation(Inline = true); 
      end density_derp_h;

      redeclare replaceable function extends density_derp_T  
      algorithm
        ddpT := state.kappa * state.d;
      end density_derp_T;

      redeclare replaceable function extends density_derT_p  
      algorithm
        ddTp := -state.beta * state.d;
      end density_derT_p;

      redeclare replaceable function extends dynamicViscosity  "Return dynamic viscosity from state" 
      algorithm
        eta := state.eta;
        annotation(Inline = true); 
      end dynamicViscosity;

      redeclare replaceable function extends specificEnthalpy  "Return specific enthalpy from state" 
      algorithm
        h := state.h;
        annotation(Inline = true); 
      end specificEnthalpy;

      redeclare replaceable function extends specificInternalEnergy  "Returns specific internal energy" 
        extends Modelica.Icons.Function;
      algorithm
        u := specificEnthalpy(state) - pressure(state) / density(state);
      end specificInternalEnergy;

      redeclare replaceable function extends isothermalCompressibility  "Return isothermal compressibility from state" 
      algorithm
        kappa := state.kappa;
        annotation(Inline = true); 
      end isothermalCompressibility;

      redeclare replaceable function extends thermalConductivity  "Return thermal conductivity from state" 
      algorithm
        lambda := state.lambda;
        annotation(Inline = true); 
      end thermalConductivity;

      redeclare replaceable function extends pressure  "Return pressure from state" 
      algorithm
        p := state.p;
        annotation(Inline = true); 
      end pressure;

      redeclare replaceable function extends specificEntropy  "Return specific entropy from state" 
      algorithm
        s := state.s;
        annotation(Inline = true); 
      end specificEntropy;

      redeclare replaceable function setSat_p  "Return saturation properties from p" 
        extends Modelica.Icons.Function;
        input AbsolutePressure p "pressure";
        output SaturationProperties sat "saturation property record";
        external "C" TwoPhaseMedium_setSat_p_C_impl(p, sat, mediumName, libraryName, substanceName) annotation(Include = "#include \"externalmedialib.h\"", Library = "ExternalMediaLib", IncludeDirectory = "modelica://ExternalMedia/Resources/Include", LibraryDirectory = "modelica://ExternalMedia/Resources/Library");
      end setSat_p;

      replaceable function setSat_p_state  "Return saturation properties from the state" 
        extends Modelica.Icons.Function;
        input ThermodynamicState state;
        output SaturationProperties sat "saturation property record";
      algorithm
        sat := setSat_p(state.p);
        annotation(Inline = true); 
      end setSat_p_state;

      redeclare replaceable function setSat_T  "Return saturation properties from p" 
        extends Modelica.Icons.Function;
        input Temperature T "temperature";
        output SaturationProperties sat "saturation property record";
        external "C" TwoPhaseMedium_setSat_T_C_impl(T, sat, mediumName, libraryName, substanceName) annotation(Include = "#include \"externalmedialib.h\"", Library = "ExternalMediaLib", IncludeDirectory = "modelica://ExternalMedia/Resources/Include", LibraryDirectory = "modelica://ExternalMedia/Resources/Library");
      end setSat_T;

      redeclare replaceable function extends saturationTemperature  
      algorithm
        T := saturationTemperature_sat(setSat_p(p));
        annotation(Inline = true); 
      end saturationTemperature;

      redeclare function extends saturationTemperature_sat   annotation(Inline = true); end saturationTemperature_sat;

      redeclare replaceable function extends saturationTemperature_derp  "Returns derivative of saturation temperature w.r.t.. pressureBeing this function inefficient, it is strongly recommended to use saturationTemperature_derp_sat
           and never use saturationTemperature_derp directly" 
        external "C" dTp = TwoPhaseMedium_saturationTemperature_derp_C_impl(p, mediumName, libraryName, substanceName) annotation(Include = "#include \"externalmedialib.h\"", Library = "ExternalMediaLib", IncludeDirectory = "modelica://ExternalMedia/Resources/Include", LibraryDirectory = "modelica://ExternalMedia/Resources/Library");
      end saturationTemperature_derp;

      redeclare replaceable function saturationTemperature_derp_sat  "Returns derivative of saturation temperature w.r.t.. pressure" 
        extends Modelica.Icons.Function;
        input SaturationProperties sat "saturation property record";
        output Real dTp "derivative of saturation temperature w.r.t. pressure";
      algorithm
        dTp := sat.dTp;
        annotation(Inline = true); 
      end saturationTemperature_derp_sat;

      redeclare replaceable function extends dBubbleDensity_dPressure  "Returns bubble point density derivative" 
      algorithm
        ddldp := sat.ddldp;
        annotation(Inline = true); 
      end dBubbleDensity_dPressure;

      redeclare replaceable function extends dDewDensity_dPressure  "Returns dew point density derivative" 
      algorithm
        ddvdp := sat.ddvdp;
        annotation(Inline = true); 
      end dDewDensity_dPressure;

      redeclare replaceable function extends dBubbleEnthalpy_dPressure  "Returns bubble point specific enthalpy derivative" 
      algorithm
        dhldp := sat.dhldp;
        annotation(Inline = true); 
      end dBubbleEnthalpy_dPressure;

      redeclare replaceable function extends dDewEnthalpy_dPressure  "Returns dew point specific enthalpy derivative" 
      algorithm
        dhvdp := sat.dhvdp;
        annotation(Inline = true); 
      end dDewEnthalpy_dPressure;

      redeclare replaceable function extends bubbleDensity  "Returns bubble point density" 
      algorithm
        dl := sat.dl;
        annotation(Inline = true); 
      end bubbleDensity;

      redeclare replaceable function extends dewDensity  "Returns dew point density" 
      algorithm
        dv := sat.dv;
        annotation(Inline = true); 
      end dewDensity;

      redeclare replaceable function extends bubbleEnthalpy  "Returns bubble point specific enthalpy" 
      algorithm
        hl := sat.hl;
        annotation(Inline = true); 
      end bubbleEnthalpy;

      redeclare replaceable function extends dewEnthalpy  "Returns dew point specific enthalpy" 
      algorithm
        hv := sat.hv;
        annotation(Inline = true); 
      end dewEnthalpy;

      redeclare replaceable function extends saturationPressure  
      algorithm
        p := saturationPressure_sat(setSat_T(T));
        annotation(Inline = false, LateInline = true, derivative = saturationPressure_der); 
      end saturationPressure;

      function saturationPressure_der  "Return saturation pressure time derivative" 
        extends Modelica.Icons.Function;
        input Temperature T "temperature";
        input Real T_der "Temperature derivative";
        output Real p_der "saturation pressure derivative";
      algorithm
        p_der := T_der / saturationTemperature_derp_sat(setSat_T(T));
        annotation(Inline = true); 
      end saturationPressure_der;

      redeclare function extends saturationPressure_sat   annotation(Inline = true); end saturationPressure_sat;

      redeclare replaceable function isentropicEnthalpy  
        input AbsolutePressure p_downstream "downstream pressure";
        input ThermodynamicState refState "reference state for entropy";
        output SpecificEnthalpy h_is "Isentropic enthalpy";
      protected
        SpecificEntropy s_ideal;
        ThermodynamicState state_ideal;
      algorithm
        s_ideal := specificEntropy(refState);
        state_ideal := setState_psX(p_downstream, s_ideal);
        h_is := specificEnthalpy(state_ideal);
      end isentropicEnthalpy;
    end HeliumMedium;
  end Media;
end ExternalMedia;

package ModelicaServices  "ModelicaServices (OpenModelica implementation) - Models and functions used in the Modelica Standard Library requiring a tool specific implementation" 
  extends Modelica.Icons.Package;

  package Machine  
    extends Modelica.Icons.Package;
    final constant Real eps = 1.e-15 "Biggest number such that 1.0 + eps = 1.0";
    final constant Real small = 1.e-60 "Smallest number such that small and -small are representable on the machine";
    final constant Real inf = 1.e+60 "Biggest Real number such that inf and -inf are representable on the machine";
    final constant Integer Integer_inf = OpenModelica.Internal.Architecture.integerMax() "Biggest Integer number such that Integer_inf and -Integer_inf are representable on the machine";
  end Machine;
  annotation(Protection(access = Access.hide), version = "3.2.2", versionBuild = 0, versionDate = "2016-01-15", dateModified = "2016-01-15 08:44:41Z"); 
end ModelicaServices;

package Modelica  "Modelica Standard Library - Version 3.2.2" 
  extends Modelica.Icons.Package;

  package Blocks  "Library of basic input/output control blocks (continuous, discrete, logical, table blocks)" 
    extends Modelica.Icons.Package;

    package Continuous  "Library of continuous control blocks with internal states" 
      extends Modelica.Icons.Package;

      block Filter  "Continuous low pass, high pass, band pass or band stop IIR-filter of type CriticalDamping, Bessel, Butterworth or ChebyshevI" 
        extends Modelica.Blocks.Interfaces.SISO;
        parameter Modelica.Blocks.Types.AnalogFilter analogFilter = Modelica.Blocks.Types.AnalogFilter.CriticalDamping "Analog filter characteristics (CriticalDamping/Bessel/Butterworth/ChebyshevI)";
        parameter Modelica.Blocks.Types.FilterType filterType = Modelica.Blocks.Types.FilterType.LowPass "Type of filter (LowPass/HighPass/BandPass/BandStop)";
        parameter Integer order(min = 1) = 2 "Order of filter";
        parameter Modelica.SIunits.Frequency f_cut "Cut-off frequency";
        parameter Real gain = 1.0 "Gain (= amplitude of frequency response at zero frequency)";
        parameter Real A_ripple(unit = "dB") = 0.5 "Pass band ripple for Chebyshev filter (otherwise not used); > 0 required";
        parameter Modelica.SIunits.Frequency f_min = 0 "Band of band pass/stop filter is f_min (A=-3db*gain) .. f_cut (A=-3db*gain)";
        parameter Boolean normalized = true "= true, if amplitude at f_cut = -3db, otherwise unmodified filter";
        parameter Modelica.Blocks.Types.Init init = Modelica.Blocks.Types.Init.SteadyState "Type of initialization (no init/steady state/initial state/initial output)" annotation(Evaluate = true);
        final parameter Integer nx = if filterType == Modelica.Blocks.Types.FilterType.LowPass or filterType == Modelica.Blocks.Types.FilterType.HighPass then order else 2 * order;
        parameter Real[nx] x_start = zeros(nx) "Initial or guess values of states";
        parameter Real y_start = 0 "Initial value of output";
        parameter Real u_nominal = 1.0 "Nominal value of input (used for scaling the states)";
        Modelica.Blocks.Interfaces.RealOutput[nx] x "Filter states";
      protected
        parameter Integer ncr = if analogFilter == Modelica.Blocks.Types.AnalogFilter.CriticalDamping then order else mod(order, 2);
        parameter Integer nc0 = if analogFilter == Modelica.Blocks.Types.AnalogFilter.CriticalDamping then 0 else integer(order / 2);
        parameter Integer na = if filterType == Modelica.Blocks.Types.FilterType.BandPass or filterType == Modelica.Blocks.Types.FilterType.BandStop then order else if analogFilter == Modelica.Blocks.Types.AnalogFilter.CriticalDamping then 0 else integer(order / 2);
        parameter Integer nr = if filterType == Modelica.Blocks.Types.FilterType.BandPass or filterType == Modelica.Blocks.Types.FilterType.BandStop then 0 else if analogFilter == Modelica.Blocks.Types.AnalogFilter.CriticalDamping then order else mod(order, 2);
        parameter Real[ncr] cr(each fixed = false);
        parameter Real[nc0] c0(each fixed = false);
        parameter Real[nc0] c1(each fixed = false);
        parameter Real[nr] r(each fixed = false);
        parameter Real[na] a(each fixed = false);
        parameter Real[na] b(each fixed = false);
        parameter Real[na] ku(each fixed = false);
        parameter Real[if filterType == Modelica.Blocks.Types.FilterType.LowPass then 0 else na] k1(each fixed = false);
        parameter Real[if filterType == Modelica.Blocks.Types.FilterType.LowPass then 0 else na] k2(each fixed = false);
        Real[na + nr + 1] uu;
      initial equation
        if analogFilter == Modelica.Blocks.Types.AnalogFilter.CriticalDamping then
          cr = Internal.Filter.base.CriticalDamping(order, normalized);
        elseif analogFilter == Modelica.Blocks.Types.AnalogFilter.Bessel then
          (cr, c0, c1) = Internal.Filter.base.Bessel(order, normalized);
        elseif analogFilter == Modelica.Blocks.Types.AnalogFilter.Butterworth then
          (cr, c0, c1) = Internal.Filter.base.Butterworth(order, normalized);
        elseif analogFilter == Modelica.Blocks.Types.AnalogFilter.ChebyshevI then
          (cr, c0, c1) = Internal.Filter.base.ChebyshevI(order, A_ripple, normalized);
        end if;
        if filterType == Modelica.Blocks.Types.FilterType.LowPass then
          (r, a, b, ku) = Internal.Filter.roots.lowPass(cr, c0, c1, f_cut);
        elseif filterType == Modelica.Blocks.Types.FilterType.HighPass then
          (r, a, b, ku, k1, k2) = Internal.Filter.roots.highPass(cr, c0, c1, f_cut);
        elseif filterType == Modelica.Blocks.Types.FilterType.BandPass then
          (a, b, ku, k1, k2) = Internal.Filter.roots.bandPass(cr, c0, c1, f_min, f_cut);
        elseif filterType == Modelica.Blocks.Types.FilterType.BandStop then
          (a, b, ku, k1, k2) = Internal.Filter.roots.bandStop(cr, c0, c1, f_min, f_cut);
        end if;
        if init == Modelica.Blocks.Types.Init.InitialState then
          x = x_start;
        elseif init == Modelica.Blocks.Types.Init.SteadyState then
          der(x) = zeros(nx);
        elseif init == Modelica.Blocks.Types.Init.InitialOutput then
          y = y_start;
          if nx > 1 then
            der(x[1:nx - 1]) = zeros(nx - 1);
          end if;
        end if;
      equation
        assert(u_nominal > 0, "u_nominal > 0 required");
        assert(filterType == Modelica.Blocks.Types.FilterType.LowPass or filterType == Modelica.Blocks.Types.FilterType.HighPass or f_min > 0, "f_min > 0 required for band pass and band stop filter");
        assert(A_ripple > 0, "A_ripple > 0 required");
        assert(f_cut > 0, "f_cut > 0 required");
        uu[1] = u / u_nominal;
        for i in 1:nr loop
          der(x[i]) = r[i] * (x[i] - uu[i]);
        end for;
        for i in 1:na loop
          der(x[nr + 2 * i - 1]) = a[i] * x[nr + 2 * i - 1] - b[i] * x[nr + 2 * i] + ku[i] * uu[nr + i];
          der(x[nr + 2 * i]) = b[i] * x[nr + 2 * i - 1] + a[i] * x[nr + 2 * i];
        end for;
        if filterType == Modelica.Blocks.Types.FilterType.LowPass then
          for i in 1:nr loop
            uu[i + 1] = x[i];
          end for;
          for i in 1:na loop
            uu[nr + i + 1] = x[nr + 2 * i];
          end for;
        elseif filterType == Modelica.Blocks.Types.FilterType.HighPass then
          for i in 1:nr loop
            uu[i + 1] = (-x[i]) + uu[i];
          end for;
          for i in 1:na loop
            uu[nr + i + 1] = k1[i] * x[nr + 2 * i - 1] + k2[i] * x[nr + 2 * i] + uu[nr + i];
          end for;
        elseif filterType == Modelica.Blocks.Types.FilterType.BandPass then
          for i in 1:na loop
            uu[nr + i + 1] = k1[i] * x[nr + 2 * i - 1] + k2[i] * x[nr + 2 * i];
          end for;
        elseif filterType == Modelica.Blocks.Types.FilterType.BandStop then
          for i in 1:na loop
            uu[nr + i + 1] = k1[i] * x[nr + 2 * i - 1] + k2[i] * x[nr + 2 * i] + uu[nr + i];
          end for;
        else
          assert(false, "filterType (= " + String(filterType) + ") is unknown");
          uu = zeros(na + nr + 1);
        end if;
        y = gain * u_nominal * uu[nr + na + 1];
      end Filter;

      package Internal  "Internal utility functions and blocks that should not be directly utilized by the user" 
        extends Modelica.Icons.InternalPackage;

        package Filter  "Internal utility functions for filters that should not be directly used" 
          extends Modelica.Icons.InternalPackage;

          package base  "Prototype low pass filters with cut-off frequency of 1 rad/s (other filters are derived by transformation from these base filters)" 
            extends Modelica.Icons.InternalPackage;

            function CriticalDamping  "Return base filter coefficients of CriticalDamping filter (= low pass filter with w_cut = 1 rad/s)" 
              extends Modelica.Icons.Function;
              input Integer order(min = 1) "Order of filter";
              input Boolean normalized = true "= true, if amplitude at f_cut = -3db, otherwise unmodified filter";
              output Real[order] cr "Coefficients of real poles";
            protected
              Real alpha = 1.0 "Frequency correction factor";
              Real alpha2 "= alpha*alpha";
              Real[order] den1 "[p] coefficients of denominator first order polynomials (a*p + 1)";
              Real[0, 2] den2 "[p^2, p] coefficients of denominator second order polynomials (b*p^2 + a*p + 1)";
              Real[0] c0 "Coefficients of s^0 term if conjugate complex pole";
              Real[0] c1 "Coefficients of s^1 term if conjugate complex pole";
            algorithm
              if normalized then
                alpha := sqrt(10 ^ (3 / 10 / order) - 1);
              else
                alpha := 1.0;
              end if;
              for i in 1:order loop
                den1[i] := alpha;
              end for;
              (cr, c0, c1) := Modelica.Blocks.Continuous.Internal.Filter.Utilities.toHighestPowerOne(den1, den2);
            end CriticalDamping;

            function Bessel  "Return base filter coefficients of Bessel filter (= low pass filter with w_cut = 1 rad/s)" 
              extends Modelica.Icons.Function;
              input Integer order(min = 1) "Order of filter";
              input Boolean normalized = true "= true, if amplitude at f_cut = -3db, otherwise unmodified filter";
              output Real[mod(order, 2)] cr "Coefficient of real pole";
              output Real[integer(order / 2)] c0 "Coefficients of s^0 term if conjugate complex pole";
              output Real[integer(order / 2)] c1 "Coefficients of s^1 term if conjugate complex pole";
            protected
              Real alpha = 1.0 "Frequency correction factor";
              Real alpha2 "= alpha*alpha";
              Real[size(cr, 1)] den1 "[p] coefficients of denominator first order polynomials (a*p + 1)";
              Real[size(c0, 1), 2] den2 "[p^2, p] coefficients of denominator second order polynomials (b*p^2 + a*p + 1)";
            algorithm
              (den1, den2, alpha) := Modelica.Blocks.Continuous.Internal.Filter.Utilities.BesselBaseCoefficients(order);
              if not normalized then
                alpha2 := alpha * alpha;
                for i in 1:size(c0, 1) loop
                  den2[i, 1] := den2[i, 1] * alpha2;
                  den2[i, 2] := den2[i, 2] * alpha;
                end for;
                if size(cr, 1) == 1 then
                  den1[1] := den1[1] * alpha;
                else
                end if;
              else
              end if;
              (cr, c0, c1) := Modelica.Blocks.Continuous.Internal.Filter.Utilities.toHighestPowerOne(den1, den2);
            end Bessel;

            function Butterworth  "Return base filter coefficients of Butterworth filter (= low pass filter with w_cut = 1 rad/s)" 
              extends Modelica.Icons.Function;
              input Integer order(min = 1) "Order of filter";
              input Boolean normalized = true "= true, if amplitude at f_cut = -3db, otherwise unmodified filter";
              output Real[mod(order, 2)] cr "Coefficient of real pole";
              output Real[integer(order / 2)] c0 "Coefficients of s^0 term if conjugate complex pole";
              output Real[integer(order / 2)] c1 "Coefficients of s^1 term if conjugate complex pole";
            protected
              Real alpha = 1.0 "Frequency correction factor";
              Real alpha2 "= alpha*alpha";
              Real[size(cr, 1)] den1 "[p] coefficients of denominator first order polynomials (a*p + 1)";
              Real[size(c0, 1), 2] den2 "[p^2, p] coefficients of denominator second order polynomials (b*p^2 + a*p + 1)";
            algorithm
              for i in 1:size(c0, 1) loop
                den2[i, 1] := 1.0;
                den2[i, 2] := -2 * Modelica.Math.cos(.Modelica.Constants.pi * (0.5 + (i - 0.5) / order));
              end for;
              if size(cr, 1) == 1 then
                den1[1] := 1.0;
              else
              end if;
              (cr, c0, c1) := Modelica.Blocks.Continuous.Internal.Filter.Utilities.toHighestPowerOne(den1, den2);
            end Butterworth;

            function ChebyshevI  "Return base filter coefficients of Chebyshev I filter (= low pass filter with w_cut = 1 rad/s)" 
              extends Modelica.Icons.Function;
              input Integer order(min = 1) "Order of filter";
              input Real A_ripple = 0.5 "Pass band ripple in [dB]";
              input Boolean normalized = true "= true, if amplitude at f_cut = -3db, otherwise unmodified filter";
              output Real[mod(order, 2)] cr "Coefficient of real pole";
              output Real[integer(order / 2)] c0 "Coefficients of s^0 term if conjugate complex pole";
              output Real[integer(order / 2)] c1 "Coefficients of s^1 term if conjugate complex pole";
            protected
              Real epsilon;
              Real fac;
              Real alpha = 1.0 "Frequency correction factor";
              Real alpha2 "= alpha*alpha";
              Real[size(cr, 1)] den1 "[p] coefficients of denominator first order polynomials (a*p + 1)";
              Real[size(c0, 1), 2] den2 "[p^2, p] coefficients of denominator second order polynomials (b*p^2 + a*p + 1)";
            algorithm
              epsilon := sqrt(10 ^ (A_ripple / 10) - 1);
              fac := .Modelica.Math.asinh(1 / epsilon) / order;
              den1 := fill(1 / sinh(fac), size(den1, 1));
              if size(cr, 1) == 0 then
                for i in 1:size(c0, 1) loop
                  den2[i, 1] := 1 / (cosh(fac) ^ 2 - cos((2 * i - 1) * .Modelica.Constants.pi / (2 * order)) ^ 2);
                  den2[i, 2] := 2 * den2[i, 1] * sinh(fac) * cos((2 * i - 1) * .Modelica.Constants.pi / (2 * order));
                end for;
              else
                for i in 1:size(c0, 1) loop
                  den2[i, 1] := 1 / (cosh(fac) ^ 2 - cos(i * .Modelica.Constants.pi / order) ^ 2);
                  den2[i, 2] := 2 * den2[i, 1] * sinh(fac) * cos(i * .Modelica.Constants.pi / order);
                end for;
              end if;
              if normalized then
                alpha := Modelica.Blocks.Continuous.Internal.Filter.Utilities.normalizationFactor(den1, den2);
                alpha2 := alpha * alpha;
                for i in 1:size(c0, 1) loop
                  den2[i, 1] := den2[i, 1] * alpha2;
                  den2[i, 2] := den2[i, 2] * alpha;
                end for;
                den1 := den1 * alpha;
              else
              end if;
              (cr, c0, c1) := Modelica.Blocks.Continuous.Internal.Filter.Utilities.toHighestPowerOne(den1, den2);
            end ChebyshevI;
          end base;

          package coefficients  "Filter coefficients" 
            extends Modelica.Icons.InternalPackage;

            function lowPass  "Return low pass filter coefficients at given cut-off frequency" 
              extends Modelica.Icons.Function;
              input Real[:] cr_in "Coefficients of real poles";
              input Real[:] c0_in "Coefficients of s^0 term if conjugate complex pole";
              input Real[size(c0_in, 1)] c1_in "Coefficients of s^1 term if conjugate complex pole";
              input Modelica.SIunits.Frequency f_cut "Cut-off frequency";
              output Real[size(cr_in, 1)] cr "Coefficient of real pole";
              output Real[size(c0_in, 1)] c0 "Coefficients of s^0 term if conjugate complex pole";
              output Real[size(c0_in, 1)] c1 "Coefficients of s^1 term if conjugate complex pole";
            protected
              Modelica.SIunits.AngularVelocity w_cut = 2 * .Modelica.Constants.pi * f_cut "Cut-off angular frequency";
              Real w_cut2 = w_cut * w_cut;
            algorithm
              assert(f_cut > 0, "Cut-off frequency f_cut must be positive");
              cr := w_cut * cr_in;
              c1 := w_cut * c1_in;
              c0 := w_cut2 * c0_in;
            end lowPass;

            function highPass  "Return high pass filter coefficients at given cut-off frequency" 
              extends Modelica.Icons.Function;
              input Real[:] cr_in "Coefficients of real poles";
              input Real[:] c0_in "Coefficients of s^0 term if conjugate complex pole";
              input Real[size(c0_in, 1)] c1_in "Coefficients of s^1 term if conjugate complex pole";
              input Modelica.SIunits.Frequency f_cut "Cut-off frequency";
              output Real[size(cr_in, 1)] cr "Coefficient of real pole";
              output Real[size(c0_in, 1)] c0 "Coefficients of s^0 term if conjugate complex pole";
              output Real[size(c0_in, 1)] c1 "Coefficients of s^1 term if conjugate complex pole";
            protected
              Modelica.SIunits.AngularVelocity w_cut = 2 * .Modelica.Constants.pi * f_cut "Cut-off angular frequency";
              Real w_cut2 = w_cut * w_cut;
            algorithm
              assert(f_cut > 0, "Cut-off frequency f_cut must be positive");
              for i in 1:size(cr_in, 1) loop
                cr[i] := w_cut / cr_in[i];
              end for;
              for i in 1:size(c0_in, 1) loop
                c0[i] := w_cut2 / c0_in[i];
                c1[i] := w_cut * c1_in[i] / c0_in[i];
              end for;
            end highPass;

            function bandPass  "Return band pass filter coefficients at given cut-off frequency" 
              extends Modelica.Icons.Function;
              input Real[:] cr_in "Coefficients of real poles";
              input Real[:] c0_in "Coefficients of s^0 term if conjugate complex pole";
              input Real[size(c0_in, 1)] c1_in "Coefficients of s^1 term if conjugate complex pole";
              input Modelica.SIunits.Frequency f_min "Band of band pass filter is f_min (A=-3db) .. f_max (A=-3db)";
              input Modelica.SIunits.Frequency f_max "Upper band frequency";
              output Real[0] cr "Coefficient of real pole";
              output Real[size(cr_in, 1) + 2 * size(c0_in, 1)] c0 "Coefficients of s^0 term if conjugate complex pole";
              output Real[size(cr_in, 1) + 2 * size(c0_in, 1)] c1 "Coefficients of s^1 term if conjugate complex pole";
              output Real cn "Numerator coefficient of the PT2 terms";
            protected
              Modelica.SIunits.Frequency f0 = sqrt(f_min * f_max);
              Modelica.SIunits.AngularVelocity w_cut = 2 * .Modelica.Constants.pi * f0 "Cut-off angular frequency";
              Real w_band = (f_max - f_min) / f0;
              Real w_cut2 = w_cut * w_cut;
              Real c;
              Real alpha;
              Integer j;
            algorithm
              assert(f_min > 0 and f_min < f_max, "Band frequencies f_min and f_max are wrong");
              for i in 1:size(cr_in, 1) loop
                c1[i] := w_cut * cr_in[i] * w_band;
                c0[i] := w_cut2;
              end for;
              for i in 1:size(c1_in, 1) loop
                alpha := Modelica.Blocks.Continuous.Internal.Filter.Utilities.bandPassAlpha(c1_in[i], c0_in[i], w_band);
                c := c1_in[i] * w_band / (alpha + 1 / alpha);
                j := size(cr_in, 1) + 2 * i - 1;
                c1[j] := w_cut * c / alpha;
                c1[j + 1] := w_cut * c * alpha;
                c0[j] := w_cut2 / alpha ^ 2;
                c0[j + 1] := w_cut2 * alpha ^ 2;
              end for;
              cn := w_band * w_cut;
            end bandPass;

            function bandStop  "Return band stop filter coefficients at given cut-off frequency" 
              extends Modelica.Icons.Function;
              input Real[:] cr_in "Coefficients of real poles";
              input Real[:] c0_in "Coefficients of s^0 term if conjugate complex pole";
              input Real[size(c0_in, 1)] c1_in "Coefficients of s^1 term if conjugate complex pole";
              input Modelica.SIunits.Frequency f_min "Band of band stop filter is f_min (A=-3db) .. f_max (A=-3db)";
              input Modelica.SIunits.Frequency f_max "Upper band frequency";
              output Real[0] cr "Coefficient of real pole";
              output Real[size(cr_in, 1) + 2 * size(c0_in, 1)] c0 "Coefficients of s^0 term if conjugate complex pole";
              output Real[size(cr_in, 1) + 2 * size(c0_in, 1)] c1 "Coefficients of s^1 term if conjugate complex pole";
            protected
              Modelica.SIunits.Frequency f0 = sqrt(f_min * f_max);
              Modelica.SIunits.AngularVelocity w_cut = 2 * .Modelica.Constants.pi * f0 "Cut-off angular frequency";
              Real w_band = (f_max - f_min) / f0;
              Real w_cut2 = w_cut * w_cut;
              Real c;
              Real ww;
              Real alpha;
              Integer j;
            algorithm
              assert(f_min > 0 and f_min < f_max, "Band frequencies f_min and f_max are wrong");
              for i in 1:size(cr_in, 1) loop
                c1[i] := w_cut * w_band / cr_in[i];
                c0[i] := w_cut2;
              end for;
              for i in 1:size(c1_in, 1) loop
                ww := w_band / c0_in[i];
                alpha := Modelica.Blocks.Continuous.Internal.Filter.Utilities.bandPassAlpha(c1_in[i], c0_in[i], ww);
                c := c1_in[i] * ww / (alpha + 1 / alpha);
                j := size(cr_in, 1) + 2 * i - 1;
                c1[j] := w_cut * c / alpha;
                c1[j + 1] := w_cut * c * alpha;
                c0[j] := w_cut2 / alpha ^ 2;
                c0[j + 1] := w_cut2 * alpha ^ 2;
              end for;
            end bandStop;
          end coefficients;

          package roots  "Filter roots and gain as needed for block implementations" 
            extends Modelica.Icons.InternalPackage;

            function lowPass  "Return low pass filter roots as needed for block for given cut-off frequency" 
              extends Modelica.Icons.Function;
              input Real[:] cr_in "Coefficients of real poles of base filter";
              input Real[:] c0_in "Coefficients of s^0 term of base filter if conjugate complex pole";
              input Real[size(c0_in, 1)] c1_in "Coefficients of s^1 term of base filter if conjugate complex pole";
              input Modelica.SIunits.Frequency f_cut "Cut-off frequency";
              output Real[size(cr_in, 1)] r "Real eigenvalues";
              output Real[size(c0_in, 1)] a "Real parts of complex conjugate eigenvalues";
              output Real[size(c0_in, 1)] b "Imaginary parts of complex conjugate eigenvalues";
              output Real[size(c0_in, 1)] ku "Input gain";
            protected
              Real[size(c0_in, 1)] c0;
              Real[size(c0_in, 1)] c1;
              Real[size(cr_in, 1)] cr;
            algorithm
              (cr, c0, c1) := coefficients.lowPass(cr_in, c0_in, c1_in, f_cut);
              for i in 1:size(cr_in, 1) loop
                r[i] := -cr[i];
              end for;
              for i in 1:size(c0_in, 1) loop
                a[i] := -c1[i] / 2;
                b[i] := sqrt(c0[i] - a[i] * a[i]);
                ku[i] := c0[i] / b[i];
              end for;
            end lowPass;

            function highPass  "Return high pass filter roots as needed for block for given cut-off frequency" 
              extends Modelica.Icons.Function;
              input Real[:] cr_in "Coefficients of real poles of base filter";
              input Real[:] c0_in "Coefficients of s^0 term of base filter if conjugate complex pole";
              input Real[size(c0_in, 1)] c1_in "Coefficients of s^1 term of base filter if conjugate complex pole";
              input Modelica.SIunits.Frequency f_cut "Cut-off frequency";
              output Real[size(cr_in, 1)] r "Real eigenvalues";
              output Real[size(c0_in, 1)] a "Real parts of complex conjugate eigenvalues";
              output Real[size(c0_in, 1)] b "Imaginary parts of complex conjugate eigenvalues";
              output Real[size(c0_in, 1)] ku "Gains of input terms";
              output Real[size(c0_in, 1)] k1 "Gains of y = k1*x1 + k2*x + u";
              output Real[size(c0_in, 1)] k2 "Gains of y = k1*x1 + k2*x + u";
            protected
              Real[size(c0_in, 1)] c0;
              Real[size(c0_in, 1)] c1;
              Real[size(cr_in, 1)] cr;
              Real ba2;
            algorithm
              (cr, c0, c1) := coefficients.highPass(cr_in, c0_in, c1_in, f_cut);
              for i in 1:size(cr_in, 1) loop
                r[i] := -cr[i];
              end for;
              for i in 1:size(c0_in, 1) loop
                a[i] := -c1[i] / 2;
                b[i] := sqrt(c0[i] - a[i] * a[i]);
                ku[i] := c0[i] / b[i];
                k1[i] := 2 * a[i] / ku[i];
                ba2 := (b[i] / a[i]) ^ 2;
                k2[i] := (1 - ba2) / (1 + ba2);
              end for;
            end highPass;

            function bandPass  "Return band pass filter roots as needed for block for given cut-off frequency" 
              extends Modelica.Icons.Function;
              input Real[:] cr_in "Coefficients of real poles of base filter";
              input Real[:] c0_in "Coefficients of s^0 term of base filter if conjugate complex pole";
              input Real[size(c0_in, 1)] c1_in "Coefficients of s^1 term of base filter if conjugate complex pole";
              input Modelica.SIunits.Frequency f_min "Band of band pass filter is f_min (A=-3db) .. f_max (A=-3db)";
              input Modelica.SIunits.Frequency f_max "Upper band frequency";
              output Real[size(cr_in, 1) + 2 * size(c0_in, 1)] a "Real parts of complex conjugate eigenvalues";
              output Real[size(cr_in, 1) + 2 * size(c0_in, 1)] b "Imaginary parts of complex conjugate eigenvalues";
              output Real[size(cr_in, 1) + 2 * size(c0_in, 1)] ku "Gains of input terms";
              output Real[size(cr_in, 1) + 2 * size(c0_in, 1)] k1 "Gains of y = k1*x1 + k2*x";
              output Real[size(cr_in, 1) + 2 * size(c0_in, 1)] k2 "Gains of y = k1*x1 + k2*x";
            protected
              Real[0] cr;
              Real[size(a, 1)] c0;
              Real[size(a, 1)] c1;
              Real cn;
              Real bb;
            algorithm
              (cr, c0, c1, cn) := coefficients.bandPass(cr_in, c0_in, c1_in, f_min, f_max);
              for i in 1:size(a, 1) loop
                a[i] := -c1[i] / 2;
                bb := c0[i] - a[i] * a[i];
                assert(bb >= 0, "\nNot possible to use band pass filter, since transformation results in\n" + "system that does not have conjugate complex poles.\n" + "Try to use another analog filter for the band pass.\n");
                b[i] := sqrt(bb);
                ku[i] := c0[i] / b[i];
                k1[i] := cn / ku[i];
                k2[i] := cn * a[i] / (b[i] * ku[i]);
              end for;
            end bandPass;

            function bandStop  "Return band stop filter roots as needed for block for given cut-off frequency" 
              extends Modelica.Icons.Function;
              input Real[:] cr_in "Coefficients of real poles of base filter";
              input Real[:] c0_in "Coefficients of s^0 term of base filter if conjugate complex pole";
              input Real[size(c0_in, 1)] c1_in "Coefficients of s^1 term of base filter if conjugate complex pole";
              input Modelica.SIunits.Frequency f_min "Band of band stop filter is f_min (A=-3db) .. f_max (A=-3db)";
              input Modelica.SIunits.Frequency f_max "Upper band frequency";
              output Real[size(cr_in, 1) + 2 * size(c0_in, 1)] a "Real parts of complex conjugate eigenvalues";
              output Real[size(cr_in, 1) + 2 * size(c0_in, 1)] b "Imaginary parts of complex conjugate eigenvalues";
              output Real[size(cr_in, 1) + 2 * size(c0_in, 1)] ku "Gains of input terms";
              output Real[size(cr_in, 1) + 2 * size(c0_in, 1)] k1 "Gains of y = k1*x1 + k2*x";
              output Real[size(cr_in, 1) + 2 * size(c0_in, 1)] k2 "Gains of y = k1*x1 + k2*x";
            protected
              Real[0] cr;
              Real[size(a, 1)] c0;
              Real[size(a, 1)] c1;
              Real cn;
              Real bb;
            algorithm
              (cr, c0, c1) := coefficients.bandStop(cr_in, c0_in, c1_in, f_min, f_max);
              for i in 1:size(a, 1) loop
                a[i] := -c1[i] / 2;
                bb := c0[i] - a[i] * a[i];
                assert(bb >= 0, "\nNot possible to use band stop filter, since transformation results in\n" + "system that does not have conjugate complex poles.\n" + "Try to use another analog filter for the band stop filter.\n");
                b[i] := sqrt(bb);
                ku[i] := c0[i] / b[i];
                k1[i] := 2 * a[i] / ku[i];
                k2[i] := (c0[i] + a[i] ^ 2 - b[i] ^ 2) / (b[i] * ku[i]);
              end for;
            end bandStop;
          end roots;

          package Utilities  "Utility functions for filter computations" 
            extends Modelica.Icons.InternalPackage;

            function BesselBaseCoefficients  "Return coefficients of normalized low pass Bessel filter (= gain at cut-off frequency 1 rad/s is decreased 3dB)" 
              extends Modelica.Icons.Function;
              input Integer order "Order of filter in the range 1..41";
              output Real[mod(order, 2)] c1 "[p] coefficients of Bessel denominator polynomials (a*p + 1)";
              output Real[integer(order / 2), 2] c2 "[p^2, p] coefficients of Bessel denominator polynomials (b2*p^2 + b1*p + 1)";
              output Real alpha "Normalization factor";
            algorithm
              if order == 1 then
                alpha := 1.002377293007601;
                c1[1] := 0.9976283451109835;
              elseif order == 2 then
                alpha := 0.7356641785819585;
                c2[1, 1] := 0.6159132201783791;
                c2[1, 2] := 1.359315879600889;
              elseif order == 3 then
                alpha := 0.5704770156982642;
                c1[1] := 0.7548574865985343;
                c2[1, 1] := 0.4756958028827457;
                c2[1, 2] := 0.9980615136104388;
              elseif order == 4 then
                alpha := 0.4737978580281427;
                c2[1, 1] := 0.4873729247240677;
                c2[1, 2] := 1.337564170455762;
                c2[2, 1] := 0.3877724315741958;
                c2[2, 2] := 0.7730405590839861;
              elseif order == 5 then
                alpha := 0.4126226974763408;
                c1[1] := 0.6645723262620757;
                c2[1, 1] := 0.4115231900614016;
                c2[1, 2] := 1.138349926728708;
                c2[2, 1] := 0.3234938702877912;
                c2[2, 2] := 0.6205992985771313;
              elseif order == 6 then
                alpha := 0.3705098000736233;
                c2[1, 1] := 0.3874508649098960;
                c2[1, 2] := 1.219740879520741;
                c2[2, 1] := 0.3493298843155746;
                c2[2, 2] := 0.9670265529381365;
                c2[3, 1] := 0.2747419229514599;
                c2[3, 2] := 0.5122165075105700;
              elseif order == 7 then
                alpha := 0.3393452623586350;
                c1[1] := 0.5927147125821412;
                c2[1, 1] := 0.3383379423919174;
                c2[1, 2] := 1.092630816438030;
                c2[2, 1] := 0.3001025788696046;
                c2[2, 2] := 0.8289928256598656;
                c2[3, 1] := 0.2372867471539579;
                c2[3, 2] := 0.4325128641920154;
              elseif order == 8 then
                alpha := 0.3150267393795002;
                c2[1, 1] := 0.3151115975207653;
                c2[1, 2] := 1.109403015460190;
                c2[2, 1] := 0.2969344839572762;
                c2[2, 2] := 0.9737455812222699;
                c2[3, 1] := 0.2612545921889538;
                c2[3, 2] := 0.7190394712068573;
                c2[4, 1] := 0.2080523342974281;
                c2[4, 2] := 0.3721456473047434;
              elseif order == 9 then
                alpha := 0.2953310177184124;
                c1[1] := 0.5377196679501422;
                c2[1, 1] := 0.2824689124281034;
                c2[1, 2] := 1.022646191567475;
                c2[2, 1] := 0.2626824161383468;
                c2[2, 2] := 0.8695626454762596;
                c2[3, 1] := 0.2302781917677917;
                c2[3, 2] := 0.6309047553448520;
                c2[4, 1] := 0.1847991729757028;
                c2[4, 2] := 0.3251978031287202;
              elseif order == 10 then
                alpha := 0.2789426890619463;
                c2[1, 1] := 0.2640769908255582;
                c2[1, 2] := 1.019788132875305;
                c2[2, 1] := 0.2540802639216947;
                c2[2, 2] := 0.9377020417760623;
                c2[3, 1] := 0.2343577229427963;
                c2[3, 2] := 0.7802229808216112;
                c2[4, 1] := 0.2052193139338624;
                c2[4, 2] := 0.5594176813008133;
                c2[5, 1] := 0.1659546953748916;
                c2[5, 2] := 0.2878349616233292;
              elseif order == 11 then
                alpha := 0.2650227766037203;
                c1[1] := 0.4950265498954191;
                c2[1, 1] := 0.2411858478546218;
                c2[1, 2] := 0.9567800996387417;
                c2[2, 1] := 0.2296849355380925;
                c2[2, 2] := 0.8592523717113126;
                c2[3, 1] := 0.2107851705677406;
                c2[3, 2] := 0.7040216048898129;
                c2[4, 1] := 0.1846461385164021;
                c2[4, 2] := 0.5006729207276717;
                c2[5, 1] := 0.1504217970817433;
                c2[5, 2] := 0.2575070491320295;
              elseif order == 12 then
                alpha := 0.2530051198547209;
                c2[1, 1] := 0.2268294941204543;
                c2[1, 2] := 0.9473116570034053;
                c2[2, 1] := 0.2207657387793729;
                c2[2, 2] := 0.8933728946287606;
                c2[3, 1] := 0.2087600700376653;
                c2[3, 2] := 0.7886236252756229;
                c2[4, 1] := 0.1909959101492760;
                c2[4, 2] := 0.6389263649257017;
                c2[5, 1] := 0.1675208146048472;
                c2[5, 2] := 0.4517847275162215;
                c2[6, 1] := 0.1374257286372761;
                c2[6, 2] := 0.2324699157474680;
              elseif order == 13 then
                alpha := 0.2424910397561007;
                c1[1] := 0.4608848369928040;
                c2[1, 1] := 0.2099813050274780;
                c2[1, 2] := 0.8992478823790660;
                c2[2, 1] := 0.2027250423101359;
                c2[2, 2] := 0.8328117484224146;
                c2[3, 1] := 0.1907635894058731;
                c2[3, 2] := 0.7257379204691213;
                c2[4, 1] := 0.1742280397887686;
                c2[4, 2] := 0.5830640944868014;
                c2[5, 1] := 0.1530858190490478;
                c2[5, 2] := 0.4106192089751885;
                c2[6, 1] := 0.1264090712880446;
                c2[6, 2] := 0.2114980230156001;
              elseif order == 14 then
                alpha := 0.2331902368695848;
                c2[1, 1] := 0.1986162311411235;
                c2[1, 2] := 0.8876961808055535;
                c2[2, 1] := 0.1946683341271615;
                c2[2, 2] := 0.8500754229171967;
                c2[3, 1] := 0.1868331332895056;
                c2[3, 2] := 0.7764629313723603;
                c2[4, 1] := 0.1752118757862992;
                c2[4, 2] := 0.6699720402924552;
                c2[5, 1] := 0.1598906457908402;
                c2[5, 2] := 0.5348446712848934;
                c2[6, 1] := 0.1407810153019944;
                c2[6, 2] := 0.3755841316563539;
                c2[7, 1] := 0.1169627966707339;
                c2[7, 2] := 0.1937088226304455;
              elseif order == 15 then
                alpha := 0.2248854870552422;
                c1[1] := 0.4328492272335646;
                c2[1, 1] := 0.1857292591004588;
                c2[1, 2] := 0.8496337061962563;
                c2[2, 1] := 0.1808644178280136;
                c2[2, 2] := 0.8020517898136011;
                c2[3, 1] := 0.1728264404199081;
                c2[3, 2] := 0.7247449729331105;
                c2[4, 1] := 0.1616970125901954;
                c2[4, 2] := 0.6205369315943097;
                c2[5, 1] := 0.1475257264578426;
                c2[5, 2] := 0.4929612162355906;
                c2[6, 1] := 0.1301861023357119;
                c2[6, 2] := 0.3454770708040735;
                c2[7, 1] := 0.1087810777120188;
                c2[7, 2] := 0.1784526655428406;
              elseif order == 16 then
                alpha := 0.2174105053474761;
                c2[1, 1] := 0.1765637967473151;
                c2[1, 2] := 0.8377453068635511;
                c2[2, 1] := 0.1738525357503125;
                c2[2, 2] := 0.8102988957433199;
                c2[3, 1] := 0.1684627004613343;
                c2[3, 2] := 0.7563265923413258;
                c2[4, 1] := 0.1604519074815815;
                c2[4, 2] := 0.6776082294687619;
                c2[5, 1] := 0.1498828607802206;
                c2[5, 2] := 0.5766417034027680;
                c2[6, 1] := 0.1367764717792823;
                c2[6, 2] := 0.4563528264410489;
                c2[7, 1] := 0.1209810465419295;
                c2[7, 2] := 0.3193782657322374;
                c2[8, 1] := 0.1016312648007554;
                c2[8, 2] := 0.1652419227369036;
              elseif order == 17 then
                alpha := 0.2106355148193306;
                c1[1] := 0.4093223608497299;
                c2[1, 1] := 0.1664014345826274;
                c2[1, 2] := 0.8067173752345952;
                c2[2, 1] := 0.1629839591538256;
                c2[2, 2] := 0.7712924931447541;
                c2[3, 1] := 0.1573277802512491;
                c2[3, 2] := 0.7134213666303411;
                c2[4, 1] := 0.1494828185148637;
                c2[4, 2] := 0.6347841731714884;
                c2[5, 1] := 0.1394948812681826;
                c2[5, 2] := 0.5375594414619047;
                c2[6, 1] := 0.1273627583380806;
                c2[6, 2] := 0.4241608926375478;
                c2[7, 1] := 0.1129187258461290;
                c2[7, 2] := 0.2965752009703245;
                c2[8, 1] := 0.9533357359908857e-1;
                c2[8, 2] := 0.1537041700889585;
              elseif order == 18 then
                alpha := 0.2044575288651841;
                c2[1, 1] := 0.1588768571976356;
                c2[1, 2] := 0.7951914263212913;
                c2[2, 1] := 0.1569357024981854;
                c2[2, 2] := 0.7744529690772538;
                c2[3, 1] := 0.1530722206358810;
                c2[3, 2] := 0.7335304425992080;
                c2[4, 1] := 0.1473206710524167;
                c2[4, 2] := 0.6735038935387268;
                c2[5, 1] := 0.1397225420331520;
                c2[5, 2] := 0.5959151542621590;
                c2[6, 1] := 0.1303092459809849;
                c2[6, 2] := 0.5026483447894845;
                c2[7, 1] := 0.1190627367060072;
                c2[7, 2] := 0.3956893824587150;
                c2[8, 1] := 0.1058058030798994;
                c2[8, 2] := 0.2765091830730650;
                c2[9, 1] := 0.8974708108800873e-1;
                c2[9, 2] := 0.1435505288284833;
              elseif order == 19 then
                alpha := 0.1987936248083529;
                c1[1] := 0.3892259966869526;
                c2[1, 1] := 0.1506640012172225;
                c2[1, 2] := 0.7693121733774260;
                c2[2, 1] := 0.1481728062796673;
                c2[2, 2] := 0.7421133586741549;
                c2[3, 1] := 0.1440444668388838;
                c2[3, 2] := 0.6975075386214800;
                c2[4, 1] := 0.1383101628540374;
                c2[4, 2] := 0.6365464378910025;
                c2[5, 1] := 0.1310032283190998;
                c2[5, 2] := 0.5606211948462122;
                c2[6, 1] := 0.1221431166405330;
                c2[6, 2] := 0.4713530424221445;
                c2[7, 1] := 0.1116991161103884;
                c2[7, 2] := 0.3703717538617073;
                c2[8, 1] := 0.9948917351196349e-1;
                c2[8, 2] := 0.2587371155559744;
                c2[9, 1] := 0.8475989238107367e-1;
                c2[9, 2] := 0.1345537894555993;
              elseif order == 20 then
                alpha := 0.1935761760416219;
                c2[1, 1] := 0.1443871348337404;
                c2[1, 2] := 0.7584165598446141;
                c2[2, 1] := 0.1429501891353184;
                c2[2, 2] := 0.7423000962318863;
                c2[3, 1] := 0.1400877384920004;
                c2[3, 2] := 0.7104185332215555;
                c2[4, 1] := 0.1358210369491446;
                c2[4, 2] := 0.6634599783272630;
                c2[5, 1] := 0.1301773703034290;
                c2[5, 2] := 0.6024175491895959;
                c2[6, 1] := 0.1231826501439148;
                c2[6, 2] := 0.5285332736326852;
                c2[7, 1] := 0.1148465498575254;
                c2[7, 2] := 0.4431977385498628;
                c2[8, 1] := 0.1051289462376788;
                c2[8, 2] := 0.3477444062821162;
                c2[9, 1] := 0.9384622797485121e-1;
                c2[9, 2] := 0.2429038300327729;
                c2[10, 1] := 0.8028211612831444e-1;
                c2[10, 2] := 0.1265329974009533;
              elseif order == 21 then
                alpha := 0.1887494014766075;
                c1[1] := 0.3718070668941645;
                c2[1, 1] := 0.1376151928386445;
                c2[1, 2] := 0.7364290859445481;
                c2[2, 1] := 0.1357438914390695;
                c2[2, 2] := 0.7150167318935022;
                c2[3, 1] := 0.1326398453462415;
                c2[3, 2] := 0.6798001808470175;
                c2[4, 1] := 0.1283231214897678;
                c2[4, 2] := 0.6314663440439816;
                c2[5, 1] := 0.1228169159777534;
                c2[5, 2] := 0.5709353626166905;
                c2[6, 1] := 0.1161406100773184;
                c2[6, 2] := 0.4993087153571335;
                c2[7, 1] := 0.1082959649233524;
                c2[7, 2] := 0.4177766148584385;
                c2[8, 1] := 0.9923596957485723e-1;
                c2[8, 2] := 0.3274257287232124;
                c2[9, 1] := 0.8877776108724853e-1;
                c2[9, 2] := 0.2287218166767916;
                c2[10, 1] := 0.7624076527736326e-1;
                c2[10, 2] := 0.1193423971506988;
              elseif order == 22 then
                alpha := 0.1842668221199706;
                c2[1, 1] := 0.1323053462701543;
                c2[1, 2] := 0.7262446126765204;
                c2[2, 1] := 0.1312121721769772;
                c2[2, 2] := 0.7134286088450949;
                c2[3, 1] := 0.1290330911166814;
                c2[3, 2] := 0.6880287870435514;
                c2[4, 1] := 0.1257817990372067;
                c2[4, 2] := 0.6505015800059301;
                c2[5, 1] := 0.1214765261983008;
                c2[5, 2] := 0.6015107185211451;
                c2[6, 1] := 0.1161365140967959;
                c2[6, 2] := 0.5418983553698413;
                c2[7, 1] := 0.1097755171533100;
                c2[7, 2] := 0.4726370779831614;
                c2[8, 1] := 0.1023889478519956;
                c2[8, 2] := 0.3947439506537486;
                c2[9, 1] := 0.9392485861253800e-1;
                c2[9, 2] := 0.3090996703083202;
                c2[10, 1] := 0.8420273775456455e-1;
                c2[10, 2] := 0.2159561978556017;
                c2[11, 1] := 0.7257600023938262e-1;
                c2[11, 2] := 0.1128633732721116;
              elseif order == 23 then
                alpha := 0.1800893554453722;
                c1[1] := 0.3565232673929280;
                c2[1, 1] := 0.1266275171652706;
                c2[1, 2] := 0.7072778066734162;
                c2[2, 1] := 0.1251865227648538;
                c2[2, 2] := 0.6900676345785905;
                c2[3, 1] := 0.1227944815236645;
                c2[3, 2] := 0.6617011100576023;
                c2[4, 1] := 0.1194647013077667;
                c2[4, 2] := 0.6226432315773119;
                c2[5, 1] := 0.1152132989252356;
                c2[5, 2] := 0.5735222810625359;
                c2[6, 1] := 0.1100558598478487;
                c2[6, 2] := 0.5151027978024605;
                c2[7, 1] := 0.1040013558214886;
                c2[7, 2] := 0.4482410942032739;
                c2[8, 1] := 0.9704014176512626e-1;
                c2[8, 2] := 0.3738049984631116;
                c2[9, 1] := 0.8911683905758054e-1;
                c2[9, 2] := 0.2925028692588410;
                c2[10, 1] := 0.8005438265072295e-1;
                c2[10, 2] := 0.2044134600278901;
                c2[11, 1] := 0.6923832296800832e-1;
                c2[11, 2] := 0.1069984887283394;
              elseif order == 24 then
                alpha := 0.1761838665838427;
                c2[1, 1] := 0.1220804912720132;
                c2[1, 2] := 0.6978026874156063;
                c2[2, 1] := 0.1212296762358897;
                c2[2, 2] := 0.6874139794926736;
                c2[3, 1] := 0.1195328372961027;
                c2[3, 2] := 0.6667954259551859;
                c2[4, 1] := 0.1169990987333593;
                c2[4, 2] := 0.6362602049901176;
                c2[5, 1] := 0.1136409040480130;
                c2[5, 2] := 0.5962662188435553;
                c2[6, 1] := 0.1094722001757955;
                c2[6, 2] := 0.5474001634109253;
                c2[7, 1] := 0.1045052832229087;
                c2[7, 2] := 0.4903523180249535;
                c2[8, 1] := 0.9874509806025907e-1;
                c2[8, 2] := 0.4258751523524645;
                c2[9, 1] := 0.9217799943472177e-1;
                c2[9, 2] := 0.3547079765396403;
                c2[10, 1] := 0.8474633796250476e-1;
                c2[10, 2] := 0.2774145482392767;
                c2[11, 1] := 0.7627722381240495e-1;
                c2[11, 2] := 0.1939329108084139;
                c2[12, 1] := 0.6618645465422745e-1;
                c2[12, 2] := 0.1016670147947242;
              elseif order == 25 then
                alpha := 0.1725220521949266;
                c1[1] := 0.3429735385896000;
                c2[1, 1] := 0.1172525033170618;
                c2[1, 2] := 0.6812327932576614;
                c2[2, 1] := 0.1161194585333535;
                c2[2, 2] := 0.6671566071153211;
                c2[3, 1] := 0.1142375145794466;
                c2[3, 2] := 0.6439167855053158;
                c2[4, 1] := 0.1116157454252308;
                c2[4, 2] := 0.6118378416180135;
                c2[5, 1] := 0.1082654809459177;
                c2[5, 2] := 0.5713609763370088;
                c2[6, 1] := 0.1041985674230918;
                c2[6, 2] := 0.5230289949762722;
                c2[7, 1] := 0.9942439308123559e-1;
                c2[7, 2] := 0.4674627926041906;
                c2[8, 1] := 0.9394453593830893e-1;
                c2[8, 2] := 0.4053226688298811;
                c2[9, 1] := 0.8774221237222533e-1;
                c2[9, 2] := 0.3372372276379071;
                c2[10, 1] := 0.8075839512216483e-1;
                c2[10, 2] := 0.2636485508005428;
                c2[11, 1] := 0.7282483286646764e-1;
                c2[11, 2] := 0.1843801345273085;
                c2[12, 1] := 0.6338571166846652e-1;
                c2[12, 2] := 0.9680153764737715e-1;
              elseif order == 26 then
                alpha := 0.1690795702796737;
                c2[1, 1] := 0.1133168695796030;
                c2[1, 2] := 0.6724297955493932;
                c2[2, 1] := 0.1126417845769961;
                c2[2, 2] := 0.6638709519790540;
                c2[3, 1] := 0.1112948749545606;
                c2[3, 2] := 0.6468652038763624;
                c2[4, 1] := 0.1092823986944244;
                c2[4, 2] := 0.6216337070799265;
                c2[5, 1] := 0.1066130386697976;
                c2[5, 2] := 0.5885011413992190;
                c2[6, 1] := 0.1032969057045413;
                c2[6, 2] := 0.5478864278297548;
                c2[7, 1] := 0.9934388184210715e-1;
                c2[7, 2] := 0.5002885306054287;
                c2[8, 1] := 0.9476081523436283e-1;
                c2[8, 2] := 0.4462644847551711;
                c2[9, 1] := 0.8954648464575577e-1;
                c2[9, 2] := 0.3863930785049522;
                c2[10, 1] := 0.8368166847159917e-1;
                c2[10, 2] := 0.3212074592527143;
                c2[11, 1] := 0.7710664731701103e-1;
                c2[11, 2] := 0.2510470347119383;
                c2[12, 1] := 0.6965807988411425e-1;
                c2[12, 2] := 0.1756419294111342;
                c2[13, 1] := 0.6080674930548766e-1;
                c2[13, 2] := 0.9234535279274277e-1;
              elseif order == 27 then
                alpha := 0.1658353543067995;
                c1[1] := 0.3308543720638957;
                c2[1, 1] := 0.1091618578712746;
                c2[1, 2] := 0.6577977071169651;
                c2[2, 1] := 0.1082549561495043;
                c2[2, 2] := 0.6461121666520275;
                c2[3, 1] := 0.1067479247890451;
                c2[3, 2] := 0.6267937760991321;
                c2[4, 1] := 0.1046471079537577;
                c2[4, 2] := 0.6000750116745808;
                c2[5, 1] := 0.1019605976654259;
                c2[5, 2] := 0.5662734183049320;
                c2[6, 1] := 0.9869726954433709e-1;
                c2[6, 2] := 0.5257827234948534;
                c2[7, 1] := 0.9486520934132483e-1;
                c2[7, 2] := 0.4790595019077763;
                c2[8, 1] := 0.9046906518775348e-1;
                c2[8, 2] := 0.4266025862147336;
                c2[9, 1] := 0.8550529998276152e-1;
                c2[9, 2] := 0.3689188223512328;
                c2[10, 1] := 0.7995282239306020e-1;
                c2[10, 2] := 0.3064589322702932;
                c2[11, 1] := 0.7375174596252882e-1;
                c2[11, 2] := 0.2394754504667310;
                c2[12, 1] := 0.6674377263329041e-1;
                c2[12, 2] := 0.1676223546666024;
                c2[13, 1] := 0.5842458027529246e-1;
                c2[13, 2] := 0.8825044329219431e-1;
              elseif order == 28 then
                alpha := 0.1627710671942929;
                c2[1, 1] := 0.1057232656113488;
                c2[1, 2] := 0.6496161226860832;
                c2[2, 1] := 0.1051786825724864;
                c2[2, 2] := 0.6424661279909941;
                c2[3, 1] := 0.1040917964935006;
                c2[3, 2] := 0.6282470268918791;
                c2[4, 1] := 0.1024670101953951;
                c2[4, 2] := 0.6071189030701136;
                c2[5, 1] := 0.1003105109519892;
                c2[5, 2] := 0.5793175191747016;
                c2[6, 1] := 0.9762969425430802e-1;
                c2[6, 2] := 0.5451486608855443;
                c2[7, 1] := 0.9443223803058400e-1;
                c2[7, 2] := 0.5049796971628137;
                c2[8, 1] := 0.9072460982036488e-1;
                c2[8, 2] := 0.4592270546572523;
                c2[9, 1] := 0.8650956423253280e-1;
                c2[9, 2] := 0.4083368605952977;
                c2[10, 1] := 0.8178165740374893e-1;
                c2[10, 2] := 0.3527525188880655;
                c2[11, 1] := 0.7651838885868020e-1;
                c2[11, 2] := 0.2928534570013572;
                c2[12, 1] := 0.7066010532447490e-1;
                c2[12, 2] := 0.2288185204390681;
                c2[13, 1] := 0.6405358596145789e-1;
                c2[13, 2] := 0.1602396172588190;
                c2[14, 1] := 0.5621780070227172e-1;
                c2[14, 2] := 0.8447589564915071e-1;
              elseif order == 29 then
                alpha := 0.1598706626277596;
                c1[1] := 0.3199314513011623;
                c2[1, 1] := 0.1021101032532951;
                c2[1, 2] := 0.6365758882240111;
                c2[2, 1] := 0.1013729819392774;
                c2[2, 2] := 0.6267495975736321;
                c2[3, 1] := 0.1001476175660628;
                c2[3, 2] := 0.6104876178266819;
                c2[4, 1] := 0.9843854640428316e-1;
                c2[4, 2] := 0.5879603139195113;
                c2[5, 1] := 0.9625164534591696e-1;
                c2[5, 2] := 0.5594012291050210;
                c2[6, 1] := 0.9359356960417668e-1;
                c2[6, 2] := 0.5251016150410664;
                c2[7, 1] := 0.9047086748649986e-1;
                c2[7, 2] := 0.4854024475590397;
                c2[8, 1] := 0.8688856407189167e-1;
                c2[8, 2] := 0.4406826457109709;
                c2[9, 1] := 0.8284779224069856e-1;
                c2[9, 2] := 0.3913408089298914;
                c2[10, 1] := 0.7834154620997181e-1;
                c2[10, 2] := 0.3377643999400627;
                c2[11, 1] := 0.7334628941928766e-1;
                c2[11, 2] := 0.2802710651919946;
                c2[12, 1] := 0.6780290487362146e-1;
                c2[12, 2] := 0.2189770008083379;
                c2[13, 1] := 0.6156321231528423e-1;
                c2[13, 2] := 0.1534235999306070;
                c2[14, 1] := 0.5416797446761512e-1;
                c2[14, 2] := 0.8098664736760292e-1;
              elseif order == 30 then
                alpha := 0.1571200296252450;
                c2[1, 1] := 0.9908074847842124e-1;
                c2[1, 2] := 0.6289618807831557;
                c2[2, 1] := 0.9863509708328196e-1;
                c2[2, 2] := 0.6229164525571278;
                c2[3, 1] := 0.9774542692037148e-1;
                c2[3, 2] := 0.6108853364240036;
                c2[4, 1] := 0.9641490581986484e-1;
                c2[4, 2] := 0.5929869253412513;
                c2[5, 1] := 0.9464802912225441e-1;
                c2[5, 2] := 0.5693960175547550;
                c2[6, 1] := 0.9245027206218041e-1;
                c2[6, 2] := 0.5403402396359503;
                c2[7, 1] := 0.8982754584112941e-1;
                c2[7, 2] := 0.5060948065875106;
                c2[8, 1] := 0.8678535291732599e-1;
                c2[8, 2] := 0.4669749797983789;
                c2[9, 1] := 0.8332744242052199e-1;
                c2[9, 2] := 0.4233249626334694;
                c2[10, 1] := 0.7945356393775309e-1;
                c2[10, 2] := 0.3755006094498054;
                c2[11, 1] := 0.7515543969833788e-1;
                c2[11, 2] := 0.3238400339292700;
                c2[12, 1] := 0.7040879901685638e-1;
                c2[12, 2] := 0.2686072427439079;
                c2[13, 1] := 0.6515528854010540e-1;
                c2[13, 2] := 0.2098650589782619;
                c2[14, 1] := 0.5925168237177876e-1;
                c2[14, 2] := 0.1471138832654873;
                c2[15, 1] := 0.5225913954211672e-1;
                c2[15, 2] := 0.7775248839507864e-1;
              elseif order == 31 then
                alpha := 0.1545067022920929;
                c1[1] := 0.3100206996451866;
                c2[1, 1] := 0.9591020358831668e-1;
                c2[1, 2] := 0.6172474793293396;
                c2[2, 1] := 0.9530301275601203e-1;
                c2[2, 2] := 0.6088916323460413;
                c2[3, 1] := 0.9429332655402368e-1;
                c2[3, 2] := 0.5950511595503025;
                c2[4, 1] := 0.9288445429894548e-1;
                c2[4, 2] := 0.5758534119053522;
                c2[5, 1] := 0.9108073420087422e-1;
                c2[5, 2] := 0.5514734636081183;
                c2[6, 1] := 0.8888719137536870e-1;
                c2[6, 2] := 0.5221306199481831;
                c2[7, 1] := 0.8630901440239650e-1;
                c2[7, 2] := 0.4880834248148061;
                c2[8, 1] := 0.8335074993373294e-1;
                c2[8, 2] := 0.4496225358496770;
                c2[9, 1] := 0.8001502494376102e-1;
                c2[9, 2] := 0.4070602306679052;
                c2[10, 1] := 0.7630041338037624e-1;
                c2[10, 2] := 0.3607139804818122;
                c2[11, 1] := 0.7219760885744920e-1;
                c2[11, 2] := 0.3108783301229550;
                c2[12, 1] := 0.6768185077153345e-1;
                c2[12, 2] := 0.2577706252514497;
                c2[13, 1] := 0.6269571766328638e-1;
                c2[13, 2] := 0.2014081375889921;
                c2[14, 1] := 0.5710081766945065e-1;
                c2[14, 2] := 0.1412581515841926;
                c2[15, 1] := 0.5047740914807019e-1;
                c2[15, 2] := 0.7474725873250158e-1;
              elseif order == 32 then
                alpha := 0.1520196210848210;
                c2[1, 1] := 0.9322163554339406e-1;
                c2[1, 2] := 0.6101488690506050;
                c2[2, 1] := 0.9285233997694042e-1;
                c2[2, 2] := 0.6049832320721264;
                c2[3, 1] := 0.9211494244473163e-1;
                c2[3, 2] := 0.5946969295569034;
                c2[4, 1] := 0.9101176786042449e-1;
                c2[4, 2] := 0.5793791854364477;
                c2[5, 1] := 0.8954614071360517e-1;
                c2[5, 2] := 0.5591619969234026;
                c2[6, 1] := 0.8772216763680164e-1;
                c2[6, 2] := 0.5342177994699602;
                c2[7, 1] := 0.8554440426912734e-1;
                c2[7, 2] := 0.5047560942986598;
                c2[8, 1] := 0.8301735302045588e-1;
                c2[8, 2] := 0.4710187048140929;
                c2[9, 1] := 0.8014469519188161e-1;
                c2[9, 2] := 0.4332730387207936;
                c2[10, 1] := 0.7692807528893225e-1;
                c2[10, 2] := 0.3918021436411035;
                c2[11, 1] := 0.7336507157284898e-1;
                c2[11, 2] := 0.3468890521471250;
                c2[12, 1] := 0.6944555312763458e-1;
                c2[12, 2] := 0.2987898029050460;
                c2[13, 1] := 0.6514446669420571e-1;
                c2[13, 2] := 0.2476810747407199;
                c2[14, 1] := 0.6040544477732702e-1;
                c2[14, 2] := 0.1935412053397663;
                c2[15, 1] := 0.5509478650672775e-1;
                c2[15, 2] := 0.1358108994174911;
                c2[16, 1] := 0.4881064725720192e-1;
                c2[16, 2] := 0.7194819894416505e-1;
              elseif order == 33 then
                alpha := 0.1496489351138032;
                c1[1] := 0.3009752799176432;
                c2[1, 1] := 0.9041725460994505e-1;
                c2[1, 2] := 0.5995521047364046;
                c2[2, 1] := 0.8991117804113002e-1;
                c2[2, 2] := 0.5923764112099496;
                c2[3, 1] := 0.8906941547422532e-1;
                c2[3, 2] := 0.5804822013853129;
                c2[4, 1] := 0.8789442491445575e-1;
                c2[4, 2] := 0.5639663528946501;
                c2[5, 1] := 0.8638945831033775e-1;
                c2[5, 2] := 0.5429623519607796;
                c2[6, 1] := 0.8455834602616358e-1;
                c2[6, 2] := 0.5176379938389326;
                c2[7, 1] := 0.8240517431382334e-1;
                c2[7, 2] := 0.4881921474066189;
                c2[8, 1] := 0.7993380417355076e-1;
                c2[8, 2] := 0.4548502528082586;
                c2[9, 1] := 0.7714713890732801e-1;
                c2[9, 2] := 0.4178579388038483;
                c2[10, 1] := 0.7404596598181127e-1;
                c2[10, 2] := 0.3774715722484659;
                c2[11, 1] := 0.7062702339160462e-1;
                c2[11, 2] := 0.3339432938810453;
                c2[12, 1] := 0.6687952672391507e-1;
                c2[12, 2] := 0.2874950693388235;
                c2[13, 1] := 0.6277828912909767e-1;
                c2[13, 2] := 0.2382680702894708;
                c2[14, 1] := 0.5826808305383988e-1;
                c2[14, 2] := 0.1862073169968455;
                c2[15, 1] := 0.5321974125363517e-1;
                c2[15, 2] := 0.1307323751236313;
                c2[16, 1] := 0.4724820282032780e-1;
                c2[16, 2] := 0.6933542082177094e-1;
              elseif order == 34 then
                alpha := 0.1473858373968463;
                c2[1, 1] := 0.8801537152275983e-1;
                c2[1, 2] := 0.5929204288972172;
                c2[2, 1] := 0.8770594341007476e-1;
                c2[2, 2] := 0.5884653382247518;
                c2[3, 1] := 0.8708797598072095e-1;
                c2[3, 2] := 0.5795895850253119;
                c2[4, 1] := 0.8616320590689187e-1;
                c2[4, 2] := 0.5663615383647170;
                c2[5, 1] := 0.8493413175570858e-1;
                c2[5, 2] := 0.5488825092350877;
                c2[6, 1] := 0.8340387368687513e-1;
                c2[6, 2] := 0.5272851839324592;
                c2[7, 1] := 0.8157596213131521e-1;
                c2[7, 2] := 0.5017313864372913;
                c2[8, 1] := 0.7945402670834270e-1;
                c2[8, 2] := 0.4724089864574216;
                c2[9, 1] := 0.7704133559556429e-1;
                c2[9, 2] := 0.4395276256463053;
                c2[10, 1] := 0.7434009635219704e-1;
                c2[10, 2] := 0.4033126590648964;
                c2[11, 1] := 0.7135035113853376e-1;
                c2[11, 2] := 0.3639961488919042;
                c2[12, 1] := 0.6806813160738834e-1;
                c2[12, 2] := 0.3218025212900124;
                c2[13, 1] := 0.6448214312000864e-1;
                c2[13, 2] := 0.2769235521088158;
                c2[14, 1] := 0.6056719318430530e-1;
                c2[14, 2] := 0.2294693573271038;
                c2[15, 1] := 0.5626925196925040e-1;
                c2[15, 2] := 0.1793564218840015;
                c2[16, 1] := 0.5146352031547277e-1;
                c2[16, 2] := 0.1259877129326412;
                c2[17, 1] := 0.4578069074410591e-1;
                c2[17, 2] := 0.6689147319568768e-1;
              elseif order == 35 then
                alpha := 0.1452224267615486;
                c1[1] := 0.2926764667564367;
                c2[1, 1] := 0.8551731299267280e-1;
                c2[1, 2] := 0.5832758214629523;
                c2[2, 1] := 0.8509109732853060e-1;
                c2[2, 2] := 0.5770596582643844;
                c2[3, 1] := 0.8438201446671953e-1;
                c2[3, 2] := 0.5667497616665494;
                c2[4, 1] := 0.8339191981579831e-1;
                c2[4, 2] := 0.5524209816238369;
                c2[5, 1] := 0.8212328610083385e-1;
                c2[5, 2] := 0.5341766459916322;
                c2[6, 1] := 0.8057906332198853e-1;
                c2[6, 2] := 0.5121470053512750;
                c2[7, 1] := 0.7876247299954955e-1;
                c2[7, 2] := 0.4864870722254752;
                c2[8, 1] := 0.7667670879950268e-1;
                c2[8, 2] := 0.4573736721705665;
                c2[9, 1] := 0.7432449556218945e-1;
                c2[9, 2] := 0.4250013835198991;
                c2[10, 1] := 0.7170742126011575e-1;
                c2[10, 2] := 0.3895767735915445;
                c2[11, 1] := 0.6882488171701314e-1;
                c2[11, 2] := 0.3513097926737368;
                c2[12, 1] := 0.6567231746957568e-1;
                c2[12, 2] := 0.3103999917596611;
                c2[13, 1] := 0.6223804362223595e-1;
                c2[13, 2] := 0.2670123611280899;
                c2[14, 1] := 0.5849696460782910e-1;
                c2[14, 2] := 0.2212298104867592;
                c2[15, 1] := 0.5439628409499822e-1;
                c2[15, 2] := 0.1729443731341637;
                c2[16, 1] := 0.4981540179136920e-1;
                c2[16, 2] := 0.1215462157134930;
                c2[17, 1] := 0.4439981033536435e-1;
                c2[17, 2] := 0.6460098363520967e-1;
              elseif order == 36 then
                alpha := 0.1431515914458580;
                c2[1, 1] := 0.8335881847130301e-1;
                c2[1, 2] := 0.5770670512160201;
                c2[2, 1] := 0.8309698922852212e-1;
                c2[2, 2] := 0.5731929100172432;
                c2[3, 1] := 0.8257400347039723e-1;
                c2[3, 2] := 0.5654713811993058;
                c2[4, 1] := 0.8179117911600136e-1;
                c2[4, 2] := 0.5539556343603020;
                c2[5, 1] := 0.8075042173126963e-1;
                c2[5, 2] := 0.5387245649546684;
                c2[6, 1] := 0.7945413151258206e-1;
                c2[6, 2] := 0.5198817177723069;
                c2[7, 1] := 0.7790506514288866e-1;
                c2[7, 2] := 0.4975537629595409;
                c2[8, 1] := 0.7610613635339480e-1;
                c2[8, 2] := 0.4718884193866789;
                c2[9, 1] := 0.7406012816626425e-1;
                c2[9, 2] := 0.4430516443136726;
                c2[10, 1] := 0.7176927060205631e-1;
                c2[10, 2] := 0.4112237708115829;
                c2[11, 1] := 0.6923460172504251e-1;
                c2[11, 2] := 0.3765940116389730;
                c2[12, 1] := 0.6645495833489556e-1;
                c2[12, 2] := 0.3393522147815403;
                c2[13, 1] := 0.6342528888937094e-1;
                c2[13, 2] := 0.2996755899575573;
                c2[14, 1] := 0.6013361864949449e-1;
                c2[14, 2] := 0.2577053294053830;
                c2[15, 1] := 0.5655503081322404e-1;
                c2[15, 2] := 0.2135004731531631;
                c2[16, 1] := 0.5263798119559069e-1;
                c2[16, 2] := 0.1669320999865636;
                c2[17, 1] := 0.4826589873626196e-1;
                c2[17, 2] := 0.1173807590715484;
                c2[18, 1] := 0.4309819397289806e-1;
                c2[18, 2] := 0.6245036108880222e-1;
              elseif order == 37 then
                alpha := 0.1411669104782917;
                c1[1] := 0.2850271036215707;
                c2[1, 1] := 0.8111958235023328e-1;
                c2[1, 2] := 0.5682412610563970;
                c2[2, 1] := 0.8075727567979578e-1;
                c2[2, 2] := 0.5628142923227016;
                c2[3, 1] := 0.8015440554413301e-1;
                c2[3, 2] := 0.5538087696879930;
                c2[4, 1] := 0.7931239302677386e-1;
                c2[4, 2] := 0.5412833323304460;
                c2[5, 1] := 0.7823314328639347e-1;
                c2[5, 2] := 0.5253190555393968;
                c2[6, 1] := 0.7691895211595101e-1;
                c2[6, 2] := 0.5060183741977191;
                c2[7, 1] := 0.7537237072011853e-1;
                c2[7, 2] := 0.4835036020049034;
                c2[8, 1] := 0.7359601294804538e-1;
                c2[8, 2] := 0.4579149413954837;
                c2[9, 1] := 0.7159227884849299e-1;
                c2[9, 2] := 0.4294078049978829;
                c2[10, 1] := 0.6936295002846032e-1;
                c2[10, 2] := 0.3981491350382047;
                c2[11, 1] := 0.6690857785828917e-1;
                c2[11, 2] := 0.3643121502867948;
                c2[12, 1] := 0.6422751692085542e-1;
                c2[12, 2] := 0.3280684291406284;
                c2[13, 1] := 0.6131430866206096e-1;
                c2[13, 2] := 0.2895750997170303;
                c2[14, 1] := 0.5815677249570920e-1;
                c2[14, 2] := 0.2489521814805720;
                c2[15, 1] := 0.5473023527947980e-1;
                c2[15, 2] := 0.2062377435955363;
                c2[16, 1] := 0.5098441033167034e-1;
                c2[16, 2] := 0.1612849131645336;
                c2[17, 1] := 0.4680658811093562e-1;
                c2[17, 2] := 0.1134672937045305;
                c2[18, 1] := 0.4186928031694695e-1;
                c2[18, 2] := 0.6042754777339966e-1;
              elseif order == 38 then
                alpha := 0.1392625697140030;
                c2[1, 1] := 0.7916943373658329e-1;
                c2[1, 2] := 0.5624158631591745;
                c2[2, 1] := 0.7894592250257840e-1;
                c2[2, 2] := 0.5590219398777304;
                c2[3, 1] := 0.7849941672384930e-1;
                c2[3, 2] := 0.5522551628416841;
                c2[4, 1] := 0.7783093084875645e-1;
                c2[4, 2] := 0.5421574325808380;
                c2[5, 1] := 0.7694193770482690e-1;
                c2[5, 2] := 0.5287909941093643;
                c2[6, 1] := 0.7583430534712885e-1;
                c2[6, 2] := 0.5122376814029880;
                c2[7, 1] := 0.7451020436122948e-1;
                c2[7, 2] := 0.4925978555548549;
                c2[8, 1] := 0.7297197617673508e-1;
                c2[8, 2] := 0.4699889739625235;
                c2[9, 1] := 0.7122194706992953e-1;
                c2[9, 2] := 0.4445436860615774;
                c2[10, 1] := 0.6926216260386816e-1;
                c2[10, 2] := 0.4164072786327193;
                c2[11, 1] := 0.6709399961255503e-1;
                c2[11, 2] := 0.3857341621868851;
                c2[12, 1] := 0.6471757977022456e-1;
                c2[12, 2] := 0.3526828388476838;
                c2[13, 1] := 0.6213084287116965e-1;
                c2[13, 2] := 0.3174082831364342;
                c2[14, 1] := 0.5932799638550641e-1;
                c2[14, 2] := 0.2800495563550299;
                c2[15, 1] := 0.5629672408524944e-1;
                c2[15, 2] := 0.2407078154782509;
                c2[16, 1] := 0.5301264751544952e-1;
                c2[16, 2] := 0.1994026830553859;
                c2[17, 1] := 0.4942673259817896e-1;
                c2[17, 2] := 0.1559719194038917;
                c2[18, 1] := 0.4542996716979947e-1;
                c2[18, 2] := 0.1097844277878470;
                c2[19, 1] := 0.4070720755433961e-1;
                c2[19, 2] := 0.5852181110523043e-1;
              elseif order == 39 then
                alpha := 0.1374332900196804;
                c1[1] := 0.2779468246419593;
                c2[1, 1] := 0.7715084161825772e-1;
                c2[1, 2] := 0.5543001331300056;
                c2[2, 1] := 0.7684028301163326e-1;
                c2[2, 2] := 0.5495289890712267;
                c2[3, 1] := 0.7632343924866024e-1;
                c2[3, 2] := 0.5416083298429741;
                c2[4, 1] := 0.7560141319808483e-1;
                c2[4, 2] := 0.5305846713929198;
                c2[5, 1] := 0.7467569064745969e-1;
                c2[5, 2] := 0.5165224112570647;
                c2[6, 1] := 0.7354807648551346e-1;
                c2[6, 2] := 0.4995030679271456;
                c2[7, 1] := 0.7222060351121389e-1;
                c2[7, 2] := 0.4796242430956156;
                c2[8, 1] := 0.7069540462458585e-1;
                c2[8, 2] := 0.4569982440368368;
                c2[9, 1] := 0.6897453353492381e-1;
                c2[9, 2] := 0.4317502624832354;
                c2[10, 1] := 0.6705970959388781e-1;
                c2[10, 2] := 0.4040159353969854;
                c2[11, 1] := 0.6495194541066725e-1;
                c2[11, 2] := 0.3739379843169939;
                c2[12, 1] := 0.6265098412417610e-1;
                c2[12, 2] := 0.3416613843816217;
                c2[13, 1] := 0.6015440984955930e-1;
                c2[13, 2] := 0.3073260166338746;
                c2[14, 1] := 0.5745615876877304e-1;
                c2[14, 2] := 0.2710546723961181;
                c2[15, 1] := 0.5454383762391338e-1;
                c2[15, 2] := 0.2329316824061170;
                c2[16, 1] := 0.5139340231935751e-1;
                c2[16, 2] := 0.1929604256043231;
                c2[17, 1] := 0.4795705862458131e-1;
                c2[17, 2] := 0.1509655259246037;
                c2[18, 1] := 0.4412933231935506e-1;
                c2[18, 2] := 0.1063130748962878;
                c2[19, 1] := 0.3960672309405603e-1;
                c2[19, 2] := 0.5672356837211527e-1;
              elseif order == 40 then
                alpha := 0.1356742655825434;
                c2[1, 1] := 0.7538038374294594e-1;
                c2[1, 2] := 0.5488228264329617;
                c2[2, 1] := 0.7518806529402738e-1;
                c2[2, 2] := 0.5458297722483311;
                c2[3, 1] := 0.7480383050347119e-1;
                c2[3, 2] := 0.5398604576730540;
                c2[4, 1] := 0.7422847031965465e-1;
                c2[4, 2] := 0.5309482987446206;
                c2[5, 1] := 0.7346313704205006e-1;
                c2[5, 2] := 0.5191429845322307;
                c2[6, 1] := 0.7250930053201402e-1;
                c2[6, 2] := 0.5045099368431007;
                c2[7, 1] := 0.7136868456879621e-1;
                c2[7, 2] := 0.4871295553902607;
                c2[8, 1] := 0.7004317764946634e-1;
                c2[8, 2] := 0.4670962098860498;
                c2[9, 1] := 0.6853470921527828e-1;
                c2[9, 2] := 0.4445169164956202;
                c2[10, 1] := 0.6684507689945471e-1;
                c2[10, 2] := 0.4195095960479698;
                c2[11, 1] := 0.6497570123412630e-1;
                c2[11, 2] := 0.3922007419030645;
                c2[12, 1] := 0.6292726794917847e-1;
                c2[12, 2] := 0.3627221993494397;
                c2[13, 1] := 0.6069918741663154e-1;
                c2[13, 2] := 0.3312065181294388;
                c2[14, 1] := 0.5828873983769410e-1;
                c2[14, 2] := 0.2977798532686911;
                c2[15, 1] := 0.5568964389813015e-1;
                c2[15, 2] := 0.2625503293999835;
                c2[16, 1] := 0.5288947816690705e-1;
                c2[16, 2] := 0.2255872486520188;
                c2[17, 1] := 0.4986456327645859e-1;
                c2[17, 2] := 0.1868796731919594;
                c2[18, 1] := 0.4656832613054458e-1;
                c2[18, 2] := 0.1462410193532463;
                c2[19, 1] := 0.4289867647614935e-1;
                c2[19, 2] := 0.1030361558710747;
                c2[20, 1] := 0.3856310684054106e-1;
                c2[20, 2] := 0.5502423832293889e-1;
              elseif order == 41 then
                alpha := 0.1339811106984253;
                c1[1] := 0.2713685065531391;
                c2[1, 1] := 0.7355140275160984e-1;
                c2[1, 2] := 0.5413274778282860;
                c2[2, 1] := 0.7328319082267173e-1;
                c2[2, 2] := 0.5371064088294270;
                c2[3, 1] := 0.7283676160772547e-1;
                c2[3, 2] := 0.5300963437270770;
                c2[4, 1] := 0.7221298133014343e-1;
                c2[4, 2] := 0.5203345998371490;
                c2[5, 1] := 0.7141302173623395e-1;
                c2[5, 2] := 0.5078728971879841;
                c2[6, 1] := 0.7043831559982149e-1;
                c2[6, 2] := 0.4927768111819803;
                c2[7, 1] := 0.6929049381827268e-1;
                c2[7, 2] := 0.4751250308594139;
                c2[8, 1] := 0.6797129849758392e-1;
                c2[8, 2] := 0.4550083840638406;
                c2[9, 1] := 0.6648246325101609e-1;
                c2[9, 2] := 0.4325285673076087;
                c2[10, 1] := 0.6482554675958526e-1;
                c2[10, 2] := 0.4077964789091151;
                c2[11, 1] := 0.6300169683004558e-1;
                c2[11, 2] := 0.3809299858742483;
                c2[12, 1] := 0.6101130648543355e-1;
                c2[12, 2] := 0.3520508315700898;
                c2[13, 1] := 0.5885349417435808e-1;
                c2[13, 2] := 0.3212801560701271;
                c2[14, 1] := 0.5652528148656809e-1;
                c2[14, 2] := 0.2887316252774887;
                c2[15, 1] := 0.5402021575818373e-1;
                c2[15, 2] := 0.2545001287790888;
                c2[16, 1] := 0.5132588802608274e-1;
                c2[16, 2] := 0.2186415296842951;
                c2[17, 1] := 0.4841900639702602e-1;
                c2[17, 2] := 0.1811322622296060;
                c2[18, 1] := 0.4525419574485134e-1;
                c2[18, 2] := 0.1417762065404688;
                c2[19, 1] := 0.4173260173087802e-1;
                c2[19, 2] := 0.9993834530966510e-1;
                c2[20, 1] := 0.3757210572966463e-1;
                c2[20, 2] := 0.5341611499960143e-1;
              else
                .Modelica.Utilities.Streams.error("Input argument order (= " + String(order) + ") of Bessel filter is not in the range 1..41");
              end if;
            end BesselBaseCoefficients;

            function toHighestPowerOne  "Transform filter to form with highest power of s equal 1" 
              extends Modelica.Icons.Function;
              input Real[:] den1 "[s] coefficients of polynomials (den1[i]*s + 1)";
              input Real[:, 2] den2 "[s^2, s] coefficients of polynomials (den2[i,1]*s^2 + den2[i,2]*s + 1)";
              output Real[size(den1, 1)] cr "[s^0] coefficients of polynomials cr[i]*(s+1/cr[i])";
              output Real[size(den2, 1)] c0 "[s^0] coefficients of polynomials (s^2 + (den2[i,2]/den2[i,1])*s + (1/den2[i,1]))";
              output Real[size(den2, 1)] c1 "[s^1] coefficients of polynomials (s^2 + (den2[i,2]/den2[i,1])*s + (1/den2[i,1]))";
            algorithm
              for i in 1:size(den1, 1) loop
                cr[i] := 1 / den1[i];
              end for;
              for i in 1:size(den2, 1) loop
                c1[i] := den2[i, 2] / den2[i, 1];
                c0[i] := 1 / den2[i, 1];
              end for;
            end toHighestPowerOne;

            function normalizationFactor  "Compute correction factor of low pass filter such that amplitude at cut-off frequency is -3db (=10^(-3/20) = 0.70794...)" 
              extends .Modelica.Icons.Function;
              input Real[:] c1 "[p] coefficients of denominator polynomials (c1[i}*p + 1)";
              input Real[:, 2] c2 "[p^2, p] coefficients of denominator polynomials (c2[i,1]*p^2 + c2[i,2]*p + 1)";
              output Real alpha "Correction factor (replace p by alpha*p)";
            protected
              Real alpha_min;
              Real alpha_max;

              function normalizationResidue  "Residue of correction factor computation" 
                extends .Modelica.Icons.Function;
                input Real[:] c1 "[p] coefficients of denominator polynomials (c1[i]*p + 1)";
                input Real[:, 2] c2 "[p^2, p] coefficients of denominator polynomials (c2[i,1]*p^2 + c2[i,2]*p + 1)";
                input Real alpha;
                output Real residue;
              protected
                constant Real beta = 10 ^ (-3 / 20) "Amplitude of -3db required, i.e., -3db = 20*log(beta)";
                Real cc1;
                Real cc2;
                Real p;
                Real alpha2 = alpha * alpha;
                Real alpha4 = alpha2 * alpha2;
                Real A2 = 1.0;
              algorithm
                assert(size(c1, 1) <= 1, "Internal error 2 (should not occur)");
                if size(c1, 1) == 1 then
                  cc1 := c1[1] * c1[1];
                  p := 1 + cc1 * alpha2;
                  A2 := A2 * p;
                else
                end if;
                for i in 1:size(c2, 1) loop
                  cc1 := c2[i, 2] * c2[i, 2] - 2 * c2[i, 1];
                  cc2 := c2[i, 1] * c2[i, 1];
                  p := 1 + cc1 * alpha2 + cc2 * alpha4;
                  A2 := A2 * p;
                end for;
                residue := 1 / sqrt(A2) - beta;
              end normalizationResidue;

              function findInterval  "Find interval for the root" 
                extends .Modelica.Icons.Function;
                input Real[:] c1 "[p] coefficients of denominator polynomials (a*p + 1)";
                input Real[:, 2] c2 "[p^2, p] coefficients of denominator polynomials (b*p^2 + a*p + 1)";
                output Real alpha_min;
                output Real alpha_max;
              protected
                Real alpha = 1.0;
                Real residue;
              algorithm
                alpha_min := 0;
                residue := normalizationResidue(c1, c2, alpha);
                if residue < 0 then
                  alpha_max := alpha;
                else
                  while residue >= 0 loop
                    alpha := 1.1 * alpha;
                    residue := normalizationResidue(c1, c2, alpha);
                  end while;
                  alpha_max := alpha;
                end if;
              end findInterval;

              function solveOneNonlinearEquation  "Solve f(u) = 0; f(u_min) and f(u_max) must have different signs" 
                extends .Modelica.Icons.Function;
                input Real[:] c1 "[p] coefficients of denominator polynomials (c1[i]*p + 1)";
                input Real[:, 2] c2 "[p^2, p] coefficients of denominator polynomials (c2[i,1]*p^2 + c2[i,2]*p + 1)";
                input Real u_min "Lower bound of search interval";
                input Real u_max "Upper bound of search interval";
                input Real tolerance = 100 * .Modelica.Constants.eps "Relative tolerance of solution u";
                output Real u "Value of independent variable so that f(u) = 0";
              protected
                constant Real eps = .Modelica.Constants.eps "machine epsilon";
                Real a = u_min "Current best minimum interval value";
                Real b = u_max "Current best maximum interval value";
                Real c "Intermediate point a <= c <= b";
                Real d;
                Real e "b - a";
                Real m;
                Real s;
                Real p;
                Real q;
                Real r;
                Real tol;
                Real fa "= f(a)";
                Real fb "= f(b)";
                Real fc;
                Boolean found = false;
              algorithm
                fa := normalizationResidue(c1, c2, u_min);
                fb := normalizationResidue(c1, c2, u_max);
                fc := fb;
                if fa > 0.0 and fb > 0.0 or fa < 0.0 and fb < 0.0 then
                  .Modelica.Utilities.Streams.error("The arguments u_min and u_max to solveOneNonlinearEquation(..)\n" + "do not bracket the root of the single non-linear equation:\n" + "  u_min  = " + String(u_min) + "\n" + "  u_max  = " + String(u_max) + "\n" + "  fa = f(u_min) = " + String(fa) + "\n" + "  fb = f(u_max) = " + String(fb) + "\n" + "fa and fb must have opposite sign which is not the case");
                else
                end if;
                c := a;
                fc := fa;
                e := b - a;
                d := e;
                while not found loop
                  if abs(fc) < abs(fb) then
                    a := b;
                    b := c;
                    c := a;
                    fa := fb;
                    fb := fc;
                    fc := fa;
                  else
                  end if;
                  tol := 2 * eps * abs(b) + tolerance;
                  m := (c - b) / 2;
                  if abs(m) <= tol or fb == 0.0 then
                    found := true;
                    u := b;
                  else
                    if abs(e) < tol or abs(fa) <= abs(fb) then
                      e := m;
                      d := e;
                    else
                      s := fb / fa;
                      if a == c then
                        p := 2 * m * s;
                        q := 1 - s;
                      else
                        q := fa / fc;
                        r := fb / fc;
                        p := s * (2 * m * q * (q - r) - (b - a) * (r - 1));
                        q := (q - 1) * (r - 1) * (s - 1);
                      end if;
                      if p > 0 then
                        q := -q;
                      else
                        p := -p;
                      end if;
                      s := e;
                      e := d;
                      if 2 * p < 3 * m * q - abs(tol * q) and p < abs(0.5 * s * q) then
                        d := p / q;
                      else
                        e := m;
                        d := e;
                      end if;
                    end if;
                    a := b;
                    fa := fb;
                    b := b + (if abs(d) > tol then d else if m > 0 then tol else -tol);
                    fb := normalizationResidue(c1, c2, b);
                    if fb > 0 and fc > 0 or fb < 0 and fc < 0 then
                      c := a;
                      fc := fa;
                      e := b - a;
                      d := e;
                    else
                    end if;
                  end if;
                end while;
              end solveOneNonlinearEquation;
            algorithm
              (alpha_min, alpha_max) := findInterval(c1, c2);
              alpha := solveOneNonlinearEquation(c1, c2, alpha_min, alpha_max);
            end normalizationFactor;

            encapsulated function bandPassAlpha  "Return alpha for band pass" 
              extends .Modelica.Icons.Function;
              input Real a "Coefficient of s^1";
              input Real b "Coefficient of s^0";
              input .Modelica.SIunits.AngularVelocity w "Bandwidth angular frequency";
              output Real alpha "Alpha factor to build up band pass";
            protected
              Real alpha_min;
              Real alpha_max;
              Real z_min;
              Real z_max;
              Real z;

              function residue  "Residue of non-linear equation" 
                extends .Modelica.Icons.Function;
                input Real a;
                input Real b;
                input Real w;
                input Real z;
                output Real res;
              algorithm
                res := z ^ 2 + (a * w * z / (1 + z)) ^ 2 - (2 + b * w ^ 2) * z + 1;
              end residue;

              function solveOneNonlinearEquation  "Solve f(u) = 0; f(u_min) and f(u_max) must have different signs" 
                extends .Modelica.Icons.Function;
                input Real aa;
                input Real bb;
                input Real ww;
                input Real u_min "Lower bound of search interval";
                input Real u_max "Upper bound of search interval";
                input Real tolerance = 100 * .Modelica.Constants.eps "Relative tolerance of solution u";
                output Real u "Value of independent variable so that f(u) = 0";
              protected
                constant Real eps = .Modelica.Constants.eps "machine epsilon";
                Real a = u_min "Current best minimum interval value";
                Real b = u_max "Current best maximum interval value";
                Real c "Intermediate point a <= c <= b";
                Real d;
                Real e "b - a";
                Real m;
                Real s;
                Real p;
                Real q;
                Real r;
                Real tol;
                Real fa "= f(a)";
                Real fb "= f(b)";
                Real fc;
                Boolean found = false;
              algorithm
                fa := residue(aa, bb, ww, u_min);
                fb := residue(aa, bb, ww, u_max);
                fc := fb;
                if fa > 0.0 and fb > 0.0 or fa < 0.0 and fb < 0.0 then
                  .Modelica.Utilities.Streams.error("The arguments u_min and u_max to solveOneNonlinearEquation(..)\n" + "do not bracket the root of the single non-linear equation:\n" + "  u_min  = " + String(u_min) + "\n" + "  u_max  = " + String(u_max) + "\n" + "  fa = f(u_min) = " + String(fa) + "\n" + "  fb = f(u_max) = " + String(fb) + "\n" + "fa and fb must have opposite sign which is not the case");
                else
                end if;
                c := a;
                fc := fa;
                e := b - a;
                d := e;
                while not found loop
                  if abs(fc) < abs(fb) then
                    a := b;
                    b := c;
                    c := a;
                    fa := fb;
                    fb := fc;
                    fc := fa;
                  else
                  end if;
                  tol := 2 * eps * abs(b) + tolerance;
                  m := (c - b) / 2;
                  if abs(m) <= tol or fb == 0.0 then
                    found := true;
                    u := b;
                  else
                    if abs(e) < tol or abs(fa) <= abs(fb) then
                      e := m;
                      d := e;
                    else
                      s := fb / fa;
                      if a == c then
                        p := 2 * m * s;
                        q := 1 - s;
                      else
                        q := fa / fc;
                        r := fb / fc;
                        p := s * (2 * m * q * (q - r) - (b - a) * (r - 1));
                        q := (q - 1) * (r - 1) * (s - 1);
                      end if;
                      if p > 0 then
                        q := -q;
                      else
                        p := -p;
                      end if;
                      s := e;
                      e := d;
                      if 2 * p < 3 * m * q - abs(tol * q) and p < abs(0.5 * s * q) then
                        d := p / q;
                      else
                        e := m;
                        d := e;
                      end if;
                    end if;
                    a := b;
                    fa := fb;
                    b := b + (if abs(d) > tol then d else if m > 0 then tol else -tol);
                    fb := residue(aa, bb, ww, b);
                    if fb > 0 and fc > 0 or fb < 0 and fc < 0 then
                      c := a;
                      fc := fa;
                      e := b - a;
                      d := e;
                    else
                    end if;
                  end if;
                end while;
              end solveOneNonlinearEquation;
            algorithm
              assert(a ^ 2 / 4 - b <= 0, "Band pass transformation cannot be computed");
              z := solveOneNonlinearEquation(a, b, w, 0, 1);
              alpha := sqrt(z);
            end bandPassAlpha;
          end Utilities;
        end Filter;
      end Internal;
    end Continuous;

    package Interfaces  "Library of connectors and partial models for input/output blocks" 
      extends Modelica.Icons.InterfacesPackage;
      connector RealInput = input Real "'input Real' as connector";
      connector RealOutput = output Real "'output Real' as connector";

      partial block SISO  "Single Input Single Output continuous control block" 
        extends Modelica.Blocks.Icons.Block;
        RealInput u "Connector of Real input signal";
        RealOutput y "Connector of Real output signal";
      end SISO;
    end Interfaces;

    package Types  "Library of constants and types with choices, especially to build menus" 
      extends Modelica.Icons.TypesPackage;
      type Init = enumeration(NoInit "No initialization (start values are used as guess values with fixed=false)", SteadyState "Steady state initialization (derivatives of states are zero)", InitialState "Initialization with initial states", InitialOutput "Initialization with initial outputs (and steady state of the states if possible)") "Enumeration defining initialization of a block" annotation(Evaluate = true);
      type AnalogFilter = enumeration(CriticalDamping "Filter with critical damping", Bessel "Bessel filter", Butterworth "Butterworth filter", ChebyshevI "Chebyshev I filter") "Enumeration defining the method of filtering" annotation(Evaluate = true);
      type FilterType = enumeration(LowPass "Low pass filter", HighPass "High pass filter", BandPass "Band pass filter", BandStop "Band stop / notch filter") "Enumeration of analog filter types (low, high, band pass or band stop filter)" annotation(Evaluate = true);
    end Types;

    package Icons  "Icons for Blocks" 
      extends Modelica.Icons.IconsPackage;

      partial block Block  "Basic graphical layout of input/output block" end Block;
    end Icons;
  end Blocks;

  package Fluid  "Library of 1-dim. thermo-fluid flow models using the Modelica.Media media description" 
    extends Modelica.Icons.Package;

    model System  "System properties and default values (ambient, flow direction, initialization)" 
      parameter Modelica.SIunits.AbsolutePressure p_ambient = 101325 "Default ambient pressure";
      parameter Modelica.SIunits.Temperature T_ambient = 293.15 "Default ambient temperature";
      parameter Modelica.SIunits.Acceleration g = Modelica.Constants.g_n "Constant gravity acceleration";
      parameter Boolean allowFlowReversal = true "= false to restrict to design flow direction (port_a -> port_b)" annotation(Evaluate = true);
      parameter Modelica.Fluid.Types.Dynamics energyDynamics = Types.Dynamics.DynamicFreeInitial "Default formulation of energy balances" annotation(Evaluate = true);
      parameter Modelica.Fluid.Types.Dynamics massDynamics = energyDynamics "Default formulation of mass balances" annotation(Evaluate = true);
      final parameter Modelica.Fluid.Types.Dynamics substanceDynamics = massDynamics "Default formulation of substance balances" annotation(Evaluate = true);
      final parameter Modelica.Fluid.Types.Dynamics traceDynamics = massDynamics "Default formulation of trace substance balances" annotation(Evaluate = true);
      parameter Modelica.Fluid.Types.Dynamics momentumDynamics = Types.Dynamics.SteadyState "Default formulation of momentum balances, if options available" annotation(Evaluate = true);
      parameter Modelica.SIunits.MassFlowRate m_flow_start = 0 "Default start value for mass flow rates";
      parameter Modelica.SIunits.AbsolutePressure p_start = p_ambient "Default start value for pressures";
      parameter Modelica.SIunits.Temperature T_start = T_ambient "Default start value for temperatures";
      parameter Boolean use_eps_Re = false "= true to determine turbulent region automatically using Reynolds number" annotation(Evaluate = true);
      parameter Modelica.SIunits.MassFlowRate m_flow_nominal = if use_eps_Re then 1 else 1e2 * m_flow_small "Default nominal mass flow rate";
      parameter Real eps_m_flow(min = 0) = 1e-4 "Regularization of zero flow for |m_flow| < eps_m_flow*m_flow_nominal";
      parameter Modelica.SIunits.AbsolutePressure dp_small(min = 0) = 1 "Default small pressure drop for regularization of laminar and zero flow";
      parameter Modelica.SIunits.MassFlowRate m_flow_small(min = 0) = 1e-2 "Default small mass flow rate for regularization of laminar and zero flow";
      annotation(defaultComponentPrefixes = "inner", missingInnerMessage = "
    Your model is using an outer \"system\" component but
    an inner \"system\" component is not defined.
    For simulation drag Modelica.Fluid.System into your model
    to specify system properties."); 
    end System;

    package Pipes  "Devices for conveying fluid" 
      extends Modelica.Icons.VariantsPackage;

      model DynamicPipe  "Dynamic pipe model with storage of mass and energy" 
        extends Modelica.Fluid.Pipes.BaseClasses.PartialStraightPipe(final port_a_exposesState = modelStructure == .Modelica.Fluid.Types.ModelStructure.av_b or modelStructure == .Modelica.Fluid.Types.ModelStructure.av_vb, final port_b_exposesState = modelStructure == .Modelica.Fluid.Types.ModelStructure.a_vb or modelStructure == .Modelica.Fluid.Types.ModelStructure.av_vb);
        extends BaseClasses.PartialTwoPortFlow(final lengths = fill(length / n, n), final crossAreas = fill(crossArea, n), final dimensions = fill(4 * crossArea / perimeter, n), final roughnesses = fill(roughness, n), final dheights = height_ab * dxs);
        parameter Boolean use_HeatTransfer = false "= true to use the HeatTransfer model";
        replaceable model HeatTransfer = Modelica.Fluid.Pipes.BaseClasses.HeatTransfer.IdealFlowHeatTransfer constrainedby Modelica.Fluid.Pipes.BaseClasses.HeatTransfer.PartialFlowHeatTransfer;
        Interfaces.HeatPorts_a[nNodes] heatPorts if use_HeatTransfer;
        HeatTransfer heatTransfer(redeclare final package Medium = Medium, final n = n, final nParallel = nParallel, final surfaceAreas = perimeter * lengths, final lengths = lengths, final dimensions = dimensions, final roughnesses = roughnesses, final states = mediums.state, final vs = vs, final use_k = use_HeatTransfer) "Heat transfer model";
        final parameter Real[n] dxs = lengths / sum(lengths);
      equation
        Qb_flows = heatTransfer.Q_flows;
        if n == 1 or useLumpedPressure then
          Wb_flows = dxs * (vs * dxs * (crossAreas * dxs) * (port_b.p - port_a.p + sum(flowModel.dps_fg) - system.g * (dheights * mediums.d))) * nParallel;
        else
          if modelStructure == .Modelica.Fluid.Types.ModelStructure.av_vb or modelStructure == .Modelica.Fluid.Types.ModelStructure.av_b then
            Wb_flows[2:n - 1] = {vs[i] * crossAreas[i] * ((mediums[i + 1].p - mediums[i - 1].p) / 2 + (flowModel.dps_fg[i - 1] + flowModel.dps_fg[i]) / 2 - system.g * dheights[i] * mediums[i].d) for i in 2:n - 1} * nParallel;
          else
            Wb_flows[2:n - 1] = {vs[i] * crossAreas[i] * ((mediums[i + 1].p - mediums[i - 1].p) / 2 + (flowModel.dps_fg[i] + flowModel.dps_fg[i + 1]) / 2 - system.g * dheights[i] * mediums[i].d) for i in 2:n - 1} * nParallel;
          end if;
          if modelStructure == .Modelica.Fluid.Types.ModelStructure.av_vb then
            Wb_flows[1] = vs[1] * crossAreas[1] * ((mediums[2].p - mediums[1].p) / 2 + flowModel.dps_fg[1] / 2 - system.g * dheights[1] * mediums[1].d) * nParallel;
            Wb_flows[n] = vs[n] * crossAreas[n] * ((mediums[n].p - mediums[n - 1].p) / 2 + flowModel.dps_fg[n - 1] / 2 - system.g * dheights[n] * mediums[n].d) * nParallel;
          elseif modelStructure == .Modelica.Fluid.Types.ModelStructure.av_b then
            Wb_flows[1] = vs[1] * crossAreas[1] * ((mediums[2].p - mediums[1].p) / 2 + flowModel.dps_fg[1] / 2 - system.g * dheights[1] * mediums[1].d) * nParallel;
            Wb_flows[n] = vs[n] * crossAreas[n] * ((port_b.p - mediums[n - 1].p) / 1.5 + flowModel.dps_fg[n - 1] / 2 + flowModel.dps_fg[n] - system.g * dheights[n] * mediums[n].d) * nParallel;
          elseif modelStructure == .Modelica.Fluid.Types.ModelStructure.a_vb then
            Wb_flows[1] = vs[1] * crossAreas[1] * ((mediums[2].p - port_a.p) / 1.5 + flowModel.dps_fg[1] + flowModel.dps_fg[2] / 2 - system.g * dheights[1] * mediums[1].d) * nParallel;
            Wb_flows[n] = vs[n] * crossAreas[n] * ((mediums[n].p - mediums[n - 1].p) / 2 + flowModel.dps_fg[n] / 2 - system.g * dheights[n] * mediums[n].d) * nParallel;
          elseif modelStructure == .Modelica.Fluid.Types.ModelStructure.a_v_b then
            Wb_flows[1] = vs[1] * crossAreas[1] * ((mediums[2].p - port_a.p) / 1.5 + flowModel.dps_fg[1] + flowModel.dps_fg[2] / 2 - system.g * dheights[1] * mediums[1].d) * nParallel;
            Wb_flows[n] = vs[n] * crossAreas[n] * ((port_b.p - mediums[n - 1].p) / 1.5 + flowModel.dps_fg[n] / 2 + flowModel.dps_fg[n + 1] - system.g * dheights[n] * mediums[n].d) * nParallel;
          else
            assert(false, "Unknown model structure");
          end if;
        end if;
        connect(heatPorts, heatTransfer.heatPorts);
      end DynamicPipe;

      package BaseClasses  "Base classes used in the Pipes package (only of interest to build new component models)" 
        extends Modelica.Icons.BasesPackage;

        partial model PartialStraightPipe  "Base class for straight pipe models" 
          extends Modelica.Fluid.Interfaces.PartialTwoPort;
          parameter Real nParallel(min = 1) = 1 "Number of identical parallel pipes";
          parameter .Modelica.SIunits.Length length "Length";
          parameter Boolean isCircular = true "= true if cross sectional area is circular";
          parameter .Modelica.SIunits.Diameter diameter "Diameter of circular pipe";
          parameter .Modelica.SIunits.Area crossArea = Modelica.Constants.pi * diameter * diameter / 4 "Inner cross section area";
          parameter .Modelica.SIunits.Length perimeter = Modelica.Constants.pi * diameter "Inner perimeter";
          parameter .Modelica.SIunits.Height roughness = 2.5e-5 "Average height of surface asperities (default: smooth steel pipe)";
          final parameter .Modelica.SIunits.Volume V = crossArea * length * nParallel "volume size";
          parameter .Modelica.SIunits.Length height_ab = 0 "Height(port_b) - Height(port_a)";
        equation
          assert(length >= height_ab, "Parameter length must be greater or equal height_ab.");
        end PartialStraightPipe;

        partial model PartialTwoPortFlow  "Base class for distributed flow models" 
          extends Modelica.Fluid.Interfaces.PartialTwoPort(final port_a_exposesState = modelStructure == .Modelica.Fluid.Types.ModelStructure.av_b or modelStructure == .Modelica.Fluid.Types.ModelStructure.av_vb, final port_b_exposesState = modelStructure == .Modelica.Fluid.Types.ModelStructure.a_vb or modelStructure == .Modelica.Fluid.Types.ModelStructure.av_vb);
          extends Modelica.Fluid.Interfaces.PartialDistributedVolume(final n = nNodes, final fluidVolumes = {crossAreas[i] * lengths[i] for i in 1:n} * nParallel);
          parameter Real nParallel(min = 1) = 1 "Number of identical parallel flow devices";
          parameter .Modelica.SIunits.Length[n] lengths "lengths of flow segments";
          parameter .Modelica.SIunits.Area[n] crossAreas "cross flow areas of flow segments";
          parameter .Modelica.SIunits.Length[n] dimensions "hydraulic diameters of flow segments";
          parameter .Modelica.SIunits.Height[n] roughnesses "Average heights of surface asperities";
          parameter .Modelica.SIunits.Length[n] dheights = zeros(n) "Differences in heights of flow segments" annotation(Evaluate = true);
          parameter Types.Dynamics momentumDynamics = system.momentumDynamics "Formulation of momentum balances" annotation(Evaluate = true);
          parameter Medium.MassFlowRate m_flow_start = system.m_flow_start "Start value for mass flow rate" annotation(Evaluate = true);
          parameter Integer nNodes(min = 1) = 2 "Number of discrete flow volumes" annotation(Evaluate = true);
          parameter Types.ModelStructure modelStructure = Types.ModelStructure.av_vb "Determines whether flow or volume models are present at the ports" annotation(Evaluate = true);
          parameter Boolean useLumpedPressure = false "=true to lump pressure states together" annotation(Evaluate = true);
          final parameter Integer nFM = if useLumpedPressure then nFMLumped else nFMDistributed "number of flow models in flowModel";
          final parameter Integer nFMDistributed = if modelStructure == Types.ModelStructure.a_v_b then n + 1 else if modelStructure == Types.ModelStructure.a_vb or modelStructure == Types.ModelStructure.av_b then n else n - 1;
          final parameter Integer nFMLumped = if modelStructure == Types.ModelStructure.a_v_b then 2 else 1;
          final parameter Integer iLumped = integer(n / 2) + 1 "Index of control volume with representative state if useLumpedPressure" annotation(Evaluate = true);
          parameter Boolean useInnerPortProperties = false "=true to take port properties for flow models from internal control volumes" annotation(Evaluate = true);
          Medium.ThermodynamicState state_a "state defined by volume outside port_a";
          Medium.ThermodynamicState state_b "state defined by volume outside port_b";
          Medium.ThermodynamicState[nFM + 1] statesFM "state vector for flowModel model";
          replaceable model FlowModel = Modelica.Fluid.Pipes.BaseClasses.FlowModels.DetailedPipeFlow constrainedby Modelica.Fluid.Pipes.BaseClasses.FlowModels.PartialStaggeredFlowModel;
          FlowModel flowModel(redeclare final package Medium = Medium, final n = nFM + 1, final states = statesFM, final vs = vsFM, final momentumDynamics = momentumDynamics, final allowFlowReversal = allowFlowReversal, final p_a_start = p_a_start, final p_b_start = p_b_start, final m_flow_start = m_flow_start, final nParallel = nParallel, final pathLengths = pathLengths, final crossAreas = crossAreasFM, final dimensions = dimensionsFM, final roughnesses = roughnessesFM, final dheights = dheightsFM, final g = system.g) "Flow model";
          Medium.MassFlowRate[n + 1] m_flows(each min = if allowFlowReversal then -Modelica.Constants.inf else 0, each start = m_flow_start) "Mass flow rates of fluid across segment boundaries";
          Medium.MassFlowRate[n + 1, Medium.nXi] mXi_flows "Independent mass flow rates across segment boundaries";
          Medium.MassFlowRate[n + 1, Medium.nC] mC_flows "Trace substance mass flow rates across segment boundaries";
          Medium.EnthalpyFlowRate[n + 1] H_flows "Enthalpy flow rates of fluid across segment boundaries";
          .Modelica.SIunits.Velocity[n] vs = {0.5 * (m_flows[i] + m_flows[i + 1]) / mediums[i].d / crossAreas[i] for i in 1:n} / nParallel "mean velocities in flow segments";
        protected
          .Modelica.SIunits.Length[nFM] pathLengths "Lengths along flow path";
          .Modelica.SIunits.Length[nFM] dheightsFM "Differences in heights between flow segments";
          .Modelica.SIunits.Area[nFM + 1] crossAreasFM "Cross flow areas of flow segments";
          .Modelica.SIunits.Velocity[nFM + 1] vsFM "Mean velocities in flow segments";
          .Modelica.SIunits.Length[nFM + 1] dimensionsFM "Hydraulic diameters of flow segments";
          .Modelica.SIunits.Height[nFM + 1] roughnessesFM "Average heights of surface asperities";
        equation
          assert(nNodes > 1 or modelStructure <> .Modelica.Fluid.Types.ModelStructure.av_vb, "nNodes needs to be at least 2 for modelStructure av_vb, as flow model disappears otherwise!");
          if useLumpedPressure then
            if modelStructure <> .Modelica.Fluid.Types.ModelStructure.a_v_b then
              pathLengths[1] = sum(lengths);
              dheightsFM[1] = sum(dheights);
              if n == 1 then
                crossAreasFM[1:2] = {crossAreas[1], crossAreas[1]};
                dimensionsFM[1:2] = {dimensions[1], dimensions[1]};
                roughnessesFM[1:2] = {roughnesses[1], roughnesses[1]};
              else
                crossAreasFM[1:2] = {sum(crossAreas[1:iLumped - 1]) / (iLumped - 1), sum(crossAreas[iLumped:n]) / (n - iLumped + 1)};
                dimensionsFM[1:2] = {sum(dimensions[1:iLumped - 1]) / (iLumped - 1), sum(dimensions[iLumped:n]) / (n - iLumped + 1)};
                roughnessesFM[1:2] = {sum(roughnesses[1:iLumped - 1]) / (iLumped - 1), sum(roughnesses[iLumped:n]) / (n - iLumped + 1)};
              end if;
            else
              if n == 1 then
                pathLengths[1:2] = {lengths[1] / 2, lengths[1] / 2};
                dheightsFM[1:2] = {dheights[1] / 2, dheights[1] / 2};
                crossAreasFM[1:3] = {crossAreas[1], crossAreas[1], crossAreas[1]};
                dimensionsFM[1:3] = {dimensions[1], dimensions[1], dimensions[1]};
                roughnessesFM[1:3] = {roughnesses[1], roughnesses[1], roughnesses[1]};
              else
                pathLengths[1:2] = {sum(lengths[1:iLumped - 1]), sum(lengths[iLumped:n])};
                dheightsFM[1:2] = {sum(dheights[1:iLumped - 1]), sum(dheights[iLumped:n])};
                crossAreasFM[1:3] = {sum(crossAreas[1:iLumped - 1]) / (iLumped - 1), sum(crossAreas) / n, sum(crossAreas[iLumped:n]) / (n - iLumped + 1)};
                dimensionsFM[1:3] = {sum(dimensions[1:iLumped - 1]) / (iLumped - 1), sum(dimensions) / n, sum(dimensions[iLumped:n]) / (n - iLumped + 1)};
                roughnessesFM[1:3] = {sum(roughnesses[1:iLumped - 1]) / (iLumped - 1), sum(roughnesses) / n, sum(roughnesses[iLumped:n]) / (n - iLumped + 1)};
              end if;
            end if;
          else
            if modelStructure == .Modelica.Fluid.Types.ModelStructure.av_vb then
              if n == 2 then
                pathLengths[1] = lengths[1] + lengths[2];
                dheightsFM[1] = dheights[1] + dheights[2];
              else
                pathLengths[1:n - 1] = cat(1, {lengths[1] + 0.5 * lengths[2]}, 0.5 * (lengths[2:n - 2] + lengths[3:n - 1]), {0.5 * lengths[n - 1] + lengths[n]});
                dheightsFM[1:n - 1] = cat(1, {dheights[1] + 0.5 * dheights[2]}, 0.5 * (dheights[2:n - 2] + dheights[3:n - 1]), {0.5 * dheights[n - 1] + dheights[n]});
              end if;
              crossAreasFM[1:n] = crossAreas;
              dimensionsFM[1:n] = dimensions;
              roughnessesFM[1:n] = roughnesses;
            elseif modelStructure == .Modelica.Fluid.Types.ModelStructure.av_b then
              pathLengths[1:n] = lengths;
              dheightsFM[1:n] = dheights;
              crossAreasFM[1:n + 1] = cat(1, crossAreas[1:n], {crossAreas[n]});
              dimensionsFM[1:n + 1] = cat(1, dimensions[1:n], {dimensions[n]});
              roughnessesFM[1:n + 1] = cat(1, roughnesses[1:n], {roughnesses[n]});
            elseif modelStructure == .Modelica.Fluid.Types.ModelStructure.a_vb then
              pathLengths[1:n] = lengths;
              dheightsFM[1:n] = dheights;
              crossAreasFM[1:n + 1] = cat(1, {crossAreas[1]}, crossAreas[1:n]);
              dimensionsFM[1:n + 1] = cat(1, {dimensions[1]}, dimensions[1:n]);
              roughnessesFM[1:n + 1] = cat(1, {roughnesses[1]}, roughnesses[1:n]);
            elseif modelStructure == .Modelica.Fluid.Types.ModelStructure.a_v_b then
              pathLengths[1:n + 1] = cat(1, {0.5 * lengths[1]}, 0.5 * (lengths[1:n - 1] + lengths[2:n]), {0.5 * lengths[n]});
              dheightsFM[1:n + 1] = cat(1, {0.5 * dheights[1]}, 0.5 * (dheights[1:n - 1] + dheights[2:n]), {0.5 * dheights[n]});
              crossAreasFM[1:n + 2] = cat(1, {crossAreas[1]}, crossAreas[1:n], {crossAreas[n]});
              dimensionsFM[1:n + 2] = cat(1, {dimensions[1]}, dimensions[1:n], {dimensions[n]});
              roughnessesFM[1:n + 2] = cat(1, {roughnesses[1]}, roughnesses[1:n], {roughnesses[n]});
            else
              assert(false, "Unknown model structure");
            end if;
          end if;
          for i in 1:n loop
            mb_flows[i] = m_flows[i] - m_flows[i + 1];
            mbXi_flows[i, :] = mXi_flows[i, :] - mXi_flows[i + 1, :];
            mbC_flows[i, :] = mC_flows[i, :] - mC_flows[i + 1, :];
            Hb_flows[i] = H_flows[i] - H_flows[i + 1];
          end for;
          for i in 2:n loop
            H_flows[i] = semiLinear(m_flows[i], mediums[i - 1].h, mediums[i].h);
            mXi_flows[i, :] = semiLinear(m_flows[i], mediums[i - 1].Xi, mediums[i].Xi);
            mC_flows[i, :] = semiLinear(m_flows[i], Cs[i - 1, :], Cs[i, :]);
          end for;
          H_flows[1] = semiLinear(port_a.m_flow, inStream(port_a.h_outflow), mediums[1].h);
          H_flows[n + 1] = -semiLinear(port_b.m_flow, inStream(port_b.h_outflow), mediums[n].h);
          mXi_flows[1, :] = semiLinear(port_a.m_flow, inStream(port_a.Xi_outflow), mediums[1].Xi);
          mXi_flows[n + 1, :] = -semiLinear(port_b.m_flow, inStream(port_b.Xi_outflow), mediums[n].Xi);
          mC_flows[1, :] = semiLinear(port_a.m_flow, inStream(port_a.C_outflow), Cs[1, :]);
          mC_flows[n + 1, :] = -semiLinear(port_b.m_flow, inStream(port_b.C_outflow), Cs[n, :]);
          port_a.m_flow = m_flows[1];
          port_b.m_flow = -m_flows[n + 1];
          port_a.h_outflow = mediums[1].h;
          port_b.h_outflow = mediums[n].h;
          port_a.Xi_outflow = mediums[1].Xi;
          port_b.Xi_outflow = mediums[n].Xi;
          port_a.C_outflow = Cs[1, :];
          port_b.C_outflow = Cs[n, :];
          if useInnerPortProperties and n > 0 then
            state_a = Medium.setState_phX(port_a.p, mediums[1].h, mediums[1].Xi);
            state_b = Medium.setState_phX(port_b.p, mediums[n].h, mediums[n].Xi);
          else
            state_a = Medium.setState_phX(port_a.p, inStream(port_a.h_outflow), inStream(port_a.Xi_outflow));
            state_b = Medium.setState_phX(port_b.p, inStream(port_b.h_outflow), inStream(port_b.Xi_outflow));
          end if;
          if useLumpedPressure then
            if modelStructure <> .Modelica.Fluid.Types.ModelStructure.av_vb then
              fill(mediums[1].p, n - 1) = mediums[2:n].p;
            elseif n > 2 then
              fill(mediums[1].p, iLumped - 2) = mediums[2:iLumped - 1].p;
              fill(mediums[n].p, n - iLumped) = mediums[iLumped:n - 1].p;
            end if;
            if modelStructure == .Modelica.Fluid.Types.ModelStructure.av_vb then
              port_a.p = mediums[1].p;
              statesFM[1] = mediums[1].state;
              m_flows[iLumped] = flowModel.m_flows[1];
              statesFM[2] = mediums[n].state;
              port_b.p = mediums[n].p;
              vsFM[1] = vs[1:iLumped - 1] * lengths[1:iLumped - 1] / sum(lengths[1:iLumped - 1]);
              vsFM[2] = vs[iLumped:n] * lengths[iLumped:n] / sum(lengths[iLumped:n]);
            elseif modelStructure == .Modelica.Fluid.Types.ModelStructure.av_b then
              port_a.p = mediums[1].p;
              statesFM[1] = mediums[iLumped].state;
              statesFM[2] = state_b;
              m_flows[n + 1] = flowModel.m_flows[1];
              vsFM[1] = vs * lengths / sum(lengths);
              vsFM[2] = m_flows[n + 1] / Medium.density(state_b) / crossAreas[n] / nParallel;
            elseif modelStructure == .Modelica.Fluid.Types.ModelStructure.a_vb then
              m_flows[1] = flowModel.m_flows[1];
              statesFM[1] = state_a;
              statesFM[2] = mediums[iLumped].state;
              port_b.p = mediums[n].p;
              vsFM[1] = m_flows[1] / Medium.density(state_a) / crossAreas[1] / nParallel;
              vsFM[2] = vs * lengths / sum(lengths);
            elseif modelStructure == .Modelica.Fluid.Types.ModelStructure.a_v_b then
              m_flows[1] = flowModel.m_flows[1];
              statesFM[1] = state_a;
              statesFM[2] = mediums[iLumped].state;
              statesFM[3] = state_b;
              m_flows[n + 1] = flowModel.m_flows[2];
              vsFM[1] = m_flows[1] / Medium.density(state_a) / crossAreas[1] / nParallel;
              vsFM[2] = vs * lengths / sum(lengths);
              vsFM[3] = m_flows[n + 1] / Medium.density(state_b) / crossAreas[n] / nParallel;
            else
              assert(false, "Unknown model structure");
            end if;
          else
            if modelStructure == .Modelica.Fluid.Types.ModelStructure.av_vb then
              statesFM[1:n] = mediums[1:n].state;
              m_flows[2:n] = flowModel.m_flows[1:n - 1];
              vsFM[1:n] = vs;
              port_a.p = mediums[1].p;
              port_b.p = mediums[n].p;
            elseif modelStructure == .Modelica.Fluid.Types.ModelStructure.av_b then
              statesFM[1:n] = mediums[1:n].state;
              statesFM[n + 1] = state_b;
              m_flows[2:n + 1] = flowModel.m_flows[1:n];
              vsFM[1:n] = vs;
              vsFM[n + 1] = m_flows[n + 1] / Medium.density(state_b) / crossAreas[n] / nParallel;
              port_a.p = mediums[1].p;
            elseif modelStructure == .Modelica.Fluid.Types.ModelStructure.a_vb then
              statesFM[1] = state_a;
              statesFM[2:n + 1] = mediums[1:n].state;
              m_flows[1:n] = flowModel.m_flows[1:n];
              vsFM[1] = m_flows[1] / Medium.density(state_a) / crossAreas[1] / nParallel;
              vsFM[2:n + 1] = vs;
              port_b.p = mediums[n].p;
            elseif modelStructure == .Modelica.Fluid.Types.ModelStructure.a_v_b then
              statesFM[1] = state_a;
              statesFM[2:n + 1] = mediums[1:n].state;
              statesFM[n + 2] = state_b;
              m_flows[1:n + 1] = flowModel.m_flows[1:n + 1];
              vsFM[1] = m_flows[1] / Medium.density(state_a) / crossAreas[1] / nParallel;
              vsFM[2:n + 1] = vs;
              vsFM[n + 2] = m_flows[n + 1] / Medium.density(state_b) / crossAreas[n] / nParallel;
            else
              assert(false, "Unknown model structure");
            end if;
          end if;
        end PartialTwoPortFlow;

        package FlowModels  "Flow models for pipes, including wall friction, static head and momentum flow" 
          extends Modelica.Icons.Package;

          partial model PartialStaggeredFlowModel  "Base class for momentum balances in flow models" 
            replaceable package Medium = Modelica.Media.Interfaces.PartialMedium "Medium in the component";
            parameter Integer n = 2 "Number of discrete flow volumes";
            input Medium.ThermodynamicState[n] states "Thermodynamic states along design flow";
            input Modelica.SIunits.Velocity[n] vs "Mean velocities of fluid flow";
            parameter Real nParallel "number of identical parallel flow devices";
            input .Modelica.SIunits.Area[n] crossAreas "Cross flow areas at segment boundaries";
            input .Modelica.SIunits.Length[n] dimensions "Characteristic dimensions for fluid flow (diameters for pipe flow)";
            input .Modelica.SIunits.Height[n] roughnesses "Average height of surface asperities";
            input .Modelica.SIunits.Length[n - 1] dheights "Height(states[2:n]) - Height(states[1:n-1])";
            parameter .Modelica.SIunits.Acceleration g = system.g "Constant gravity acceleration";
            parameter Boolean allowFlowReversal = system.allowFlowReversal "= true to allow flow reversal, false restricts to design direction (states[1] -> states[n+1])" annotation(Evaluate = true);
            parameter Modelica.Fluid.Types.Dynamics momentumDynamics = system.momentumDynamics "Formulation of momentum balance" annotation(Evaluate = true);
            parameter Medium.MassFlowRate m_flow_start = system.m_flow_start "Start value of mass flow rates";
            parameter Medium.AbsolutePressure p_a_start "Start value for p[1] at design inflow";
            parameter Medium.AbsolutePressure p_b_start "Start value for p[n+1] at design outflow";
            extends Modelica.Fluid.Interfaces.PartialDistributedFlow(final m = n - 1);
            parameter Boolean useUpstreamScheme = true "= false to average upstream and downstream properties across flow segments" annotation(Evaluate = true);
            parameter Boolean use_Ib_flows = momentumDynamics <> Types.Dynamics.SteadyState "= true to consider differences in flow of momentum through boundaries" annotation(Evaluate = true);
            Medium.Density[n] rhos = if use_rho_nominal then fill(rho_nominal, n) else Medium.density(states);
            Medium.Density[n - 1] rhos_act "Actual density per segment";
            Medium.DynamicViscosity[n] mus = if use_mu_nominal then fill(mu_nominal, n) else Medium.dynamicViscosity(states);
            Medium.DynamicViscosity[n - 1] mus_act "Actual viscosity per segment";
            Modelica.SIunits.Pressure[n - 1] dps_fg(each start = (p_a_start - p_b_start) / (n - 1)) "pressure drop between states";
            parameter .Modelica.SIunits.ReynoldsNumber Re_turbulent = 4000 "Start of turbulent regime, depending on type of flow device";
            parameter Boolean show_Res = false "= true, if Reynolds numbers are included for plotting" annotation(Evaluate = true);
            .Modelica.SIunits.ReynoldsNumber[n] Res = Modelica.Fluid.Pipes.BaseClasses.CharacteristicNumbers.ReynoldsNumber(vs, rhos, mus, dimensions) if show_Res "Reynolds numbers";
            Medium.MassFlowRate[n - 1] m_flows_turbulent = {nParallel * (crossAreas[i] + crossAreas[i + 1]) / (dimensions[i] + dimensions[i + 1]) * mus_act[i] * Re_turbulent for i in 1:n - 1} if show_Res "Start of turbulent flow";
          protected
            parameter Boolean use_rho_nominal = false "= true, if rho_nominal is used, otherwise computed from medium" annotation(Evaluate = true);
            parameter .Modelica.SIunits.Density rho_nominal = Medium.density_pTX(Medium.p_default, Medium.T_default, Medium.X_default) "Nominal density (e.g., rho_liquidWater = 995, rho_air = 1.2)";
            parameter Boolean use_mu_nominal = false "= true, if mu_nominal is used, otherwise computed from medium" annotation(Evaluate = true);
            parameter .Modelica.SIunits.DynamicViscosity mu_nominal = Medium.dynamicViscosity(Medium.setState_pTX(Medium.p_default, Medium.T_default, Medium.X_default)) "Nominal dynamic viscosity (e.g., mu_liquidWater = 1e-3, mu_air = 1.8e-5)";
          equation
            if not allowFlowReversal then
              rhos_act = rhos[1:n - 1];
              mus_act = mus[1:n - 1];
            elseif not useUpstreamScheme then
              rhos_act = 0.5 * (rhos[1:n - 1] + rhos[2:n]);
              mus_act = 0.5 * (mus[1:n - 1] + mus[2:n]);
            else
              for i in 1:n - 1 loop
                rhos_act[i] = noEvent(if m_flows[i] > 0 then rhos[i] else rhos[i + 1]);
                mus_act[i] = noEvent(if m_flows[i] > 0 then mus[i] else mus[i + 1]);
              end for;
            end if;
            if use_Ib_flows then
              Ib_flows = nParallel * {rhos[i] * vs[i] * vs[i] * crossAreas[i] - rhos[i + 1] * vs[i + 1] * vs[i + 1] * crossAreas[i + 1] for i in 1:n - 1};
            else
              Ib_flows = zeros(n - 1);
            end if;
            Fs_p = nParallel * {0.5 * (crossAreas[i] + crossAreas[i + 1]) * (Medium.pressure(states[i + 1]) - Medium.pressure(states[i])) for i in 1:n - 1};
            dps_fg = {Fs_fg[i] / nParallel * 2 / (crossAreas[i] + crossAreas[i + 1]) for i in 1:n - 1};
          end PartialStaggeredFlowModel;

          partial model PartialGenericPipeFlow  "GenericPipeFlow: Pipe flow pressure loss and gravity with replaceable WallFriction package" 
            parameter Boolean from_dp = momentumDynamics >= Types.Dynamics.SteadyStateInitial "= true, use m_flow = f(dp), otherwise dp = f(m_flow)" annotation(Evaluate = true);
            extends Modelica.Fluid.Pipes.BaseClasses.FlowModels.PartialStaggeredFlowModel(final Re_turbulent = 4000);
            replaceable package WallFriction = Modelica.Fluid.Pipes.BaseClasses.WallFriction.Detailed constrainedby Modelica.Fluid.Pipes.BaseClasses.WallFriction.PartialWallFriction;
            input .Modelica.SIunits.Length[n - 1] pathLengths_internal "pathLengths used internally; to be defined by extending class";
            input .Modelica.SIunits.ReynoldsNumber[n - 1] Res_turbulent_internal = Re_turbulent * ones(n - 1) "Re_turbulent used internally; to be defined by extending class";
            parameter .Modelica.SIunits.AbsolutePressure dp_nominal "Nominal pressure loss (only for nominal models)";
            parameter .Modelica.SIunits.MassFlowRate m_flow_nominal "Nominal mass flow rate";
            parameter .Modelica.SIunits.MassFlowRate m_flow_small = if system.use_eps_Re then system.eps_m_flow * m_flow_nominal else system.m_flow_small "Within regularization if |m_flows| < m_flow_small (may be wider for large discontinuities in static head)";
          protected
            parameter .Modelica.SIunits.AbsolutePressure dp_small(start = 1, fixed = false) "Within regularization if |dp| < dp_small (may be wider for large discontinuities in static head)";
            final parameter Boolean constantPressureLossCoefficient = use_rho_nominal and (use_mu_nominal or not WallFriction.use_mu) "= true if the pressure loss does not depend on fluid states" annotation(Evaluate = true);
            final parameter Boolean continuousFlowReversal = not useUpstreamScheme or constantPressureLossCoefficient or not allowFlowReversal "= true if the pressure loss is continuous around zero flow" annotation(Evaluate = true);
            .Modelica.SIunits.Length[n - 1] diameters = 0.5 * (dimensions[1:n - 1] + dimensions[2:n]) "mean diameters between segments";
            .Modelica.SIunits.AbsolutePressure dp_fric_nominal = sum(WallFriction.pressureLoss_m_flow(m_flow_nominal / nParallel, rho_nominal, rho_nominal, mu_nominal, mu_nominal, pathLengths_internal, diameters, (crossAreas[1:n - 1] + crossAreas[2:n]) / 2, (roughnesses[1:n - 1] + roughnesses[2:n]) / 2, m_flow_small / nParallel, Res_turbulent_internal)) "pressure loss for nominal conditions";
          initial equation
            if system.use_eps_Re then
              dp_small = dp_fric_nominal / m_flow_nominal * m_flow_small;
            else
              dp_small = system.dp_small;
            end if;
          equation
            for i in 1:n - 1 loop
              assert(m_flows[i] > (-m_flow_small) or allowFlowReversal, "Reverting flow occurs even though allowFlowReversal is false");
            end for;
            if continuousFlowReversal then
              if from_dp and not WallFriction.dp_is_zero then
                m_flows = homotopy(actual = WallFriction.massFlowRate_dp(dps_fg - {g * dheights[i] * rhos_act[i] for i in 1:n - 1}, rhos_act, rhos_act, mus_act, mus_act, pathLengths_internal, diameters, (crossAreas[1:n - 1] + crossAreas[2:n]) / 2, (roughnesses[1:n - 1] + roughnesses[2:n]) / 2, dp_small / (n - 1), Res_turbulent_internal) * nParallel, simplified = m_flow_nominal / dp_nominal * (dps_fg - g * dheights * rho_nominal));
              else
                dps_fg = homotopy(actual = WallFriction.pressureLoss_m_flow(m_flows / nParallel, rhos_act, rhos_act, mus_act, mus_act, pathLengths_internal, diameters, (crossAreas[1:n - 1] + crossAreas[2:n]) / 2, (roughnesses[1:n - 1] + roughnesses[2:n]) / 2, m_flow_small / nParallel, Res_turbulent_internal) + {g * dheights[i] * rhos_act[i] for i in 1:n - 1}, simplified = dp_nominal / m_flow_nominal * m_flows + g * dheights * rho_nominal);
              end if;
            else
              if from_dp and not WallFriction.dp_is_zero then
                m_flows = homotopy(actual = WallFriction.massFlowRate_dp_staticHead(dps_fg, rhos[1:n - 1], rhos[2:n], mus[1:n - 1], mus[2:n], pathLengths_internal, diameters, g * dheights, (crossAreas[1:n - 1] + crossAreas[2:n]) / 2, (roughnesses[1:n - 1] + roughnesses[2:n]) / 2, dp_small / (n - 1), Res_turbulent_internal) * nParallel, simplified = m_flow_nominal / dp_nominal * (dps_fg - g * dheights * rho_nominal));
              else
                dps_fg = homotopy(actual = WallFriction.pressureLoss_m_flow_staticHead(m_flows / nParallel, rhos[1:n - 1], rhos[2:n], mus[1:n - 1], mus[2:n], pathLengths_internal, diameters, g * dheights, (crossAreas[1:n - 1] + crossAreas[2:n]) / 2, (roughnesses[1:n - 1] + roughnesses[2:n]) / 2, m_flow_small / nParallel, Res_turbulent_internal), simplified = dp_nominal / m_flow_nominal * m_flows + g * dheights * rho_nominal);
              end if;
            end if;
          end PartialGenericPipeFlow;

          model DetailedPipeFlow  "DetailedPipeFlow: Detailed characteristic for laminar and turbulent flow" 
            extends Modelica.Fluid.Pipes.BaseClasses.FlowModels.PartialGenericPipeFlow(redeclare package WallFriction = Modelica.Fluid.Pipes.BaseClasses.WallFriction.Detailed, pathLengths_internal = pathLengths, dp_nominal(start = 1, fixed = false), m_flow_nominal = if system.use_eps_Re then system.m_flow_nominal else 1e2 * m_flow_small, Res_turbulent_internal = Re_turbulent * ones(n - 1));
          initial equation
            if system.use_eps_Re then
              dp_nominal = dp_fric_nominal + g * sum(dheights) * rho_nominal;
            else
              dp_nominal = 1e3 * dp_small;
            end if;
          end DetailedPipeFlow;
        end FlowModels;

        package HeatTransfer  "Heat transfer for flow models" 
          extends Modelica.Icons.Package;

          partial model PartialFlowHeatTransfer  "base class for any pipe heat transfer correlation" 
            extends Modelica.Fluid.Interfaces.PartialHeatTransfer;
            input .Modelica.SIunits.Velocity[n] vs "Mean velocities of fluid flow in segments";
            parameter Real nParallel "number of identical parallel flow devices";
            input .Modelica.SIunits.Length[n] lengths "Lengths along flow path";
            input .Modelica.SIunits.Length[n] dimensions "Characteristic dimensions for fluid flow (diameter for pipe flow)";
            input .Modelica.SIunits.Height[n] roughnesses "Average heights of surface asperities";
          end PartialFlowHeatTransfer;

          model IdealFlowHeatTransfer  "IdealHeatTransfer: Ideal heat transfer without thermal resistance" 
            extends PartialFlowHeatTransfer;
          equation
            Ts = heatPorts.T;
          end IdealFlowHeatTransfer;

          partial model PartialPipeFlowHeatTransfer  "Base class for pipe heat transfer correlation in terms of Nusselt number heat transfer in a circular pipe for laminar and turbulent one-phase flow" 
            extends PartialFlowHeatTransfer;
            parameter .Modelica.SIunits.CoefficientOfHeatTransfer alpha0 = 100 "guess value for heat transfer coefficients";
            .Modelica.SIunits.CoefficientOfHeatTransfer[n] alphas(each start = alpha0) "CoefficientOfHeatTransfer";
            Real[n] Res "Reynolds numbers";
            Real[n] Prs "Prandtl numbers";
            Real[n] Nus "Nusselt numbers";
            Medium.Density[n] ds "Densities";
            Medium.DynamicViscosity[n] mus "Dynamic viscosities";
            Medium.ThermalConductivity[n] lambdas "Thermal conductivity";
            .Modelica.SIunits.Length[n] diameters = dimensions "Hydraulic diameters for pipe flow";
          equation
            ds = Medium.density(states);
            mus = Medium.dynamicViscosity(states);
            lambdas = Medium.thermalConductivity(states);
            Prs = Medium.prandtlNumber(states);
            Res = CharacteristicNumbers.ReynoldsNumber(vs, ds, mus, diameters);
            Nus = CharacteristicNumbers.NusseltNumber(alphas, diameters, lambdas);
            Q_flows = {alphas[i] * surfaceAreas[i] * (heatPorts[i].T - Ts[i]) * nParallel for i in 1:n};
          end PartialPipeFlowHeatTransfer;

          model LocalPipeFlowHeatTransfer  "LocalPipeFlowHeatTransfer: Laminar and turbulent forced convection in pipes, local coefficients" 
            extends PartialPipeFlowHeatTransfer;
          protected
            Real[n] Nus_turb "Nusselt number for turbulent flow";
            Real[n] Nus_lam "Nusselt number for laminar flow";
            Real Nu_1;
            Real[n] Nus_2;
            Real[n] Xis;
          equation
            Nu_1 = 3.66;
            for i in 1:n loop
              Nus_turb[i] = smooth(0, Xis[i] / 8 * abs(Res[i]) * Prs[i] / (1 + 12.7 * (Xis[i] / 8) ^ 0.5 * (Prs[i] ^ (2 / 3) - 1)) * (1 + 1 / 3 * (diameters[i] / lengths[i] / (if vs[i] >= 0 then i - 0.5 else n - i + 0.5)) ^ (2 / 3)));
              Xis[i] = (1.8 * Modelica.Math.log10(max(1e-10, Res[i])) - 1.5) ^ (-2);
              Nus_lam[i] = (Nu_1 ^ 3 + 0.7 ^ 3 + (Nus_2[i] - 0.7) ^ 3) ^ (1 / 3);
              Nus_2[i] = smooth(0, 1.077 * (abs(Res[i]) * Prs[i] * diameters[i] / lengths[i] / (if vs[i] >= 0 then i - 0.5 else n - i + 0.5)) ^ (1 / 3));
              Nus[i] = Modelica.Media.Air.MoistAir.Utilities.spliceFunction(Nus_turb[i], Nus_lam[i], Res[i] - 6150, 3850);
            end for;
          end LocalPipeFlowHeatTransfer;
        end HeatTransfer;

        package CharacteristicNumbers  "Functions to compute characteristic numbers" 
          extends Modelica.Icons.Package;

          function ReynoldsNumber  "Return Reynolds number from v, rho, mu, D" 
            extends Modelica.Icons.Function;
            input .Modelica.SIunits.Velocity v "Mean velocity of fluid flow";
            input .Modelica.SIunits.Density rho "Fluid density";
            input .Modelica.SIunits.DynamicViscosity mu "Dynamic (absolute) viscosity";
            input .Modelica.SIunits.Length D "Characteristic dimension (hydraulic diameter of pipes)";
            output .Modelica.SIunits.ReynoldsNumber Re "Reynolds number";
          algorithm
            Re := abs(v) * rho * D / mu;
          end ReynoldsNumber;

          function NusseltNumber  "Return Nusselt number" 
            extends Modelica.Icons.Function;
            input .Modelica.SIunits.CoefficientOfHeatTransfer alpha "Coefficient of heat transfer";
            input .Modelica.SIunits.Length D "Characteristic dimension";
            input .Modelica.SIunits.ThermalConductivity lambda "Thermal conductivity";
            output .Modelica.SIunits.NusseltNumber Nu "Nusselt number";
          algorithm
            Nu := alpha * D / lambda;
          end NusseltNumber;
        end CharacteristicNumbers;

        package WallFriction  "Different variants for pressure drops due to pipe wall friction" 
          extends Modelica.Icons.Package;

          partial package PartialWallFriction  "Partial wall friction characteristic (base package of all wall friction characteristics)" 
            extends Modelica.Icons.Package;
            constant Boolean use_mu = true "= true, if mu_a/mu_b are used in function, otherwise value is not used";
            constant Boolean use_roughness = true "= true, if roughness is used in function, otherwise value is not used";
            constant Boolean use_dp_small = true "= true, if dp_small is used in function, otherwise value is not used";
            constant Boolean use_m_flow_small = true "= true, if m_flow_small is used in function, otherwise value is not used";
            constant Boolean dp_is_zero = false "= true, if no wall friction is present, i.e., dp = 0 (function massFlowRate_dp() cannot be used)";
            constant Boolean use_Re_turbulent = true "= true, if Re_turbulent input is used in function, otherwise value is not used";

            replaceable partial function massFlowRate_dp  "Return mass flow rate m_flow as function of pressure loss dp, i.e., m_flow = f(dp), due to wall friction" 
              extends Modelica.Icons.Function;
              input .Modelica.SIunits.Pressure dp "Pressure loss (dp = port_a.p - port_b.p)";
              input .Modelica.SIunits.Density rho_a "Density at port_a";
              input .Modelica.SIunits.Density rho_b "Density at port_b";
              input .Modelica.SIunits.DynamicViscosity mu_a "Dynamic viscosity at port_a (dummy if use_mu = false)";
              input .Modelica.SIunits.DynamicViscosity mu_b "Dynamic viscosity at port_b (dummy if use_mu = false)";
              input .Modelica.SIunits.Length length "Length of pipe";
              input .Modelica.SIunits.Diameter diameter "Inner (hydraulic) diameter of pipe";
              input .Modelica.SIunits.Area crossArea = .Modelica.Constants.pi * diameter ^ 2 / 4 "Inner cross section area";
              input .Modelica.SIunits.Length roughness(min = 0) = 2.5e-5 "Absolute roughness of pipe, with a default for a smooth steel pipe (dummy if use_roughness = false)";
              input .Modelica.SIunits.AbsolutePressure dp_small = 1 "Regularization of zero flow if |dp| < dp_small (dummy if use_dp_small = false)";
              input .Modelica.SIunits.ReynoldsNumber Re_turbulent = 4000 "Turbulent flow if Re >= Re_turbulent (dummy if use_Re_turbulent = false)";
              output .Modelica.SIunits.MassFlowRate m_flow "Mass flow rate from port_a to port_b";
            end massFlowRate_dp;

            replaceable partial function massFlowRate_dp_staticHead  "Return mass flow rate m_flow as function of pressure loss dp, i.e., m_flow = f(dp), due to wall friction and static head" 
              extends Modelica.Icons.Function;
              input .Modelica.SIunits.Pressure dp "Pressure loss (dp = port_a.p - port_b.p)";
              input .Modelica.SIunits.Density rho_a "Density at port_a";
              input .Modelica.SIunits.Density rho_b "Density at port_b";
              input .Modelica.SIunits.DynamicViscosity mu_a "Dynamic viscosity at port_a (dummy if use_mu = false)";
              input .Modelica.SIunits.DynamicViscosity mu_b "Dynamic viscosity at port_b (dummy if use_mu = false)";
              input .Modelica.SIunits.Length length "Length of pipe";
              input .Modelica.SIunits.Diameter diameter "Inner (hydraulic) diameter of pipe";
              input Real g_times_height_ab "Gravity times (Height(port_b) - Height(port_a))";
              input .Modelica.SIunits.Area crossArea = .Modelica.Constants.pi * diameter ^ 2 / 4 "Inner cross section area";
              input .Modelica.SIunits.Length roughness(min = 0) = 2.5e-5 "Absolute roughness of pipe, with a default for a smooth steel pipe (dummy if use_roughness = false)";
              input .Modelica.SIunits.AbsolutePressure dp_small = 1 "Regularization of zero flow if |dp| < dp_small (dummy if use_dp_small = false)";
              input .Modelica.SIunits.ReynoldsNumber Re_turbulent = 4000 "Turbulent flow if Re >= Re_turbulent (dummy if use_Re_turbulent = false)";
              output .Modelica.SIunits.MassFlowRate m_flow "Mass flow rate from port_a to port_b";
            end massFlowRate_dp_staticHead;

            replaceable partial function pressureLoss_m_flow  "Return pressure loss dp as function of mass flow rate m_flow, i.e., dp = f(m_flow), due to wall friction" 
              extends Modelica.Icons.Function;
              input .Modelica.SIunits.MassFlowRate m_flow "Mass flow rate from port_a to port_b";
              input .Modelica.SIunits.Density rho_a "Density at port_a";
              input .Modelica.SIunits.Density rho_b "Density at port_b";
              input .Modelica.SIunits.DynamicViscosity mu_a "Dynamic viscosity at port_a (dummy if use_mu = false)";
              input .Modelica.SIunits.DynamicViscosity mu_b "Dynamic viscosity at port_b (dummy if use_mu = false)";
              input .Modelica.SIunits.Length length "Length of pipe";
              input .Modelica.SIunits.Diameter diameter "Inner (hydraulic) diameter of pipe";
              input .Modelica.SIunits.Area crossArea = .Modelica.Constants.pi * diameter ^ 2 / 4 "Inner cross section area";
              input .Modelica.SIunits.Length roughness(min = 0) = 2.5e-5 "Absolute roughness of pipe, with a default for a smooth steel pipe (dummy if use_roughness = false)";
              input .Modelica.SIunits.MassFlowRate m_flow_small = 0.01 "Regularization of zero flow if |m_flow| < m_flow_small (dummy if use_m_flow_small = false)";
              input .Modelica.SIunits.ReynoldsNumber Re_turbulent = 4000 "Turbulent flow if Re >= Re_turbulent (dummy if use_Re_turbulent = false)";
              output .Modelica.SIunits.Pressure dp "Pressure loss (dp = port_a.p - port_b.p)";
            end pressureLoss_m_flow;

            replaceable partial function pressureLoss_m_flow_staticHead  "Return pressure loss dp as function of mass flow rate m_flow, i.e., dp = f(m_flow), due to wall friction and static head" 
              extends Modelica.Icons.Function;
              input .Modelica.SIunits.MassFlowRate m_flow "Mass flow rate from port_a to port_b";
              input .Modelica.SIunits.Density rho_a "Density at port_a";
              input .Modelica.SIunits.Density rho_b "Density at port_b";
              input .Modelica.SIunits.DynamicViscosity mu_a "Dynamic viscosity at port_a (dummy if use_mu = false)";
              input .Modelica.SIunits.DynamicViscosity mu_b "Dynamic viscosity at port_b (dummy if use_mu = false)";
              input .Modelica.SIunits.Length length "Length of pipe";
              input .Modelica.SIunits.Diameter diameter "Inner (hydraulic) diameter of pipe";
              input Real g_times_height_ab "Gravity times (Height(port_b) - Height(port_a))";
              input .Modelica.SIunits.Area crossArea = .Modelica.Constants.pi * diameter ^ 2 / 4 "Inner cross section area";
              input .Modelica.SIunits.Length roughness(min = 0) = 2.5e-5 "Absolute roughness of pipe, with a default for a smooth steel pipe (dummy if use_roughness = false)";
              input .Modelica.SIunits.MassFlowRate m_flow_small = 0.01 "Regularization of zero flow if |m_flow| < m_flow_small (dummy if use_m_flow_small = false)";
              input .Modelica.SIunits.ReynoldsNumber Re_turbulent = 4000 "Turbulent flow if Re >= Re_turbulent (dummy if use_Re_turbulent = false)";
              output .Modelica.SIunits.Pressure dp "Pressure loss (dp = port_a.p - port_b.p)";
            end pressureLoss_m_flow_staticHead;
          end PartialWallFriction;

          package Detailed  "Pipe wall friction for laminar and turbulent flow (detailed characteristic)" 
            extends PartialWallFriction(final use_mu = true, final use_roughness = true, final use_dp_small = true, final use_m_flow_small = true, final use_Re_turbulent = true);

            redeclare function extends massFlowRate_dp  "Return mass flow rate m_flow as function of pressure loss dp, i.e., m_flow = f(dp), due to wall friction" 
            protected
              Real Delta = roughness / diameter "Relative roughness";
              .Modelica.SIunits.ReynoldsNumber Re1 = min((745 * .Modelica.Math.exp(if Delta <= 0.0065 then 1 else 0.0065 / Delta)) ^ 0.97, Re_turbulent) "Re leaving laminar curve";
              .Modelica.SIunits.ReynoldsNumber Re2 = Re_turbulent "Re entering turbulent curve";
              .Modelica.SIunits.DynamicViscosity mu "Upstream viscosity";
              .Modelica.SIunits.Density rho "Upstream density";
              .Modelica.SIunits.ReynoldsNumber Re "Reynolds number";
              Real lambda2 "Modified friction coefficient (= lambda*Re^2)";

              function interpolateInRegion2  
                input Real Re_turbulent;
                input .Modelica.SIunits.ReynoldsNumber Re1;
                input .Modelica.SIunits.ReynoldsNumber Re2;
                input Real Delta;
                input Real lambda2;
                output .Modelica.SIunits.ReynoldsNumber Re;
              protected
                Real x1 = .Modelica.Math.log10(64 * Re1);
                Real y1 = .Modelica.Math.log10(Re1);
                Real yd1 = 1;
                Real aux1 = 0.5 / .Modelica.Math.log(10) * 5.74 * 0.9;
                Real aux2 = Delta / 3.7 + 5.74 / Re2 ^ 0.9;
                Real aux3 = .Modelica.Math.log10(aux2);
                Real L2 = 0.25 * (Re2 / aux3) ^ 2;
                Real aux4 = 2.51 / sqrt(L2) + 0.27 * Delta;
                Real aux5 = -2 * sqrt(L2) * .Modelica.Math.log10(aux4);
                Real x2 = .Modelica.Math.log10(L2);
                Real y2 = .Modelica.Math.log10(aux5);
                Real yd2 = 0.5 + 2.51 / .Modelica.Math.log(10) / (aux5 * aux4);
                Real diff_x = x2 - x1;
                Real m = (y2 - y1) / diff_x;
                Real c2 = (3 * m - 2 * yd1 - yd2) / diff_x;
                Real c3 = (yd1 + yd2 - 2 * m) / (diff_x * diff_x);
                Real lambda2_1 = 64 * Re1;
                Real dx;
              algorithm
                dx := .Modelica.Math.log10(lambda2 / lambda2_1);
                Re := Re1 * (lambda2 / lambda2_1) ^ (1 + dx * (c2 + dx * c3));
                annotation(smoothOrder = 1); 
              end interpolateInRegion2;
            algorithm
              rho := if dp >= 0 then rho_a else rho_b;
              mu := if dp >= 0 then mu_a else mu_b;
              lambda2 := abs(dp) * 2 * diameter ^ 3 * rho / (length * mu * mu);
              Re := lambda2 / 64;
              if Re > Re1 then
                Re := -2 * sqrt(lambda2) * .Modelica.Math.log10(2.51 / sqrt(lambda2) + 0.27 * Delta);
                if Re < Re2 then
                  Re := interpolateInRegion2(Re, Re1, Re2, Delta, lambda2);
                else
                end if;
              else
              end if;
              m_flow := crossArea / diameter * mu * (if dp >= 0 then Re else -Re);
              annotation(smoothOrder = 1); 
            end massFlowRate_dp;

            redeclare function extends pressureLoss_m_flow  "Return pressure loss dp as function of mass flow rate m_flow, i.e., dp = f(m_flow), due to wall friction" 
            protected
              Real Delta = roughness / diameter "Relative roughness";
              .Modelica.SIunits.ReynoldsNumber Re1 = min(745 * .Modelica.Math.exp(if Delta <= 0.0065 then 1 else 0.0065 / Delta), Re_turbulent) "Re leaving laminar curve";
              .Modelica.SIunits.ReynoldsNumber Re2 = Re_turbulent "Re entering turbulent curve";
              .Modelica.SIunits.DynamicViscosity mu "Upstream viscosity";
              .Modelica.SIunits.Density rho "Upstream density";
              .Modelica.SIunits.ReynoldsNumber Re "Reynolds number";
              Real lambda2 "Modified friction coefficient (= lambda*Re^2)";

              function interpolateInRegion2  
                input .Modelica.SIunits.ReynoldsNumber Re;
                input .Modelica.SIunits.ReynoldsNumber Re1;
                input .Modelica.SIunits.ReynoldsNumber Re2;
                input Real Delta;
                output Real lambda2;
              protected
                Real x1 = .Modelica.Math.log10(Re1);
                Real y1 = .Modelica.Math.log10(64 * Re1);
                Real yd1 = 1;
                Real aux1 = 0.5 / .Modelica.Math.log(10) * 5.74 * 0.9;
                Real aux2 = Delta / 3.7 + 5.74 / Re2 ^ 0.9;
                Real aux3 = .Modelica.Math.log10(aux2);
                Real L2 = 0.25 * (Re2 / aux3) ^ 2;
                Real aux4 = 2.51 / sqrt(L2) + 0.27 * Delta;
                Real aux5 = -2 * sqrt(L2) * .Modelica.Math.log10(aux4);
                Real x2 = .Modelica.Math.log10(Re2);
                Real y2 = .Modelica.Math.log10(L2);
                Real yd2 = 2 + 4 * aux1 / (aux2 * aux3 * Re2 ^ 0.9);
                Real diff_x = x2 - x1;
                Real m = (y2 - y1) / diff_x;
                Real c2 = (3 * m - 2 * yd1 - yd2) / diff_x;
                Real c3 = (yd1 + yd2 - 2 * m) / (diff_x * diff_x);
                Real dx;
              algorithm
                dx := .Modelica.Math.log10(Re / Re1);
                lambda2 := 64 * Re1 * (Re / Re1) ^ (1 + dx * (c2 + dx * c3));
                annotation(smoothOrder = 1); 
              end interpolateInRegion2;
            algorithm
              rho := if m_flow >= 0 then rho_a else rho_b;
              mu := if m_flow >= 0 then mu_a else mu_b;
              Re := diameter * abs(m_flow) / (crossArea * mu);
              lambda2 := if Re <= Re1 then 64 * Re else if Re >= Re2 then 0.25 * (Re / .Modelica.Math.log10(Delta / 3.7 + 5.74 / Re ^ 0.9)) ^ 2 else interpolateInRegion2(Re, Re1, Re2, Delta);
              dp := length * mu * mu / (2 * rho * diameter * diameter * diameter) * (if m_flow >= 0 then lambda2 else -lambda2);
              annotation(smoothOrder = 1); 
            end pressureLoss_m_flow;

            redeclare function extends massFlowRate_dp_staticHead  "Return mass flow rate m_flow as function of pressure loss dp, i.e., m_flow = f(dp), due to wall friction and static head" 
            protected
              Real Delta = roughness / diameter "Relative roughness";
              .Modelica.SIunits.ReynoldsNumber Re "Reynolds number";
              .Modelica.SIunits.ReynoldsNumber Re1 = min((745 * .Modelica.Math.exp(if Delta <= 0.0065 then 1 else 0.0065 / Delta)) ^ 0.97, Re_turbulent) "Boundary between laminar regime and transition";
              .Modelica.SIunits.ReynoldsNumber Re2 = Re_turbulent "Boundary between transition and turbulent regime";
              .Modelica.SIunits.Pressure dp_a "Upper end of regularization domain of the m_flow(dp) relation";
              .Modelica.SIunits.Pressure dp_b "Lower end of regularization domain of the m_flow(dp) relation";
              .Modelica.SIunits.MassFlowRate m_flow_a "Value at upper end of regularization domain";
              .Modelica.SIunits.MassFlowRate m_flow_b "Value at lower end of regularization domain";
              .Modelica.SIunits.MassFlowRate dm_flow_ddp_fric_a "Derivative at upper end of regularization domain";
              .Modelica.SIunits.MassFlowRate dm_flow_ddp_fric_b "Derivative at lower end of regularization domain";
              .Modelica.SIunits.Pressure dp_grav_a = g_times_height_ab * rho_a "Static head if mass flows in design direction (a to b)";
              .Modelica.SIunits.Pressure dp_grav_b = g_times_height_ab * rho_b "Static head if mass flows against design direction (b to a)";
              .Modelica.SIunits.MassFlowRate m_flow_zero = 0;
              .Modelica.SIunits.Pressure dp_zero = (dp_grav_a + dp_grav_b) / 2;
              Real dm_flow_ddp_fric_zero;
            algorithm
              dp_a := max(dp_grav_a, dp_grav_b) + dp_small;
              dp_b := min(dp_grav_a, dp_grav_b) - dp_small;
              if dp >= dp_a then
                m_flow := Internal.m_flow_of_dp_fric(dp - dp_grav_a, rho_a, rho_b, mu_a, mu_b, length, diameter, crossArea, Re1, Re2, Delta);
              elseif dp <= dp_b then
                m_flow := Internal.m_flow_of_dp_fric(dp - dp_grav_b, rho_a, rho_b, mu_a, mu_b, length, diameter, crossArea, Re1, Re2, Delta);
              else
                (m_flow_a, dm_flow_ddp_fric_a) := Internal.m_flow_of_dp_fric(dp_a - dp_grav_a, rho_a, rho_b, mu_a, mu_b, length, diameter, crossArea, Re1, Re2, Delta);
                (m_flow_b, dm_flow_ddp_fric_b) := Internal.m_flow_of_dp_fric(dp_b - dp_grav_b, rho_a, rho_b, mu_a, mu_b, length, diameter, crossArea, Re1, Re2, Delta);
                (m_flow, dm_flow_ddp_fric_zero) := Utilities.regFun3(dp_zero, dp_b, dp_a, m_flow_b, m_flow_a, dm_flow_ddp_fric_b, dm_flow_ddp_fric_a);
                if dp > dp_zero then
                  m_flow := Utilities.regFun3(dp, dp_zero, dp_a, m_flow_zero, m_flow_a, dm_flow_ddp_fric_zero, dm_flow_ddp_fric_a);
                else
                  m_flow := Utilities.regFun3(dp, dp_b, dp_zero, m_flow_b, m_flow_zero, dm_flow_ddp_fric_b, dm_flow_ddp_fric_zero);
                end if;
              end if;
              annotation(smoothOrder = 1); 
            end massFlowRate_dp_staticHead;

            redeclare function extends pressureLoss_m_flow_staticHead  "Return pressure loss dp as function of mass flow rate m_flow, i.e., dp = f(m_flow), due to wall friction and static head" 
            protected
              Real Delta = roughness / diameter "Relative roughness";
              .Modelica.SIunits.ReynoldsNumber Re1 = min(745 * .Modelica.Math.exp(if Delta <= 0.0065 then 1 else 0.0065 / Delta), Re_turbulent) "Boundary between laminar regime and transition";
              .Modelica.SIunits.ReynoldsNumber Re2 = Re_turbulent "Boundary between transition and turbulent regime";
              .Modelica.SIunits.MassFlowRate m_flow_a "Upper end of regularization domain of the dp(m_flow) relation";
              .Modelica.SIunits.MassFlowRate m_flow_b "Lower end of regularization domain of the dp(m_flow) relation";
              .Modelica.SIunits.Pressure dp_a "Value at upper end of regularization domain";
              .Modelica.SIunits.Pressure dp_b "Value at lower end of regularization domain";
              .Modelica.SIunits.Pressure dp_grav_a = g_times_height_ab * rho_a "Static head if mass flows in design direction (a to b)";
              .Modelica.SIunits.Pressure dp_grav_b = g_times_height_ab * rho_b "Static head if mass flows against design direction (b to a)";
              Real ddp_dm_flow_a "Derivative of pressure drop with mass flow rate at m_flow_a";
              Real ddp_dm_flow_b "Derivative of pressure drop with mass flow rate at m_flow_b";
              .Modelica.SIunits.MassFlowRate m_flow_zero = 0;
              .Modelica.SIunits.Pressure dp_zero = (dp_grav_a + dp_grav_b) / 2;
              Real ddp_dm_flow_zero;
            algorithm
              m_flow_a := if dp_grav_a < dp_grav_b then Internal.m_flow_of_dp_fric(dp_grav_b - dp_grav_a, rho_a, rho_b, mu_a, mu_b, length, diameter, crossArea, Re1, Re2, Delta) + m_flow_small else m_flow_small;
              m_flow_b := if dp_grav_a < dp_grav_b then Internal.m_flow_of_dp_fric(dp_grav_a - dp_grav_b, rho_a, rho_b, mu_a, mu_b, length, diameter, crossArea, Re1, Re2, Delta) - m_flow_small else -m_flow_small;
              if m_flow >= m_flow_a then
                dp := Internal.dp_fric_of_m_flow(m_flow, rho_a, rho_b, mu_a, mu_b, length, diameter, crossArea, Re1, Re2, Delta) + dp_grav_a;
              elseif m_flow <= m_flow_b then
                dp := Internal.dp_fric_of_m_flow(m_flow, rho_a, rho_b, mu_a, mu_b, length, diameter, crossArea, Re1, Re2, Delta) + dp_grav_b;
              else
                (dp_a, ddp_dm_flow_a) := Internal.dp_fric_of_m_flow(m_flow_a, rho_a, rho_b, mu_a, mu_b, length, diameter, crossArea, Re1, Re2, Delta);
                dp_a := dp_a + dp_grav_a "Adding dp_grav to dp_fric to get dp";
                (dp_b, ddp_dm_flow_b) := Internal.dp_fric_of_m_flow(m_flow_b, rho_a, rho_b, mu_a, mu_b, length, diameter, crossArea, Re1, Re2, Delta);
                dp_b := dp_b + dp_grav_b "Adding dp_grav to dp_fric to get dp";
                (dp, ddp_dm_flow_zero) := Utilities.regFun3(m_flow_zero, m_flow_b, m_flow_a, dp_b, dp_a, ddp_dm_flow_b, ddp_dm_flow_a);
                if m_flow > m_flow_zero then
                  dp := Utilities.regFun3(m_flow, m_flow_zero, m_flow_a, dp_zero, dp_a, ddp_dm_flow_zero, ddp_dm_flow_a);
                else
                  dp := Utilities.regFun3(m_flow, m_flow_b, m_flow_zero, dp_b, dp_zero, ddp_dm_flow_b, ddp_dm_flow_zero);
                end if;
              end if;
              annotation(smoothOrder = 1); 
            end pressureLoss_m_flow_staticHead;

            package Internal  "Functions to calculate mass flow rate from friction pressure drop and vice versa" 
              extends Modelica.Icons.InternalPackage;

              function m_flow_of_dp_fric  "Calculate mass flow rate as function of pressure drop due to friction" 
                extends Modelica.Icons.Function;
                input .Modelica.SIunits.Pressure dp_fric "Pressure loss due to friction (dp = port_a.p - port_b.p)";
                input .Modelica.SIunits.Density rho_a "Density at port_a";
                input .Modelica.SIunits.Density rho_b "Density at port_b";
                input .Modelica.SIunits.DynamicViscosity mu_a "Dynamic viscosity at port_a (dummy if use_mu = false)";
                input .Modelica.SIunits.DynamicViscosity mu_b "Dynamic viscosity at port_b (dummy if use_mu = false)";
                input .Modelica.SIunits.Length length "Length of pipe";
                input .Modelica.SIunits.Diameter diameter "Inner (hydraulic) diameter of pipe";
                input .Modelica.SIunits.Area crossArea "Inner cross section area";
                input .Modelica.SIunits.ReynoldsNumber Re1 "Boundary between laminar regime and transition";
                input .Modelica.SIunits.ReynoldsNumber Re2 "Boundary between transition and turbulent regime";
                input Real Delta "Relative roughness";
                output .Modelica.SIunits.MassFlowRate m_flow "Mass flow rate from port_a to port_b";
                output Real dm_flow_ddp_fric "Derivative of mass flow rate with dp_fric";

              protected
                function interpolateInRegion2_withDerivative  "Interpolation in log-log space using a cubic Hermite polynomial, where x=log10(lambda2), y=log10(Re)" 
                  input Real lambda2 "Known independent variable";
                  input .Modelica.SIunits.ReynoldsNumber Re1 "Boundary between laminar regime and transition";
                  input .Modelica.SIunits.ReynoldsNumber Re2 "Boundary between transition and turbulent regime";
                  input Real Delta "Relative roughness";
                  input .Modelica.SIunits.Pressure dp_fric "Pressure loss due to friction (dp = port_a.p - port_b.p)";
                  output .Modelica.SIunits.ReynoldsNumber Re "Unknown return variable";
                  output Real dRe_ddp "Derivative of return value";
                protected
                  Real x1 = .Modelica.Math.log10(64 * Re1);
                  Real y1 = .Modelica.Math.log10(Re1);
                  Real y1d = 1;
                  Real aux2 = Delta / 3.7 + 5.74 / Re2 ^ 0.9;
                  Real aux3 = .Modelica.Math.log10(aux2);
                  Real L2 = 0.25 * (Re2 / aux3) ^ 2;
                  Real aux4 = 2.51 / sqrt(L2) + 0.27 * Delta;
                  Real aux5 = -2 * sqrt(L2) * .Modelica.Math.log10(aux4);
                  Real x2 = .Modelica.Math.log10(L2);
                  Real y2 = .Modelica.Math.log10(aux5);
                  Real y2d = 0.5 + 2.51 / log(10) / (aux5 * aux4);
                  Real x = .Modelica.Math.log10(lambda2);
                  Real y;
                  Real dy_dx "Derivative in transformed space";
                algorithm
                  (y, dy_dx) := Utilities.cubicHermite_withDerivative(x, x1, x2, y1, y2, y1d, y2d);
                  Re := 10 ^ y;
                  dRe_ddp := Re / abs(dp_fric) * dy_dx;
                  annotation(smoothOrder = 1); 
                end interpolateInRegion2_withDerivative;

                .Modelica.SIunits.DynamicViscosity mu "Upstream viscosity";
                .Modelica.SIunits.Density rho "Upstream density";
                Real lambda2 "Modified friction coefficient (= lambda*Re^2)";
                .Modelica.SIunits.ReynoldsNumber Re "Reynolds number";
                Real dRe_ddp "dRe/ddp";
                Real aux1;
                Real aux2;
              algorithm
                if dp_fric >= 0 then
                  rho := rho_a;
                  mu := mu_a;
                else
                  rho := rho_b;
                  mu := mu_b;
                end if;
                lambda2 := abs(dp_fric) * 2 * diameter ^ 3 * rho / (length * mu * mu) "Known as lambda2=f(dp)";
                aux1 := 2 * diameter ^ 3 * rho / (length * mu ^ 2);
                Re := lambda2 / 64 "Hagen-Poiseuille";
                dRe_ddp := aux1 / 64 "Hagen-Poiseuille";
                if Re > Re1 then
                  Re := -2 * sqrt(lambda2) * .Modelica.Math.log10(2.51 / sqrt(lambda2) + 0.27 * Delta) "Colebrook-White";
                  aux2 := sqrt(aux1 * abs(dp_fric));
                  dRe_ddp := 1 / log(10) * ((-2 * log(2.51 / aux2 + 0.27 * Delta) * aux1 / (2 * aux2)) + 2 * 2.51 / (2 * abs(dp_fric) * (2.51 / aux2 + 0.27 * Delta)));
                  if Re < Re2 then
                    (Re, dRe_ddp) := interpolateInRegion2_withDerivative(lambda2, Re1, Re2, Delta, dp_fric);
                  else
                  end if;
                else
                end if;
                m_flow := crossArea / diameter * mu * (if dp_fric >= 0 then Re else -Re);
                dm_flow_ddp_fric := crossArea / diameter * mu * dRe_ddp;
                annotation(smoothOrder = 1); 
              end m_flow_of_dp_fric;

              function dp_fric_of_m_flow  "Calculate pressure drop due to friction as function of mass flow rate" 
                extends Modelica.Icons.Function;
                input .Modelica.SIunits.MassFlowRate m_flow "Mass flow rate from port_a to port_b";
                input .Modelica.SIunits.Density rho_a "Density at port_a";
                input .Modelica.SIunits.Density rho_b "Density at port_b";
                input .Modelica.SIunits.DynamicViscosity mu_a "Dynamic viscosity at port_a (dummy if use_mu = false)";
                input .Modelica.SIunits.DynamicViscosity mu_b "Dynamic viscosity at port_b (dummy if use_mu = false)";
                input .Modelica.SIunits.Length length "Length of pipe";
                input .Modelica.SIunits.Diameter diameter "Inner (hydraulic) diameter of pipe";
                input .Modelica.SIunits.Area crossArea "Inner cross section area";
                input .Modelica.SIunits.ReynoldsNumber Re1 "Boundary between laminar regime and transition";
                input .Modelica.SIunits.ReynoldsNumber Re2 "Boundary between transition and turbulent regime";
                input Real Delta "Relative roughness";
                output .Modelica.SIunits.Pressure dp_fric "Pressure loss due to friction (dp_fric = port_a.p - port_b.p - dp_grav)";
                output Real ddp_fric_dm_flow "Derivative of pressure drop with mass flow rate";

              protected
                function interpolateInRegion2  "Interpolation in log-log space using a cubic Hermite polynomial, where x=log10(Re), y=log10(lambda2)" 
                  input .Modelica.SIunits.ReynoldsNumber Re "Known independent variable";
                  input .Modelica.SIunits.ReynoldsNumber Re1 "Boundary between laminar regime and transition";
                  input .Modelica.SIunits.ReynoldsNumber Re2 "Boundary between transition and turbulent regime";
                  input Real Delta "Relative roughness";
                  input .Modelica.SIunits.MassFlowRate m_flow "Mass flow rate from port_a to port_b";
                  output Real lambda2 "Unknown return value";
                  output Real dlambda2_dm_flow "Derivative of return value";
                protected
                  Real x1 = .Modelica.Math.log10(Re1);
                  Real y1 = .Modelica.Math.log10(64 * Re1);
                  Real y1d = 1;
                  Real aux2 = Delta / 3.7 + 5.74 / Re2 ^ 0.9;
                  Real aux3 = .Modelica.Math.log10(aux2);
                  Real L2 = 0.25 * (Re2 / aux3) ^ 2;
                  Real x2 = .Modelica.Math.log10(Re2);
                  Real y2 = .Modelica.Math.log10(L2);
                  Real y2d = 2 + 2 * 5.74 * 0.9 / (log(aux2) * Re2 ^ 0.9 * aux2);
                  Real x = .Modelica.Math.log10(Re);
                  Real y;
                  Real dy_dx "Derivative in transformed space";
                algorithm
                  (y, dy_dx) := Utilities.cubicHermite_withDerivative(x, x1, x2, y1, y2, y1d, y2d);
                  lambda2 := 10 ^ y;
                  dlambda2_dm_flow := lambda2 / abs(m_flow) * dy_dx;
                  annotation(smoothOrder = 1); 
                end interpolateInRegion2;

                .Modelica.SIunits.DynamicViscosity mu "Upstream viscosity";
                .Modelica.SIunits.Density rho "Upstream density";
                .Modelica.SIunits.ReynoldsNumber Re "Reynolds number";
                Real lambda2 "Modified friction coefficient (= lambda*Re^2)";
                Real dlambda2_dm_flow "dlambda2/dm_flow";
                Real aux1;
                Real aux2;
              algorithm
                if m_flow >= 0 then
                  rho := rho_a;
                  mu := mu_a;
                else
                  rho := rho_b;
                  mu := mu_b;
                end if;
                Re := abs(m_flow) * diameter / (crossArea * mu);
                aux1 := diameter / (crossArea * mu);
                if Re <= Re1 then
                  lambda2 := 64 * Re "Hagen-Poiseuille";
                  dlambda2_dm_flow := 64 * aux1 "Hagen-Poiseuille";
                elseif Re >= Re2 then
                  lambda2 := 0.25 * (Re / .Modelica.Math.log10(Delta / 3.7 + 5.74 / Re ^ 0.9)) ^ 2 "Swamee-Jain";
                  aux2 := Delta / 3.7 + 5.74 / (aux1 * abs(m_flow)) ^ 0.9;
                  dlambda2_dm_flow := 0.5 * aux1 * Re * log(10) ^ 2 * (1 / log(aux2) ^ 2 + 5.74 * 0.9 / (log(aux2) ^ 3 * Re ^ 0.9 * aux2)) "Swamee-Jain";
                else
                  (lambda2, dlambda2_dm_flow) := interpolateInRegion2(Re, Re1, Re2, Delta, m_flow);
                end if;
                dp_fric := length * mu * mu / (2 * rho * diameter * diameter * diameter) * (if m_flow >= 0 then lambda2 else -lambda2);
                ddp_fric_dm_flow := length * mu ^ 2 / (2 * diameter ^ 3 * rho) * dlambda2_dm_flow;
                annotation(smoothOrder = 1); 
              end dp_fric_of_m_flow;
            end Internal;
          end Detailed;
        end WallFriction;
      end BaseClasses;
    end Pipes;

    package Valves  "Components for the regulation and control of fluid flow" 
      extends Modelica.Icons.VariantsPackage;

      model ValveCompressible  "Valve for compressible fluids, accounts for choked flow conditions" 
        extends BaseClasses.PartialValve;
        parameter Medium.AbsolutePressure p_nominal "Nominal inlet pressure";
        parameter Real Fxt_full = 0.5 "Fk*xt critical ratio at full opening";
        replaceable function xtCharacteristic = Modelica.Fluid.Valves.BaseClasses.ValveCharacteristics.one constrainedby Modelica.Fluid.Valves.BaseClasses.ValveCharacteristics.baseFun;
        Real Fxt;
        Real x "Pressure drop ratio";
        Real xs "Saturated pressure drop ratio";
        Real Y "Compressibility factor";
        Medium.AbsolutePressure p "Inlet pressure";
        constant .Modelica.SIunits.ReynoldsNumber Re_turbulent = 4000 "cf. straight pipe for fully open valve -- dp_turbulent increases for closing valve";
        parameter Boolean use_Re = system.use_eps_Re "= true, if turbulent region is defined by Re, otherwise by m_flow_small" annotation(Evaluate = true);
        .Modelica.SIunits.AbsolutePressure dp_turbulent = if not use_Re then dp_small else max(dp_small, (Medium.dynamicViscosity(state_a) + Medium.dynamicViscosity(state_b)) ^ 2 * .Modelica.Constants.pi / 8 * Re_turbulent ^ 2 / (max(valveCharacteristic(opening_actual), 0.001) * Av * Y * (Medium.density(state_a) + Medium.density(state_b))));
      protected
        parameter Real Fxt_nominal(fixed = false) "Nominal Fxt";
        parameter Real x_nominal(fixed = false) "Nominal pressure drop ratio";
        parameter Real xs_nominal(fixed = false) "Nominal saturated pressure drop ratio";
        parameter Real Y_nominal(fixed = false) "Nominal compressibility factor";
      initial equation
        if CvData == .Modelica.Fluid.Types.CvTypes.OpPoint then
          Fxt_nominal = Fxt_full * xtCharacteristic(opening_nominal);
          x_nominal = dp_nominal / p_nominal;
          xs_nominal = smooth(0, if x_nominal > Fxt_nominal then Fxt_nominal else x_nominal);
          Y_nominal = 1 - abs(xs_nominal) / (3 * Fxt_nominal);
          m_flow_nominal = valveCharacteristic(opening_nominal) * Av * Y_nominal * sqrt(rho_nominal) * Utilities.regRoot(p_nominal * xs_nominal, dp_small);
        else
          Fxt_nominal = 0;
          x_nominal = 0;
          xs_nominal = 0;
          Y_nominal = 0;
        end if;
      equation
        p = max(port_a.p, port_b.p);
        Fxt = Fxt_full * xtCharacteristic(opening_actual);
        x = dp / p;
        xs = max(-Fxt, min(x, Fxt));
        Y = 1 - abs(xs) / (3 * Fxt);
        if checkValve then
          m_flow = homotopy(valveCharacteristic(opening_actual) * Av * Y * sqrt(Medium.density(state_a)) * (if xs >= 0 then Utilities.regRoot(p * xs, dp_turbulent) else 0), valveCharacteristic(opening_actual) * m_flow_nominal * dp / dp_nominal);
        elseif not allowFlowReversal then
          m_flow = homotopy(valveCharacteristic(opening_actual) * Av * Y * sqrt(Medium.density(state_a)) * Utilities.regRoot(p * xs, dp_turbulent), valveCharacteristic(opening_actual) * m_flow_nominal * dp / dp_nominal);
        else
          m_flow = homotopy(valveCharacteristic(opening_actual) * Av * Y * Utilities.regRoot2(p * xs, dp_turbulent, Medium.density(state_a), Medium.density(state_b)), valveCharacteristic(opening_actual) * m_flow_nominal * dp / dp_nominal);
        end if;
      end ValveCompressible;

      package BaseClasses  "Base classes used in the Valves package (only of interest to build new component models)" 
        extends Modelica.Icons.BasesPackage;

        partial model PartialValve  "Base model for valves" 
          extends Modelica.Fluid.Interfaces.PartialTwoPortTransport(dp_start = dp_nominal, m_flow_small = if system.use_eps_Re then system.eps_m_flow * m_flow_nominal else system.m_flow_small, m_flow_start = m_flow_nominal);
          parameter Modelica.Fluid.Types.CvTypes CvData = Modelica.Fluid.Types.CvTypes.OpPoint "Selection of flow coefficient";
          parameter .Modelica.SIunits.Area Av(fixed = if CvData == Modelica.Fluid.Types.CvTypes.Av then true else false, start = m_flow_nominal / sqrt(rho_nominal * dp_nominal) * valveCharacteristic(opening_nominal)) "Av (metric) flow coefficient";
          parameter Real Kv = 0 "Kv (metric) flow coefficient [m3/h]";
          parameter Real Cv = 0 "Cv (US) flow coefficient [USG/min]";
          parameter .Modelica.SIunits.Pressure dp_nominal "Nominal pressure drop";
          parameter Medium.MassFlowRate m_flow_nominal "Nominal mass flowrate";
          parameter Medium.Density rho_nominal = Medium.density_pTX(Medium.p_default, Medium.T_default, Medium.X_default) "Nominal inlet density";
          parameter Real opening_nominal(min = 0, max = 1) = 1 "Nominal opening";
          parameter Boolean filteredOpening = false "= true, if opening is filtered with a 2nd order CriticalDamping filter";
          parameter Modelica.SIunits.Time riseTime = 1 "Rise time of the filter (time to reach 99.6 % of an opening step)";
          parameter Real leakageOpening(min = 0, max = 1) = 1e-3 "The opening signal is limited by leakageOpening (to improve the numerics)";
          parameter Boolean checkValve = false "Reverse flow stopped";
          replaceable function valveCharacteristic = Modelica.Fluid.Valves.BaseClasses.ValveCharacteristics.linear constrainedby Modelica.Fluid.Valves.BaseClasses.ValveCharacteristics.baseFun;
        protected
          parameter .Modelica.SIunits.Pressure dp_small = if system.use_eps_Re then dp_nominal / m_flow_nominal * m_flow_small else system.dp_small "Regularisation of zero flow";
        public
          constant .Modelica.SIunits.Area Kv2Av = 27.7e-6 "Conversion factor";
          constant .Modelica.SIunits.Area Cv2Av = 24.0e-6 "Conversion factor";
          Modelica.Blocks.Interfaces.RealInput opening(min = 0, max = 1) "Valve position in the range 0..1";
          Modelica.Blocks.Interfaces.RealOutput opening_filtered if filteredOpening "Filtered valve position in the range 0..1";
          Modelica.Blocks.Continuous.Filter filter(order = 2, f_cut = 5 / (2 * Modelica.Constants.pi * riseTime)) if filteredOpening;
        protected
          Modelica.Blocks.Interfaces.RealOutput opening_actual;

          block MinLimiter  "Limit the signal above a threshold" 
            parameter Real uMin = 0 "Lower limit of input signal";
            extends Modelica.Blocks.Interfaces.SISO;
          equation
            y = smooth(0, noEvent(if u < uMin then uMin else u));
          end MinLimiter;

          MinLimiter minLimiter(uMin = leakageOpening);
        initial equation
          if CvData == .Modelica.Fluid.Types.CvTypes.Kv then
            Av = Kv * Kv2Av "Unit conversion";
          elseif CvData == .Modelica.Fluid.Types.CvTypes.Cv then
            Av = Cv * Cv2Av "Unit conversion";
          end if;
        equation
          port_a.h_outflow = inStream(port_b.h_outflow);
          port_b.h_outflow = inStream(port_a.h_outflow);
          connect(filter.y, opening_filtered);
          if filteredOpening then
            connect(filter.y, opening_actual);
          else
            connect(opening, opening_actual);
          end if;
          connect(minLimiter.y, filter.u);
          connect(minLimiter.u, opening);
        end PartialValve;

        package ValveCharacteristics  "Functions for valve characteristics" 
          extends Modelica.Icons.VariantsPackage;

          partial function baseFun  "Base class for valve characteristics" 
            extends Modelica.Icons.Function;
            input Real pos(min = 0, max = 1) "Opening position (0: closed, 1: fully open)";
            output Real rc "Relative flow coefficient (per unit)";
          end baseFun;

          function linear  "Linear characteristic" 
            extends baseFun;
          algorithm
            rc := pos;
          end linear;

          function one  "Constant characteristic" 
            extends baseFun;
          algorithm
            rc := 1;
          end one;
        end ValveCharacteristics;
      end BaseClasses;
    end Valves;

    package Sources  "Define fixed or prescribed boundary conditions" 
      extends Modelica.Icons.SourcesPackage;

      model Boundary_pT  "Boundary with prescribed pressure, temperature, composition and trace substances" 
        extends Sources.BaseClasses.PartialSource;
        parameter Boolean use_p_in = false "Get the pressure from the input connector" annotation(Evaluate = true, HideResult = true);
        parameter Boolean use_T_in = false "Get the temperature from the input connector" annotation(Evaluate = true, HideResult = true);
        parameter Boolean use_X_in = false "Get the composition from the input connector" annotation(Evaluate = true, HideResult = true);
        parameter Boolean use_C_in = false "Get the trace substances from the input connector" annotation(Evaluate = true, HideResult = true);
        parameter Medium.AbsolutePressure p = Medium.p_default "Fixed value of pressure" annotation(Evaluate = true);
        parameter Medium.Temperature T = Medium.T_default "Fixed value of temperature" annotation(Evaluate = true);
        parameter Medium.MassFraction[Medium.nX] X = Medium.X_default "Fixed value of composition" annotation(Evaluate = true);
        parameter Medium.ExtraProperty[Medium.nC] C(quantity = Medium.extraPropertiesNames) = fill(0, Medium.nC) "Fixed values of trace substances" annotation(Evaluate = true);
        Modelica.Blocks.Interfaces.RealInput p_in if use_p_in "Prescribed boundary pressure";
        Modelica.Blocks.Interfaces.RealInput T_in if use_T_in "Prescribed boundary temperature";
        Modelica.Blocks.Interfaces.RealInput[Medium.nX] X_in if use_X_in "Prescribed boundary composition";
        Modelica.Blocks.Interfaces.RealInput[Medium.nC] C_in if use_C_in "Prescribed boundary trace substances";
      protected
        Modelica.Blocks.Interfaces.RealInput p_in_internal "Needed to connect to conditional connector";
        Modelica.Blocks.Interfaces.RealInput T_in_internal "Needed to connect to conditional connector";
        Modelica.Blocks.Interfaces.RealInput[Medium.nX] X_in_internal "Needed to connect to conditional connector";
        Modelica.Blocks.Interfaces.RealInput[Medium.nC] C_in_internal "Needed to connect to conditional connector";
      equation
        Modelica.Fluid.Utilities.checkBoundary(Medium.mediumName, Medium.substanceNames, Medium.singleState, true, X_in_internal, "Boundary_pT");
        connect(p_in, p_in_internal);
        connect(T_in, T_in_internal);
        connect(X_in, X_in_internal);
        connect(C_in, C_in_internal);
        if not use_p_in then
          p_in_internal = p;
        end if;
        if not use_T_in then
          T_in_internal = T;
        end if;
        if not use_X_in then
          X_in_internal = X;
        end if;
        if not use_C_in then
          C_in_internal = C;
        end if;
        medium.p = p_in_internal;
        if Medium.ThermoStates == .Modelica.Media.Interfaces.Choices.IndependentVariables.ph or Medium.ThermoStates == .Modelica.Media.Interfaces.Choices.IndependentVariables.phX then
          medium.h = Medium.specificEnthalpy(Medium.setState_pTX(p_in_internal, T_in_internal, X_in_internal));
        else
          medium.T = T_in_internal;
        end if;
        medium.Xi = X_in_internal[1:Medium.nXi];
        ports.C_outflow = fill(C_in_internal, nPorts);
      end Boundary_pT;

      package BaseClasses  "Base classes used in the Sources package (only of interest to build new component models)" 
        extends Modelica.Icons.BasesPackage;

        partial model PartialSource  "Partial component source with one fluid connector" 
          parameter Integer nPorts = 0 "Number of ports";
          replaceable package Medium = Modelica.Media.Interfaces.PartialMedium "Medium model within the source" annotation(choicesAllMatching = true);
          Medium.BaseProperties medium "Medium in the source";
          Interfaces.FluidPorts_b[nPorts] ports(redeclare each package Medium = Medium, m_flow(each max = if flowDirection == Types.PortFlowDirection.Leaving then 0 else +.Modelica.Constants.inf, each min = if flowDirection == Types.PortFlowDirection.Entering then 0 else -.Modelica.Constants.inf));
        protected
          parameter Types.PortFlowDirection flowDirection = Types.PortFlowDirection.Bidirectional "Allowed flow direction" annotation(Evaluate = true);
        equation
          for i in 1:nPorts loop
            assert(cardinality(ports[i]) <= 1, "
        each ports[i] of boundary shall at most be connected to one component.
        If two or more connections are present, ideal mixing takes
        place with these connections, which is usually not the intention
        of the modeller. Increase nPorts to add an additional port.
            ");
            ports[i].p = medium.p;
            ports[i].h_outflow = medium.h;
            ports[i].Xi_outflow = medium.Xi;
          end for;
        end PartialSource;
      end BaseClasses;
    end Sources;

    package Interfaces  "Interfaces for steady state and unsteady, mixed-phase, multi-substance, incompressible and compressible flow" 
      extends Modelica.Icons.InterfacesPackage;

      connector FluidPort  "Interface for quasi one-dimensional fluid flow in a piping network (incompressible or compressible, one or more phases, one or more substances)" 
        replaceable package Medium = Modelica.Media.Interfaces.PartialMedium "Medium model" annotation(choicesAllMatching = true);
        flow Medium.MassFlowRate m_flow "Mass flow rate from the connection point into the component";
        Medium.AbsolutePressure p "Thermodynamic pressure in the connection point";
        stream Medium.SpecificEnthalpy h_outflow "Specific thermodynamic enthalpy close to the connection point if m_flow < 0";
        stream Medium.MassFraction[Medium.nXi] Xi_outflow "Independent mixture mass fractions m_i/m close to the connection point if m_flow < 0";
        stream Medium.ExtraProperty[Medium.nC] C_outflow "Properties c_i/m close to the connection point if m_flow < 0";
      end FluidPort;

      connector FluidPort_a  "Generic fluid connector at design inlet" 
        extends FluidPort;
      end FluidPort_a;

      connector FluidPort_b  "Generic fluid connector at design outlet" 
        extends FluidPort;
      end FluidPort_b;

      connector FluidPorts_b  "Fluid connector with outlined, large icon to be used for vectors of FluidPorts (vector dimensions must be added after dragging)" 
        extends FluidPort;
      end FluidPorts_b;

      partial model PartialTwoPort  "Partial component with two ports" 
        outer Modelica.Fluid.System system "System wide properties";
        replaceable package Medium = Modelica.Media.Interfaces.PartialMedium "Medium in the component" annotation(choicesAllMatching = true);
        parameter Boolean allowFlowReversal = system.allowFlowReversal "= true to allow flow reversal, false restricts to design direction (port_a -> port_b)" annotation(Evaluate = true);
        Modelica.Fluid.Interfaces.FluidPort_a port_a(redeclare package Medium = Medium, m_flow(min = if allowFlowReversal then -.Modelica.Constants.inf else 0)) "Fluid connector a (positive design flow direction is from port_a to port_b)";
        Modelica.Fluid.Interfaces.FluidPort_b port_b(redeclare package Medium = Medium, m_flow(max = if allowFlowReversal then +.Modelica.Constants.inf else 0)) "Fluid connector b (positive design flow direction is from port_a to port_b)";
      protected
        parameter Boolean port_a_exposesState = false "= true if port_a exposes the state of a fluid volume";
        parameter Boolean port_b_exposesState = false "= true if port_b.p exposes the state of a fluid volume";
        parameter Boolean showDesignFlowDirection = true "= false to hide the arrow in the model icon";
      end PartialTwoPort;

      partial model PartialTwoPortTransport  "Partial element transporting fluid between two ports without storage of mass or energy" 
        extends PartialTwoPort(final port_a_exposesState = false, final port_b_exposesState = false);
        parameter Medium.AbsolutePressure dp_start(min = -Modelica.Constants.inf) = 0.01 * system.p_start "Guess value of dp = port_a.p - port_b.p";
        parameter Medium.MassFlowRate m_flow_start = system.m_flow_start "Guess value of m_flow = port_a.m_flow";
        parameter Medium.MassFlowRate m_flow_small = if system.use_eps_Re then system.eps_m_flow * system.m_flow_nominal else system.m_flow_small "Small mass flow rate for regularization of zero flow";
        parameter Boolean show_T = true "= true, if temperatures at port_a and port_b are computed";
        parameter Boolean show_V_flow = true "= true, if volume flow rate at inflowing port is computed";
        Medium.MassFlowRate m_flow(min = if allowFlowReversal then -Modelica.Constants.inf else 0, start = m_flow_start) "Mass flow rate in design flow direction";
        Modelica.SIunits.Pressure dp(start = dp_start) "Pressure difference between port_a and port_b (= port_a.p - port_b.p)";
        Modelica.SIunits.VolumeFlowRate V_flow = m_flow / Modelica.Fluid.Utilities.regStep(m_flow, Medium.density(state_a), Medium.density(state_b), m_flow_small) if show_V_flow "Volume flow rate at inflowing port (positive when flow from port_a to port_b)";
        Medium.Temperature port_a_T = Modelica.Fluid.Utilities.regStep(port_a.m_flow, Medium.temperature(state_a), Medium.temperature(Medium.setState_phX(port_a.p, port_a.h_outflow, port_a.Xi_outflow)), m_flow_small) if show_T "Temperature close to port_a, if show_T = true";
        Medium.Temperature port_b_T = Modelica.Fluid.Utilities.regStep(port_b.m_flow, Medium.temperature(state_b), Medium.temperature(Medium.setState_phX(port_b.p, port_b.h_outflow, port_b.Xi_outflow)), m_flow_small) if show_T "Temperature close to port_b, if show_T = true";
      protected
        Medium.ThermodynamicState state_a "state for medium inflowing through port_a";
        Medium.ThermodynamicState state_b "state for medium inflowing through port_b";
      equation
        state_a = Medium.setState_phX(port_a.p, inStream(port_a.h_outflow), inStream(port_a.Xi_outflow));
        state_b = Medium.setState_phX(port_b.p, inStream(port_b.h_outflow), inStream(port_b.Xi_outflow));
        dp = port_a.p - port_b.p;
        m_flow = port_a.m_flow;
        assert(m_flow > (-m_flow_small) or allowFlowReversal, "Reverting flow occurs even though allowFlowReversal is false");
        port_a.m_flow + port_b.m_flow = 0;
        port_a.Xi_outflow = inStream(port_b.Xi_outflow);
        port_b.Xi_outflow = inStream(port_a.Xi_outflow);
        port_a.C_outflow = inStream(port_b.C_outflow);
        port_b.C_outflow = inStream(port_a.C_outflow);
      end PartialTwoPortTransport;

      connector HeatPorts_a  "HeatPort connector with filled, large icon to be used for vectors of HeatPorts (vector dimensions must be added after dragging)" 
        extends Modelica.Thermal.HeatTransfer.Interfaces.HeatPort;
      end HeatPorts_a;

      partial model PartialHeatTransfer  "Common interface for heat transfer models" 
        replaceable package Medium = Modelica.Media.Interfaces.PartialMedium "Medium in the component";
        parameter Integer n = 1 "Number of heat transfer segments" annotation(Evaluate = true);
        input Medium.ThermodynamicState[n] states "Thermodynamic states of flow segments";
        input .Modelica.SIunits.Area[n] surfaceAreas "Heat transfer areas";
        output .Modelica.SIunits.HeatFlowRate[n] Q_flows "Heat flow rates";
        parameter Boolean use_k = false "= true to use k value for thermal isolation";
        parameter .Modelica.SIunits.CoefficientOfHeatTransfer k = 0 "Heat transfer coefficient to ambient" annotation(Evaluate = true);
        parameter .Modelica.SIunits.Temperature T_ambient = system.T_ambient "Ambient temperature";
        outer Modelica.Fluid.System system "System wide properties";
        Modelica.Fluid.Interfaces.HeatPorts_a[n] heatPorts "Heat port to component boundary";
        .Modelica.SIunits.Temperature[n] Ts = Medium.temperature(states) "Temperatures defined by fluid states";
      equation
        if use_k then
          Q_flows = heatPorts.Q_flow + {k * surfaceAreas[i] * (T_ambient - heatPorts[i].T) for i in 1:n};
        else
          Q_flows = heatPorts.Q_flow;
        end if;
      end PartialHeatTransfer;

      partial model PartialDistributedVolume  "Base class for distributed volume models" 
        outer Modelica.Fluid.System system "System properties";
        replaceable package Medium = Modelica.Media.Interfaces.PartialMedium "Medium in the component" annotation(choicesAllMatching = true);
        parameter Integer n = 2 "Number of discrete volumes";
        input .Modelica.SIunits.Volume[n] fluidVolumes "Discretized volume, determine in inheriting class";
        parameter .Modelica.Fluid.Types.Dynamics energyDynamics = system.energyDynamics "Formulation of energy balances" annotation(Evaluate = true);
        parameter .Modelica.Fluid.Types.Dynamics massDynamics = system.massDynamics "Formulation of mass balances" annotation(Evaluate = true);
        final parameter .Modelica.Fluid.Types.Dynamics substanceDynamics = massDynamics "Formulation of substance balances" annotation(Evaluate = true);
        final parameter .Modelica.Fluid.Types.Dynamics traceDynamics = massDynamics "Formulation of trace substance balances" annotation(Evaluate = true);
        parameter Medium.AbsolutePressure p_a_start = system.p_start "Start value of pressure at port a";
        parameter Medium.AbsolutePressure p_b_start = p_a_start "Start value of pressure at port b";
        final parameter Medium.AbsolutePressure[n] ps_start = if n > 1 then linspace(p_a_start, p_b_start, n) else {(p_a_start + p_b_start) / 2} "Start value of pressure";
        parameter Boolean use_T_start = true "Use T_start if true, otherwise h_start" annotation(Evaluate = true);
        parameter Medium.Temperature T_start = if use_T_start then system.T_start else Medium.temperature_phX((p_a_start + p_b_start) / 2, h_start, X_start) "Start value of temperature" annotation(Evaluate = true);
        parameter Medium.SpecificEnthalpy h_start = if use_T_start then Medium.specificEnthalpy_pTX((p_a_start + p_b_start) / 2, T_start, X_start) else Medium.h_default "Start value of specific enthalpy" annotation(Evaluate = true);
        parameter Medium.MassFraction[Medium.nX] X_start = Medium.X_default "Start value of mass fractions m_i/m";
        parameter Medium.ExtraProperty[Medium.nC] C_start(quantity = Medium.extraPropertiesNames) = fill(0, Medium.nC) "Start value of trace substances";
        .Modelica.SIunits.Energy[n] Us "Internal energy of fluid";
        .Modelica.SIunits.Mass[n] ms "Fluid mass";
        .Modelica.SIunits.Mass[n, Medium.nXi] mXis "Substance mass";
        .Modelica.SIunits.Mass[n, Medium.nC] mCs "Trace substance mass";
        .Modelica.SIunits.Mass[n, Medium.nC] mCs_scaled "Scaled trace substance mass";
        Medium.ExtraProperty[n, Medium.nC] Cs "Trace substance mixture content";
        Medium.BaseProperties[n] mediums(each preferredMediumStates = true, p(start = ps_start), each h(start = h_start), each T(start = T_start), each Xi(start = X_start[1:Medium.nXi]));
        Medium.MassFlowRate[n] mb_flows "Mass flow rate, source or sink";
        Medium.MassFlowRate[n, Medium.nXi] mbXi_flows "Independent mass flow rates, source or sink";
        Medium.ExtraPropertyFlowRate[n, Medium.nC] mbC_flows "Trace substance mass flow rates, source or sink";
        .Modelica.SIunits.EnthalpyFlowRate[n] Hb_flows "Enthalpy flow rate, source or sink";
        .Modelica.SIunits.HeatFlowRate[n] Qb_flows "Heat flow rate, source or sink";
        .Modelica.SIunits.Power[n] Wb_flows "Mechanical power, p*der(V) etc.";
      protected
        parameter Boolean initialize_p = not Medium.singleState "= true to set up initial equations for pressure";
      initial equation
        if energyDynamics == .Modelica.Fluid.Types.Dynamics.FixedInitial then
          if Medium.ThermoStates == .Modelica.Media.Interfaces.Choices.IndependentVariables.ph or Medium.ThermoStates == .Modelica.Media.Interfaces.Choices.IndependentVariables.phX then
            mediums.h = fill(h_start, n);
          else
            mediums.T = fill(T_start, n);
          end if;
        elseif energyDynamics == .Modelica.Fluid.Types.Dynamics.SteadyStateInitial then
          if Medium.ThermoStates == .Modelica.Media.Interfaces.Choices.IndependentVariables.ph or Medium.ThermoStates == .Modelica.Media.Interfaces.Choices.IndependentVariables.phX then
            der(mediums.h) = zeros(n);
          else
            der(mediums.T) = zeros(n);
          end if;
        end if;
        if massDynamics == .Modelica.Fluid.Types.Dynamics.FixedInitial then
          if initialize_p then
            mediums.p = ps_start;
          end if;
        elseif massDynamics == .Modelica.Fluid.Types.Dynamics.SteadyStateInitial then
          if initialize_p then
            der(mediums.p) = zeros(n);
          end if;
        end if;
        if substanceDynamics == .Modelica.Fluid.Types.Dynamics.FixedInitial then
          mediums.Xi = fill(X_start[1:Medium.nXi], n);
        elseif substanceDynamics == .Modelica.Fluid.Types.Dynamics.SteadyStateInitial then
          for i in 1:n loop
            der(mediums[i].Xi) = zeros(Medium.nXi);
          end for;
        end if;
        if traceDynamics == .Modelica.Fluid.Types.Dynamics.FixedInitial then
          Cs = fill(C_start[1:Medium.nC], n);
        elseif traceDynamics == .Modelica.Fluid.Types.Dynamics.SteadyStateInitial then
          for i in 1:n loop
            der(mCs[i, :]) = zeros(Medium.nC);
          end for;
        end if;
      equation
        assert(not (energyDynamics <> .Modelica.Fluid.Types.Dynamics.SteadyState and massDynamics == .Modelica.Fluid.Types.Dynamics.SteadyState) or Medium.singleState, "Bad combination of dynamics options and Medium not conserving mass if fluidVolumes are fixed.");
        for i in 1:n loop
          ms[i] = fluidVolumes[i] * mediums[i].d;
          mXis[i, :] = ms[i] * mediums[i].Xi;
          mCs[i, :] = ms[i] * Cs[i, :];
          Us[i] = ms[i] * mediums[i].u;
        end for;
        if energyDynamics == .Modelica.Fluid.Types.Dynamics.SteadyState then
          for i in 1:n loop
            0 = Hb_flows[i] + Wb_flows[i] + Qb_flows[i];
          end for;
        else
          for i in 1:n loop
            der(Us[i]) = Hb_flows[i] + Wb_flows[i] + Qb_flows[i];
          end for;
        end if;
        if massDynamics == .Modelica.Fluid.Types.Dynamics.SteadyState then
          for i in 1:n loop
            0 = mb_flows[i];
          end for;
        else
          for i in 1:n loop
            der(ms[i]) = mb_flows[i];
          end for;
        end if;
        if substanceDynamics == .Modelica.Fluid.Types.Dynamics.SteadyState then
          for i in 1:n loop
            zeros(Medium.nXi) = mbXi_flows[i, :];
          end for;
        else
          for i in 1:n loop
            der(mXis[i, :]) = mbXi_flows[i, :];
          end for;
        end if;
        if traceDynamics == .Modelica.Fluid.Types.Dynamics.SteadyState then
          for i in 1:n loop
            zeros(Medium.nC) = mbC_flows[i, :];
          end for;
        else
          for i in 1:n loop
            der(mCs_scaled[i, :]) = mbC_flows[i, :] ./ Medium.C_nominal;
            mCs[i, :] = mCs_scaled[i, :] .* Medium.C_nominal;
          end for;
        end if;
      end PartialDistributedVolume;

      partial model PartialDistributedFlow  "Base class for a distributed momentum balance" 
        outer Modelica.Fluid.System system "System properties";
        replaceable package Medium = Modelica.Media.Interfaces.PartialMedium "Medium in the component";
        parameter Boolean allowFlowReversal = system.allowFlowReversal "= true to allow flow reversal, false restricts to design direction (m_flows >= zeros(m))" annotation(Evaluate = true);
        parameter Integer m = 1 "Number of flow segments";
        input .Modelica.SIunits.Length[m] pathLengths "Lengths along flow path";
        Medium.MassFlowRate[m] m_flows(each min = if allowFlowReversal then -Modelica.Constants.inf else 0, each start = m_flow_start, each stateSelect = if momentumDynamics == Types.Dynamics.SteadyState then StateSelect.default else StateSelect.prefer) "mass flow rates between states";
        parameter Modelica.Fluid.Types.Dynamics momentumDynamics = system.momentumDynamics "Formulation of momentum balance" annotation(Evaluate = true);
        parameter Medium.MassFlowRate m_flow_start = system.m_flow_start "Start value of mass flow rates";
        .Modelica.SIunits.Momentum[m] Is "Momenta of flow segments";
        .Modelica.SIunits.Force[m] Ib_flows "Flow of momentum across boundaries";
        .Modelica.SIunits.Force[m] Fs_p "Pressure forces";
        .Modelica.SIunits.Force[m] Fs_fg "Friction and gravity forces";
      initial equation
        if momentumDynamics == Types.Dynamics.FixedInitial then
          m_flows = fill(m_flow_start, m);
        elseif momentumDynamics == Types.Dynamics.SteadyStateInitial then
          der(m_flows) = zeros(m);
        end if;
      equation
        Is = {m_flows[i] * pathLengths[i] for i in 1:m};
        if momentumDynamics == Types.Dynamics.SteadyState then
          zeros(m) = Ib_flows - Fs_p - Fs_fg;
        else
          der(Is) = Ib_flows - Fs_p - Fs_fg;
        end if;
      end PartialDistributedFlow;
    end Interfaces;

    package Types  "Common types for fluid models" 
      extends Modelica.Icons.TypesPackage;
      type Dynamics = enumeration(DynamicFreeInitial "DynamicFreeInitial -- Dynamic balance, Initial guess value", FixedInitial "FixedInitial -- Dynamic balance, Initial value fixed", SteadyStateInitial "SteadyStateInitial -- Dynamic balance, Steady state initial with guess value", SteadyState "SteadyState -- Steady state balance, Initial guess value") "Enumeration to define definition of balance equations";
      type CvTypes = enumeration(Av "Av (metric) flow coefficient", Kv "Kv (metric) flow coefficient", Cv "Cv (US) flow coefficient", OpPoint "Av defined by operating point") "Enumeration to define the choice of valve flow coefficient";
      type PortFlowDirection = enumeration(Entering "Fluid flow is only entering", Leaving "Fluid flow is only leaving", Bidirectional "No restrictions on fluid flow (flow reversal possible)") "Enumeration to define whether flow reversal is allowed";
      type ModelStructure = enumeration(av_vb "av_vb: port_a - volume - flow model - volume - port_b", a_v_b "a_v_b: port_a - flow model - volume - flow model - port_b", av_b "av_b: port_a - volume - flow model - port_b", a_vb "a_vb: port_a - flow model - volume - port_b") "Enumeration with choices for model structure in distributed pipe model";
    end Types;

    package Utilities  "Utility models to construct fluid components (should not be used directly)" 
      extends Modelica.Icons.UtilitiesPackage;

      function checkBoundary  "Check whether boundary definition is correct" 
        extends Modelica.Icons.Function;
        input String mediumName;
        input String[:] substanceNames "Names of substances";
        input Boolean singleState;
        input Boolean define_p;
        input Real[:] X_boundary;
        input String modelName = "??? boundary ???";
      protected
        Integer nX = size(X_boundary, 1);
        String X_str;
      algorithm
        assert(not singleState or singleState and define_p, "
      Wrong value of parameter define_p (= false) in model \"" + modelName + "\":
      The selected medium \"" + mediumName + "\" has Medium.singleState=true.
      Therefore, an boundary density cannot be defined and
      define_p = true is required.
        ");
        for i in 1:nX loop
          assert(X_boundary[i] >= 0.0, "
      Wrong boundary mass fractions in medium \"" + mediumName + "\" in model \"" + modelName + "\":
      The boundary value X_boundary(" + String(i) + ") = " + String(X_boundary[i]) + "
      is negative. It must be positive.
          ");
        end for;
        if nX > 0 and abs(sum(X_boundary) - 1.0) > 1.e-10 then
          X_str := "";
          for i in 1:nX loop
            X_str := X_str + "   X_boundary[" + String(i) + "] = " + String(X_boundary[i]) + " \"" + substanceNames[i] + "\"\n";
          end for;
          Modelica.Utilities.Streams.error("The boundary mass fractions in medium \"" + mediumName + "\" in model \"" + modelName + "\"\n" + "do not sum up to 1. Instead, sum(X_boundary) = " + String(sum(X_boundary)) + ":\n" + X_str);
        else
        end if;
      end checkBoundary;

      function regRoot  "Anti-symmetric square root approximation with finite derivative in the origin" 
        extends Modelica.Icons.Function;
        input Real x;
        input Real delta = 0.01 "Range of significant deviation from sqrt(abs(x))*sgn(x)";
        output Real y;
      algorithm
        y := x / (x * x + delta * delta) ^ 0.25;
        annotation(derivative(zeroDerivative = delta) = regRoot_der); 
      end regRoot;

      function regRoot_der  "Derivative of regRoot" 
        extends Modelica.Icons.Function;
        input Real x;
        input Real delta = 0.01 "Range of significant deviation from sqrt(x)";
        input Real dx "Derivative of x";
        output Real dy;
      algorithm
        dy := dx * 0.5 * (x * x + 2 * delta * delta) / (x * x + delta * delta) ^ 1.25;
      end regRoot_der;

      function regRoot2  "Anti-symmetric approximation of square root with discontinuous factor so that the first derivative is finite and continuous" 
        extends Modelica.Icons.Function;
        input Real x "abscissa value";
        input Real x_small(min = 0) = 0.01 "approximation of function for |x| <= x_small";
        input Real k1(min = 0) = 1 "y = if x>=0 then sqrt(k1*x) else -sqrt(k2*|x|)";
        input Real k2(min = 0) = 1 "y = if x>=0 then sqrt(k1*x) else -sqrt(k2*|x|)";
        input Boolean use_yd0 = false "= true, if yd0 shall be used";
        input Real yd0(min = 0) = 1 "Desired derivative at x=0: dy/dx = yd0";
        output Real y "ordinate value";

      protected
        encapsulated function regRoot2_utility  "Interpolating with two 3-order polynomials with a prescribed derivative at x=0" 
          extends .Modelica.Icons.Function;
          input Real x;
          input Real x1 "approximation of function abs(x) < x1";
          input Real k1 "y = if x>=0 then sqrt(k1*x) else -sqrt(k2*|x|); k1 >= k2";
          input Real k2 "y = if x>=0 then sqrt(k1*x) else -sqrt(k2*|x|))";
          input Boolean use_yd0 "= true, if yd0 shall be used";
          input Real yd0(min = 0) "Desired derivative at x=0: dy/dx = yd0";
          output Real y;
        protected
          Real x2;
          Real xsqrt1;
          Real xsqrt2;
          Real y1;
          Real y2;
          Real y1d;
          Real y2d;
          Real w;
          Real y0d;
          Real w1;
          Real w2;
          Real sqrt_k1 = if k1 > 0 then sqrt(k1) else 0;
          Real sqrt_k2 = if k2 > 0 then sqrt(k2) else 0;
        algorithm
          if k2 > 0 then
            x2 := -x1 * (k2 / k1);
          elseif k1 > 0 then
            x2 := -x1;
          else
            y := 0;
            return;
          end if;
          if x <= x2 then
            y := -sqrt_k2 * sqrt(abs(x));
          else
            y1 := sqrt_k1 * sqrt(x1);
            y2 := -sqrt_k2 * sqrt(abs(x2));
            y1d := sqrt_k1 / sqrt(x1) / 2;
            y2d := sqrt_k2 / sqrt(abs(x2)) / 2;
            if use_yd0 then
              y0d := yd0;
            else
              w := x2 / x1;
              y0d := ((3 * y2 - x2 * y2d) / w - (3 * y1 - x1 * y1d) * w) / (2 * x1 * (1 - w));
            end if;
            w1 := sqrt_k1 * sqrt(8.75 / x1);
            w2 := sqrt_k2 * sqrt(8.75 / abs(x2));
            y0d := smooth(2, min(y0d, 0.9 * min(w1, w2)));
            y := y1 * (if x >= 0 then .Modelica.Fluid.Utilities.evaluatePoly3_derivativeAtZero(x / x1, 1, 1, y1d * x1 / y1, y0d * x1 / y1) else .Modelica.Fluid.Utilities.evaluatePoly3_derivativeAtZero(x / x1, x2 / x1, y2 / y1, y2d * x1 / y1, y0d * x1 / y1));
          end if;
          annotation(smoothOrder = 2); 
        end regRoot2_utility;
      algorithm
        y := smooth(2, if x >= x_small then sqrt(k1 * x) else if x <= (-x_small) then -sqrt(k2 * abs(x)) else if k1 >= k2 then regRoot2_utility(x, x_small, k1, k2, use_yd0, yd0) else -regRoot2_utility(-x, x_small, k2, k1, use_yd0, yd0));
        annotation(smoothOrder = 2); 
      end regRoot2;

      function regStep  "Approximation of a general step, such that the characteristic is continuous and differentiable" 
        extends Modelica.Icons.Function;
        input Real x "Abscissa value";
        input Real y1 "Ordinate value for x > 0";
        input Real y2 "Ordinate value for x < 0";
        input Real x_small(min = 0) = 1e-5 "Approximation of step for -x_small <= x <= x_small; x_small >= 0 required";
        output Real y "Ordinate value to approximate y = if x > 0 then y1 else y2";
      algorithm
        y := smooth(1, if x > x_small then y1 else if x < (-x_small) then y2 else if x_small > 0 then x / x_small * ((x / x_small) ^ 2 - 3) * (y2 - y1) / 4 + (y1 + y2) / 2 else (y1 + y2) / 2);
      end regStep;

      function evaluatePoly3_derivativeAtZero  "Evaluate polynomial of order 3 that passes the origin with a predefined derivative" 
        extends Modelica.Icons.Function;
        input Real x "Value for which polynomial shall be evaluated";
        input Real x1 "Abscissa value";
        input Real y1 "y1=f(x1)";
        input Real y1d "First derivative at y1";
        input Real y0d "First derivative at f(x=0)";
        output Real y;
      protected
        Real a1;
        Real a2;
        Real a3;
        Real xx;
      algorithm
        a1 := x1 * y0d;
        a2 := 3 * y1 - x1 * y1d - 2 * a1;
        a3 := y1 - a2 - a1;
        xx := x / x1;
        y := xx * (a1 + xx * (a2 + xx * a3));
        annotation(smoothOrder = 3); 
      end evaluatePoly3_derivativeAtZero;

      function regFun3  "Co-monotonic and C1 smooth regularization function" 
        extends Modelica.Icons.Function;
        input Real x "Abscissa value";
        input Real x0 "Lower abscissa value";
        input Real x1 "Upper abscissa value";
        input Real y0 "Ordinate value at lower abscissa value";
        input Real y1 "Ordinate value at upper abscissa value";
        input Real y0d "Derivative at lower abscissa value";
        input Real y1d "Derivative at upper abscissa value";
        output Real y "Ordinate value";
        output Real c "Slope of linear section between two cubic polynomials or dummy linear section slope if single cubic is used";
      protected
        Real h0 "Width of interval i=0";
        Real Delta0 "Slope of secant on interval i=0";
        Real xstar "Inflection point of cubic polynomial S0";
        Real mu "Distance of inflection point and left limit x0";
        Real eta "Distance of right limit x1 and inflection point";
        Real omega "Slope of cubic polynomial S0 at inflection point";
        Real rho "Weighting factor of eta and eta_tilde, mu and mu_tilde";
        Real theta0 "Slope metric";
        Real mu_tilde "Distance of start of linear section and left limit x0";
        Real eta_tilde "Distance of right limit x1 and end of linear section";
        Real xi1 "Start of linear section";
        Real xi2 "End of linear section";
        Real a1 "Leading coefficient of cubic on the left";
        Real a2 "Leading coefficient of cubic on the right";
        Real const12 "Integration constant of left cubic, linear section";
        Real const3 "Integration constant of right cubic";
        Real aux01;
        Real aux02;
        Boolean useSingleCubicPolynomial = false "Indicate to override further logic and use single cubic";
      algorithm
        assert(x0 < x1, "regFun3(): Data points not sorted appropriately (x0 = " + String(x0) + " > x1 = " + String(x1) + "). Please flip arguments.");
        if y0d * y1d >= 0 then
        else
          assert(abs(y0d) < Modelica.Constants.eps or abs(y1d) < Modelica.Constants.eps, "regFun3(): Derivatives at data points do not allow co-monotone interpolation, as both are non-zero, of opposite sign and have an absolute value larger than machine eps (y0d = " + String(y0d) + ", y1d = " + String(y1d) + "). Please correct arguments.");
        end if;
        h0 := x1 - x0;
        Delta0 := (y1 - y0) / h0;
        if abs(Delta0) <= 0 then
          y := y0 + Delta0 * (x - x0);
          c := 0;
        elseif abs(y1d + y0d - 2 * Delta0) < 100 * Modelica.Constants.eps then
          y := y0 + (x - x0) * (y0d + (x - x0) / h0 * ((-2 * y0d) - y1d + 3 * Delta0 + (x - x0) * (y0d + y1d - 2 * Delta0) / h0));
          aux01 := (x0 + x1) / 2;
          c := 3 * (y0d + y1d - 2 * Delta0) * (aux01 - x0) ^ 2 / h0 ^ 2 + 2 * ((-2 * y0d) - y1d + 3 * Delta0) * (aux01 - x0) / h0 + y0d;
        else
          xstar := 1 / 3 * ((-3 * x0 * y0d) - 3 * x0 * y1d + 6 * x0 * Delta0 - 2 * h0 * y0d - h0 * y1d + 3 * h0 * Delta0) / ((-y0d) - y1d + 2 * Delta0);
          mu := xstar - x0;
          eta := x1 - xstar;
          omega := 3 * (y0d + y1d - 2 * Delta0) * (xstar - x0) ^ 2 / h0 ^ 2 + 2 * ((-2 * y0d) - y1d + 3 * Delta0) * (xstar - x0) / h0 + y0d;
          aux01 := 0.25 * sign(Delta0) * min(abs(omega), abs(Delta0)) "Slope c if not using plain cubic S0";
          if abs(y0d - y1d) <= 100 * Modelica.Constants.eps then
            aux02 := y0d;
            if y1 > y0 + y0d * (x1 - x0) then
              useSingleCubicPolynomial := true;
            else
            end if;
          elseif abs(y1d + y0d - 2 * Delta0) < 100 * Modelica.Constants.eps then
            aux02 := (6 * Delta0 * (y1d + y0d - 3 / 2 * Delta0) - y1d * y0d - y1d ^ 2 - y0d ^ 2) * (if y1d + y0d - 2 * Delta0 >= 0 then 1 else -1) * Modelica.Constants.inf;
          else
            aux02 := (6 * Delta0 * (y1d + y0d - 3 / 2 * Delta0) - y1d * y0d - y1d ^ 2 - y0d ^ 2) / (3 * (y1d + y0d - 2 * Delta0));
          end if;
          if (mu > 0 and eta < h0 and Delta0 * omega <= 0 or abs(aux01) < abs(aux02) and aux02 * Delta0 >= 0 or abs(aux01) < abs(0.1 * Delta0)) and not useSingleCubicPolynomial then
            c := aux01;
            if abs(c) < abs(aux02) and aux02 * Delta0 >= 0 then
              c := aux02;
            else
            end if;
            if abs(c) < abs(0.1 * Delta0) then
              c := 0.1 * Delta0;
            else
            end if;
            theta0 := (y0d * mu + y1d * eta) / h0;
            if abs(theta0 - c) < 1e-6 then
              c := (1 - 1e-6) * theta0;
            else
            end if;
            rho := 3 * (Delta0 - c) / (theta0 - c);
            mu_tilde := rho * mu;
            eta_tilde := rho * eta;
            xi1 := x0 + mu_tilde;
            xi2 := x1 - eta_tilde;
            a1 := (y0d - c) / max(mu_tilde ^ 2, 100 * Modelica.Constants.eps);
            a2 := (y1d - c) / max(eta_tilde ^ 2, 100 * Modelica.Constants.eps);
            const12 := y0 - a1 / 3 * (x0 - xi1) ^ 3 - c * x0;
            const3 := y1 - a2 / 3 * (x1 - xi2) ^ 3 - c * x1;
            if x < xi1 then
              y := a1 / 3 * (x - xi1) ^ 3 + c * x + const12;
            elseif x < xi2 then
              y := c * x + const12;
            else
              y := a2 / 3 * (x - xi2) ^ 3 + c * x + const3;
            end if;
          else
            y := y0 + (x - x0) * (y0d + (x - x0) / h0 * ((-2 * y0d) - y1d + 3 * Delta0 + (x - x0) * (y0d + y1d - 2 * Delta0) / h0));
            aux01 := (x0 + x1) / 2;
            c := 3 * (y0d + y1d - 2 * Delta0) * (aux01 - x0) ^ 2 / h0 ^ 2 + 2 * ((-2 * y0d) - y1d + 3 * Delta0) * (aux01 - x0) / h0 + y0d;
          end if;
        end if;
        annotation(smoothOrder = 1); 
      end regFun3;

      function cubicHermite_withDerivative  "Evaluate a cubic Hermite spline, return value and derivative" 
        extends Modelica.Icons.Function;
        input Real x "Abscissa value";
        input Real x1 "Lower abscissa value";
        input Real x2 "Upper abscissa value";
        input Real y1 "Lower ordinate value";
        input Real y2 "Upper ordinate value";
        input Real y1d "Lower gradient";
        input Real y2d "Upper gradient";
        output Real y "Interpolated ordinate value";
        output Real dy_dx "Derivative dy/dx at abscissa value x";
      protected
        Real h "Distance between x1 and x2";
        Real t "abscissa scaled with h, i.e., t=[0..1] within x=[x1..x2]";
        Real h00 "Basis function 00 of cubic Hermite spline";
        Real h10 "Basis function 10 of cubic Hermite spline";
        Real h01 "Basis function 01 of cubic Hermite spline";
        Real h11 "Basis function 11 of cubic Hermite spline";
        Real h00d "d/dt h00";
        Real h10d "d/dt h10";
        Real h01d "d/dt h01";
        Real h11d "d/dt h11";
        Real aux3 "t cube";
        Real aux2 "t square";
      algorithm
        h := x2 - x1;
        if abs(h) > 0 then
          t := (x - x1) / h;
          aux3 := t ^ 3;
          aux2 := t ^ 2;
          h00 := 2 * aux3 - 3 * aux2 + 1;
          h10 := aux3 - 2 * aux2 + t;
          h01 := (-2 * aux3) + 3 * aux2;
          h11 := aux3 - aux2;
          h00d := 6 * (aux2 - t);
          h10d := 3 * aux2 - 4 * t + 1;
          h01d := 6 * (t - aux2);
          h11d := 3 * aux2 - 2 * t;
          y := y1 * h00 + h * y1d * h10 + y2 * h01 + h * y2d * h11;
          dy_dx := y1 * h00d / h + y1d * h10d + y2 * h01d / h + y2d * h11d;
        else
          y := (y1 + y2) / 2;
          dy_dx := sign(y2 - y1) * Modelica.Constants.inf;
        end if;
        annotation(smoothOrder = 3); 
      end cubicHermite_withDerivative;
    end Utilities;
  end Fluid;

  package Media  "Library of media property models" 
    extends Modelica.Icons.Package;

    package Interfaces  "Interfaces for media models" 
      extends Modelica.Icons.InterfacesPackage;

      partial package PartialMedium  "Partial medium properties (base package of all media packages)" 
        extends Modelica.Media.Interfaces.Types;
        extends Modelica.Icons.MaterialPropertiesPackage;
        constant Modelica.Media.Interfaces.Choices.IndependentVariables ThermoStates "Enumeration type for independent variables";
        constant String mediumName = "unusablePartialMedium" "Name of the medium";
        constant String[:] substanceNames = {mediumName} "Names of the mixture substances. Set substanceNames={mediumName} if only one substance.";
        constant String[:] extraPropertiesNames = fill("", 0) "Names of the additional (extra) transported properties. Set extraPropertiesNames=fill(\"\",0) if unused";
        constant Boolean singleState "= true, if u and d are not a function of pressure";
        constant Boolean reducedX = true "= true if medium contains the equation sum(X) = 1.0; set reducedX=true if only one substance (see docu for details)";
        constant Boolean fixedX = false "= true if medium contains the equation X = reference_X";
        constant AbsolutePressure reference_p = 101325 "Reference pressure of Medium: default 1 atmosphere";
        constant MassFraction[nX] reference_X = fill(1 / nX, nX) "Default mass fractions of medium";
        constant AbsolutePressure p_default = 101325 "Default value for pressure of medium (for initialization)";
        constant Temperature T_default = Modelica.SIunits.Conversions.from_degC(20) "Default value for temperature of medium (for initialization)";
        constant SpecificEnthalpy h_default = specificEnthalpy_pTX(p_default, T_default, X_default) "Default value for specific enthalpy of medium (for initialization)";
        constant MassFraction[nX] X_default = reference_X "Default value for mass fractions of medium (for initialization)";
        final constant Integer nS = size(substanceNames, 1) "Number of substances" annotation(Evaluate = true);
        constant Integer nX = nS "Number of mass fractions" annotation(Evaluate = true);
        constant Integer nXi = if fixedX then 0 else if reducedX then nS - 1 else nS "Number of structurally independent mass fractions (see docu for details)" annotation(Evaluate = true);
        final constant Integer nC = size(extraPropertiesNames, 1) "Number of extra (outside of standard mass-balance) transported properties" annotation(Evaluate = true);
        constant Real[nC] C_nominal(min = fill(Modelica.Constants.eps, nC)) = 1.0e-6 * ones(nC) "Default for the nominal values for the extra properties";
        replaceable record FluidConstants = Modelica.Media.Interfaces.Types.Basic.FluidConstants "Critical, triple, molecular and other standard data of fluid";

        replaceable record ThermodynamicState  "Minimal variable set that is available as input argument to every medium function" 
          extends Modelica.Icons.Record;
        end ThermodynamicState;

        replaceable partial model BaseProperties  "Base properties (p, d, T, h, u, R, MM and, if applicable, X and Xi) of a medium" 
          InputAbsolutePressure p "Absolute pressure of medium";
          InputMassFraction[nXi] Xi(start = reference_X[1:nXi]) "Structurally independent mass fractions";
          InputSpecificEnthalpy h "Specific enthalpy of medium";
          Density d "Density of medium";
          Temperature T "Temperature of medium";
          MassFraction[nX] X(start = reference_X) "Mass fractions (= (component mass)/total mass  m_i/m)";
          SpecificInternalEnergy u "Specific internal energy of medium";
          SpecificHeatCapacity R "Gas constant (of mixture if applicable)";
          MolarMass MM "Molar mass (of mixture or single fluid)";
          ThermodynamicState state "Thermodynamic state record for optional functions";
          parameter Boolean preferredMediumStates = false "= true if StateSelect.prefer shall be used for the independent property variables of the medium" annotation(Evaluate = true);
          parameter Boolean standardOrderComponents = true "If true, and reducedX = true, the last element of X will be computed from the other ones";
          .Modelica.SIunits.Conversions.NonSIunits.Temperature_degC T_degC = Modelica.SIunits.Conversions.to_degC(T) "Temperature of medium in [degC]";
          .Modelica.SIunits.Conversions.NonSIunits.Pressure_bar p_bar = Modelica.SIunits.Conversions.to_bar(p) "Absolute pressure of medium in [bar]";
          connector InputAbsolutePressure = input .Modelica.SIunits.AbsolutePressure "Pressure as input signal connector";
          connector InputSpecificEnthalpy = input .Modelica.SIunits.SpecificEnthalpy "Specific enthalpy as input signal connector";
          connector InputMassFraction = input .Modelica.SIunits.MassFraction "Mass fraction as input signal connector";
        equation
          if standardOrderComponents then
            Xi = X[1:nXi];
            if fixedX then
              X = reference_X;
            end if;
            if reducedX and not fixedX then
              X[nX] = 1 - sum(Xi);
            end if;
            for i in 1:nX loop
              assert(X[i] >= (-1.e-5) and X[i] <= 1 + 1.e-5, "Mass fraction X[" + String(i) + "] = " + String(X[i]) + "of substance " + substanceNames[i] + "\nof medium " + mediumName + " is not in the range 0..1");
            end for;
          end if;
          assert(p >= 0.0, "Pressure (= " + String(p) + " Pa) of medium \"" + mediumName + "\" is negative\n(Temperature = " + String(T) + " K)");
        end BaseProperties;

        replaceable partial function setState_pTX  "Return thermodynamic state as function of p, T and composition X or Xi" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input Temperature T "Temperature";
          input MassFraction[:] X = reference_X "Mass fractions";
          output ThermodynamicState state "Thermodynamic state record";
        end setState_pTX;

        replaceable partial function setState_phX  "Return thermodynamic state as function of p, h and composition X or Xi" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input SpecificEnthalpy h "Specific enthalpy";
          input MassFraction[:] X = reference_X "Mass fractions";
          output ThermodynamicState state "Thermodynamic state record";
        end setState_phX;

        replaceable partial function setState_psX  "Return thermodynamic state as function of p, s and composition X or Xi" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input SpecificEntropy s "Specific entropy";
          input MassFraction[:] X = reference_X "Mass fractions";
          output ThermodynamicState state "Thermodynamic state record";
        end setState_psX;

        replaceable partial function setState_dTX  "Return thermodynamic state as function of d, T and composition X or Xi" 
          extends Modelica.Icons.Function;
          input Density d "Density";
          input Temperature T "Temperature";
          input MassFraction[:] X = reference_X "Mass fractions";
          output ThermodynamicState state "Thermodynamic state record";
        end setState_dTX;

        replaceable partial function setSmoothState  "Return thermodynamic state so that it smoothly approximates: if x > 0 then state_a else state_b" 
          extends Modelica.Icons.Function;
          input Real x "m_flow or dp";
          input ThermodynamicState state_a "Thermodynamic state if x > 0";
          input ThermodynamicState state_b "Thermodynamic state if x < 0";
          input Real x_small(min = 0) "Smooth transition in the region -x_small < x < x_small";
          output ThermodynamicState state "Smooth thermodynamic state for all x (continuous and differentiable)";
        end setSmoothState;

        replaceable partial function dynamicViscosity  "Return dynamic viscosity" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output DynamicViscosity eta "Dynamic viscosity";
        end dynamicViscosity;

        replaceable partial function thermalConductivity  "Return thermal conductivity" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output ThermalConductivity lambda "Thermal conductivity";
        end thermalConductivity;

        replaceable function prandtlNumber  "Return the Prandtl number" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output PrandtlNumber Pr "Prandtl number";
        algorithm
          Pr := dynamicViscosity(state) * specificHeatCapacityCp(state) / thermalConductivity(state);
        end prandtlNumber;

        replaceable partial function pressure  "Return pressure" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output AbsolutePressure p "Pressure";
        end pressure;

        replaceable partial function temperature  "Return temperature" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output Temperature T "Temperature";
        end temperature;

        replaceable partial function density  "Return density" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output Density d "Density";
        end density;

        replaceable partial function specificEnthalpy  "Return specific enthalpy" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output SpecificEnthalpy h "Specific enthalpy";
        end specificEnthalpy;

        replaceable partial function specificInternalEnergy  "Return specific internal energy" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output SpecificEnergy u "Specific internal energy";
        end specificInternalEnergy;

        replaceable partial function specificEntropy  "Return specific entropy" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output SpecificEntropy s "Specific entropy";
        end specificEntropy;

        replaceable partial function specificGibbsEnergy  "Return specific Gibbs energy" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output SpecificEnergy g "Specific Gibbs energy";
        end specificGibbsEnergy;

        replaceable partial function specificHelmholtzEnergy  "Return specific Helmholtz energy" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output SpecificEnergy f "Specific Helmholtz energy";
        end specificHelmholtzEnergy;

        replaceable partial function specificHeatCapacityCp  "Return specific heat capacity at constant pressure" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output SpecificHeatCapacity cp "Specific heat capacity at constant pressure";
        end specificHeatCapacityCp;

        replaceable partial function specificHeatCapacityCv  "Return specific heat capacity at constant volume" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output SpecificHeatCapacity cv "Specific heat capacity at constant volume";
        end specificHeatCapacityCv;

        replaceable partial function isentropicExponent  "Return isentropic exponent" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output IsentropicExponent gamma "Isentropic exponent";
        end isentropicExponent;

        replaceable partial function isentropicEnthalpy  "Return isentropic enthalpy" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p_downstream "Downstream pressure";
          input ThermodynamicState refState "Reference state for entropy";
          output SpecificEnthalpy h_is "Isentropic enthalpy";
        end isentropicEnthalpy;

        replaceable partial function velocityOfSound  "Return velocity of sound" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output VelocityOfSound a "Velocity of sound";
        end velocityOfSound;

        replaceable partial function isobaricExpansionCoefficient  "Return overall the isobaric expansion coefficient beta" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output IsobaricExpansionCoefficient beta "Isobaric expansion coefficient";
        end isobaricExpansionCoefficient;

        replaceable partial function isothermalCompressibility  "Return overall the isothermal compressibility factor" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output .Modelica.SIunits.IsothermalCompressibility kappa "Isothermal compressibility";
        end isothermalCompressibility;

        replaceable partial function density_derp_h  "Return density derivative w.r.t. pressure at const specific enthalpy" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output DerDensityByPressure ddph "Density derivative w.r.t. pressure";
        end density_derp_h;

        replaceable partial function density_derh_p  "Return density derivative w.r.t. specific enthalpy at constant pressure" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output DerDensityByEnthalpy ddhp "Density derivative w.r.t. specific enthalpy";
        end density_derh_p;

        replaceable partial function density_derp_T  "Return density derivative w.r.t. pressure at const temperature" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output DerDensityByPressure ddpT "Density derivative w.r.t. pressure";
        end density_derp_T;

        replaceable partial function density_derT_p  "Return density derivative w.r.t. temperature at constant pressure" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output DerDensityByTemperature ddTp "Density derivative w.r.t. temperature";
        end density_derT_p;

        replaceable partial function density_derX  "Return density derivative w.r.t. mass fraction" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output Density[nX] dddX "Derivative of density w.r.t. mass fraction";
        end density_derX;

        replaceable partial function molarMass  "Return the molar mass of the medium" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state record";
          output MolarMass MM "Mixture molar mass";
        end molarMass;

        replaceable function specificEnthalpy_pTX  "Return specific enthalpy from p, T, and X or Xi" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input Temperature T "Temperature";
          input MassFraction[:] X = reference_X "Mass fractions";
          output SpecificEnthalpy h "Specific enthalpy";
        algorithm
          h := specificEnthalpy(setState_pTX(p, T, X));
          annotation(inverse(T = temperature_phX(p, h, X))); 
        end specificEnthalpy_pTX;

        replaceable function density_pTX  "Return density from p, T, and X or Xi" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input Temperature T "Temperature";
          input MassFraction[:] X "Mass fractions";
          output Density d "Density";
        algorithm
          d := density(setState_pTX(p, T, X));
        end density_pTX;

        replaceable function temperature_phX  "Return temperature from p, h, and X or Xi" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input SpecificEnthalpy h "Specific enthalpy";
          input MassFraction[:] X = reference_X "Mass fractions";
          output Temperature T "Temperature";
        algorithm
          T := temperature(setState_phX(p, h, X));
        end temperature_phX;

        replaceable function density_phX  "Return density from p, h, and X or Xi" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input SpecificEnthalpy h "Specific enthalpy";
          input MassFraction[:] X = reference_X "Mass fractions";
          output Density d "Density";
        algorithm
          d := density(setState_phX(p, h, X));
        end density_phX;

        type MassFlowRate = .Modelica.SIunits.MassFlowRate(quantity = "MassFlowRate." + mediumName, min = -1.0e5, max = 1.e5) "Type for mass flow rate with medium specific attributes";
      end PartialMedium;

      partial package PartialPureSubstance  "Base class for pure substances of one chemical substance" 
        extends PartialMedium(final reducedX = true, final fixedX = true);

        replaceable function setState_pT  "Return thermodynamic state from p and T" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input Temperature T "Temperature";
          output ThermodynamicState state "Thermodynamic state record";
        algorithm
          state := setState_pTX(p, T, fill(0, 0));
        end setState_pT;

        replaceable function setState_ph  "Return thermodynamic state from p and h" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input SpecificEnthalpy h "Specific enthalpy";
          output ThermodynamicState state "Thermodynamic state record";
        algorithm
          state := setState_phX(p, h, fill(0, 0));
        end setState_ph;

        replaceable function setState_ps  "Return thermodynamic state from p and s" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input SpecificEntropy s "Specific entropy";
          output ThermodynamicState state "Thermodynamic state record";
        algorithm
          state := setState_psX(p, s, fill(0, 0));
        end setState_ps;

        replaceable function setState_dT  "Return thermodynamic state from d and T" 
          extends Modelica.Icons.Function;
          input Density d "Density";
          input Temperature T "Temperature";
          output ThermodynamicState state "Thermodynamic state record";
        algorithm
          state := setState_dTX(d, T, fill(0, 0));
        end setState_dT;

        replaceable function density_ph  "Return density from p and h" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input SpecificEnthalpy h "Specific enthalpy";
          output Density d "Density";
        algorithm
          d := density_phX(p, h, fill(0, 0));
        end density_ph;

        replaceable function temperature_ph  "Return temperature from p and h" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input SpecificEnthalpy h "Specific enthalpy";
          output Temperature T "Temperature";
        algorithm
          T := temperature_phX(p, h, fill(0, 0));
        end temperature_ph;

        redeclare replaceable partial model extends BaseProperties(final standardOrderComponents = true)  end BaseProperties;
      end PartialPureSubstance;

      partial package PartialMixtureMedium  "Base class for pure substances of several chemical substances" 
        extends PartialMedium(redeclare replaceable record FluidConstants = Modelica.Media.Interfaces.Types.IdealGas.FluidConstants);

        redeclare replaceable record extends ThermodynamicState  "Thermodynamic state variables" 
          AbsolutePressure p "Absolute pressure of medium";
          Temperature T "Temperature of medium";
          MassFraction[nX] X(start = reference_X) "Mass fractions (= (component mass)/total mass  m_i/m)";
        end ThermodynamicState;

        constant FluidConstants[nS] fluidConstants "Constant data for the fluid";

        replaceable function gasConstant  "Return the gas constant of the mixture (also for liquids)" 
          extends Modelica.Icons.Function;
          input ThermodynamicState state "Thermodynamic state";
          output .Modelica.SIunits.SpecificHeatCapacity R "Mixture gas constant";
        end gasConstant;

        function massToMoleFractions  "Return mole fractions from mass fractions X" 
          extends Modelica.Icons.Function;
          input .Modelica.SIunits.MassFraction[:] X "Mass fractions of mixture";
          input .Modelica.SIunits.MolarMass[:] MMX "Molar masses of components";
          output .Modelica.SIunits.MoleFraction[size(X, 1)] moleFractions "Mole fractions of gas mixture";
        protected
          Real[size(X, 1)] invMMX "Inverses of molar weights";
          .Modelica.SIunits.MolarMass Mmix "Molar mass of mixture";
        algorithm
          for i in 1:size(X, 1) loop
            invMMX[i] := 1 / MMX[i];
          end for;
          Mmix := 1 / (X * invMMX);
          for i in 1:size(X, 1) loop
            moleFractions[i] := Mmix * X[i] / MMX[i];
          end for;
          annotation(smoothOrder = 5); 
        end massToMoleFractions;
      end PartialMixtureMedium;

      partial package PartialCondensingGases  "Base class for mixtures of condensing and non-condensing gases" 
        extends PartialMixtureMedium(ThermoStates = Choices.IndependentVariables.pTX);

        replaceable partial function saturationPressure  "Return saturation pressure of condensing fluid" 
          extends Modelica.Icons.Function;
          input Temperature Tsat "Saturation temperature";
          output AbsolutePressure psat "Saturation pressure";
        end saturationPressure;

        replaceable partial function enthalpyOfVaporization  "Return vaporization enthalpy of condensing fluid" 
          extends Modelica.Icons.Function;
          input Temperature T "Temperature";
          output SpecificEnthalpy r0 "Vaporization enthalpy";
        end enthalpyOfVaporization;

        replaceable partial function enthalpyOfLiquid  "Return liquid enthalpy of condensing fluid" 
          extends Modelica.Icons.Function;
          input Temperature T "Temperature";
          output SpecificEnthalpy h "Liquid enthalpy";
        end enthalpyOfLiquid;

        replaceable partial function enthalpyOfGas  "Return enthalpy of non-condensing gas mixture" 
          extends Modelica.Icons.Function;
          input Temperature T "Temperature";
          input MassFraction[:] X "Vector of mass fractions";
          output SpecificEnthalpy h "Specific enthalpy";
        end enthalpyOfGas;

        replaceable partial function enthalpyOfCondensingGas  "Return enthalpy of condensing gas (most often steam)" 
          extends Modelica.Icons.Function;
          input Temperature T "Temperature";
          output SpecificEnthalpy h "Specific enthalpy";
        end enthalpyOfCondensingGas;

        replaceable partial function enthalpyOfNonCondensingGas  "Return enthalpy of the non-condensing species" 
          extends Modelica.Icons.Function;
          input Temperature T "Temperature";
          output SpecificEnthalpy h "Specific enthalpy";
        end enthalpyOfNonCondensingGas;
      end PartialCondensingGases;

      partial package PartialTwoPhaseMedium  "Base class for two phase medium of one substance" 
        extends PartialPureSubstance(redeclare record FluidConstants = Modelica.Media.Interfaces.Types.TwoPhase.FluidConstants);
        constant Boolean smoothModel = false "True if the (derived) model should not generate state events";
        constant Boolean onePhase = false "True if the (derived) model should never be called with two-phase inputs";
        constant FluidConstants[nS] fluidConstants "Constant data for the fluid";

        redeclare replaceable record extends ThermodynamicState  "Thermodynamic state of two phase medium" 
          FixedPhase phase(min = 0, max = 2) "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use";
        end ThermodynamicState;

        redeclare replaceable partial model extends BaseProperties  "Base properties (p, d, T, h, u, R, MM, sat) of two phase medium" 
          SaturationProperties sat "Saturation properties at the medium pressure";
        end BaseProperties;

        redeclare replaceable partial function extends setState_dTX  "Return thermodynamic state as function of d, T and composition X or Xi" 
          input FixedPhase phase = 0 "2 for two-phase, 1 for one-phase, 0 if not known";
        end setState_dTX;

        redeclare replaceable partial function extends setState_phX  "Return thermodynamic state as function of p, h and composition X or Xi" 
          input FixedPhase phase = 0 "2 for two-phase, 1 for one-phase, 0 if not known";
        end setState_phX;

        redeclare replaceable partial function extends setState_psX  "Return thermodynamic state as function of p, s and composition X or Xi" 
          input FixedPhase phase = 0 "2 for two-phase, 1 for one-phase, 0 if not known";
        end setState_psX;

        redeclare replaceable partial function extends setState_pTX  "Return thermodynamic state as function of p, T and composition X or Xi" 
          input FixedPhase phase = 0 "2 for two-phase, 1 for one-phase, 0 if not known";
        end setState_pTX;

        replaceable function setSat_T  "Return saturation property record from temperature" 
          extends Modelica.Icons.Function;
          input Temperature T "Temperature";
          output SaturationProperties sat "Saturation property record";
        algorithm
          sat.Tsat := T;
          sat.psat := saturationPressure(T);
        end setSat_T;

        replaceable function setSat_p  "Return saturation property record from pressure" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          output SaturationProperties sat "Saturation property record";
        algorithm
          sat.psat := p;
          sat.Tsat := saturationTemperature(p);
        end setSat_p;

        replaceable partial function bubbleEnthalpy  "Return bubble point specific enthalpy" 
          extends Modelica.Icons.Function;
          input SaturationProperties sat "Saturation property record";
          output .Modelica.SIunits.SpecificEnthalpy hl "Boiling curve specific enthalpy";
        end bubbleEnthalpy;

        replaceable partial function dewEnthalpy  "Return dew point specific enthalpy" 
          extends Modelica.Icons.Function;
          input SaturationProperties sat "Saturation property record";
          output .Modelica.SIunits.SpecificEnthalpy hv "Dew curve specific enthalpy";
        end dewEnthalpy;

        replaceable partial function bubbleDensity  "Return bubble point density" 
          extends Modelica.Icons.Function;
          input SaturationProperties sat "Saturation property record";
          output Density dl "Boiling curve density";
        end bubbleDensity;

        replaceable partial function dewDensity  "Return dew point density" 
          extends Modelica.Icons.Function;
          input SaturationProperties sat "Saturation property record";
          output Density dv "Dew curve density";
        end dewDensity;

        replaceable partial function saturationPressure  "Return saturation pressure" 
          extends Modelica.Icons.Function;
          input Temperature T "Temperature";
          output AbsolutePressure p "Saturation pressure";
        end saturationPressure;

        replaceable partial function saturationTemperature  "Return saturation temperature" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          output Temperature T "Saturation temperature";
        end saturationTemperature;

        replaceable function saturationPressure_sat  "Return saturation temperature" 
          extends Modelica.Icons.Function;
          input SaturationProperties sat "Saturation property record";
          output AbsolutePressure p "Saturation pressure";
        algorithm
          p := sat.psat;
        end saturationPressure_sat;

        replaceable function saturationTemperature_sat  "Return saturation temperature" 
          extends Modelica.Icons.Function;
          input SaturationProperties sat "Saturation property record";
          output Temperature T "Saturation temperature";
        algorithm
          T := sat.Tsat;
        end saturationTemperature_sat;

        replaceable partial function saturationTemperature_derp  "Return derivative of saturation temperature w.r.t. pressure" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          output DerTemperatureByPressure dTp "Derivative of saturation temperature w.r.t. pressure";
        end saturationTemperature_derp;

        replaceable function saturationTemperature_derp_sat  "Return derivative of saturation temperature w.r.t. pressure" 
          extends Modelica.Icons.Function;
          input SaturationProperties sat "Saturation property record";
          output DerTemperatureByPressure dTp "Derivative of saturation temperature w.r.t. pressure";
        algorithm
          dTp := saturationTemperature_derp(sat.psat);
        end saturationTemperature_derp_sat;

        redeclare replaceable function extends molarMass  "Return the molar mass of the medium" 
        algorithm
          MM := fluidConstants[1].molarMass;
        end molarMass;

        replaceable partial function dBubbleDensity_dPressure  "Return bubble point density derivative" 
          extends Modelica.Icons.Function;
          input SaturationProperties sat "Saturation property record";
          output DerDensityByPressure ddldp "Boiling curve density derivative";
        end dBubbleDensity_dPressure;

        replaceable partial function dDewDensity_dPressure  "Return dew point density derivative" 
          extends Modelica.Icons.Function;
          input SaturationProperties sat "Saturation property record";
          output DerDensityByPressure ddvdp "Saturated steam density derivative";
        end dDewDensity_dPressure;

        replaceable partial function dBubbleEnthalpy_dPressure  "Return bubble point specific enthalpy derivative" 
          extends Modelica.Icons.Function;
          input SaturationProperties sat "Saturation property record";
          output DerEnthalpyByPressure dhldp "Boiling curve specific enthalpy derivative";
        end dBubbleEnthalpy_dPressure;

        replaceable partial function dDewEnthalpy_dPressure  "Return dew point specific enthalpy derivative" 
          extends Modelica.Icons.Function;
          input SaturationProperties sat "Saturation property record";
          output DerEnthalpyByPressure dhvdp "Saturated steam specific enthalpy derivative";
        end dDewEnthalpy_dPressure;

        redeclare replaceable function specificEnthalpy_pTX  "Return specific enthalpy from pressure, temperature and mass fraction" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input Temperature T "Temperature";
          input MassFraction[:] X "Mass fractions";
          input FixedPhase phase = 0 "2 for two-phase, 1 for one-phase, 0 if not known";
          output SpecificEnthalpy h "Specific enthalpy at p, T, X";
        algorithm
          h := specificEnthalpy(setState_pTX(p, T, X, phase));
        end specificEnthalpy_pTX;

        redeclare replaceable function temperature_phX  "Return temperature from p, h, and X or Xi" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input SpecificEnthalpy h "Specific enthalpy";
          input MassFraction[:] X "Mass fractions";
          input FixedPhase phase = 0 "2 for two-phase, 1 for one-phase, 0 if not known";
          output Temperature T "Temperature";
        algorithm
          T := temperature(setState_phX(p, h, X, phase));
        end temperature_phX;

        redeclare replaceable function density_phX  "Return density from p, h, and X or Xi" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input SpecificEnthalpy h "Specific enthalpy";
          input MassFraction[:] X "Mass fractions";
          input FixedPhase phase = 0 "2 for two-phase, 1 for one-phase, 0 if not known";
          output Density d "Density";
        algorithm
          d := density(setState_phX(p, h, X, phase));
        end density_phX;

        redeclare replaceable function setState_pT  "Return thermodynamic state from p and T" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input Temperature T "Temperature";
          input FixedPhase phase = 0 "2 for two-phase, 1 for one-phase, 0 if not known";
          output ThermodynamicState state "Thermodynamic state record";
        algorithm
          state := setState_pTX(p, T, fill(0, 0), phase);
        end setState_pT;

        redeclare replaceable function setState_ph  "Return thermodynamic state from p and h" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input SpecificEnthalpy h "Specific enthalpy";
          input FixedPhase phase = 0 "2 for two-phase, 1 for one-phase, 0 if not known";
          output ThermodynamicState state "Thermodynamic state record";
        algorithm
          state := setState_phX(p, h, fill(0, 0), phase);
        end setState_ph;

        redeclare replaceable function setState_ps  "Return thermodynamic state from p and s" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input SpecificEntropy s "Specific entropy";
          input FixedPhase phase = 0 "2 for two-phase, 1 for one-phase, 0 if not known";
          output ThermodynamicState state "Thermodynamic state record";
        algorithm
          state := setState_psX(p, s, fill(0, 0), phase);
        end setState_ps;

        redeclare replaceable function setState_dT  "Return thermodynamic state from d and T" 
          extends Modelica.Icons.Function;
          input Density d "Density";
          input Temperature T "Temperature";
          input FixedPhase phase = 0 "2 for two-phase, 1 for one-phase, 0 if not known";
          output ThermodynamicState state "Thermodynamic state record";
        algorithm
          state := setState_dTX(d, T, fill(0, 0), phase);
        end setState_dT;

        redeclare replaceable function density_ph  "Return density from p and h" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input SpecificEnthalpy h "Specific enthalpy";
          input FixedPhase phase = 0 "2 for two-phase, 1 for one-phase, 0 if not known";
          output Density d "Density";
        algorithm
          d := density_phX(p, h, fill(0, 0), phase);
        end density_ph;

        redeclare replaceable function temperature_ph  "Return temperature from p and h" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input SpecificEnthalpy h "Specific enthalpy";
          input FixedPhase phase = 0 "2 for two-phase, 1 for one-phase, 0 if not known";
          output Temperature T "Temperature";
        algorithm
          T := temperature_phX(p, h, fill(0, 0), phase);
        end temperature_ph;
      end PartialTwoPhaseMedium;

      package Choices  "Types, constants to define menu choices" 
        extends Modelica.Icons.Package;
        type IndependentVariables = enumeration(T "Temperature", pT "Pressure, Temperature", ph "Pressure, Specific Enthalpy", phX "Pressure, Specific Enthalpy, Mass Fraction", pTX "Pressure, Temperature, Mass Fractions", dTX "Density, Temperature, Mass Fractions") "Enumeration defining the independent variables of a medium";
        type ReferenceEnthalpy = enumeration(ZeroAt0K "The enthalpy is 0 at 0 K (default), if the enthalpy of formation is excluded", ZeroAt25C "The enthalpy is 0 at 25 degC, if the enthalpy of formation is excluded", UserDefined "The user-defined reference enthalpy is used at 293.15 K (25 degC)") "Enumeration defining the reference enthalpy of a medium" annotation(Evaluate = true);
      end Choices;

      package Types  "Types to be used in fluid models" 
        extends Modelica.Icons.Package;
        type AbsolutePressure = .Modelica.SIunits.AbsolutePressure(min = 0, max = 1.e8, nominal = 1.e5, start = 1.e5) "Type for absolute pressure with medium specific attributes";
        type Density = .Modelica.SIunits.Density(min = 0, max = 1.e5, nominal = 1, start = 1) "Type for density with medium specific attributes";
        type DynamicViscosity = .Modelica.SIunits.DynamicViscosity(min = 0, max = 1.e8, nominal = 1.e-3, start = 1.e-3) "Type for dynamic viscosity with medium specific attributes";
        type EnthalpyFlowRate = .Modelica.SIunits.EnthalpyFlowRate(nominal = 1000.0, min = -1.0e8, max = 1.e8) "Type for enthalpy flow rate with medium specific attributes";
        type MassFraction = Real(quantity = "MassFraction", final unit = "kg/kg", min = 0, max = 1, nominal = 0.1) "Type for mass fraction with medium specific attributes";
        type MoleFraction = Real(quantity = "MoleFraction", final unit = "mol/mol", min = 0, max = 1, nominal = 0.1) "Type for mole fraction with medium specific attributes";
        type MolarMass = .Modelica.SIunits.MolarMass(min = 0.001, max = 0.25, nominal = 0.032) "Type for molar mass with medium specific attributes";
        type MolarVolume = .Modelica.SIunits.MolarVolume(min = 1e-6, max = 1.0e6, nominal = 1.0) "Type for molar volume with medium specific attributes";
        type IsentropicExponent = .Modelica.SIunits.RatioOfSpecificHeatCapacities(min = 1, max = 500000, nominal = 1.2, start = 1.2) "Type for isentropic exponent with medium specific attributes";
        type SpecificEnergy = .Modelica.SIunits.SpecificEnergy(min = -1.0e8, max = 1.e8, nominal = 1.e6) "Type for specific energy with medium specific attributes";
        type SpecificInternalEnergy = SpecificEnergy "Type for specific internal energy with medium specific attributes";
        type SpecificEnthalpy = .Modelica.SIunits.SpecificEnthalpy(min = -1.0e10, max = 1.e10, nominal = 1.e6) "Type for specific enthalpy with medium specific attributes";
        type SpecificEntropy = .Modelica.SIunits.SpecificEntropy(min = -1.e7, max = 1.e7, nominal = 1.e3) "Type for specific entropy with medium specific attributes";
        type SpecificHeatCapacity = .Modelica.SIunits.SpecificHeatCapacity(min = 0, max = 1.e7, nominal = 1.e3, start = 1.e3) "Type for specific heat capacity with medium specific attributes";
        type SurfaceTension = .Modelica.SIunits.SurfaceTension "Type for surface tension with medium specific attributes";
        type Temperature = .Modelica.SIunits.Temperature(min = 1, max = 1.e4, nominal = 300, start = 288.15) "Type for temperature with medium specific attributes";
        type ThermalConductivity = .Modelica.SIunits.ThermalConductivity(min = 0, max = 500, nominal = 1, start = 1) "Type for thermal conductivity with medium specific attributes";
        type PrandtlNumber = .Modelica.SIunits.PrandtlNumber(min = 1e-3, max = 1e5, nominal = 1.0) "Type for Prandtl number with medium specific attributes";
        type VelocityOfSound = .Modelica.SIunits.Velocity(min = 0, max = 1.e5, nominal = 1000, start = 1000) "Type for velocity of sound with medium specific attributes";
        type ExtraProperty = Real(min = 0.0, start = 1.0) "Type for unspecified, mass-specific property transported by flow";
        type ExtraPropertyFlowRate = Real(unit = "kg/s") "Type for flow rate of unspecified, mass-specific property";
        type IsobaricExpansionCoefficient = Real(min = 0, max = 1.0e8, unit = "1/K") "Type for isobaric expansion coefficient with medium specific attributes";
        type DipoleMoment = Real(min = 0.0, max = 2.0, unit = "debye", quantity = "ElectricDipoleMoment") "Type for dipole moment with medium specific attributes";
        type DerDensityByPressure = .Modelica.SIunits.DerDensityByPressure "Type for partial derivative of density with respect to pressure with medium specific attributes";
        type DerDensityByEnthalpy = .Modelica.SIunits.DerDensityByEnthalpy "Type for partial derivative of density with respect to enthalpy with medium specific attributes";
        type DerEnthalpyByPressure = .Modelica.SIunits.DerEnthalpyByPressure "Type for partial derivative of enthalpy with respect to pressure with medium specific attributes";
        type DerDensityByTemperature = .Modelica.SIunits.DerDensityByTemperature "Type for partial derivative of density with respect to temperature with medium specific attributes";
        type DerTemperatureByPressure = Real(final unit = "K/Pa") "Type for partial derivative of temperature with respect to pressure with medium specific attributes";

        replaceable record SaturationProperties  "Saturation properties of two phase medium" 
          extends Modelica.Icons.Record;
          AbsolutePressure psat "Saturation pressure";
          Temperature Tsat "Saturation temperature";
        end SaturationProperties;

        type FixedPhase = Integer(min = 0, max = 2) "Phase of the fluid: 1 for 1-phase, 2 for two-phase, 0 for not known, e.g., interactive use";

        package Basic  "The most basic version of a record used in several degrees of detail" 
          extends Icons.Package;

          record FluidConstants  "Critical, triple, molecular and other standard data of fluid" 
            extends Modelica.Icons.Record;
            String iupacName "Complete IUPAC name (or common name, if non-existent)";
            String casRegistryNumber "Chemical abstracts sequencing number (if it exists)";
            String chemicalFormula "Chemical formula, (brutto, nomenclature according to Hill";
            String structureFormula "Chemical structure formula";
            MolarMass molarMass "Molar mass";
          end FluidConstants;
        end Basic;

        package IdealGas  "The ideal gas version of a record used in several degrees of detail" 
          extends Icons.Package;

          record FluidConstants  "Extended fluid constants" 
            extends Modelica.Media.Interfaces.Types.Basic.FluidConstants;
            Temperature criticalTemperature "Critical temperature";
            AbsolutePressure criticalPressure "Critical pressure";
            MolarVolume criticalMolarVolume "Critical molar Volume";
            Real acentricFactor "Pitzer acentric factor";
            Temperature meltingPoint "Melting point at 101325 Pa";
            Temperature normalBoilingPoint "Normal boiling point (at 101325 Pa)";
            DipoleMoment dipoleMoment "Dipole moment of molecule in Debye (1 debye = 3.33564e10-30 C.m)";
            Boolean hasIdealGasHeatCapacity = false "True if ideal gas heat capacity is available";
            Boolean hasCriticalData = false "True if critical data are known";
            Boolean hasDipoleMoment = false "True if a dipole moment known";
            Boolean hasFundamentalEquation = false "True if a fundamental equation";
            Boolean hasLiquidHeatCapacity = false "True if liquid heat capacity is available";
            Boolean hasSolidHeatCapacity = false "True if solid heat capacity is available";
            Boolean hasAccurateViscosityData = false "True if accurate data for a viscosity function is available";
            Boolean hasAccurateConductivityData = false "True if accurate data for thermal conductivity is available";
            Boolean hasVapourPressureCurve = false "True if vapour pressure data, e.g., Antoine coefficients are known";
            Boolean hasAcentricFactor = false "True if Pitzer accentric factor is known";
            SpecificEnthalpy HCRIT0 = 0.0 "Critical specific enthalpy of the fundamental equation";
            SpecificEntropy SCRIT0 = 0.0 "Critical specific entropy of the fundamental equation";
            SpecificEnthalpy deltah = 0.0 "Difference between specific enthalpy model (h_m) and f.eq. (h_f) (h_m - h_f)";
            SpecificEntropy deltas = 0.0 "Difference between specific enthalpy model (s_m) and f.eq. (s_f) (s_m - s_f)";
          end FluidConstants;
        end IdealGas;

        package TwoPhase  "The two phase fluid version of a record used in several degrees of detail" 
          extends Icons.Package;

          record FluidConstants  "Extended fluid constants" 
            extends Modelica.Media.Interfaces.Types.Basic.FluidConstants;
            Temperature criticalTemperature "Critical temperature";
            AbsolutePressure criticalPressure "Critical pressure";
            MolarVolume criticalMolarVolume "Critical molar Volume";
            Real acentricFactor "Pitzer acentric factor";
            Temperature triplePointTemperature "Triple point temperature";
            AbsolutePressure triplePointPressure "Triple point pressure";
            Temperature meltingPoint "Melting point at 101325 Pa";
            Temperature normalBoilingPoint "Normal boiling point (at 101325 Pa)";
            DipoleMoment dipoleMoment "Dipole moment of molecule in Debye (1 debye = 3.33564e10-30 C.m)";
            Boolean hasIdealGasHeatCapacity = false "True if ideal gas heat capacity is available";
            Boolean hasCriticalData = false "True if critical data are known";
            Boolean hasDipoleMoment = false "True if a dipole moment known";
            Boolean hasFundamentalEquation = false "True if a fundamental equation";
            Boolean hasLiquidHeatCapacity = false "True if liquid heat capacity is available";
            Boolean hasSolidHeatCapacity = false "True if solid heat capacity is available";
            Boolean hasAccurateViscosityData = false "True if accurate data for a viscosity function is available";
            Boolean hasAccurateConductivityData = false "True if accurate data for thermal conductivity is available";
            Boolean hasVapourPressureCurve = false "True if vapour pressure data, e.g., Antoine coefficients are known";
            Boolean hasAcentricFactor = false "True if Pitzer accentric factor is known";
            SpecificEnthalpy HCRIT0 = 0.0 "Critical specific enthalpy of the fundamental equation";
            SpecificEntropy SCRIT0 = 0.0 "Critical specific entropy of the fundamental equation";
            SpecificEnthalpy deltah = 0.0 "Difference between specific enthalpy model (h_m) and f.eq. (h_f) (h_m - h_f)";
            SpecificEntropy deltas = 0.0 "Difference between specific enthalpy model (s_m) and f.eq. (s_f) (s_m - s_f)";
          end FluidConstants;
        end TwoPhase;
      end Types;
    end Interfaces;

    package Common  "Data structures and fundamental functions for fluid properties" 
      extends Modelica.Icons.Package;
      constant Real MINPOS = 1.0e-9 "Minimal value for physical variables which are always > 0.0";

      function smoothStep  "Approximation of a general step, such that the characteristic is continuous and differentiable" 
        extends Modelica.Icons.Function;
        input Real x "Abscissa value";
        input Real y1 "Ordinate value for x > 0";
        input Real y2 "Ordinate value for x < 0";
        input Real x_small(min = 0) = 1e-5 "Approximation of step for -x_small <= x <= x_small; x_small > 0 required";
        output Real y "Ordinate value to approximate y = if x > 0 then y1 else y2";
      algorithm
        y := smooth(1, if x > x_small then y1 else if x < (-x_small) then y2 else if abs(x_small) > 0 then x / x_small * ((x / x_small) ^ 2 - 3) * (y2 - y1) / 4 + (y1 + y2) / 2 else (y1 + y2) / 2);
        annotation(Inline = true, smoothOrder = 1); 
      end smoothStep;

      package OneNonLinearEquation  "Determine solution of a non-linear algebraic equation in one unknown without derivatives in a reliable and efficient way" 
        extends Modelica.Icons.Package;

        replaceable record f_nonlinear_Data  "Data specific for function f_nonlinear" 
          extends Modelica.Icons.Record;
        end f_nonlinear_Data;

        replaceable partial function f_nonlinear  "Nonlinear algebraic equation in one unknown: y = f_nonlinear(x,p,X)" 
          extends Modelica.Icons.Function;
          input Real x "Independent variable of function";
          input Real p = 0.0 "Disregarded variables (here always used for pressure)";
          input Real[:] X = fill(0, 0) "Disregarded variables (her always used for composition)";
          input f_nonlinear_Data f_nonlinear_data "Additional data for the function";
          output Real y "= f_nonlinear(x)";
        end f_nonlinear;

        replaceable function solve  "Solve f_nonlinear(x_zero)=y_zero; f_nonlinear(x_min) - y_zero and f_nonlinear(x_max)-y_zero must have different sign" 
          extends Modelica.Icons.Function;
          input Real y_zero "Determine x_zero, such that f_nonlinear(x_zero) = y_zero";
          input Real x_min "Minimum value of x";
          input Real x_max "Maximum value of x";
          input Real pressure = 0.0 "Disregarded variables (here always used for pressure)";
          input Real[:] X = fill(0, 0) "Disregarded variables (here always used for composition)";
          input f_nonlinear_Data f_nonlinear_data "Additional data for function f_nonlinear";
          input Real x_tol = 100 * Modelica.Constants.eps "Relative tolerance of the result";
          output Real x_zero "f_nonlinear(x_zero) = y_zero";
        protected
          constant Real eps = Modelica.Constants.eps "Machine epsilon";
          constant Real x_eps = 1e-10 "Slight modification of x_min, x_max, since x_min, x_max are usually exactly at the borders T_min/h_min and then small numeric noise may make the interval invalid";
          Real x_min2 = x_min - x_eps;
          Real x_max2 = x_max + x_eps;
          Real a = x_min2 "Current best minimum interval value";
          Real b = x_max2 "Current best maximum interval value";
          Real c "Intermediate point a <= c <= b";
          Real d;
          Real e "b - a";
          Real m;
          Real s;
          Real p;
          Real q;
          Real r;
          Real tol;
          Real fa "= f_nonlinear(a) - y_zero";
          Real fb "= f_nonlinear(b) - y_zero";
          Real fc;
          Boolean found = false;
        algorithm
          fa := f_nonlinear(x_min2, pressure, X, f_nonlinear_data) - y_zero;
          fb := f_nonlinear(x_max2, pressure, X, f_nonlinear_data) - y_zero;
          fc := fb;
          if fa > 0.0 and fb > 0.0 or fa < 0.0 and fb < 0.0 then
            .Modelica.Utilities.Streams.error("The arguments x_min and x_max to OneNonLinearEquation.solve(..)\n" + "do not bracket the root of the single non-linear equation:\n" + "  x_min  = " + String(x_min2) + "\n" + "  x_max  = " + String(x_max2) + "\n" + "  y_zero = " + String(y_zero) + "\n" + "  fa = f(x_min) - y_zero = " + String(fa) + "\n" + "  fb = f(x_max) - y_zero = " + String(fb) + "\n" + "fa and fb must have opposite sign which is not the case");
          else
          end if;
          c := a;
          fc := fa;
          e := b - a;
          d := e;
          while not found loop
            if abs(fc) < abs(fb) then
              a := b;
              b := c;
              c := a;
              fa := fb;
              fb := fc;
              fc := fa;
            else
            end if;
            tol := 2 * eps * abs(b) + x_tol;
            m := (c - b) / 2;
            if abs(m) <= tol or fb == 0.0 then
              found := true;
              x_zero := b;
            else
              if abs(e) < tol or abs(fa) <= abs(fb) then
                e := m;
                d := e;
              else
                s := fb / fa;
                if a == c then
                  p := 2 * m * s;
                  q := 1 - s;
                else
                  q := fa / fc;
                  r := fb / fc;
                  p := s * (2 * m * q * (q - r) - (b - a) * (r - 1));
                  q := (q - 1) * (r - 1) * (s - 1);
                end if;
                if p > 0 then
                  q := -q;
                else
                  p := -p;
                end if;
                s := e;
                e := d;
                if 2 * p < 3 * m * q - abs(tol * q) and p < abs(0.5 * s * q) then
                  d := p / q;
                else
                  e := m;
                  d := e;
                end if;
              end if;
              a := b;
              fa := fb;
              b := b + (if abs(d) > tol then d else if m > 0 then tol else -tol);
              fb := f_nonlinear(b, pressure, X, f_nonlinear_data) - y_zero;
              if fb > 0 and fc > 0 or fb < 0 and fc < 0 then
                c := a;
                fc := fa;
                e := b - a;
                d := e;
              else
              end if;
            end if;
          end while;
        end solve;
      end OneNonLinearEquation;
    end Common;

    package Air  "Medium models for air" 
      extends Modelica.Icons.VariantsPackage;

      package MoistAir  "Air: Moist air model (190 ... 647 K)" 
        extends .Modelica.Media.Interfaces.PartialCondensingGases(mediumName = "Moist air", substanceNames = {"water", "air"}, final reducedX = true, final singleState = false, reference_X = {0.01, 0.99}, fluidConstants = {IdealGases.Common.FluidData.H2O, IdealGases.Common.FluidData.N2}, Temperature(min = 190, max = 647));
        constant Integer Water = 1 "Index of water (in substanceNames, massFractions X, etc.)";
        constant Integer Air = 2 "Index of air (in substanceNames, massFractions X, etc.)";
        constant Real k_mair = steam.MM / dryair.MM "Ratio of molar weights";
        constant IdealGases.Common.DataRecord dryair = IdealGases.Common.SingleGasesData.Air;
        constant IdealGases.Common.DataRecord steam = IdealGases.Common.SingleGasesData.H2O;
        constant .Modelica.SIunits.MolarMass[2] MMX = {steam.MM, dryair.MM} "Molar masses of components";

        redeclare record extends ThermodynamicState  "ThermodynamicState record for moist air" end ThermodynamicState;

        redeclare replaceable model extends BaseProperties(T(stateSelect = if preferredMediumStates then StateSelect.prefer else StateSelect.default), p(stateSelect = if preferredMediumStates then StateSelect.prefer else StateSelect.default), Xi(each stateSelect = if preferredMediumStates then StateSelect.prefer else StateSelect.default), final standardOrderComponents = true)  "Moist air base properties record" 
          MassFraction x_water "Mass of total water/mass of dry air";
          Real phi "Relative humidity";
        protected
          MassFraction X_liquid "Mass fraction of liquid or solid water";
          MassFraction X_steam "Mass fraction of steam water";
          MassFraction X_air "Mass fraction of air";
          MassFraction X_sat "Steam water mass fraction of saturation boundary in kg_water/kg_moistair";
          MassFraction x_sat "Steam water mass content of saturation boundary in kg_water/kg_dryair";
          AbsolutePressure p_steam_sat "partial saturation pressure of steam";
        equation
          assert(T >= 190 and T <= 647, "
        Temperature T is not in the allowed range
        190.0 K <= (T =" + String(T) + " K) <= 647.0 K
        required from medium model \"" + mediumName + "\".");
          MM = 1 / (Xi[Water] / MMX[Water] + (1.0 - Xi[Water]) / MMX[Air]);
          p_steam_sat = min(saturationPressure(T), 0.999 * p);
          X_sat = min(p_steam_sat * k_mair / max(100 * .Modelica.Constants.eps, p - p_steam_sat) * (1 - Xi[Water]), 1.0) "Water content at saturation with respect to actual water content";
          X_liquid = max(Xi[Water] - X_sat, 0.0);
          X_steam = Xi[Water] - X_liquid;
          X_air = 1 - Xi[Water];
          h = specificEnthalpy_pTX(p, T, Xi);
          R = dryair.R * (X_air / (1 - X_liquid)) + steam.R * X_steam / (1 - X_liquid);
          u = h - R * T;
          d = p / (R * T);
          state.p = p;
          state.T = T;
          state.X = X;
          x_sat = k_mair * p_steam_sat / max(100 * .Modelica.Constants.eps, p - p_steam_sat);
          x_water = Xi[Water] / max(X_air, 100 * .Modelica.Constants.eps);
          phi = p / p_steam_sat * Xi[Water] / (Xi[Water] + k_mair * X_air);
        end BaseProperties;

        redeclare function setState_pTX  "Return thermodynamic state as function of pressure p, temperature T and composition X" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input Temperature T "Temperature";
          input MassFraction[:] X = reference_X "Mass fractions";
          output ThermodynamicState state "Thermodynamic state";
        algorithm
          state := if size(X, 1) == nX then ThermodynamicState(p = p, T = T, X = X) else ThermodynamicState(p = p, T = T, X = cat(1, X, {1 - sum(X)}));
          annotation(smoothOrder = 2); 
        end setState_pTX;

        redeclare function setState_phX  "Return thermodynamic state as function of pressure p, specific enthalpy h and composition X" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input SpecificEnthalpy h "Specific enthalpy";
          input MassFraction[:] X = reference_X "Mass fractions";
          output ThermodynamicState state "Thermodynamic state";
        algorithm
          state := if size(X, 1) == nX then ThermodynamicState(p = p, T = T_phX(p, h, X), X = X) else ThermodynamicState(p = p, T = T_phX(p, h, X), X = cat(1, X, {1 - sum(X)}));
          annotation(smoothOrder = 2); 
        end setState_phX;

        redeclare function setState_dTX  "Return thermodynamic state as function of density d, temperature T and composition X" 
          extends Modelica.Icons.Function;
          input Density d "Density";
          input Temperature T "Temperature";
          input MassFraction[:] X = reference_X "Mass fractions";
          output ThermodynamicState state "Thermodynamic state";
        algorithm
          state := if size(X, 1) == nX then ThermodynamicState(p = d * ({steam.R, dryair.R} * X) * T, T = T, X = X) else ThermodynamicState(p = d * ({steam.R, dryair.R} * cat(1, X, {1 - sum(X)})) * T, T = T, X = cat(1, X, {1 - sum(X)}));
          annotation(smoothOrder = 2); 
        end setState_dTX;

        redeclare function extends setSmoothState  "Return thermodynamic state so that it smoothly approximates: if x > 0 then state_a else state_b" 
        algorithm
          state := ThermodynamicState(p = Media.Common.smoothStep(x, state_a.p, state_b.p, x_small), T = Media.Common.smoothStep(x, state_a.T, state_b.T, x_small), X = Media.Common.smoothStep(x, state_a.X, state_b.X, x_small));
        end setSmoothState;

        redeclare function extends gasConstant  "Return ideal gas constant as a function from thermodynamic state, only valid for phi<1" 
        algorithm
          R := dryair.R * (1 - state.X[Water]) + steam.R * state.X[Water];
          annotation(smoothOrder = 2); 
        end gasConstant;

        function saturationPressureLiquid  "Return saturation pressure of water as a function of temperature T in the range of 273.16 to 647.096 K" 
          extends Modelica.Icons.Function;
          input .Modelica.SIunits.Temperature Tsat "Saturation temperature";
          output .Modelica.SIunits.AbsolutePressure psat "Saturation pressure";
        protected
          .Modelica.SIunits.Temperature Tcritical = 647.096 "Critical temperature";
          .Modelica.SIunits.AbsolutePressure pcritical = 22.064e6 "Critical pressure";
          Real r1 = 1 - Tsat / Tcritical "Common subexpression";
          Real[:] a = {-7.85951783, 1.84408259, -11.7866497, 22.6807411, -15.9618719, 1.80122502} "Coefficients a[:]";
          Real[:] n = {1.0, 1.5, 3.0, 3.5, 4.0, 7.5} "Coefficients n[:]";
        algorithm
          psat := exp((a[1] * r1 ^ n[1] + a[2] * r1 ^ n[2] + a[3] * r1 ^ n[3] + a[4] * r1 ^ n[4] + a[5] * r1 ^ n[5] + a[6] * r1 ^ n[6]) * Tcritical / Tsat) * pcritical;
          annotation(derivative = saturationPressureLiquid_der, Inline = false, smoothOrder = 5); 
        end saturationPressureLiquid;

        function saturationPressureLiquid_der  "Derivative function for 'saturationPressureLiquid'" 
          extends Modelica.Icons.Function;
          input .Modelica.SIunits.Temperature Tsat "Saturation temperature";
          input Real dTsat(unit = "K/s") "Saturation temperature derivative";
          output Real psat_der(unit = "Pa/s") "Saturation pressure derivative";
        protected
          .Modelica.SIunits.Temperature Tcritical = 647.096 "Critical temperature";
          .Modelica.SIunits.AbsolutePressure pcritical = 22.064e6 "Critical pressure";
          Real r1 = 1 - Tsat / Tcritical "Common subexpression 1";
          Real r1_der = -1 / Tcritical * dTsat "Derivative of common subexpression 1";
          Real[:] a = {-7.85951783, 1.84408259, -11.7866497, 22.6807411, -15.9618719, 1.80122502} "Coefficients a[:]";
          Real[:] n = {1.0, 1.5, 3.0, 3.5, 4.0, 7.5} "Coefficients n[:]";
          Real r2 = a[1] * r1 ^ n[1] + a[2] * r1 ^ n[2] + a[3] * r1 ^ n[3] + a[4] * r1 ^ n[4] + a[5] * r1 ^ n[5] + a[6] * r1 ^ n[6] "Common subexpression 2";
        algorithm
          psat_der := exp(r2 * Tcritical / Tsat) * pcritical * ((a[1] * (r1 ^ (n[1] - 1) * n[1] * r1_der) + a[2] * (r1 ^ (n[2] - 1) * n[2] * r1_der) + a[3] * (r1 ^ (n[3] - 1) * n[3] * r1_der) + a[4] * (r1 ^ (n[4] - 1) * n[4] * r1_der) + a[5] * (r1 ^ (n[5] - 1) * n[5] * r1_der) + a[6] * (r1 ^ (n[6] - 1) * n[6] * r1_der)) * Tcritical / Tsat - r2 * Tcritical * dTsat / Tsat ^ 2);
          annotation(Inline = false, smoothOrder = 5); 
        end saturationPressureLiquid_der;

        function sublimationPressureIce  "Return sublimation pressure of water as a function of temperature T between 190 and 273.16 K" 
          extends Modelica.Icons.Function;
          input .Modelica.SIunits.Temperature Tsat "Sublimation temperature";
          output .Modelica.SIunits.AbsolutePressure psat "Sublimation pressure";
        protected
          .Modelica.SIunits.Temperature Ttriple = 273.16 "Triple point temperature";
          .Modelica.SIunits.AbsolutePressure ptriple = 611.657 "Triple point pressure";
          Real r1 = Tsat / Ttriple "Common subexpression";
          Real[:] a = {-13.9281690, 34.7078238} "Coefficients a[:]";
          Real[:] n = {-1.5, -1.25} "Coefficients n[:]";
        algorithm
          psat := exp(a[1] - a[1] * r1 ^ n[1] + a[2] - a[2] * r1 ^ n[2]) * ptriple;
          annotation(Inline = false, smoothOrder = 5, derivative = sublimationPressureIce_der); 
        end sublimationPressureIce;

        function sublimationPressureIce_der  "Derivative function for 'sublimationPressureIce'" 
          extends Modelica.Icons.Function;
          input .Modelica.SIunits.Temperature Tsat "Sublimation temperature";
          input Real dTsat(unit = "K/s") "Sublimation temperature derivative";
          output Real psat_der(unit = "Pa/s") "Sublimation pressure derivative";
        protected
          .Modelica.SIunits.Temperature Ttriple = 273.16 "Triple point temperature";
          .Modelica.SIunits.AbsolutePressure ptriple = 611.657 "Triple point pressure";
          Real r1 = Tsat / Ttriple "Common subexpression 1";
          Real r1_der = dTsat / Ttriple "Derivative of common subexpression 1";
          Real[:] a = {-13.9281690, 34.7078238} "Coefficients a[:]";
          Real[:] n = {-1.5, -1.25} "Coefficients n[:]";
        algorithm
          psat_der := exp(a[1] - a[1] * r1 ^ n[1] + a[2] - a[2] * r1 ^ n[2]) * ptriple * ((-a[1] * (r1 ^ (n[1] - 1) * n[1] * r1_der)) - a[2] * (r1 ^ (n[2] - 1) * n[2] * r1_der));
          annotation(Inline = false, smoothOrder = 5); 
        end sublimationPressureIce_der;

        redeclare function extends saturationPressure  "Return saturation pressure of water as a function of temperature T between 190 and 647.096 K" 
        algorithm
          psat := Utilities.spliceFunction(saturationPressureLiquid(Tsat), sublimationPressureIce(Tsat), Tsat - 273.16, 1.0);
          annotation(Inline = false, smoothOrder = 5, derivative = saturationPressure_der); 
        end saturationPressure;

        function saturationPressure_der  "Derivative function for 'saturationPressure'" 
          extends Modelica.Icons.Function;
          input Temperature Tsat "Saturation temperature";
          input Real dTsat(unit = "K/s") "Time derivative of saturation temperature";
          output Real psat_der(unit = "Pa/s") "Saturation pressure";
        algorithm
          psat_der := Utilities.spliceFunction_der(saturationPressureLiquid(Tsat), sublimationPressureIce(Tsat), Tsat - 273.16, 1.0, saturationPressureLiquid_der(Tsat = Tsat, dTsat = dTsat), sublimationPressureIce_der(Tsat = Tsat, dTsat = dTsat), dTsat, 0);
          annotation(Inline = false, smoothOrder = 5); 
        end saturationPressure_der;

        redeclare function extends enthalpyOfVaporization  "Return enthalpy of vaporization of water as a function of temperature T, 273.16 to 647.096 K" 
        protected
          Real Tcritical = 647.096 "Critical temperature";
          Real dcritical = 322 "Critical density";
          Real pcritical = 22.064e6 "Critical pressure";
          Real[:] n = {1, 1.5, 3, 3.5, 4, 7.5} "Powers in equation (1)";
          Real[:] a = {-7.85951783, 1.84408259, -11.7866497, 22.6807411, -15.9618719, 1.80122502} "Coefficients in equation (1) of [1]";
          Real[:] m = {1 / 3, 2 / 3, 5 / 3, 16 / 3, 43 / 3, 110 / 3} "Powers in equation (2)";
          Real[:] b = {1.99274064, 1.09965342, -0.510839303, -1.75493479, -45.5170352, -6.74694450e5} "Coefficients in equation (2) of [1]";
          Real[:] o = {2 / 6, 4 / 6, 8 / 6, 18 / 6, 37 / 6, 71 / 6} "Powers in equation (3)";
          Real[:] c = {-2.03150240, -2.68302940, -5.38626492, -17.2991605, -44.7586581, -63.9201063} "Coefficients in equation (3) of [1]";
          Real tau = 1 - T / Tcritical "Temperature expression";
          Real r1 = a[1] * Tcritical * tau ^ n[1] / T + a[2] * Tcritical * tau ^ n[2] / T + a[3] * Tcritical * tau ^ n[3] / T + a[4] * Tcritical * tau ^ n[4] / T + a[5] * Tcritical * tau ^ n[5] / T + a[6] * Tcritical * tau ^ n[6] / T "Expression 1";
          Real r2 = a[1] * n[1] * tau ^ n[1] + a[2] * n[2] * tau ^ n[2] + a[3] * n[3] * tau ^ n[3] + a[4] * n[4] * tau ^ n[4] + a[5] * n[5] * tau ^ n[5] + a[6] * n[6] * tau ^ n[6] "Expression 2";
          Real dp = dcritical * (1 + b[1] * tau ^ m[1] + b[2] * tau ^ m[2] + b[3] * tau ^ m[3] + b[4] * tau ^ m[4] + b[5] * tau ^ m[5] + b[6] * tau ^ m[6]) "Density of saturated liquid";
          Real dpp = dcritical * exp(c[1] * tau ^ o[1] + c[2] * tau ^ o[2] + c[3] * tau ^ o[3] + c[4] * tau ^ o[4] + c[5] * tau ^ o[5] + c[6] * tau ^ o[6]) "Density of saturated vapor";
        algorithm
          r0 := -(dp - dpp) * exp(r1) * pcritical * (r2 + r1 * tau) / (dp * dpp * tau) "Difference of equations (7) and (6)";
          annotation(smoothOrder = 2); 
        end enthalpyOfVaporization;

        redeclare function extends enthalpyOfLiquid  "Return enthalpy of liquid water as a function of temperature T(use enthalpyOfWater instead)" 
        algorithm
          h := (T - 273.15) * 1e3 * (4.2166 - 0.5 * (T - 273.15) * (0.0033166 + 0.333333 * (T - 273.15) * (0.00010295 - 0.25 * (T - 273.15) * (1.3819e-6 + 0.2 * (T - 273.15) * 7.3221e-9))));
          annotation(Inline = false, smoothOrder = 5); 
        end enthalpyOfLiquid;

        redeclare function extends enthalpyOfGas  "Return specific enthalpy of gas (air and steam) as a function of temperature T and composition X" 
        algorithm
          h := Modelica.Media.IdealGases.Common.Functions.h_Tlow(data = steam, T = T, refChoice = .Modelica.Media.Interfaces.Choices.ReferenceEnthalpy.UserDefined, h_off = 46479.819 + 2501014.5) * X[Water] + Modelica.Media.IdealGases.Common.Functions.h_Tlow(data = dryair, T = T, refChoice = .Modelica.Media.Interfaces.Choices.ReferenceEnthalpy.UserDefined, h_off = 25104.684) * (1.0 - X[Water]);
          annotation(Inline = false, smoothOrder = 5); 
        end enthalpyOfGas;

        redeclare function extends enthalpyOfCondensingGas  "Return specific enthalpy of steam as a function of temperature T" 
        algorithm
          h := Modelica.Media.IdealGases.Common.Functions.h_Tlow(data = steam, T = T, refChoice = .Modelica.Media.Interfaces.Choices.ReferenceEnthalpy.UserDefined, h_off = 46479.819 + 2501014.5);
          annotation(Inline = false, smoothOrder = 5); 
        end enthalpyOfCondensingGas;

        redeclare function extends enthalpyOfNonCondensingGas  "Return specific enthalpy of dry air as a function of temperature T" 
        algorithm
          h := Modelica.Media.IdealGases.Common.Functions.h_Tlow(data = dryair, T = T, refChoice = .Modelica.Media.Interfaces.Choices.ReferenceEnthalpy.UserDefined, h_off = 25104.684);
          annotation(Inline = false, smoothOrder = 1); 
        end enthalpyOfNonCondensingGas;

        function enthalpyOfWater  "Computes specific enthalpy of water (solid/liquid) near atmospheric pressure from temperature T" 
          extends Modelica.Icons.Function;
          input SIunits.Temperature T "Temperature";
          output SIunits.SpecificEnthalpy h "Specific enthalpy of water";
        algorithm
          h := Utilities.spliceFunction(4200 * (T - 273.15), 2050 * (T - 273.15) - 333000, T - 273.16, 0.1);
          annotation(derivative = enthalpyOfWater_der); 
        end enthalpyOfWater;

        function enthalpyOfWater_der  "Derivative function of enthalpyOfWater" 
          extends Modelica.Icons.Function;
          input SIunits.Temperature T "Temperature";
          input Real dT(unit = "K/s") "Time derivative of temperature";
          output Real dh(unit = "J/(kg.s)") "Time derivative of specific enthalpy";
        algorithm
          dh := Utilities.spliceFunction_der(4200 * (T - 273.15), 2050 * (T - 273.15) - 333000, T - 273.16, 0.1, 4200 * dT, 2050 * dT, dT, 0);
        end enthalpyOfWater_der;

        redeclare function extends pressure  "Returns pressure of ideal gas as a function of the thermodynamic state record" 
        algorithm
          p := state.p;
          annotation(smoothOrder = 2); 
        end pressure;

        redeclare function extends temperature  "Return temperature of ideal gas as a function of the thermodynamic state record" 
        algorithm
          T := state.T;
          annotation(smoothOrder = 2); 
        end temperature;

        function T_phX  "Return temperature as a function of pressure p, specific enthalpy h and composition X" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input SpecificEnthalpy h "Specific enthalpy";
          input MassFraction[:] X "Mass fractions of composition";
          output Temperature T "Temperature";

        protected
          package Internal  "Solve h(data,T) for T with given h (use only indirectly via temperature_phX)" 
            extends Modelica.Media.Common.OneNonLinearEquation;

            redeclare record extends f_nonlinear_Data  "Data to be passed to non-linear function" 
              extends Modelica.Media.IdealGases.Common.DataRecord;
            end f_nonlinear_Data;

            redeclare function extends f_nonlinear  
            algorithm
              y := h_pTX(p, x, X);
            end f_nonlinear;

            redeclare function extends solve  end solve;
          end Internal;
        algorithm
          T := Internal.solve(h, 190, 647, p, X[1:nXi], steam);
        end T_phX;

        redeclare function extends density  "Returns density of ideal gas as a function of the thermodynamic state record" 
        algorithm
          d := state.p / (gasConstant(state) * state.T);
          annotation(smoothOrder = 2); 
        end density;

        redeclare function extends specificEnthalpy  "Return specific enthalpy of moist air as a function of the thermodynamic state record" 
        algorithm
          h := h_pTX(state.p, state.T, state.X);
          annotation(smoothOrder = 2); 
        end specificEnthalpy;

        function h_pTX  "Return specific enthalpy of moist air as a function of pressure p, temperature T and composition X" 
          extends Modelica.Icons.Function;
          input .Modelica.SIunits.Pressure p "Pressure";
          input .Modelica.SIunits.Temperature T "Temperature";
          input .Modelica.SIunits.MassFraction[:] X "Mass fractions of moist air";
          output .Modelica.SIunits.SpecificEnthalpy h "Specific enthalpy at p, T, X";
        protected
          .Modelica.SIunits.AbsolutePressure p_steam_sat "partial saturation pressure of steam";
          .Modelica.SIunits.MassFraction X_sat "Absolute humidity per unit mass of moist air";
          .Modelica.SIunits.MassFraction X_liquid "Mass fraction of liquid water";
          .Modelica.SIunits.MassFraction X_steam "Mass fraction of steam water";
          .Modelica.SIunits.MassFraction X_air "Mass fraction of air";
        algorithm
          p_steam_sat := saturationPressure(T);
          X_sat := min(p_steam_sat * k_mair / max(100 * .Modelica.Constants.eps, p - p_steam_sat) * (1 - X[Water]), 1.0);
          X_liquid := max(X[Water] - X_sat, 0.0);
          X_steam := X[Water] - X_liquid;
          X_air := 1 - X[Water];
          h := {Modelica.Media.IdealGases.Common.Functions.h_Tlow(data = steam, T = T, refChoice = .Modelica.Media.Interfaces.Choices.ReferenceEnthalpy.UserDefined, h_off = 46479.819 + 2501014.5), Modelica.Media.IdealGases.Common.Functions.h_Tlow(data = dryair, T = T, refChoice = .Modelica.Media.Interfaces.Choices.ReferenceEnthalpy.UserDefined, h_off = 25104.684)} * {X_steam, X_air} + enthalpyOfWater(T) * X_liquid;
          annotation(derivative = h_pTX_der, Inline = false); 
        end h_pTX;

        function h_pTX_der  "Derivative function of h_pTX" 
          extends Modelica.Icons.Function;
          input .Modelica.SIunits.Pressure p "Pressure";
          input .Modelica.SIunits.Temperature T "Temperature";
          input .Modelica.SIunits.MassFraction[:] X "Mass fractions of moist air";
          input Real dp(unit = "Pa/s") "Pressure derivative";
          input Real dT(unit = "K/s") "Temperature derivative";
          input Real[:] dX(each unit = "1/s") "Composition derivative";
          output Real h_der(unit = "J/(kg.s)") "Time derivative of specific enthalpy";
        protected
          .Modelica.SIunits.AbsolutePressure p_steam_sat "partial saturation pressure of steam";
          .Modelica.SIunits.MassFraction X_sat "Absolute humidity per unit mass of moist air";
          .Modelica.SIunits.MassFraction X_liquid "Mass fraction of liquid water";
          .Modelica.SIunits.MassFraction X_steam "Mass fraction of steam water";
          .Modelica.SIunits.MassFraction X_air "Mass fraction of air";
          .Modelica.SIunits.MassFraction x_sat "Absolute humidity per unit mass of dry air at saturation";
          Real dX_steam(unit = "1/s") "Time derivative of steam mass fraction";
          Real dX_air(unit = "1/s") "Time derivative of dry air mass fraction";
          Real dX_liq(unit = "1/s") "Time derivative of liquid/solid water mass fraction";
          Real dps(unit = "Pa/s") "Time derivative of saturation pressure";
          Real dx_sat(unit = "1/s") "Time derivative of absolute humidity per unit mass of dry air";
        algorithm
          p_steam_sat := saturationPressure(T);
          x_sat := p_steam_sat * k_mair / max(100 * Modelica.Constants.eps, p - p_steam_sat);
          X_sat := min(x_sat * (1 - X[Water]), 1.0);
          X_liquid := Utilities.smoothMax(X[Water] - X_sat, 0.0, 1e-5);
          X_steam := X[Water] - X_liquid;
          X_air := 1 - X[Water];
          dX_air := -dX[Water];
          dps := saturationPressure_der(Tsat = T, dTsat = dT);
          dx_sat := k_mair * (dps * (p - p_steam_sat) - p_steam_sat * (dp - dps)) / (p - p_steam_sat) / (p - p_steam_sat);
          dX_liq := Utilities.smoothMax_der(X[Water] - X_sat, 0.0, 1e-5, (1 + x_sat) * dX[Water] - (1 - X[Water]) * dx_sat, 0, 0);
          dX_steam := dX[Water] - dX_liq;
          h_der := X_steam * Modelica.Media.IdealGases.Common.Functions.h_Tlow_der(data = steam, T = T, refChoice = .Modelica.Media.Interfaces.Choices.ReferenceEnthalpy.UserDefined, h_off = 46479.819 + 2501014.5, dT = dT) + dX_steam * Modelica.Media.IdealGases.Common.Functions.h_Tlow(data = steam, T = T, refChoice = .Modelica.Media.Interfaces.Choices.ReferenceEnthalpy.UserDefined, h_off = 46479.819 + 2501014.5) + X_air * Modelica.Media.IdealGases.Common.Functions.h_Tlow_der(data = dryair, T = T, refChoice = .Modelica.Media.Interfaces.Choices.ReferenceEnthalpy.UserDefined, h_off = 25104.684, dT = dT) + dX_air * Modelica.Media.IdealGases.Common.Functions.h_Tlow(data = dryair, T = T, refChoice = .Modelica.Media.Interfaces.Choices.ReferenceEnthalpy.UserDefined, h_off = 25104.684) + X_liquid * enthalpyOfWater_der(T = T, dT = dT) + dX_liq * enthalpyOfWater(T);
          annotation(Inline = false, smoothOrder = 1); 
        end h_pTX_der;

        redeclare function extends isentropicExponent  "Return isentropic exponent (only for gas fraction!)" 
        algorithm
          gamma := specificHeatCapacityCp(state) / specificHeatCapacityCv(state);
        end isentropicExponent;

        redeclare function extends specificInternalEnergy  "Return specific internal energy of moist air as a function of the thermodynamic state record" 
          extends Modelica.Icons.Function;
          output .Modelica.SIunits.SpecificInternalEnergy u "Specific internal energy";
        algorithm
          u := specificInternalEnergy_pTX(state.p, state.T, state.X);
          annotation(smoothOrder = 2); 
        end specificInternalEnergy;

        function specificInternalEnergy_pTX  "Return specific internal energy of moist air as a function of pressure p, temperature T and composition X" 
          extends Modelica.Icons.Function;
          input .Modelica.SIunits.Pressure p "Pressure";
          input .Modelica.SIunits.Temperature T "Temperature";
          input .Modelica.SIunits.MassFraction[:] X "Mass fractions of moist air";
          output .Modelica.SIunits.SpecificInternalEnergy u "Specific internal energy";
        protected
          .Modelica.SIunits.AbsolutePressure p_steam_sat "partial saturation pressure of steam";
          .Modelica.SIunits.MassFraction X_liquid "Mass fraction of liquid water";
          .Modelica.SIunits.MassFraction X_steam "Mass fraction of steam water";
          .Modelica.SIunits.MassFraction X_air "Mass fraction of air";
          .Modelica.SIunits.MassFraction X_sat "Absolute humidity per unit mass of moist air";
          Real R_gas "Ideal gas constant";
        algorithm
          p_steam_sat := saturationPressure(T);
          X_sat := min(p_steam_sat * k_mair / max(100 * .Modelica.Constants.eps, p - p_steam_sat) * (1 - X[Water]), 1.0);
          X_liquid := max(X[Water] - X_sat, 0.0);
          X_steam := X[Water] - X_liquid;
          X_air := 1 - X[Water];
          R_gas := dryair.R * X_air / (1 - X_liquid) + steam.R * X_steam / (1 - X_liquid);
          u := X_steam * Modelica.Media.IdealGases.Common.Functions.h_Tlow(data = steam, T = T, refChoice = .Modelica.Media.Interfaces.Choices.ReferenceEnthalpy.UserDefined, h_off = 46479.819 + 2501014.5) + X_air * Modelica.Media.IdealGases.Common.Functions.h_Tlow(data = dryair, T = T, refChoice = .Modelica.Media.Interfaces.Choices.ReferenceEnthalpy.UserDefined, h_off = 25104.684) + enthalpyOfWater(T) * X_liquid - R_gas * T;
          annotation(derivative = specificInternalEnergy_pTX_der); 
        end specificInternalEnergy_pTX;

        function specificInternalEnergy_pTX_der  "Derivative function for specificInternalEnergy_pTX" 
          extends Modelica.Icons.Function;
          input .Modelica.SIunits.Pressure p "Pressure";
          input .Modelica.SIunits.Temperature T "Temperature";
          input .Modelica.SIunits.MassFraction[:] X "Mass fractions of moist air";
          input Real dp(unit = "Pa/s") "Pressure derivative";
          input Real dT(unit = "K/s") "Temperature derivative";
          input Real[:] dX(each unit = "1/s") "Mass fraction derivatives";
          output Real u_der(unit = "J/(kg.s)") "Specific internal energy derivative";
        protected
          .Modelica.SIunits.AbsolutePressure p_steam_sat "partial saturation pressure of steam";
          .Modelica.SIunits.MassFraction X_liquid "Mass fraction of liquid water";
          .Modelica.SIunits.MassFraction X_steam "Mass fraction of steam water";
          .Modelica.SIunits.MassFraction X_air "Mass fraction of air";
          .Modelica.SIunits.MassFraction X_sat "Absolute humidity per unit mass of moist air";
          .Modelica.SIunits.SpecificHeatCapacity R_gas "Ideal gas constant";
          .Modelica.SIunits.MassFraction x_sat "Absolute humidity per unit mass of dry air at saturation";
          Real dX_steam(unit = "1/s") "Time derivative of steam mass fraction";
          Real dX_air(unit = "1/s") "Time derivative of dry air mass fraction";
          Real dX_liq(unit = "1/s") "Time derivative of liquid/solid water mass fraction";
          Real dps(unit = "Pa/s") "Time derivative of saturation pressure";
          Real dx_sat(unit = "1/s") "Time derivative of absolute humidity per unit mass of dry air";
          Real dR_gas(unit = "J/(kg.K.s)") "Time derivative of ideal gas constant";
        algorithm
          p_steam_sat := saturationPressure(T);
          x_sat := p_steam_sat * k_mair / max(100 * Modelica.Constants.eps, p - p_steam_sat);
          X_sat := min(x_sat * (1 - X[Water]), 1.0);
          X_liquid := Utilities.spliceFunction(X[Water] - X_sat, 0.0, X[Water] - X_sat, 1e-6);
          X_steam := X[Water] - X_liquid;
          X_air := 1 - X[Water];
          R_gas := steam.R * X_steam / (1 - X_liquid) + dryair.R * X_air / (1 - X_liquid);
          dX_air := -dX[Water];
          dps := saturationPressure_der(Tsat = T, dTsat = dT);
          dx_sat := k_mair * (dps * (p - p_steam_sat) - p_steam_sat * (dp - dps)) / (p - p_steam_sat) / (p - p_steam_sat);
          dX_liq := Utilities.spliceFunction_der(X[Water] - X_sat, 0.0, X[Water] - X_sat, 1e-6, (1 + x_sat) * dX[Water] - (1 - X[Water]) * dx_sat, 0.0, (1 + x_sat) * dX[Water] - (1 - X[Water]) * dx_sat, 0.0);
          dX_steam := dX[Water] - dX_liq;
          dR_gas := (steam.R * (dX_steam * (1 - X_liquid) + dX_liq * X_steam) + dryair.R * (dX_air * (1 - X_liquid) + dX_liq * X_air)) / (1 - X_liquid) / (1 - X_liquid);
          u_der := X_steam * Modelica.Media.IdealGases.Common.Functions.h_Tlow_der(data = steam, T = T, refChoice = .Modelica.Media.Interfaces.Choices.ReferenceEnthalpy.UserDefined, h_off = 46479.819 + 2501014.5, dT = dT) + dX_steam * Modelica.Media.IdealGases.Common.Functions.h_Tlow(data = steam, T = T, refChoice = .Modelica.Media.Interfaces.Choices.ReferenceEnthalpy.UserDefined, h_off = 46479.819 + 2501014.5) + X_air * Modelica.Media.IdealGases.Common.Functions.h_Tlow_der(data = dryair, T = T, refChoice = .Modelica.Media.Interfaces.Choices.ReferenceEnthalpy.UserDefined, h_off = 25104.684, dT = dT) + dX_air * Modelica.Media.IdealGases.Common.Functions.h_Tlow(data = dryair, T = T, refChoice = .Modelica.Media.Interfaces.Choices.ReferenceEnthalpy.UserDefined, h_off = 25104.684) + X_liquid * enthalpyOfWater_der(T = T, dT = dT) + dX_liq * enthalpyOfWater(T) - dR_gas * T - R_gas * dT;
        end specificInternalEnergy_pTX_der;

        redeclare function extends specificEntropy  "Return specific entropy from thermodynamic state record, only valid for phi<1" 
        algorithm
          s := s_pTX(state.p, state.T, state.X);
          annotation(Inline = false, smoothOrder = 2); 
        end specificEntropy;

        redeclare function extends specificGibbsEnergy  "Return specific Gibbs energy as a function of the thermodynamic state record, only valid for phi<1" 
          extends Modelica.Icons.Function;
        algorithm
          g := h_pTX(state.p, state.T, state.X) - state.T * specificEntropy(state);
          annotation(smoothOrder = 2); 
        end specificGibbsEnergy;

        redeclare function extends specificHelmholtzEnergy  "Return specific Helmholtz energy as a function of the thermodynamic state record, only valid for phi<1" 
          extends Modelica.Icons.Function;
        algorithm
          f := h_pTX(state.p, state.T, state.X) - gasConstant(state) * state.T - state.T * specificEntropy(state);
          annotation(smoothOrder = 2); 
        end specificHelmholtzEnergy;

        redeclare function extends specificHeatCapacityCp  "Return specific heat capacity at constant pressure as a function of the thermodynamic state record" 
        protected
          Real dT(unit = "s/K") = 1.0;
        algorithm
          cp := h_pTX_der(state.p, state.T, state.X, 0.0, 1.0, zeros(size(state.X, 1))) * dT "Definition of cp: dh/dT @ constant p";
          annotation(Inline = false, smoothOrder = 2); 
        end specificHeatCapacityCp;

        redeclare function extends specificHeatCapacityCv  "Return specific heat capacity at constant volume as a function of the thermodynamic state record" 
        algorithm
          cv := Modelica.Media.IdealGases.Common.Functions.cp_Tlow(dryair, state.T) * (1 - state.X[Water]) + Modelica.Media.IdealGases.Common.Functions.cp_Tlow(steam, state.T) * state.X[Water] - gasConstant(state);
          annotation(Inline = false, smoothOrder = 2); 
        end specificHeatCapacityCv;

        redeclare function extends dynamicViscosity  "Return dynamic viscosity as a function of the thermodynamic state record, valid from 123.15 K to 1273.15 K" 
        algorithm
          eta := 1e-6 * .Modelica.Media.Incompressible.TableBased.Polynomials_Temp.evaluateWithRange({9.7391102886305869E-15, -3.1353724870333906E-11, 4.3004876595642225E-08, -3.8228016291758240E-05, 5.0427874367180762E-02, 1.7239260139242528E+01}, .Modelica.SIunits.Conversions.to_degC(123.15), .Modelica.SIunits.Conversions.to_degC(1273.15), .Modelica.SIunits.Conversions.to_degC(state.T));
          annotation(smoothOrder = 2); 
        end dynamicViscosity;

        redeclare function extends thermalConductivity  "Return thermal conductivity as a function of the thermodynamic state record, valid from 123.15 K to 1273.15 K" 
        algorithm
          lambda := 1e-3 * .Modelica.Media.Incompressible.TableBased.Polynomials_Temp.evaluateWithRange({6.5691470817717812E-15, -3.4025961923050509E-11, 5.3279284846303157E-08, -4.5340839289219472E-05, 7.6129675309037664E-02, 2.4169481088097051E+01}, .Modelica.SIunits.Conversions.to_degC(123.15), .Modelica.SIunits.Conversions.to_degC(1273.15), .Modelica.SIunits.Conversions.to_degC(state.T));
          annotation(smoothOrder = 2); 
        end thermalConductivity;

        redeclare function extends velocityOfSound  
        algorithm
          a := sqrt(isentropicExponent(state) * gasConstant(state) * temperature(state));
        end velocityOfSound;

        redeclare function extends isobaricExpansionCoefficient  
        algorithm
          beta := 1 / temperature(state);
        end isobaricExpansionCoefficient;

        redeclare function extends isothermalCompressibility  
        algorithm
          kappa := 1 / pressure(state);
        end isothermalCompressibility;

        redeclare function extends density_derp_h  
        algorithm
          ddph := 1 / (gasConstant(state) * temperature(state));
        end density_derp_h;

        redeclare function extends density_derh_p  
        algorithm
          ddhp := -density(state) / (specificHeatCapacityCp(state) * temperature(state));
        end density_derh_p;

        redeclare function extends density_derp_T  
        algorithm
          ddpT := 1 / (gasConstant(state) * temperature(state));
        end density_derp_T;

        redeclare function extends density_derT_p  
        algorithm
          ddTp := -density(state) / temperature(state);
        end density_derT_p;

        redeclare function extends density_derX  
        algorithm
          dddX[Water] := pressure(state) * (steam.R - dryair.R) / ((steam.R - dryair.R) * state.X[Water] * temperature(state) + dryair.R * temperature(state)) ^ 2;
          dddX[Air] := pressure(state) * (dryair.R - steam.R) / ((dryair.R - steam.R) * state.X[Air] * temperature(state) + steam.R * temperature(state)) ^ 2;
        end density_derX;

        redeclare function extends molarMass  
        algorithm
          MM := Modelica.Media.Air.MoistAir.gasConstant(state) / Modelica.Constants.R;
        end molarMass;

        function T_psX  "Return temperature as a function of pressure p, specific entropy s and composition X" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input SpecificEntropy s "Specific entropy";
          input MassFraction[:] X "Mass fractions of composition";
          output Temperature T "Temperature";

        protected
          package Internal  "Solve s(data,T) for T with given s" 
            extends Modelica.Media.Common.OneNonLinearEquation;

            redeclare record extends f_nonlinear_Data  "Data to be passed to non-linear function" 
              extends Modelica.Media.IdealGases.Common.DataRecord;
            end f_nonlinear_Data;

            redeclare function extends f_nonlinear  
            algorithm
              y := s_pTX(p, x, X);
            end f_nonlinear;

            redeclare function extends solve  end solve;
          end Internal;
        algorithm
          T := Internal.solve(s, 190, 647, p, X[1:nX], steam);
        end T_psX;

        redeclare function extends setState_psX  
        algorithm
          state := if size(X, 1) == nX then ThermodynamicState(p = p, T = T_psX(p, s, X), X = X) else ThermodynamicState(p = p, T = T_psX(p, s, X), X = cat(1, X, {1 - sum(X)}));
          annotation(smoothOrder = 2); 
        end setState_psX;

        function s_pTX  "Return specific entropy of moist air as a function of pressure p, temperature T and composition X (only valid for phi<1)" 
          extends Modelica.Icons.Function;
          input .Modelica.SIunits.Pressure p "Pressure";
          input .Modelica.SIunits.Temperature T "Temperature";
          input .Modelica.SIunits.MassFraction[:] X "Mass fractions of moist air";
          output .Modelica.SIunits.SpecificEntropy s "Specific entropy at p, T, X";
        protected
          MoleFraction[2] Y = massToMoleFractions(X, {steam.MM, dryair.MM}) "Molar fraction";
        algorithm
          s := Modelica.Media.IdealGases.Common.Functions.s0_Tlow(dryair, T) * (1 - X[Water]) + Modelica.Media.IdealGases.Common.Functions.s0_Tlow(steam, T) * X[Water] - Modelica.Constants.R * (Utilities.smoothMax(X[Water] / MMX[Water] * Modelica.Math.log(max(Y[Water], Modelica.Constants.eps) * p / reference_p), 0.0, 1e-9) - Utilities.smoothMax((1 - X[Water]) / MMX[Air] * Modelica.Math.log(max(Y[Air], Modelica.Constants.eps) * p / reference_p), 0.0, 1e-9));
          annotation(derivative = s_pTX_der, Inline = false); 
        end s_pTX;

        function s_pTX_der  "Return specific entropy of moist air as a function of pressure p, temperature T and composition X (only valid for phi<1)" 
          extends Modelica.Icons.Function;
          input .Modelica.SIunits.Pressure p "Pressure";
          input .Modelica.SIunits.Temperature T "Temperature";
          input .Modelica.SIunits.MassFraction[:] X "Mass fractions of moist air";
          input Real dp(unit = "Pa/s") "Derivative of pressure";
          input Real dT(unit = "K/s") "Derivative of temperature";
          input Real[nX] dX(unit = "1/s") "Derivative of mass fractions";
          output Real ds(unit = "J/(kg.K.s)") "Specific entropy at p, T, X";
        protected
          MoleFraction[2] Y = massToMoleFractions(X, {steam.MM, dryair.MM}) "Molar fraction";
        algorithm
          ds := Modelica.Media.IdealGases.Common.Functions.s0_Tlow_der(dryair, T, dT) * (1 - X[Water]) + Modelica.Media.IdealGases.Common.Functions.s0_Tlow_der(steam, T, dT) * X[Water] + Modelica.Media.IdealGases.Common.Functions.s0_Tlow(dryair, T) * dX[Air] + Modelica.Media.IdealGases.Common.Functions.s0_Tlow(steam, T) * dX[Water] - Modelica.Constants.R * (1 / MMX[Water] * Utilities.smoothMax_der(X[Water] * Modelica.Math.log(max(Y[Water], Modelica.Constants.eps) * p / reference_p), 0.0, 1e-9, (Modelica.Math.log(max(Y[Water], Modelica.Constants.eps) * p / reference_p) + X[Water] / Y[Water] * (X[Air] * MMX[Water] / (X[Air] * MMX[Water] + X[Water] * MMX[Air]) ^ 2)) * dX[Water] + X[Water] * reference_p / p * dp, 0, 0) - 1 / MMX[Air] * Utilities.smoothMax_der((1 - X[Water]) * Modelica.Math.log(max(Y[Air], Modelica.Constants.eps) * p / reference_p), 0.0, 1e-9, (Modelica.Math.log(max(Y[Air], Modelica.Constants.eps) * p / reference_p) + X[Air] / Y[Air] * (X[Water] * MMX[Air] / (X[Air] * MMX[Water] + X[Water] * MMX[Air]) ^ 2)) * dX[Air] + X[Air] * reference_p / p * dp, 0, 0));
          annotation(Inline = false, smoothOrder = 1); 
        end s_pTX_der;

        redeclare function extends isentropicEnthalpy  "Isentropic enthalpy (only valid for phi<1)" 
          extends Modelica.Icons.Function;
        algorithm
          h_is := Modelica.Media.Air.MoistAir.h_pTX(p_downstream, Modelica.Media.Air.MoistAir.T_psX(p_downstream, Modelica.Media.Air.MoistAir.specificEntropy(refState), refState.X), refState.X);
        end isentropicEnthalpy;

        package Utilities  "Utility functions" 
          extends Modelica.Icons.UtilitiesPackage;

          function spliceFunction  "Spline interpolation of two functions" 
            extends Modelica.Icons.Function;
            input Real pos "Returned value for x-deltax >= 0";
            input Real neg "Returned value for x+deltax <= 0";
            input Real x "Function argument";
            input Real deltax = 1 "Region around x with spline interpolation";
            output Real out;
          protected
            Real scaledX;
            Real scaledX1;
            Real y;
          algorithm
            scaledX1 := x / deltax;
            scaledX := scaledX1 * Modelica.Math.asin(1);
            if scaledX1 <= (-0.999999999) then
              y := 0;
            elseif scaledX1 >= 0.999999999 then
              y := 1;
            else
              y := (Modelica.Math.tanh(Modelica.Math.tan(scaledX)) + 1) / 2;
            end if;
            out := pos * y + (1 - y) * neg;
            annotation(derivative = spliceFunction_der); 
          end spliceFunction;

          function spliceFunction_der  "Derivative of spliceFunction" 
            extends Modelica.Icons.Function;
            input Real pos;
            input Real neg;
            input Real x;
            input Real deltax = 1;
            input Real dpos;
            input Real dneg;
            input Real dx;
            input Real ddeltax = 0;
            output Real out;
          protected
            Real scaledX;
            Real scaledX1;
            Real dscaledX1;
            Real y;
          algorithm
            scaledX1 := x / deltax;
            scaledX := scaledX1 * Modelica.Math.asin(1);
            dscaledX1 := (dx - scaledX1 * ddeltax) / deltax;
            if scaledX1 <= (-0.99999999999) then
              y := 0;
            elseif scaledX1 >= 0.9999999999 then
              y := 1;
            else
              y := (Modelica.Math.tanh(Modelica.Math.tan(scaledX)) + 1) / 2;
            end if;
            out := dpos * y + (1 - y) * dneg;
            if abs(scaledX1) < 1 then
              out := out + (pos - neg) * dscaledX1 * Modelica.Math.asin(1) / 2 / (Modelica.Math.cosh(Modelica.Math.tan(scaledX)) * Modelica.Math.cos(scaledX)) ^ 2;
            else
            end if;
          end spliceFunction_der;

          function smoothMax  
            extends Modelica.Icons.Function;
            input Real x1 "First argument of smooth max operator";
            input Real x2 "Second argument of smooth max operator";
            input Real dx "Approximate difference between x1 and x2, below which regularization starts";
            output Real y "Result of smooth max operator";
          algorithm
            y := max(x1, x2) + .Modelica.Math.log(exp(4 / dx * (x1 - max(x1, x2))) + exp(4 / dx * (x2 - max(x1, x2)))) / (4 / dx);
            annotation(smoothOrder = 2); 
          end smoothMax;

          function smoothMax_der  
            extends Modelica.Icons.Function;
            input Real x1 "First argument of smooth max operator";
            input Real x2 "Second argument of smooth max operator";
            input Real dx "Approximate difference between x1 and x2, below which regularization starts";
            input Real dx1;
            input Real dx2;
            input Real ddx;
            output Real dy "Derivative of smooth max operator";
          algorithm
            dy := (if x1 > x2 then dx1 else dx2) + 0.25 * (((4 * (dx1 - (if x1 > x2 then dx1 else dx2)) / dx - 4 * (x1 - max(x1, x2)) * ddx / dx ^ 2) * .Modelica.Math.exp(4 * (x1 - max(x1, x2)) / dx) + (4 * (dx2 - (if x1 > x2 then dx1 else dx2)) / dx - 4 * (x2 - max(x1, x2)) * ddx / dx ^ 2) * .Modelica.Math.exp(4 * (x2 - max(x1, x2)) / dx)) * dx / (.Modelica.Math.exp(4 * (x1 - max(x1, x2)) / dx) + .Modelica.Math.exp(4 * (x2 - max(x1, x2)) / dx)) + .Modelica.Math.log(.Modelica.Math.exp(4 * (x1 - max(x1, x2)) / dx) + .Modelica.Math.exp(4 * (x2 - max(x1, x2)) / dx)) * ddx);
          end smoothMax_der;
        end Utilities;
      end MoistAir;
    end Air;

    package IdealGases  "Data and models of ideal gases (single, fixed and dynamic mixtures) from NASA source" 
      extends Modelica.Icons.VariantsPackage;

      package Common  "Common packages and data for the ideal gas models" 
        extends Modelica.Icons.Package;

        record DataRecord  "Coefficient data record for properties of ideal gases based on NASA source" 
          extends Modelica.Icons.Record;
          String name "Name of ideal gas";
          .Modelica.SIunits.MolarMass MM "Molar mass";
          .Modelica.SIunits.SpecificEnthalpy Hf "Enthalpy of formation at 298.15K";
          .Modelica.SIunits.SpecificEnthalpy H0 "H0(298.15K) - H0(0K)";
          .Modelica.SIunits.Temperature Tlimit "Temperature limit between low and high data sets";
          Real[7] alow "Low temperature coefficients a";
          Real[2] blow "Low temperature constants b";
          Real[7] ahigh "High temperature coefficients a";
          Real[2] bhigh "High temperature constants b";
          .Modelica.SIunits.SpecificHeatCapacity R "Gas constant";
        end DataRecord;

        package Functions  "Basic Functions for ideal gases: cp, h, s, thermal conductivity, viscosity" 
          extends Modelica.Icons.Package;
          constant Boolean excludeEnthalpyOfFormation = true "If true, enthalpy of formation Hf is not included in specific enthalpy h";
          constant Modelica.Media.Interfaces.Choices.ReferenceEnthalpy referenceChoice = Modelica.Media.Interfaces.Choices.ReferenceEnthalpy.ZeroAt0K "Choice of reference enthalpy";
          constant Modelica.Media.Interfaces.Types.SpecificEnthalpy h_offset = 0.0 "User defined offset for reference enthalpy, if referenceChoice = UserDefined";

          function cp_Tlow  "Compute specific heat capacity at constant pressure, low T region" 
            extends Modelica.Icons.Function;
            input IdealGases.Common.DataRecord data "Ideal gas data";
            input .Modelica.SIunits.Temperature T "Temperature";
            output .Modelica.SIunits.SpecificHeatCapacity cp "Specific heat capacity at temperature T";
          algorithm
            cp := data.R * (1 / (T * T) * (data.alow[1] + T * (data.alow[2] + T * (1. * data.alow[3] + T * (data.alow[4] + T * (data.alow[5] + T * (data.alow[6] + data.alow[7] * T)))))));
            annotation(Inline = false, derivative(zeroDerivative = data) = cp_Tlow_der); 
          end cp_Tlow;

          function cp_Tlow_der  "Compute specific heat capacity at constant pressure, low T region" 
            extends Modelica.Icons.Function;
            input IdealGases.Common.DataRecord data "Ideal gas data";
            input .Modelica.SIunits.Temperature T "Temperature";
            input Real dT "Temperature derivative";
            output Real cp_der "Derivative of specific heat capacity";
          algorithm
            cp_der := dT * data.R / (T * T * T) * ((-2 * data.alow[1]) + T * ((-data.alow[2]) + T * T * (data.alow[4] + T * (2. * data.alow[5] + T * (3. * data.alow[6] + 4. * data.alow[7] * T)))));
            annotation(smoothOrder = 2); 
          end cp_Tlow_der;

          function h_Tlow  "Compute specific enthalpy, low T region; reference is decided by the
              refChoice input, or by the referenceChoice package constant by default" 
            extends Modelica.Icons.Function;
            input IdealGases.Common.DataRecord data "Ideal gas data";
            input .Modelica.SIunits.Temperature T "Temperature";
            input Boolean exclEnthForm = excludeEnthalpyOfFormation "If true, enthalpy of formation Hf is not included in specific enthalpy h";
            input Modelica.Media.Interfaces.Choices.ReferenceEnthalpy refChoice = referenceChoice "Choice of reference enthalpy";
            input .Modelica.SIunits.SpecificEnthalpy h_off = h_offset "User defined offset for reference enthalpy, if referenceChoice = UserDefined";
            output .Modelica.SIunits.SpecificEnthalpy h "Specific enthalpy at temperature T";
          algorithm
            h := data.R * (((-data.alow[1]) + T * (data.blow[1] + data.alow[2] * Math.log(T) + T * (1. * data.alow[3] + T * (0.5 * data.alow[4] + T * (1 / 3 * data.alow[5] + T * (0.25 * data.alow[6] + 0.2 * data.alow[7] * T)))))) / T) + (if exclEnthForm then -data.Hf else 0.0) + (if refChoice == .Modelica.Media.Interfaces.Choices.ReferenceEnthalpy.ZeroAt0K then data.H0 else 0.0) + (if refChoice == .Modelica.Media.Interfaces.Choices.ReferenceEnthalpy.UserDefined then h_off else 0.0);
            annotation(Inline = false, smoothOrder = 2); 
          end h_Tlow;

          function h_Tlow_der  "Compute specific enthalpy, low T region; reference is decided by the
              refChoice input, or by the referenceChoice package constant by default" 
            extends Modelica.Icons.Function;
            input IdealGases.Common.DataRecord data "Ideal gas data";
            input .Modelica.SIunits.Temperature T "Temperature";
            input Boolean exclEnthForm = excludeEnthalpyOfFormation "If true, enthalpy of formation Hf is not included in specific enthalpy h";
            input Modelica.Media.Interfaces.Choices.ReferenceEnthalpy refChoice = referenceChoice "Choice of reference enthalpy";
            input .Modelica.SIunits.SpecificEnthalpy h_off = h_offset "User defined offset for reference enthalpy, if referenceChoice = UserDefined";
            input Real dT(unit = "K/s") "Temperature derivative";
            output Real h_der(unit = "J/(kg.s)") "Derivative of specific enthalpy at temperature T";
          algorithm
            h_der := dT * Modelica.Media.IdealGases.Common.Functions.cp_Tlow(data, T);
            annotation(Inline = true, smoothOrder = 2); 
          end h_Tlow_der;

          function s0_Tlow  "Compute specific entropy, low T region" 
            extends Modelica.Icons.Function;
            input IdealGases.Common.DataRecord data "Ideal gas data";
            input .Modelica.SIunits.Temperature T "Temperature";
            output .Modelica.SIunits.SpecificEntropy s "Specific entropy at temperature T";
          algorithm
            s := data.R * (data.blow[2] - 0.5 * data.alow[1] / (T * T) - data.alow[2] / T + data.alow[3] * Math.log(T) + T * (data.alow[4] + T * (0.5 * data.alow[5] + T * (1 / 3 * data.alow[6] + 0.25 * data.alow[7] * T))));
            annotation(Inline = true); 
          end s0_Tlow;

          function s0_Tlow_der  "Compute derivative of specific entropy, low T region" 
            extends Modelica.Icons.Function;
            input IdealGases.Common.DataRecord data "Ideal gas data";
            input .Modelica.SIunits.Temperature T "Temperature";
            input Real T_der "Temperature derivative";
            output .Modelica.SIunits.SpecificEntropy s "Specific entropy at temperature T";
          algorithm
            s := data.R * (data.blow[2] - 0.5 * data.alow[1] / (T * T) - data.alow[2] / T + data.alow[3] * Math.log(T) + T * (data.alow[4] + T * (0.5 * data.alow[5] + T * (1 / 3 * data.alow[6] + 0.25 * data.alow[7] * T))));
            annotation(Inline = true); 
          end s0_Tlow_der;
        end Functions;

        package FluidData  "Critical data, dipole moments and related data" 
          extends Modelica.Icons.Package;
          constant Modelica.Media.Interfaces.Types.IdealGas.FluidConstants N2(chemicalFormula = "N2", iupacName = "unknown", structureFormula = "unknown", casRegistryNumber = "7727-37-9", meltingPoint = 63.15, normalBoilingPoint = 77.35, criticalTemperature = 126.20, criticalPressure = 33.98e5, criticalMolarVolume = 90.10e-6, acentricFactor = 0.037, dipoleMoment = 0.0, molarMass = SingleGasesData.N2.MM, hasDipoleMoment = true, hasIdealGasHeatCapacity = true, hasCriticalData = true, hasAcentricFactor = true);
          constant Modelica.Media.Interfaces.Types.IdealGas.FluidConstants H2O(chemicalFormula = "H2O", iupacName = "oxidane", structureFormula = "H2O", casRegistryNumber = "7732-18-5", meltingPoint = 273.15, normalBoilingPoint = 373.124, criticalTemperature = 647.096, criticalPressure = 220.64e5, criticalMolarVolume = 55.95e-6, acentricFactor = 0.344, dipoleMoment = 1.8, molarMass = SingleGasesData.H2O.MM, hasDipoleMoment = true, hasIdealGasHeatCapacity = true, hasCriticalData = true, hasAcentricFactor = true);
        end FluidData;

        package SingleGasesData  "Ideal gas data based on the NASA Glenn coefficients" 
          extends Modelica.Icons.Package;
          constant IdealGases.Common.DataRecord Air(name = "Air", MM = 0.0289651159, Hf = -4333.833858403446, H0 = 298609.6803431054, Tlimit = 1000, alow = {10099.5016, -196.827561, 5.00915511, -0.00576101373, 1.06685993e-005, -7.94029797e-009, 2.18523191e-012}, blow = {-176.796731, -3.921504225}, ahigh = {241521.443, -1257.8746, 5.14455867, -0.000213854179, 7.06522784e-008, -1.07148349e-011, 6.57780015e-016}, bhigh = {6462.26319, -8.147411905}, R = 287.0512249529787);
          constant IdealGases.Common.DataRecord Ar(name = "Ar", MM = 0.039948, Hf = 0, H0 = 155137.3785921698, Tlimit = 1000, alow = {0, 0, 2.5, 0, 0, 0, 0}, blow = {-745.375, 4.37967491}, ahigh = {20.10538475, -0.05992661069999999, 2.500069401, -3.99214116e-008, 1.20527214e-011, -1.819015576e-015, 1.078576636e-019}, bhigh = {-744.993961, 4.37918011}, R = 208.1323720837088);
          constant IdealGases.Common.DataRecord CH4(name = "CH4", MM = 0.01604246, Hf = -4650159.63885838, H0 = 624355.7409524474, Tlimit = 1000, alow = {-176685.0998, 2786.18102, -12.0257785, 0.0391761929, -3.61905443e-005, 2.026853043e-008, -4.976705489999999e-012}, blow = {-23313.1436, 89.0432275}, ahigh = {3730042.76, -13835.01485, 20.49107091, -0.001961974759, 4.72731304e-007, -3.72881469e-011, 1.623737207e-015}, bhigh = {75320.6691, -121.9124889}, R = 518.2791167938085);
          constant IdealGases.Common.DataRecord CH3OH(name = "CH3OH", MM = 0.03204186, Hf = -6271171.523750494, H0 = 356885.5553329301, Tlimit = 1000, alow = {-241664.2886, 4032.14719, -20.46415436, 0.0690369807, -7.59893269e-005, 4.59820836e-008, -1.158706744e-011}, blow = {-44332.61169999999, 140.014219}, ahigh = {3411570.76, -13455.00201, 22.61407623, -0.002141029179, 3.73005054e-007, -3.49884639e-011, 1.366073444e-015}, bhigh = {56360.8156, -127.7814279}, R = 259.4878075117987);
          constant IdealGases.Common.DataRecord CO(name = "CO", MM = 0.0280101, Hf = -3946262.098314536, H0 = 309570.6191695138, Tlimit = 1000, alow = {14890.45326, -292.2285939, 5.72452717, -0.008176235030000001, 1.456903469e-005, -1.087746302e-008, 3.027941827e-012}, blow = {-13031.31878, -7.85924135}, ahigh = {461919.725, -1944.704863, 5.91671418, -0.0005664282830000001, 1.39881454e-007, -1.787680361e-011, 9.62093557e-016}, bhigh = {-2466.261084, -13.87413108}, R = 296.8383547363272);
          constant IdealGases.Common.DataRecord CO2(name = "CO2", MM = 0.0440095, Hf = -8941478.544405185, H0 = 212805.6215135368, Tlimit = 1000, alow = {49436.5054, -626.411601, 5.30172524, 0.002503813816, -2.127308728e-007, -7.68998878e-010, 2.849677801e-013}, blow = {-45281.9846, -7.04827944}, ahigh = {117696.2419, -1788.791477, 8.29152319, -9.22315678e-005, 4.86367688e-009, -1.891053312e-012, 6.330036589999999e-016}, bhigh = {-39083.5059, -26.52669281}, R = 188.9244822140674);
          constant IdealGases.Common.DataRecord C2H2_vinylidene(name = "C2H2_vinylidene", MM = 0.02603728, Hf = 15930556.80163212, H0 = 417638.4015534649, Tlimit = 1000, alow = {-14660.42239, 278.9475593, 1.276229776, 0.01395015463, -1.475702649e-005, 9.476298110000001e-009, -2.567602217e-012}, blow = {47361.1018, 16.58225704}, ahigh = {1940838.725, -6892.718150000001, 13.39582494, -0.0009368968669999999, 1.470804368e-007, -1.220040365e-011, 4.12239166e-016}, bhigh = {91071.1293, -63.3750293}, R = 319.3295152181795);
          constant IdealGases.Common.DataRecord C2H4(name = "C2H4", MM = 0.02805316, Hf = 1871446.924339362, H0 = 374955.5843263291, Tlimit = 1000, alow = {-116360.5836, 2554.85151, -16.09746428, 0.0662577932, -7.885081859999999e-005, 5.12522482e-008, -1.370340031e-011}, blow = {-6176.19107, 109.3338343}, ahigh = {3408763.67, -13748.47903, 23.65898074, -0.002423804419, 4.43139566e-007, -4.35268339e-011, 1.775410633e-015}, bhigh = {88204.2938, -137.1278108}, R = 296.3827247982046);
          constant IdealGases.Common.DataRecord C2H6(name = "C2H6", MM = 0.03006904, Hf = -2788633.890539904, H0 = 395476.3437741943, Tlimit = 1000, alow = {-186204.4161, 3406.19186, -19.51705092, 0.0756583559, -8.20417322e-005, 5.0611358e-008, -1.319281992e-011}, blow = {-27029.3289, 129.8140496}, ahigh = {5025782.13, -20330.22397, 33.2255293, -0.00383670341, 7.23840586e-007, -7.3191825e-011, 3.065468699e-015}, bhigh = {111596.395, -203.9410584}, R = 276.5127187299628);
          constant IdealGases.Common.DataRecord C2H5OH(name = "C2H5OH", MM = 0.04606844, Hf = -5100020.751733725, H0 = 315659.1801241805, Tlimit = 1000, alow = {-234279.1392, 4479.18055, -27.44817302, 0.1088679162, -0.0001305309334, 8.437346399999999e-008, -2.234559017e-011}, blow = {-50222.29, 176.4829211}, ahigh = {4694817.65, -19297.98213, 34.4758404, -0.00323616598, 5.78494772e-007, -5.56460027e-011, 2.2262264e-015}, bhigh = {86016.22709999999, -203.4801732}, R = 180.4808671619877);
          constant IdealGases.Common.DataRecord C3H6_propylene(name = "C3H6_propylene", MM = 0.04207974, Hf = 475288.1077687267, H0 = 322020.9535515191, Tlimit = 1000, alow = {-191246.2174, 3542.07424, -21.14878626, 0.0890148479, -0.0001001429154, 6.267959389999999e-008, -1.637870781e-011}, blow = {-15299.61824, 140.7641382}, ahigh = {5017620.34, -20860.84035, 36.4415634, -0.00388119117, 7.27867719e-007, -7.321204500000001e-011, 3.052176369e-015}, bhigh = {126124.5355, -219.5715757}, R = 197.588483198803);
          constant IdealGases.Common.DataRecord C3H8(name = "C3H8", MM = 0.04409562, Hf = -2373931.923397381, H0 = 334301.1845620949, Tlimit = 1000, alow = {-243314.4337, 4656.27081, -29.39466091, 0.1188952745, -0.0001376308269, 8.814823909999999e-008, -2.342987994e-011}, blow = {-35403.3527, 184.1749277}, ahigh = {6420731.680000001, -26597.91134, 45.3435684, -0.00502066392, 9.471216939999999e-007, -9.57540523e-011, 4.00967288e-015}, bhigh = {145558.2459, -281.8374734}, R = 188.5555073270316);
          constant IdealGases.Common.DataRecord C4H8_1_butene(name = "C4H8_1_butene", MM = 0.05610631999999999, Hf = -9624.584182316718, H0 = 305134.9651875226, Tlimit = 1000, alow = {-272149.2014, 5100.079250000001, -31.8378625, 0.1317754442, -0.0001527359339, 9.714761109999999e-008, -2.56020447e-011}, blow = {-25230.96386, 200.6932108}, ahigh = {6257948.609999999, -26603.76305, 47.6492005, -0.00438326711, 7.12883844e-007, -5.991020839999999e-011, 2.051753504e-015}, bhigh = {156925.2657, -291.3869761}, R = 148.1913623991023);
          constant IdealGases.Common.DataRecord C4H10_n_butane(name = "C4H10_n_butane", MM = 0.0581222, Hf = -2164233.28779709, H0 = 330832.0228759407, Tlimit = 1000, alow = {-317587.254, 6176.331819999999, -38.9156212, 0.1584654284, -0.0001860050159, 1.199676349e-007, -3.20167055e-011}, blow = {-45403.63390000001, 237.9488665}, ahigh = {7682322.45, -32560.5151, 57.3673275, -0.00619791681, 1.180186048e-006, -1.221893698e-010, 5.250635250000001e-015}, bhigh = {177452.656, -358.791876}, R = 143.0515706563069);
          constant IdealGases.Common.DataRecord C5H10_1_pentene(name = "C5H10_1_pentene", MM = 0.07013290000000001, Hf = -303423.9279995551, H0 = 309127.3852927798, Tlimit = 1000, alow = {-534054.813, 9298.917380000001, -56.6779245, 0.2123100266, -0.000257129829, 1.666834304e-007, -4.43408047e-011}, blow = {-47906.8218, 339.60364}, ahigh = {3744014.97, -21044.85321, 47.3612699, -0.00042442012, -3.89897505e-008, 1.367074243e-011, -9.31319423e-016}, bhigh = {115409.1373, -278.6177449000001}, R = 118.5530899192818);
          constant IdealGases.Common.DataRecord C5H12_n_pentane(name = "C5H12_n_pentane", MM = 0.07214878, Hf = -2034130.029641527, H0 = 335196.2430965569, Tlimit = 1000, alow = {-276889.4625, 5834.28347, -36.1754148, 0.1533339707, -0.0001528395882, 8.191092e-008, -1.792327902e-011}, blow = {-46653.7525, 226.5544053}, ahigh = {-2530779.286, -8972.59326, 45.3622326, -0.002626989916, 3.135136419e-006, -5.31872894e-010, 2.886896868e-014}, bhigh = {14846.16529, -251.6550384}, R = 115.2406457877736);
          constant IdealGases.Common.DataRecord C6H6(name = "C6H6", MM = 0.07811184, Hf = 1061042.730525872, H0 = 181735.4577743912, Tlimit = 1000, alow = {-167734.0902, 4404.50004, -37.1737791, 0.1640509559, -0.0002020812374, 1.307915264e-007, -3.4442841e-011}, blow = {-10354.55401, 216.9853345}, ahigh = {4538575.72, -22605.02547, 46.940073, -0.004206676830000001, 7.90799433e-007, -7.9683021e-011, 3.32821208e-015}, bhigh = {139146.4686, -286.8751333}, R = 106.4431717393932);
          constant IdealGases.Common.DataRecord C6H12_1_hexene(name = "C6H12_1_hexene", MM = 0.08415948000000001, Hf = -498458.4030224521, H0 = 311788.9986962847, Tlimit = 1000, alow = {-666883.165, 11768.64939, -72.70998330000001, 0.2709398396, -0.00033332464, 2.182347097e-007, -5.85946882e-011}, blow = {-62157.8054, 428.682564}, ahigh = {733290.696, -14488.48641, 46.7121549, 0.00317297847, -5.24264652e-007, 4.28035582e-011, -1.472353254e-015}, bhigh = {66977.4041, -262.3643854}, R = 98.79424159940152);
          constant IdealGases.Common.DataRecord C6H14_n_hexane(name = "C6H14_n_hexane", MM = 0.08617535999999999, Hf = -1936980.593988816, H0 = 333065.0431863586, Tlimit = 1000, alow = {-581592.67, 10790.97724, -66.3394703, 0.2523715155, -0.0002904344705, 1.802201514e-007, -4.617223680000001e-011}, blow = {-72715.4457, 393.828354}, ahigh = {-3106625.684, -7346.087920000001, 46.94131760000001, 0.001693963977, 2.068996667e-006, -4.21214168e-010, 2.452345845e-014}, bhigh = {523.750312, -254.9967718}, R = 96.48317105956971);
          constant IdealGases.Common.DataRecord C7H14_1_heptene(name = "C7H14_1_heptene", MM = 0.09818605999999999, Hf = -639194.6066478277, H0 = 313588.3036756949, Tlimit = 1000, alow = {-744940.284, 13321.79893, -82.81694379999999, 0.3108065994, -0.000378677992, 2.446841042e-007, -6.488763869999999e-011}, blow = {-72178.8501, 485.667149}, ahigh = {-1927608.174, -9125.024420000002, 47.4817797, 0.00606766053, -8.684859080000001e-007, 5.81399526e-011, -1.473979569e-015}, bhigh = {26009.14656, -256.2880707}, R = 84.68077851377274);
          constant IdealGases.Common.DataRecord C7H16_n_heptane(name = "C7H16_n_heptane", MM = 0.10020194, Hf = -1874015.612871368, H0 = 331540.487140269, Tlimit = 1000, alow = {-612743.289, 11840.85437, -74.87188599999999, 0.2918466052, -0.000341679549, 2.159285269e-007, -5.65585273e-011}, blow = {-80134.0894, 440.721332}, ahigh = {9135632.469999999, -39233.1969, 78.8978085, -0.00465425193, 2.071774142e-006, -3.4425393e-010, 1.976834775e-014}, bhigh = {205070.8295, -485.110402}, R = 82.97715593131233);
          constant IdealGases.Common.DataRecord C8H10_ethylbenz(name = "C8H10_ethylbenz", MM = 0.106165, Hf = 281825.4603682946, H0 = 209862.0072528611, Tlimit = 1000, alow = {-469494, 9307.16836, -65.2176947, 0.2612080237, -0.000318175348, 2.051355473e-007, -5.40181735e-011}, blow = {-40738.7021, 378.090436}, ahigh = {5551564.100000001, -28313.80598, 60.6124072, 0.001042112857, -1.327426719e-006, 2.166031743e-010, -1.142545514e-014}, bhigh = {164224.1062, -369.176982}, R = 78.31650732350586);
          constant IdealGases.Common.DataRecord C8H18_n_octane(name = "C8H18_n_octane", MM = 0.11422852, Hf = -1827477.060895125, H0 = 330740.51909278, Tlimit = 1000, alow = {-698664.715, 13385.01096, -84.1516592, 0.327193666, -0.000377720959, 2.339836988e-007, -6.01089265e-011}, blow = {-90262.2325, 493.922214}, ahigh = {6365406.949999999, -31053.64657, 69.6916234, 0.01048059637, -4.12962195e-006, 5.543226319999999e-010, -2.651436499e-014}, bhigh = {150096.8785, -416.989565}, R = 72.78805678301707);
          constant IdealGases.Common.DataRecord CL2(name = "CL2", MM = 0.07090600000000001, Hf = 0, H0 = 129482.8364313316, Tlimit = 1000, alow = {34628.1517, -554.7126520000001, 6.20758937, -0.002989632078, 3.17302729e-006, -1.793629562e-009, 4.260043590000001e-013}, blow = {1534.069331, -9.438331107}, ahigh = {6092569.42, -19496.27662, 28.54535795, -0.01449968764, 4.46389077e-006, -6.35852586e-010, 3.32736029e-014}, bhigh = {121211.7724, -169.0778824}, R = 117.2604857134798);
          constant IdealGases.Common.DataRecord F2(name = "F2", MM = 0.0379968064, Hf = 0, H0 = 232259.1511269747, Tlimit = 1000, alow = {10181.76308, 22.74241183, 1.97135304, 0.008151604010000001, -1.14896009e-005, 7.95865253e-009, -2.167079526e-012}, blow = {-958.6943, 11.30600296}, ahigh = {-2941167.79, 9456.5977, -7.73861615, 0.00764471299, -2.241007605e-006, 2.915845236e-010, -1.425033974e-014}, bhigh = {-60710.0561, 84.23835080000001}, R = 218.8202848542556);
          constant IdealGases.Common.DataRecord H2(name = "H2", MM = 0.00201588, Hf = 0, H0 = 4200697.462150524, Tlimit = 1000, alow = {40783.2321, -800.918604, 8.21470201, -0.01269714457, 1.753605076e-005, -1.20286027e-008, 3.36809349e-012}, blow = {2682.484665, -30.43788844}, ahigh = {560812.801, -837.150474, 2.975364532, 0.001252249124, -3.74071619e-007, 5.936625200000001e-011, -3.6069941e-015}, bhigh = {5339.82441, -2.202774769}, R = 4124.487568704486);
          constant IdealGases.Common.DataRecord H2O(name = "H2O", MM = 0.01801528, Hf = -13423382.81725291, H0 = 549760.6476280135, Tlimit = 1000, alow = {-39479.6083, 575.573102, 0.931782653, 0.00722271286, -7.34255737e-006, 4.95504349e-009, -1.336933246e-012}, blow = {-33039.7431, 17.24205775}, ahigh = {1034972.096, -2412.698562, 4.64611078, 0.002291998307, -6.836830479999999e-007, 9.426468930000001e-011, -4.82238053e-015}, bhigh = {-13842.86509, -7.97814851}, R = 461.5233290850878);
          constant IdealGases.Common.DataRecord He(name = "He", MM = 0.004002602, Hf = 0, H0 = 1548349.798456104, Tlimit = 1000, alow = {0, 0, 2.5, 0, 0, 0, 0}, blow = {-745.375, 0.9287239740000001}, ahigh = {0, 0, 2.5, 0, 0, 0, 0}, bhigh = {-745.375, 0.9287239740000001}, R = 2077.26673798694);
          constant IdealGases.Common.DataRecord NH3(name = "NH3", MM = 0.01703052, Hf = -2697510.117130892, H0 = 589713.1150428759, Tlimit = 1000, alow = {-76812.26149999999, 1270.951578, -3.89322913, 0.02145988418, -2.183766703e-005, 1.317385706e-008, -3.33232206e-012}, blow = {-12648.86413, 43.66014588}, ahigh = {2452389.535, -8040.89424, 12.71346201, -0.000398018658, 3.55250275e-008, 2.53092357e-012, -3.32270053e-016}, bhigh = {43861.91959999999, -64.62330602}, R = 488.2101075011215);
          constant IdealGases.Common.DataRecord NO(name = "NO", MM = 0.0300061, Hf = 3041758.509103149, H0 = 305908.1320131574, Tlimit = 1000, alow = {-11439.16503, 153.6467592, 3.43146873, -0.002668592368, 8.48139912e-006, -7.685111050000001e-009, 2.386797655e-012}, blow = {9098.214410000001, 6.72872549}, ahigh = {223901.8716, -1289.651623, 5.43393603, -0.00036560349, 9.880966450000001e-008, -1.416076856e-011, 9.380184619999999e-016}, bhigh = {17503.17656, -8.50166909}, R = 277.0927244793559);
          constant IdealGases.Common.DataRecord NO2(name = "NO2", MM = 0.0460055, Hf = 743237.6346306421, H0 = 221890.3174620426, Tlimit = 1000, alow = {-56420.3878, 963.308572, -2.434510974, 0.01927760886, -1.874559328e-005, 9.145497730000001e-009, -1.777647635e-012}, blow = {-1547.925037, 40.6785121}, ahigh = {721300.157, -3832.6152, 11.13963285, -0.002238062246, 6.54772343e-007, -7.6113359e-011, 3.32836105e-015}, bhigh = {25024.97403, -43.0513004}, R = 180.7277825477389);
          constant IdealGases.Common.DataRecord N2(name = "N2", MM = 0.0280134, Hf = 0, H0 = 309498.4543111511, Tlimit = 1000, alow = {22103.71497, -381.846182, 6.08273836, -0.00853091441, 1.384646189e-005, -9.62579362e-009, 2.519705809e-012}, blow = {710.846086, -10.76003744}, ahigh = {587712.406, -2239.249073, 6.06694922, -0.00061396855, 1.491806679e-007, -1.923105485e-011, 1.061954386e-015}, bhigh = {12832.10415, -15.86640027}, R = 296.8033869505308);
          constant IdealGases.Common.DataRecord N2O(name = "N2O", MM = 0.0440128, Hf = 1854006.107314236, H0 = 217685.1961247637, Tlimit = 1000, alow = {42882.2597, -644.011844, 6.03435143, 0.0002265394436, 3.47278285e-006, -3.62774864e-009, 1.137969552e-012}, blow = {11794.05506, -10.0312857}, ahigh = {343844.804, -2404.557558, 9.125636220000001, -0.000540166793, 1.315124031e-007, -1.4142151e-011, 6.38106687e-016}, bhigh = {21986.32638, -31.47805016}, R = 188.9103169986913);
          constant IdealGases.Common.DataRecord Ne(name = "Ne", MM = 0.0201797, Hf = 0, H0 = 307111.9986917546, Tlimit = 1000, alow = {0, 0, 2.5, 0, 0, 0, 0}, blow = {-745.375, 3.35532272}, ahigh = {0, 0, 2.5, 0, 0, 0, 0}, bhigh = {-745.375, 3.35532272}, R = 412.0215860493466);
          constant IdealGases.Common.DataRecord O2(name = "O2", MM = 0.0319988, Hf = 0, H0 = 271263.4223783392, Tlimit = 1000, alow = {-34255.6342, 484.700097, 1.119010961, 0.00429388924, -6.83630052e-007, -2.0233727e-009, 1.039040018e-012}, blow = {-3391.45487, 18.4969947}, ahigh = {-1037939.022, 2344.830282, 1.819732036, 0.001267847582, -2.188067988e-007, 2.053719572e-011, -8.193467050000001e-016}, bhigh = {-16890.10929, 17.38716506}, R = 259.8369938872708);
          constant IdealGases.Common.DataRecord SO2(name = "SO2", MM = 0.0640638, Hf = -4633037.690552231, H0 = 164650.3485587805, Tlimit = 1000, alow = {-53108.4214, 909.031167, -2.356891244, 0.02204449885, -2.510781471e-005, 1.446300484e-008, -3.36907094e-012}, blow = {-41137.52080000001, 40.45512519}, ahigh = {-112764.0116, -825.226138, 7.61617863, -0.000199932761, 5.65563143e-008, -5.45431661e-012, 2.918294102e-016}, bhigh = {-33513.0869, -16.55776085}, R = 129.7842463294403);
          constant IdealGases.Common.DataRecord SO3(name = "SO3", MM = 0.0800632, Hf = -4944843.573576874, H0 = 145990.9046852986, Tlimit = 1000, alow = {-39528.5529, 620.857257, -1.437731716, 0.02764126467, -3.144958662e-005, 1.792798e-008, -4.12638666e-012}, blow = {-51841.0617, 33.91331216}, ahigh = {-216692.3781, -1301.022399, 10.96287985, -0.000383710002, 8.466889039999999e-008, -9.70539929e-012, 4.49839754e-016}, bhigh = {-43982.83990000001, -36.55217314}, R = 103.8488594010732);
        end SingleGasesData;
      end Common;
    end IdealGases;

    package Incompressible  "Medium model for T-dependent properties, defined by tables or polynomials" 
      extends Modelica.Icons.VariantsPackage;

      package Common  "Common data structures" 
        extends Modelica.Icons.Package;

        record BaseProps_Tpoly  "Fluid state record" 
          extends Modelica.Icons.Record;
          .Modelica.SIunits.Temperature T "Temperature";
          .Modelica.SIunits.Pressure p "Pressure";
        end BaseProps_Tpoly;
      end Common;

      package TableBased  "Incompressible medium properties based on tables" 
        extends Modelica.Media.Interfaces.PartialMedium(ThermoStates = if enthalpyOfT then Modelica.Media.Interfaces.Choices.IndependentVariables.T else Modelica.Media.Interfaces.Choices.IndependentVariables.pT, final reducedX = true, final fixedX = true, mediumName = "tableMedium", redeclare record ThermodynamicState = Common.BaseProps_Tpoly, singleState = true, reference_p = 1.013e5, Temperature(min = T_min, max = T_max));
        constant Boolean enthalpyOfT = true "True if enthalpy is approximated as a function of T only, (p-dependence neglected)";
        constant Boolean densityOfT = size(tableDensity, 1) > 1 "True if density is a function of temperature";
        constant Modelica.SIunits.Temperature T_min "Minimum temperature valid for medium model";
        constant Modelica.SIunits.Temperature T_max "Maximum temperature valid for medium model";
        constant Temperature T0 = 273.15 "Reference Temperature";
        constant SpecificEnthalpy h0 = 0 "Reference enthalpy at T0, reference_p";
        constant SpecificEntropy s0 = 0 "Reference entropy at T0, reference_p";
        constant MolarMass MM_const = 0.1 "Molar mass";
        constant Integer npol = 2 "Degree of polynomial used for fitting";
        constant Integer npolDensity = npol "Degree of polynomial used for fitting rho(T)";
        constant Integer npolHeatCapacity = npol "Degree of polynomial used for fitting Cp(T)";
        constant Integer npolViscosity = npol "Degree of polynomial used for fitting eta(T)";
        constant Integer npolVaporPressure = npol "Degree of polynomial used for fitting pVap(T)";
        constant Integer npolConductivity = npol "Degree of polynomial used for fitting lambda(T)";
        constant Integer neta = size(tableViscosity, 1) "Number of data points for viscosity";
        constant Real[:, 2] tableDensity "Table for rho(T)";
        constant Real[:, 2] tableHeatCapacity "Table for Cp(T)";
        constant Real[:, 2] tableViscosity "Table for eta(T)";
        constant Real[:, 2] tableVaporPressure "Table for pVap(T)";
        constant Real[:, 2] tableConductivity "Table for lambda(T)";
        constant Boolean TinK "True if T[K],Kelvin used for table temperatures";
        constant Boolean hasDensity = not size(tableDensity, 1) == 0 "True if table tableDensity is present";
        constant Boolean hasHeatCapacity = not size(tableHeatCapacity, 1) == 0 "True if table tableHeatCapacity is present";
        constant Boolean hasViscosity = not size(tableViscosity, 1) == 0 "True if table tableViscosity is present";
        constant Boolean hasVaporPressure = not size(tableVaporPressure, 1) == 0 "True if table tableVaporPressure is present";
        final constant Real[neta] invTK = if size(tableViscosity, 1) > 0 then if TinK then 1 ./ tableViscosity[:, 1] else 1 ./ .Modelica.SIunits.Conversions.from_degC(tableViscosity[:, 1]) else fill(0, neta);
        final constant Real[:] poly_rho = if hasDensity then Polynomials_Temp.fitting(tableDensity[:, 1], tableDensity[:, 2], npolDensity) else zeros(npolDensity + 1);
        final constant Real[:] poly_Cp = if hasHeatCapacity then Polynomials_Temp.fitting(tableHeatCapacity[:, 1], tableHeatCapacity[:, 2], npolHeatCapacity) else zeros(npolHeatCapacity + 1);
        final constant Real[:] poly_eta = if hasViscosity then Polynomials_Temp.fitting(invTK, .Modelica.Math.log(tableViscosity[:, 2]), npolViscosity) else zeros(npolViscosity + 1);
        final constant Real[:] poly_lam = if size(tableConductivity, 1) > 0 then Polynomials_Temp.fitting(tableConductivity[:, 1], tableConductivity[:, 2], npolConductivity) else zeros(npolConductivity + 1);

        redeclare model extends BaseProperties(final standardOrderComponents = true, p_bar = .Modelica.SIunits.Conversions.to_bar(p), T_degC(start = T_start - 273.15) = .Modelica.SIunits.Conversions.to_degC(T), T(start = T_start, stateSelect = if preferredMediumStates then StateSelect.prefer else StateSelect.default))  "Base properties of T dependent medium" 
          .Modelica.SIunits.SpecificHeatCapacity cp "Specific heat capacity";
          parameter .Modelica.SIunits.Temperature T_start = 298.15 "Initial temperature";
        equation
          assert(hasDensity, "Medium " + mediumName + " can not be used without assigning tableDensity.");
          assert(T >= T_min and T <= T_max, "Temperature T (= " + String(T) + " K) is not in the allowed range (" + String(T_min) + " K <= T <= " + String(T_max) + " K) required from medium model \"" + mediumName + "\".");
          R = Modelica.Constants.R;
          cp = Polynomials_Temp.evaluate(poly_Cp, if TinK then T else T_degC);
          h = if enthalpyOfT then h_T(T) else h_pT(p, T, densityOfT);
          u = h - (if singleState then reference_p / d else state.p / d);
          d = Polynomials_Temp.evaluate(poly_rho, if TinK then T else T_degC);
          state.T = T;
          state.p = p;
          MM = MM_const;
        end BaseProperties;

        redeclare function extends setState_pTX  "Returns state record, given pressure and temperature" 
        algorithm
          state := ThermodynamicState(p = p, T = T);
          annotation(smoothOrder = 3); 
        end setState_pTX;

        redeclare function extends setState_dTX  "Returns state record, given pressure and temperature" 
        algorithm
          assert(false, "For incompressible media with d(T) only, state can not be set from density and temperature");
        end setState_dTX;

        redeclare function extends setState_phX  "Returns state record, given pressure and specific enthalpy" 
        algorithm
          state := ThermodynamicState(p = p, T = T_ph(p, h));
          annotation(Inline = true, smoothOrder = 3); 
        end setState_phX;

        redeclare function extends setState_psX  "Returns state record, given pressure and specific entropy" 
        algorithm
          state := ThermodynamicState(p = p, T = T_ps(p, s));
          annotation(Inline = true, smoothOrder = 3); 
        end setState_psX;

        redeclare function extends setSmoothState  "Return thermodynamic state so that it smoothly approximates: if x > 0 then state_a else state_b" 
        algorithm
          state := ThermodynamicState(p = Media.Common.smoothStep(x, state_a.p, state_b.p, x_small), T = Media.Common.smoothStep(x, state_a.T, state_b.T, x_small));
          annotation(Inline = true, smoothOrder = 3); 
        end setSmoothState;

        redeclare function extends specificHeatCapacityCv  "Specific heat capacity at constant volume (or pressure) of medium" 
        algorithm
          assert(hasHeatCapacity, "Specific Heat Capacity, Cv, is not defined for medium " + mediumName + ".");
          cv := Polynomials_Temp.evaluate(poly_Cp, if TinK then state.T else state.T - 273.15);
          annotation(smoothOrder = 2); 
        end specificHeatCapacityCv;

        redeclare function extends specificHeatCapacityCp  "Specific heat capacity at constant volume (or pressure) of medium" 
        algorithm
          assert(hasHeatCapacity, "Specific Heat Capacity, Cv, is not defined for medium " + mediumName + ".");
          cp := Polynomials_Temp.evaluate(poly_Cp, if TinK then state.T else state.T - 273.15);
          annotation(smoothOrder = 2); 
        end specificHeatCapacityCp;

        redeclare function extends dynamicViscosity  "Return dynamic viscosity as a function of the thermodynamic state record" 
        algorithm
          assert(size(tableViscosity, 1) > 0, "DynamicViscosity, eta, is not defined for medium " + mediumName + ".");
          eta := .Modelica.Math.exp(Polynomials_Temp.evaluate(poly_eta, 1 / state.T));
          annotation(smoothOrder = 2); 
        end dynamicViscosity;

        redeclare function extends thermalConductivity  "Return thermal conductivity as a function of the thermodynamic state record" 
        algorithm
          assert(size(tableConductivity, 1) > 0, "ThermalConductivity, lambda, is not defined for medium " + mediumName + ".");
          lambda := Polynomials_Temp.evaluate(poly_lam, if TinK then state.T else .Modelica.SIunits.Conversions.to_degC(state.T));
          annotation(smoothOrder = 2); 
        end thermalConductivity;

        function s_T  "Compute specific entropy" 
          extends Modelica.Icons.Function;
          input Temperature T "Temperature";
          output SpecificEntropy s "Specific entropy";
        algorithm
          s := s0 + (if TinK then Polynomials_Temp.integralValue(poly_Cp[1:npol], T, T0) else Polynomials_Temp.integralValue(poly_Cp[1:npol], .Modelica.SIunits.Conversions.to_degC(T), .Modelica.SIunits.Conversions.to_degC(T0))) + Modelica.Math.log(T / T0) * Polynomials_Temp.evaluate(poly_Cp, if TinK then 0 else Modelica.Constants.T_zero);
          annotation(Inline = true, smoothOrder = 2); 
        end s_T;

        redeclare function extends specificEntropy  "Return specific entropy as a function of the thermodynamic state record" 
        protected
          Integer npol = size(poly_Cp, 1) - 1;
        algorithm
          assert(hasHeatCapacity, "Specific Entropy, s(T), is not defined for medium " + mediumName + ".");
          s := s_T(state.T);
          annotation(smoothOrder = 2); 
        end specificEntropy;

        function h_T  "Compute specific enthalpy from temperature" 
          extends Modelica.Icons.Function;
          input .Modelica.SIunits.Temperature T "Temperature";
          output .Modelica.SIunits.SpecificEnthalpy h "Specific enthalpy at p, T";
        algorithm
          h := h0 + Polynomials_Temp.integralValue(poly_Cp, if TinK then T else .Modelica.SIunits.Conversions.to_degC(T), if TinK then T0 else .Modelica.SIunits.Conversions.to_degC(T0));
          annotation(derivative = h_T_der); 
        end h_T;

        function h_T_der  "Compute specific enthalpy from temperature" 
          extends Modelica.Icons.Function;
          input .Modelica.SIunits.Temperature T "Temperature";
          input Real dT "Temperature derivative";
          output Real dh "Derivative of Specific enthalpy at T";
        algorithm
          dh := Polynomials_Temp.evaluate(poly_Cp, if TinK then T else .Modelica.SIunits.Conversions.to_degC(T)) * dT;
          annotation(smoothOrder = 1); 
        end h_T_der;

        function h_pT  "Compute specific enthalpy from pressure and temperature" 
          extends Modelica.Icons.Function;
          input .Modelica.SIunits.Pressure p "Pressure";
          input .Modelica.SIunits.Temperature T "Temperature";
          input Boolean densityOfT = false "Include or neglect density derivative dependence of enthalpy";
          output .Modelica.SIunits.SpecificEnthalpy h "Specific enthalpy at p, T";
        algorithm
          h := h0 + Polynomials_Temp.integralValue(poly_Cp, if TinK then T else .Modelica.SIunits.Conversions.to_degC(T), if TinK then T0 else .Modelica.SIunits.Conversions.to_degC(T0)) + (p - reference_p) / Polynomials_Temp.evaluate(poly_rho, if TinK then T else .Modelica.SIunits.Conversions.to_degC(T)) * (if densityOfT then 1 + T / Polynomials_Temp.evaluate(poly_rho, if TinK then T else .Modelica.SIunits.Conversions.to_degC(T)) * Polynomials_Temp.derivativeValue(poly_rho, if TinK then T else .Modelica.SIunits.Conversions.to_degC(T)) else 1.0);
          annotation(smoothOrder = 2); 
        end h_pT;

        redeclare function extends temperature  "Return temperature as a function of the thermodynamic state record" 
        algorithm
          T := state.T;
          annotation(Inline = true, smoothOrder = 2); 
        end temperature;

        redeclare function extends pressure  "Return pressure as a function of the thermodynamic state record" 
        algorithm
          p := state.p;
          annotation(Inline = true, smoothOrder = 2); 
        end pressure;

        redeclare function extends density  "Return density as a function of the thermodynamic state record" 
        algorithm
          d := Polynomials_Temp.evaluate(poly_rho, if TinK then state.T else .Modelica.SIunits.Conversions.to_degC(state.T));
          annotation(Inline = true, smoothOrder = 2); 
        end density;

        redeclare function extends specificEnthalpy  "Return specific enthalpy as a function of the thermodynamic state record" 
        algorithm
          h := if enthalpyOfT then h_T(state.T) else h_pT(state.p, state.T);
          annotation(Inline = true, smoothOrder = 2); 
        end specificEnthalpy;

        redeclare function extends specificInternalEnergy  "Return specific internal energy as a function of the thermodynamic state record" 
        algorithm
          u := (if enthalpyOfT then h_T(state.T) else h_pT(state.p, state.T)) - (if singleState then reference_p else state.p) / density(state);
          annotation(Inline = true, smoothOrder = 2); 
        end specificInternalEnergy;

        function T_ph  "Compute temperature from pressure and specific enthalpy" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input SpecificEnthalpy h "Specific enthalpy";
          output Temperature T "Temperature";

        protected
          package Internal  "Solve h(T) for T with given h (use only indirectly via temperature_phX)" 
            extends Modelica.Media.Common.OneNonLinearEquation;

            redeclare record extends f_nonlinear_Data  "Superfluous record, fix later when better structure of inverse functions exists" 
              constant Real[5] dummy = {1, 2, 3, 4, 5};
            end f_nonlinear_Data;

            redeclare function extends f_nonlinear  "P is smuggled in via vector" 
            algorithm
              y := if singleState then h_T(x) else h_pT(p, x);
            end f_nonlinear;
          end Internal;
        algorithm
          T := Internal.solve(h, T_min, T_max, p, {1}, Internal.f_nonlinear_Data());
          annotation(Inline = false, LateInline = true, inverse(h = h_pT(p, T))); 
        end T_ph;

        function T_ps  "Compute temperature from pressure and specific enthalpy" 
          extends Modelica.Icons.Function;
          input AbsolutePressure p "Pressure";
          input SpecificEntropy s "Specific entropy";
          output Temperature T "Temperature";

        protected
          package Internal  "Solve h(T) for T with given h (use only indirectly via temperature_phX)" 
            extends Modelica.Media.Common.OneNonLinearEquation;

            redeclare record extends f_nonlinear_Data  "Superfluous record, fix later when better structure of inverse functions exists" 
              constant Real[5] dummy = {1, 2, 3, 4, 5};
            end f_nonlinear_Data;

            redeclare function extends f_nonlinear  "P is smuggled in via vector" 
            algorithm
              y := s_T(x);
            end f_nonlinear;
          end Internal;
        algorithm
          T := Internal.solve(s, T_min, T_max, p, {1}, Internal.f_nonlinear_Data());
        end T_ps;

        package Polynomials_Temp  "Temporary Functions operating on polynomials (including polynomial fitting); only to be used in Modelica.Media.Incompressible.TableBased" 
          extends Modelica.Icons.Package;

          function evaluate  "Evaluate polynomial at a given abscissa value" 
            extends Modelica.Icons.Function;
            input Real[:] p "Polynomial coefficients (p[1] is coefficient of highest power)";
            input Real u "Abscissa value";
            output Real y "Value of polynomial at u";
          algorithm
            y := p[1];
            for j in 2:size(p, 1) loop
              y := p[j] + u * y;
            end for;
            annotation(derivative(zeroDerivative = p) = evaluate_der); 
          end evaluate;

          function evaluateWithRange  "Evaluate polynomial at a given abscissa value with linear extrapolation outside of the defined range" 
            extends Modelica.Icons.Function;
            input Real[:] p "Polynomial coefficients (p[1] is coefficient of highest power)";
            input Real uMin "Polynomial valid in the range uMin .. uMax";
            input Real uMax "Polynomial valid in the range uMin .. uMax";
            input Real u "Abscissa value";
            output Real y "Value of polynomial at u. Outside of uMin,uMax, linear extrapolation is used";
          algorithm
            if u < uMin then
              y := evaluate(p, uMin) - evaluate_der(p, uMin, uMin - u);
            elseif u > uMax then
              y := evaluate(p, uMax) + evaluate_der(p, uMax, u - uMax);
            else
              y := evaluate(p, u);
            end if;
            annotation(derivative(zeroDerivative = p, zeroDerivative = uMin, zeroDerivative = uMax) = evaluateWithRange_der); 
          end evaluateWithRange;

          function derivativeValue  "Value of derivative of polynomial at abscissa value u" 
            extends Modelica.Icons.Function;
            input Real[:] p "Polynomial coefficients (p[1] is coefficient of highest power)";
            input Real u "Abscissa value";
            output Real y "Value of derivative of polynomial at u";
          protected
            Integer n = size(p, 1);
          algorithm
            y := p[1] * (n - 1);
            for j in 2:size(p, 1) - 1 loop
              y := p[j] * (n - j) + u * y;
            end for;
            annotation(derivative(zeroDerivative = p) = derivativeValue_der); 
          end derivativeValue;

          function secondDerivativeValue  "Value of 2nd derivative of polynomial at abscissa value u" 
            extends Modelica.Icons.Function;
            input Real[:] p "Polynomial coefficients (p[1] is coefficient of highest power)";
            input Real u "Abscissa value";
            output Real y "Value of 2nd derivative of polynomial at u";
          protected
            Integer n = size(p, 1);
          algorithm
            y := p[1] * (n - 1) * (n - 2);
            for j in 2:size(p, 1) - 2 loop
              y := p[j] * (n - j) * (n - j - 1) + u * y;
            end for;
          end secondDerivativeValue;

          function integralValue  "Integral of polynomial p(u) from u_low to u_high" 
            extends Modelica.Icons.Function;
            input Real[:] p "Polynomial coefficients";
            input Real u_high "High integrand value";
            input Real u_low = 0 "Low integrand value, default 0";
            output Real integral = 0.0 "Integral of polynomial p from u_low to u_high";
          protected
            Integer n = size(p, 1) "Degree of integrated polynomial";
            Real y_low = 0 "Value at lower integrand";
          algorithm
            for j in 1:n loop
              integral := u_high * (p[j] / (n - j + 1) + integral);
              y_low := u_low * (p[j] / (n - j + 1) + y_low);
            end for;
            integral := integral - y_low;
            annotation(derivative(zeroDerivative = p) = integralValue_der); 
          end integralValue;

          function fitting  "Computes the coefficients of a polynomial that fits a set of data points in a least-squares sense" 
            extends Modelica.Icons.Function;
            input Real[:] u "Abscissa data values";
            input Real[size(u, 1)] y "Ordinate data values";
            input Integer n(min = 1) "Order of desired polynomial that fits the data points (u,y)";
            output Real[n + 1] p "Polynomial coefficients of polynomial that fits the date points";
          protected
            Real[size(u, 1), n + 1] V "Vandermonde matrix";
          algorithm
            V[:, n + 1] := ones(size(u, 1));
            for j in n:(-1):1 loop
              V[:, j] := {u[i] * V[i, j + 1] for i in 1:size(u, 1)};
            end for;
            p := Modelica.Math.Matrices.leastSquares(V, y);
          end fitting;

          function evaluate_der  "Evaluate derivative of polynomial at a given abscissa value" 
            extends Modelica.Icons.Function;
            input Real[:] p "Polynomial coefficients (p[1] is coefficient of highest power)";
            input Real u "Abscissa value";
            input Real du "Delta of abscissa value";
            output Real dy "Value of derivative of polynomial at u";
          protected
            Integer n = size(p, 1);
          algorithm
            dy := p[1] * (n - 1);
            for j in 2:size(p, 1) - 1 loop
              dy := p[j] * (n - j) + u * dy;
            end for;
            dy := dy * du;
          end evaluate_der;

          function evaluateWithRange_der  "Evaluate derivative of polynomial at a given abscissa value with extrapolation outside of the defined range" 
            extends Modelica.Icons.Function;
            input Real[:] p "Polynomial coefficients (p[1] is coefficient of highest power)";
            input Real uMin "Polynomial valid in the range uMin .. uMax";
            input Real uMax "Polynomial valid in the range uMin .. uMax";
            input Real u "Abscissa value";
            input Real du "Delta of abscissa value";
            output Real dy "Value of derivative of polynomial at u";
          algorithm
            if u < uMin then
              dy := evaluate_der(p, uMin, du);
            elseif u > uMax then
              dy := evaluate_der(p, uMax, du);
            else
              dy := evaluate_der(p, u, du);
            end if;
          end evaluateWithRange_der;

          function integralValue_der  "Time derivative of integral of polynomial p(u) from u_low to u_high, assuming only u_high as time-dependent (Leibniz rule)" 
            extends Modelica.Icons.Function;
            input Real[:] p "Polynomial coefficients";
            input Real u_high "High integrand value";
            input Real u_low = 0 "Low integrand value, default 0";
            input Real du_high "High integrand value";
            input Real du_low = 0 "Low integrand value, default 0";
            output Real dintegral = 0.0 "Integral of polynomial p from u_low to u_high";
          algorithm
            dintegral := evaluate(p, u_high) * du_high;
          end integralValue_der;

          function derivativeValue_der  "Time derivative of derivative of polynomial" 
            extends Modelica.Icons.Function;
            input Real[:] p "Polynomial coefficients (p[1] is coefficient of highest power)";
            input Real u "Abscissa value";
            input Real du "Delta of abscissa value";
            output Real dy "Time-derivative of derivative of polynomial w.r.t. input variable at u";
          protected
            Integer n = size(p, 1);
          algorithm
            dy := secondDerivativeValue(p, u) * du;
          end derivativeValue_der;
        end Polynomials_Temp;
      end TableBased;
    end Incompressible;
  end Media;

  package Thermal  "Library of thermal system components to model heat transfer and simple thermo-fluid pipe flow" 
    extends Modelica.Icons.Package;

    package HeatTransfer  "Library of 1-dimensional heat transfer with lumped elements" 
      extends Modelica.Icons.Package;

      package Sources  "Thermal sources" 
        extends Modelica.Icons.SourcesPackage;

        model FixedHeatFlow  "Fixed heat flow boundary condition" 
          parameter Modelica.SIunits.HeatFlowRate Q_flow "Fixed heat flow rate at port";
          parameter Modelica.SIunits.Temperature T_ref = 293.15 "Reference temperature";
          parameter Modelica.SIunits.LinearTemperatureCoefficient alpha = 0 "Temperature coefficient of heat flow rate";
          Interfaces.HeatPort_b port;
        equation
          port.Q_flow = -Q_flow * (1 + alpha * (port.T - T_ref));
        end FixedHeatFlow;
      end Sources;

      package Interfaces  "Connectors and partial models" 
        extends Modelica.Icons.InterfacesPackage;

        partial connector HeatPort  "Thermal port for 1-dim. heat transfer" 
          Modelica.SIunits.Temperature T "Port temperature";
          flow Modelica.SIunits.HeatFlowRate Q_flow "Heat flow rate (positive if flowing from outside into the component)";
        end HeatPort;

        connector HeatPort_b  "Thermal port for 1-dim. heat transfer (unfilled rectangular icon)" 
          extends HeatPort;
        end HeatPort_b;
      end Interfaces;
    end HeatTransfer;
  end Thermal;

  package Math  "Library of mathematical functions (e.g., sin, cos) and of functions operating on vectors and matrices" 
    extends Modelica.Icons.Package;

    package Matrices  "Library of functions operating on matrices" 
      extends Modelica.Icons.Package;

      function leastSquares  "Solve linear equation A*x = b (exactly if possible, or otherwise in a least square sense; A may be non-square and may be rank deficient)" 
        extends Modelica.Icons.Function;
        input Real[:, :] A "Matrix A";
        input Real[size(A, 1)] b "Vector b";
        input Real rcond = 100 * Modelica.Constants.eps "Reciprocal condition number to estimate the rank of A";
        output Real[size(A, 2)] x "Vector x such that min|A*x-b|^2 if size(A,1) >= size(A,2) or min|x|^2 and A*x=b, if size(A,1) < size(A,2)";
        output Integer rank "Rank of A";
      protected
        Integer info;
        Real[max(size(A, 1), size(A, 2))] xx;
      algorithm
        if min(size(A)) > 0 then
          (xx, info, rank) := LAPACK.dgelsy_vec(A, b, rcond);
          x := xx[1:size(A, 2)];
          assert(info == 0, "Solving an overdetermined or underdetermined linear system\n" + "of equations with function \"Matrices.leastSquares\" failed.");
        else
          x := fill(0.0, size(A, 2));
        end if;
      end leastSquares;

      package LAPACK  "Interface to LAPACK library (should usually not directly be used but only indirectly via Modelica.Math.Matrices)" 
        extends Modelica.Icons.Package;

        function dgelsy_vec  "Computes the minimum-norm solution to a real linear least squares problem with rank deficient A" 
          extends Modelica.Icons.Function;
          input Real[:, :] A;
          input Real[size(A, 1)] b;
          input Real rcond = 0.0 "Reciprocal condition number to estimate rank";
          output Real[max(size(A, 1), size(A, 2))] x = cat(1, b, zeros(max(nrow, ncol) - nrow)) "solution is in first size(A,2) rows";
          output Integer info;
          output Integer rank "Effective rank of A";
        protected
          Integer nrow = size(A, 1);
          Integer ncol = size(A, 2);
          Integer nx = max(nrow, ncol);
          Integer lwork = max(min(nrow, ncol) + 3 * ncol + 1, 2 * min(nrow, ncol) + 1);
          Real[max(min(size(A, 1), size(A, 2)) + 3 * size(A, 2) + 1, 2 * min(size(A, 1), size(A, 2)) + 1)] work;
          Real[size(A, 1), size(A, 2)] Awork = A;
          Integer[size(A, 2)] jpvt = zeros(ncol);
          external "FORTRAN 77" dgelsy(nrow, ncol, 1, Awork, nrow, x, nx, jpvt, rcond, rank, work, lwork, info) annotation(Library = "lapack");
        end dgelsy_vec;
      end LAPACK;
    end Matrices;

    package Icons  "Icons for Math" 
      extends Modelica.Icons.IconsPackage;

      partial function AxisLeft  "Basic icon for mathematical function with y-axis on left side" end AxisLeft;

      partial function AxisCenter  "Basic icon for mathematical function with y-axis in the center" end AxisCenter;
    end Icons;

    function cos  "Cosine" 
      extends Modelica.Math.Icons.AxisLeft;
      input .Modelica.SIunits.Angle u;
      output Real y;
      external "builtin" y = cos(u);
    end cos;

    function tan  "Tangent (u shall not be -pi/2, pi/2, 3*pi/2, ...)" 
      extends Modelica.Math.Icons.AxisCenter;
      input .Modelica.SIunits.Angle u;
      output Real y;
      external "builtin" y = tan(u);
    end tan;

    function asin  "Inverse sine (-1 <= u <= 1)" 
      extends Modelica.Math.Icons.AxisCenter;
      input Real u;
      output .Modelica.SIunits.Angle y;
      external "builtin" y = asin(u);
    end asin;

    function cosh  "Hyperbolic cosine" 
      extends Modelica.Math.Icons.AxisCenter;
      input Real u;
      output Real y;
      external "builtin" y = cosh(u);
    end cosh;

    function tanh  "Hyperbolic tangent" 
      extends Modelica.Math.Icons.AxisCenter;
      input Real u;
      output Real y;
      external "builtin" y = tanh(u);
    end tanh;

    function asinh  "Inverse of sinh (area hyperbolic sine)" 
      extends Modelica.Math.Icons.AxisCenter;
      input Real u;
      output Real y;
    algorithm
      y := Modelica.Math.log(u + sqrt(u * u + 1));
    end asinh;

    function exp  "Exponential, base e" 
      extends Modelica.Math.Icons.AxisCenter;
      input Real u;
      output Real y;
      external "builtin" y = exp(u);
    end exp;

    function log  "Natural (base e) logarithm (u shall be > 0)" 
      extends Modelica.Math.Icons.AxisLeft;
      input Real u;
      output Real y;
      external "builtin" y = log(u);
    end log;

    function log10  "Base 10 logarithm (u shall be > 0)" 
      extends Modelica.Math.Icons.AxisLeft;
      input Real u;
      output Real y;
      external "builtin" y = log10(u);
    end log10;
  end Math;

  package Utilities  "Library of utility functions dedicated to scripting (operating on files, streams, strings, system)" 
    extends Modelica.Icons.Package;

    package Streams  "Read from files and write to files" 
      extends Modelica.Icons.Package;

      function error  "Print error message and cancel all actions" 
        extends Modelica.Icons.Function;
        input String string "String to be printed to error message window";
        external "C" ModelicaError(string) annotation(Library = "ModelicaExternalC");
      end error;
    end Streams;
  end Utilities;

  package Constants  "Library of mathematical constants and constants of nature (e.g., pi, eps, R, sigma)" 
    extends Modelica.Icons.Package;
    final constant Real pi = 2 * Math.asin(1.0);
    final constant Real eps = ModelicaServices.Machine.eps "Biggest number such that 1.0 + eps = 1.0";
    final constant Real inf = ModelicaServices.Machine.inf "Biggest Real number such that inf and -inf are representable on the machine";
    final constant .Modelica.SIunits.Velocity c = 299792458 "Speed of light in vacuum";
    final constant .Modelica.SIunits.Acceleration g_n = 9.80665 "Standard acceleration of gravity on earth";
    final constant Real R(final unit = "J/(mol.K)") = 8.3144598 "Molar gas constant (previous value: 8.314472)";
    final constant Real mue_0(final unit = "N/A2") = 4 * pi * 1.e-7 "Magnetic constant";
    final constant .Modelica.SIunits.Conversions.NonSIunits.Temperature_degC T_zero = -273.15 "Absolute zero temperature";
  end Constants;

  package Icons  "Library of icons" 
    extends Icons.Package;

    partial package Package  "Icon for standard packages" end Package;

    partial package BasesPackage  "Icon for packages containing base classes" 
      extends Modelica.Icons.Package;
    end BasesPackage;

    partial package VariantsPackage  "Icon for package containing variants" 
      extends Modelica.Icons.Package;
    end VariantsPackage;

    partial package InterfacesPackage  "Icon for packages containing interfaces" 
      extends Modelica.Icons.Package;
    end InterfacesPackage;

    partial package SourcesPackage  "Icon for packages containing sources" 
      extends Modelica.Icons.Package;
    end SourcesPackage;

    partial package UtilitiesPackage  "Icon for utility packages" 
      extends Modelica.Icons.Package;
    end UtilitiesPackage;

    partial package TypesPackage  "Icon for packages containing type definitions" 
      extends Modelica.Icons.Package;
    end TypesPackage;

    partial package IconsPackage  "Icon for packages containing icons" 
      extends Modelica.Icons.Package;
    end IconsPackage;

    partial package InternalPackage  "Icon for an internal package (indicating that the package should not be directly utilized by user)" end InternalPackage;

    partial package MaterialPropertiesPackage  "Icon for package containing property classes" 
      extends Modelica.Icons.Package;
    end MaterialPropertiesPackage;

    partial function Function  "Icon for functions" end Function;

    partial record Record  "Icon for records" end Record;
  end Icons;

  package SIunits  "Library of type and unit definitions based on SI units according to ISO 31-1992" 
    extends Modelica.Icons.Package;

    package Icons  "Icons for SIunits" 
      extends Modelica.Icons.IconsPackage;

      partial function Conversion  "Base icon for conversion functions" end Conversion;
    end Icons;

    package Conversions  "Conversion functions to/from non SI units and type definitions of non SI units" 
      extends Modelica.Icons.Package;

      package NonSIunits  "Type definitions of non SI units" 
        extends Modelica.Icons.Package;
        type Temperature_degC = Real(final quantity = "ThermodynamicTemperature", final unit = "degC") "Absolute temperature in degree Celsius (for relative temperature use SIunits.TemperatureDifference)" annotation(absoluteValue = true);
        type Pressure_bar = Real(final quantity = "Pressure", final unit = "bar") "Absolute pressure in bar";
      end NonSIunits;

      function to_degC  "Convert from Kelvin to degCelsius" 
        extends Modelica.SIunits.Icons.Conversion;
        input Temperature Kelvin "Kelvin value";
        output NonSIunits.Temperature_degC Celsius "Celsius value";
      algorithm
        Celsius := Kelvin + Modelica.Constants.T_zero;
        annotation(Inline = true); 
      end to_degC;

      function from_degC  "Convert from degCelsius to Kelvin" 
        extends Modelica.SIunits.Icons.Conversion;
        input NonSIunits.Temperature_degC Celsius "Celsius value";
        output Temperature Kelvin "Kelvin value";
      algorithm
        Kelvin := Celsius - Modelica.Constants.T_zero;
        annotation(Inline = true); 
      end from_degC;

      function to_bar  "Convert from Pascal to bar" 
        extends Modelica.SIunits.Icons.Conversion;
        input Pressure Pa "Pascal value";
        output NonSIunits.Pressure_bar bar "bar value";
      algorithm
        bar := Pa / 1e5;
        annotation(Inline = true); 
      end to_bar;
    end Conversions;

    type Angle = Real(final quantity = "Angle", final unit = "rad", displayUnit = "deg");
    type Length = Real(final quantity = "Length", final unit = "m");
    type Height = Length(min = 0);
    type Diameter = Length(min = 0);
    type Area = Real(final quantity = "Area", final unit = "m2");
    type Volume = Real(final quantity = "Volume", final unit = "m3");
    type Time = Real(final quantity = "Time", final unit = "s");
    type AngularVelocity = Real(final quantity = "AngularVelocity", final unit = "rad/s");
    type Velocity = Real(final quantity = "Velocity", final unit = "m/s");
    type Acceleration = Real(final quantity = "Acceleration", final unit = "m/s2");
    type Frequency = Real(final quantity = "Frequency", final unit = "Hz");
    type Mass = Real(quantity = "Mass", final unit = "kg", min = 0);
    type Density = Real(final quantity = "Density", final unit = "kg/m3", displayUnit = "g/cm3", min = 0.0);
    type Momentum = Real(final quantity = "Momentum", final unit = "kg.m/s");
    type Force = Real(final quantity = "Force", final unit = "N");
    type Pressure = Real(final quantity = "Pressure", final unit = "Pa", displayUnit = "bar");
    type AbsolutePressure = Pressure(min = 0.0, nominal = 1e5);
    type DynamicViscosity = Real(final quantity = "DynamicViscosity", final unit = "Pa.s", min = 0);
    type SurfaceTension = Real(final quantity = "SurfaceTension", final unit = "N/m");
    type Energy = Real(final quantity = "Energy", final unit = "J");
    type Power = Real(final quantity = "Power", final unit = "W");
    type EnthalpyFlowRate = Real(final quantity = "EnthalpyFlowRate", final unit = "W");
    type MassFlowRate = Real(quantity = "MassFlowRate", final unit = "kg/s");
    type VolumeFlowRate = Real(final quantity = "VolumeFlowRate", final unit = "m3/s");
    type MomentumFlux = Real(final quantity = "MomentumFlux", final unit = "N");
    type ThermodynamicTemperature = Real(final quantity = "ThermodynamicTemperature", final unit = "K", min = 0.0, start = 288.15, nominal = 300, displayUnit = "degC") "Absolute temperature (use type TemperatureDifference for relative temperatures)" annotation(absoluteValue = true);
    type Temperature = ThermodynamicTemperature;
    type LinearTemperatureCoefficient = Real(final quantity = "LinearTemperatureCoefficient", final unit = "1/K");
    type CubicExpansionCoefficient = Real(final quantity = "CubicExpansionCoefficient", final unit = "1/K");
    type Compressibility = Real(final quantity = "Compressibility", final unit = "1/Pa");
    type IsothermalCompressibility = Compressibility;
    type HeatFlowRate = Real(final quantity = "Power", final unit = "W");
    type ThermalConductivity = Real(final quantity = "ThermalConductivity", final unit = "W/(m.K)");
    type CoefficientOfHeatTransfer = Real(final quantity = "CoefficientOfHeatTransfer", final unit = "W/(m2.K)");
    type SpecificHeatCapacity = Real(final quantity = "SpecificHeatCapacity", final unit = "J/(kg.K)");
    type RatioOfSpecificHeatCapacities = Real(final quantity = "RatioOfSpecificHeatCapacities", final unit = "1");
    type Entropy = Real(final quantity = "Entropy", final unit = "J/K");
    type SpecificEntropy = Real(final quantity = "SpecificEntropy", final unit = "J/(kg.K)");
    type SpecificEnergy = Real(final quantity = "SpecificEnergy", final unit = "J/kg");
    type SpecificInternalEnergy = SpecificEnergy;
    type SpecificEnthalpy = SpecificEnergy;
    type DerDensityByEnthalpy = Real(final unit = "kg.s2/m5");
    type DerDensityByPressure = Real(final unit = "s2/m2");
    type DerDensityByTemperature = Real(final unit = "kg/(m3.K)");
    type DerEnthalpyByPressure = Real(final unit = "J.m.s2/kg2");
    type AmountOfSubstance = Real(final quantity = "AmountOfSubstance", final unit = "mol", min = 0);
    type MolarMass = Real(final quantity = "MolarMass", final unit = "kg/mol", min = 0);
    type MolarVolume = Real(final quantity = "MolarVolume", final unit = "m3/mol", min = 0);
    type MassFraction = Real(final quantity = "MassFraction", final unit = "1", min = 0, max = 1);
    type MoleFraction = Real(final quantity = "MoleFraction", final unit = "1", min = 0, max = 1);
    type FaradayConstant = Real(final quantity = "FaradayConstant", final unit = "C/mol");
    type ReynoldsNumber = Real(final quantity = "ReynoldsNumber", final unit = "1");
    type NusseltNumber = Real(final quantity = "NusseltNumber", final unit = "1");
    type PrandtlNumber = Real(final quantity = "PrandtlNumber", final unit = "1");
  end SIunits;
  annotation(version = "3.2.2", versionBuild = 3, versionDate = "2016-04-03", dateModified = "2016-04-03 08:44:41Z"); 
end Modelica;

model SIS100ProportionalSafetyValveLowPressure_total
  extends SafetyValveDimensions.SIS100ProportionalSafetyValveLowPressure;
 annotation(experiment(StartTime = 0, StopTime = 20, Tolerance = 1e-06, Interval = 0.01));
end SIS100ProportionalSafetyValveLowPressure_total;
