//Author: Ravi Saripalli
model car  " A car "

 import mylib.A.* ;
 import mylib.A.B.C.*;

Real x ;

equation 
  der(x) =  afun(1) + cfun(0.3) ;
  //der(x) =   A.amul(0.3) ;
  // der(x) =  bdiv(1)  ;

initial equation
  x = 0 ;

end car;


