//Author: Ravi Saripalli
within;
 package mylib  "Mylib ..."

package A   "Toplevel Package"  
  import A.B.C.* ;    // This combo fails
  function  afun
    input Real x ;
    output Real y ;
  algorithm
        y := 5 * x *  cfun(3)  ;  // This combo fails
 //     y := 5 * x *  A.B.C.cfun(3)  ;  // But This  works
  end afun;

package B  "Mid level package"

package C  "Lowest level package"

  function cfun 
    input Real x ;
    output Real y ;
  algorithm
      y := 6 * x ;
  end cfun; 

end C;
end B;

end A;

end mylib;
