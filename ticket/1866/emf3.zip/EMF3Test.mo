model EMF3Test
  Modelica.Electrical.Analog.Basic.Ground ground1 annotation(Placement(visible = true, transformation(origin = {-59.9764,-55.49}, extent = {{-12,-12},{12,12}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor resistor1(R = fill(5.25, 3)) annotation(Placement(visible = true, transformation(origin = {-30.2243,57.6151}, extent = {{-12,-12},{12,12}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Inductor inductor1(L = fill(0.0016, 3)) annotation(Placement(visible = true, transformation(origin = {8.97285,57.6151}, extent = {{-12,-12},{12,12}}, rotation = 0)));
  EMF3 emf31 annotation(Placement(visible = true, transformation(origin = {29.0437,24.0851}, extent = {{-12,-12},{12,12}}, rotation = 0)));
  Modelica.Mechanics.Rotational.Components.Inertia inertia1(J = 0.00066) annotation(Placement(visible = true, transformation(origin = {67.0602,24.085}, extent = {{-12,-12},{12,12}}, rotation = 0)));
  Modelica.Mechanics.Rotational.Components.BearingFriction bearingfriction1(tau_pos = [0,0.001;5,0.005]) annotation(Placement(visible = true, transformation(origin = {67.0602,-43.6836}, extent = {{-12,-12},{12,12}}, rotation = 0)));
  annotation(experiment(StartTime = 0.0, StopTime = 9.0, Tolerance = 1e-06));
  Modelica.Electrical.MultiPhase.Basic.Star star1 annotation(Placement(visible = true, transformation(origin = {-59.9764,-19.1263}, extent = {{-12,12},{12,-12}}, rotation = -90)));
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sinevoltage1(V = fill(20, 3), freqHz = fill(2, 3)) annotation(Placement(visible = true, transformation(origin = {-59.9764,22.9044}, extent = {{-12,12},{12,-12}}, rotation = -90)));
  Modelica.Mechanics.Rotational.Components.Fixed fixed1 annotation(Placement(visible = true, transformation(origin = {-3.30579,23.8489}, extent = {{-12,-12},{12,12}}, rotation = 0)));
equation
  connect(fixed1.flange,emf31.support) annotation(Line(points = {{-3.30579,23.8489},{16.7651,23.8489},{16.7651,24.0851},{17.0579,24.0851}}));
  connect(inertia1.flange_b,bearingfriction1.flange_b) annotation(Line(points = {{79.0602,24.085},{89.2562,24.085},{89.2562,-13.9315},{79.0602,-13.9315},{79.0602,-43.6836}}));
  connect(inductor1.plug_n,emf31.p) annotation(Line(points = {{20.9728,57.6151},{29.0437,57.6151},{29.0437,35.5042},{29.0154,35.5042}}));
  connect(emf31.n,star1.plug_p) annotation(Line(points = {{29.0437,12.6659},{29.0436,12.6659},{29.0436,-7.31995},{-59.9764,-7.31995},{-59.9764,-7.1263}}));
  connect(emf31.flange,inertia1.flange_a) annotation(Line(points = {{40.4345,24.1134},{55.2538,24.1134},{55.2538,24.085},{55.0602,24.085}}));
  connect(resistor1.plug_n,inductor1.plug_p) annotation(Line(points = {{-18.2243,57.6151},{-2.83353,57.6151},{-2.83353,57.6151},{-3.02715,57.6151}}));
  connect(sinevoltage1.plug_p,resistor1.plug_p) annotation(Line(points = {{-59.9764,34.9044},{-59.9764,34.9044},{-59.9764,57.6151},{-42.2243,57.6151},{-42.2243,57.6151}}));
  connect(sinevoltage1.plug_n,star1.plug_p) annotation(Line(points = {{-59.9764,10.9044},{-59.9764,10.9044},{-59.9764,-7.12633},{-59.9764,-7.12633}}));
  connect(ground1.p,star1.pin_n) annotation(Line(points = {{-59.9764,-43.49},{-59.9764,-31.405},{-59.9764,-31.405},{-59.9764,-31.1263}}));
end EMF3Test;

