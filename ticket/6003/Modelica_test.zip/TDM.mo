model TDM
  extends Modelica.Blocks.Interfaces.MISO;

  // Input selection signal (discrete)
    Modelica.Blocks.Interfaces.IntegerInput index( min=1, max=nin, start=1) "Connector of Digital input signal"
                annotation (Placement(transformation(origin={0,110},extent={{-10,-10},{10,
            10}},rotation = -90)));

equation
  y = u[index];
annotation (
    Diagram(coordinateSystem(initialScale = 0.1)),
    Icon(graphics={  Rectangle(fillColor = {213, 255, 170}, fillPattern = FillPattern.Solid,
            lineThickness =                                                                                  0.5, extent = {{-14, 60}, {14, -60}}), Line(origin = {14, 0}, points = {{0, 0}, {86, 0}}), Line(origin = {-14, 55}, points = {{0, 0}, {-20, 0}}), Line(origin = {-14, 45}, points = {{0, 0}, {-20, 0}}), Line(origin = {-14, 35}, points = {{0, 0}, {-20, 0}}), Line(origin = {-14, 25}, points = {{0, 0}, {-20, 0}}), Line(origin = {-14, 15}, points = {{0, 0}, {-20, 0}}), Line(origin = {-14, 5}, points = {{0, 0}, {-20, 0}}), Line(origin = {-14, -5}, points = {{0, 0}, {-20, 0}}), Line(origin = {-14, -15}, points = {{0, 0}, {-20, 0}}), Line(origin = {-14, -55}, points = {{0, 0}, {-20, 0}})}, coordinateSystem(initialScale = 0.1)));
end TDM;
