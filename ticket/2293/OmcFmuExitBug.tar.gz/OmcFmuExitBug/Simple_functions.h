#ifndef Simple__H
#define Simple__H
#ifdef _OPENMP_
#include <omp.h>
#else
#define omp_get_thread_num() 0
#define omp_get_max_threads() 1
#endif
#include "modelica.h"
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#include "simulation_runtime.h"
#ifdef __cplusplus
extern "C" {
#endif
#ifdef __cplusplus
}
#endif
#endif


