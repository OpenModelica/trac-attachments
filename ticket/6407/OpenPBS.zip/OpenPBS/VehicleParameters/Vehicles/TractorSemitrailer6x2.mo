within OpenPBS.VehicleParameters.Vehicles;
record TractorSemitrailer6x2 = OpenPBS.VehicleParameters.Base.VehicleModel (
    nu=2,
    na=3,
    L=[0.0,-3.0,-4.37; 0.0,-1.3,-2.6],
    W=[2.5,2.5,2.5; 2.5,2.5,2.5],
    A={0.0,6.4},
    B={-3.4,-4.0},
    Fz=[71607.3,82532.4,82532.4;63116,63116,63116],
    mk={9460, 4300},
    driven=[false,true,false; false,false,false],
    CCy0=[5.5,5.5,5.5; 5.5,5.5,5.5],
    Iz={0.2991,5.7348},
    axlegroups=[1,2,2; 1,1,1],
    FOH={1,7},
    ROH={-4.8,-3.5}) "6x2 tractor with semitrailer";
