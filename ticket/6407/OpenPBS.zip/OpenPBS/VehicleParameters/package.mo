within OpenPBS;

package VehicleParameters
  annotation(
    Documentation(info = "<html>
<p><u><b>VehicleParameters</b></u> contains registries (sets of parameters) which defines the vehicles in terms of vehicle parameters, such as wheelbase and kerb mass. Note that no vehicle equations are introduced so far. </p>
</html>"));
end VehicleParameters;
