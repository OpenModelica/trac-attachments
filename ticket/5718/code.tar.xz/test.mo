model test "Для тестирования"
  import Modelica.Math;
  RlsIdentifier tryit;
  parameter Real omega = 5 "Циклическая частота сигнала";
equation
  tryit.x = {{cos(time * omega), sin(time * omega)}};
  tryit.y = {{sin(time * omega + pi / 4)}};
  tryit.lambda = 0.5;
end test;