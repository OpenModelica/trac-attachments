within TestGTest2;
model GTest
  Modelica.Blocks.Interfaces.RealOutput outVal annotation (Placement(transformation(extent={{90,-10},{110,10}})));

  replaceable function G = TestGTest2.FunctionsPrototypes.G(fun=GsubSpring);

  replaceable function GsubSpring
    extends TestGTest2.FunctionsPrototypes.Gsubfun;
  algorithm
    f:=1.1;
  end GsubSpring;


equation
  outVal=G(def=time);

  annotation (Icon(coordinateSystem(preserveAspectRatio=false)), Diagram(coordinateSystem(preserveAspectRatio=false)));
end GTest;
