within TestGTest3;
model GTest
  Modelica.Blocks.Interfaces.RealOutput outVal annotation (Placement(transformation(extent={{90,-10},{110,10}})));

  replaceable function G = TestGTest3.FunctionsPrototypes.G(fun=GsubSpring);

  replaceable function GsubSpring
    extends TestGTest3.FunctionsPrototypes.Gsubfun;
  algorithm
    f:=1.1;
  end GsubSpring;


equation
  outVal=G(def=time);

  annotation (Icon(coordinateSystem(preserveAspectRatio=false)), Diagram(coordinateSystem(preserveAspectRatio=false)));
end GTest;
