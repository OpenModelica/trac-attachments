within TestGTest3;
package FunctionsPrototypes

  function G
    input TestGTest3.FunctionsPrototypes.Gsubfun fun;
    input Real def;
    output Real f;
  algorithm
    f:= fun(inVal=def) + fun(inVal=def);
  end G;

  partial function Gsubfun
    input Real inVal;
    output Real f;
  end Gsubfun;
end FunctionsPrototypes;
