model Stage3
  extends Modelica.Mechanics.MultiBody.Interfaces.PartialOneFrame_a;
  parameter Real hub_angle = 0;
  parameter Real shaft_length = 0.1;
  Modelica.Mechanics.MultiBody.Parts.FixedRotation fixedRotation1(angles = {0, 90, hub_angle}, animation = true, r = {shaft_length, 0, 0}, rotationType = Modelica.Mechanics.MultiBody.Types.RotationTypes.PlanarRotationSequence) annotation(
    Placement(visible = true, transformation(origin = {30, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Mechanics.MultiBody.Parts.PointMass pointMass1(animation = false, m = 1.0, stateSelect = StateSelect.never) annotation(
    Placement(visible = true, transformation(origin = {40, 20}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(fixedRotation1.frame_a, frame_a) annotation(
    Line(points = {{20, 0}, {-100, 0}, {-100, 0}, {-100, 0}}, color = {95, 95, 95}));
  connect(fixedRotation1.frame_b, pointMass1.frame_a) annotation(
    Line(points = {{40, 0}, {40, 20}}, color = {95, 95, 95}));
end Stage3;