model TopModel
  parameter Integer N = 3 annotation(
    Evaluate = true);
  //
  inner Modelica.Mechanics.MultiBody.World world(enableAnimation = true, n = {-1, 0, 0}, nominalLength = 0.25) annotation(
    Placement(visible = true, transformation(origin = {-80, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Stage1 stage1(N = N) annotation(
    Placement(visible = true, transformation(origin = {70, 70}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Mechanics.MultiBody.Parts.Body bodyCM(I_11 = 1, I_22 = 1, I_33 = 1, angles_fixed = true, enforceStates = true, m = 1.0, r_0(each fixed = true), r_CM = {0, 0, 0}, v_0(each fixed = true), w_0_fixed = true) annotation(
    Placement(visible = true, transformation(origin = {-30, 0}, extent = {{10, -10}, {-10, 10}}, rotation = 0)));
  Modelica.Mechanics.MultiBody.Sensors.AbsoluteSensor absoluteSensor1(animation = false, get_r = true, resolveInFrame = Modelica.Mechanics.MultiBody.Types.ResolveInFrameA.world) annotation(
    Placement(visible = true, transformation(origin = {-62, -30}, extent = {{10, 10}, {-10, -10}}, rotation = 0)));
  Modelica.Blocks.Routing.DeMultiplex3 deMultiplex31 annotation(
    Placement(visible = true, transformation(origin = {-64, 38}, extent = {{-10, -10}, {10, 10}}, rotation = 90)));
  Modelica.Blocks.Nonlinear.Limiter limiter1(limitsAtInit = true, uMax = 1000, uMin = 0) annotation(
    Placement(visible = true, transformation(origin = {-40, 80}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(absoluteSensor1.frame_a, bodyCM.frame_a) annotation(
    Line(points = {{-52, -30}, {-20, -30}, {-20, 0}}, color = {95, 95, 95}));
  connect(absoluteSensor1.r, deMultiplex31.u) annotation(
    Line(points = {{-52, -18}, {-52, -18}, {-52, 26}, {-64, 26}, {-64, 26}}, color = {0, 0, 127}, thickness = 0.5));
  connect(stage1.frame_a, bodyCM.frame_a) annotation(
    Line(points = {{60, 70}, {-20, 70}, {-20, 0}, {-20, 0}}, color = {95, 95, 95}));
  connect(limiter1.y, stage1.input1) annotation(
    Line(points = {{-28, 80}, {56, 80}, {56, 78}, {58, 78}}, color = {0, 0, 127}));
  connect(limiter1.u, deMultiplex31.y1[1]) annotation(
    Line(points = {{-52, 80}, {-70, 80}, {-70, 50}, {-70, 50}}, color = {0, 0, 127}));
  annotation(
    experiment(StartTime = 0, StopTime = 10, Tolerance = 1e-08, Interval = 0.02));
end TopModel;