within TestPackage.Electrical;
model VBus "electrical bus with constant voltage"
  import Modelica.ComplexMath;
  import TestPackage.Connectors;
    Connectors.ACPower pin
       annotation (Placement(transformation(extent={{-120,-10},{-100,10}}), iconTransformation(extent={{-120,-10},{-100,10}})));
equation
    pin.V = Complex( 1, 0);
  annotation (uses(Modelica(version="3.2.1")), Icon(graphics={
        Rectangle(
          extent={{-100,100},{100,-100}},
          lineColor={28,108,200},
          fillColor={255,255,255},
          fillPattern=FillPattern.Solid),
        Text(
          extent={{-84,-94},{86,-152}},
          lineColor={28,108,200},
          fillColor={255,255,255},
          fillPattern=FillPattern.Solid,
          textString="VBus"),
        Text(
          extent={{-88,82},{82,24}},
          lineColor={28,108,200},
          fillColor={255,255,255},
          fillPattern=FillPattern.Solid,
          textString="V.re=1"),
        Text(
          extent={{-88,-6},{82,-64}},
          lineColor={28,108,200},
          fillColor={255,255,255},
          fillPattern=FillPattern.Solid,
          textString="V.im=0")}));
end VBus;
