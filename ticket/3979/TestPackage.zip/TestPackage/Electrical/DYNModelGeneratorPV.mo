within TestPackage.Electrical;
model DYNModelGeneratorPV
  "Generator with pre-set active power and voltage outputs"
   extends GeneratorPV;
equation
    Q = smooth( 0,
      if (QControl <= QMin) then QMin
      elseif (QControl >= QMax) then QMax
      else QControl);
  annotation (uses(TestPackage(version="0.1"), Modelica(version="3.2.2")));
end DYNModelGeneratorPV;
