within TestPackage.Setups;
package PVGenerator "test cases for PV generators"

end PVGenerator;
