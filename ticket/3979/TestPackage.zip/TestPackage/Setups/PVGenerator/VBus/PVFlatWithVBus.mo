within TestPackage.Setups.PVGenerator.VBus;
model PVFlatWithVBus = GeneratorWithVBus (redeclare
      Electrical.DYNModelGeneratorPV_flat generator);
