within TestPackage.Setups.PVGenerator.VBus;
model PVWithVBus = GeneratorWithVBus (redeclare Electrical.DYNModelGeneratorPV generator);
