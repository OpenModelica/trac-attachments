within TestPackage.Setups.PVGenerator.LoadVar;
partial model GeneratorWithLoadVar
  extends Modelica.Icons.Example;
            // 0 unknowns, 4 equations
  extends Setups.PVGenerator.StandardParameters;
  
  
  replaceable Electrical.DYNModelGeneratorPV generator( lambda = lambda, QMin = QMin, QMax = QMax, PMin = PMin, PMax = PMax, P0 = p0, Q0 = q0)
    annotation (Placement(transformation(extent={{-40,-10},{-20,10}})));
  Electrical.simpleLoadVar load(p0 = p0, q0 = q0, alpha = 1.0, beta = 1.0, qDer = qDer, T = T)
    annotation (Placement(transformation(extent={{0,-10},{20,10}})));
  Modelica.Blocks.Sources.Constant UTarget(k=1)
    annotation (Placement(transformation(extent={{-80,-10},{-60,10}})));
initial equation
  generator.out.V.re = 1;

equation
  connect(generator.out, load.pin)
    annotation (Line(points={{-18.8,0},{-1,0}},      color={0,0,255}));
  connect(UTarget.y, generator.UControl)
    annotation (Line(points={{-59,0},{-42,0}},         color={0,0,127}));
  annotation (uses(Modelica(version="3.2.2"), TestPackage(version="0.1")),
                                               experiment(StartTime=0,StopTime=20));
end GeneratorWithLoadVar;