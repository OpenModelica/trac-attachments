within TestPackage.Setups.PVGenerator;
package LoadVar "test cases for PV generators with load variation"
end LoadVar;
