within TestPackage.Setups.PVGenerator.LoadVar;
model PVFlatWithLoadVar = GeneratorWithLoadVar (redeclare Electrical.DYNModelGeneratorPV_flat generator);