within TestPackage.Setups.PVGenerator.LoadVar;
model PVWithLoadVar = GeneratorWithLoadVar (redeclare Electrical.DYNModelGeneratorPV generator);