within TestPackage.Connectors;

connector ImPin "connector for continuous real value"
public
    Real value;
end ImPin;
