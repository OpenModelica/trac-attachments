within TestPackage.Connectors;

connector ACPower "connector for AC power (described using complex V and i variables)"
public
    Types.AC.Voltage V "complex AC voltage";
    flow Types.AC.Current i "complex AC current (positive when entering the device)";
  annotation(Icon(graphics={  Rectangle(extent = {{-100, 98}, {100, -102}}, lineColor = {0, 0, 255}, fillColor = {0, 0, 255},
            fillPattern =                                                                                                                   FillPattern.Solid)}));
end ACPower;
