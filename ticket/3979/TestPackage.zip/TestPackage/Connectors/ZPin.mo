within TestPackage.Connectors;
connector ZPin "connector for propagating discrete values (and events)"
public
    discrete Real value;
end ZPin;

