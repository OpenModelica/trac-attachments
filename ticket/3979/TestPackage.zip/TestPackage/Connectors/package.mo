within TestPackage;
package Connectors "Connectors specific to TestPackage software"
  annotation(uses(Modelica(version = "3.2.1"), Complex(version = "3.2.1")), version = "0.1", conversion(noneFromVersion = ""));
end Connectors;
