within ;
encapsulated package TestPackage "TestPackage models library"

  // generic import commands
  import Complex "complex numbers foundation class";
  import Modelica.ComplexMath
  "complex numbers operators (+, - , *, exp, abs...)";
  import Modelica.SIunits "Modelica SI units";
  import Modelica;

  import TestPackage.Types "standard TestPackage variable types";


  annotation(uses(Modelica(version="3.2.1"), Complex(version="3.2.1")),     version = "0.1", conversion(noneFromVersion = ""), Documentation(info = "<html>
<h1>TestPackage models library</h1>
<p>Copyright 2016 RTE (France) (<a href='http://www.rte-france.com/'>RTE website</a>) </p>
<p> This library is a test library</p>
<p> The library may be distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.</p>
</html>"));
end TestPackage;
