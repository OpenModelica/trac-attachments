#ifndef _MAINFUNCTIONS_H_
#define _MAINFUNCTIONS_H_

#ifdef __cplusplus
extern "C" {
#endif

// create externalObject (Class etc.)
void* create(int someNumber);

// delete externalObject (Class etc.)
void destroy(void* obj);


#ifdef __cplusplus
}
#endif

#endif //_MAINFUNCTIONS_H_