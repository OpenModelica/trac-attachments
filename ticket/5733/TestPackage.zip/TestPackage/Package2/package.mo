within TestPackage;

package Package2
end Package2;
