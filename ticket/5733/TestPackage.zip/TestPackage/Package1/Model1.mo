within TestPackage.Package1;

model Model1
equation

end Model1;
