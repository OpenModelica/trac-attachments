#ifdef __cplusplus
extern "C" {
#endif
/* header part */
#include "modelica.h"


/* body part */


#ifdef __cplusplus
}
#endif
