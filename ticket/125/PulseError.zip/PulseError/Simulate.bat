C:\OpenModelica1.4.3\bin\omc PulseError.mos
pause
