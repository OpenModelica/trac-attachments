model PulseError
  Modelica.Blocks.Sources.Pulse     pulse(amplitude = 5, period=0.2, width=50, startTime = 0.1);
  Modelica.Blocks.Sources.Trapezoid trapezoid(amplitude = -5, period=0.2, width=50, startTime = 0.1);
end PulseError;
