within P;
package P1
  model M
    Real x = 2;
  end M;
end P1;