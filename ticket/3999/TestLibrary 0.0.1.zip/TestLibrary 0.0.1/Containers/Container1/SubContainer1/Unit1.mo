within TestLibrary.Containers.Container1.SubContainer1;

class Unit1 "Unit1"
	replaceable TestLibrary.Models.ModelContainer1.Model1.SubModel5 sm5;

	replaceable TestLibrary.Models.ModelContainer1.Model1.SubModel1 sm1;
	replaceable TestLibrary.Models.ModelContainer1.Model1.SubModel3 sm3;
	replaceable TestLibrary.Models.ModelContainer1.Model1.SubModel4 sm4;

	parameter Real Q = 10000;

equation
	sm3.states = sm1.states;
	sm4.states = sm1.states;

	sm5.Q = -Q;

	sm5.states = sm1.states;
	sm5.composites = sm3.composites;
	sm5.species = sm4.species;
end Unit1;
