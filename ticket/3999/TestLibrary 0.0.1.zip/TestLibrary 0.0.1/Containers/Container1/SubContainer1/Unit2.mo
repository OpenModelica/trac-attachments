within TestLibrary.Containers.Container1.SubContainer1;

class Unit2 "Unit2"
	replaceable TestLibrary.Models.ModelContainer1.Model1.SubModel5 sm5;
end Unit2;