within ;
package Test_multifile
annotation (uses(Modelica(version="3.2.3"), PhotoVoltaics(version="1.6.0")));
end Test_multifile;
