within Test_multifile;
model testNew
  Real x;

equation
  x=1;
end testNew;
