within Test_multifile;
model test
  Real x;

equation
  x=1;
end test;
