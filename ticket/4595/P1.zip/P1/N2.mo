within P1;
model N2
  Real x=1;
end N2;
