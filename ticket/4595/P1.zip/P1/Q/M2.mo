within P1.Q;
model M2
  Real x=1;
end M2;
