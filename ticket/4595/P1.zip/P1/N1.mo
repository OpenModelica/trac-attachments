within P1;
model N1
  Real x=1;
end N1;
