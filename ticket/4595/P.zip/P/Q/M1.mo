within P.Q;
model M1
  Real x=1;
end M1;
