model dc_control
  Modelica.Blocks.Interfaces.RealInput vdcmeas annotation(
    Placement(visible = true, transformation(origin = {-120, -40}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, -40}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput vmppt annotation(
    Placement(visible = true, transformation(origin = {-120, 40}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, 40}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Math.Feedback feedback annotation(
    Placement(visible = true, transformation(origin = {-54, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Gain gain(k = 1.45)  annotation(
    Placement(visible = true, transformation(origin = {-12, 58}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Continuous.Integrator integrator(k = 1.15)  annotation(
    Placement(visible = true, transformation(origin = {-12, 24}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Add add annotation(
    Placement(visible = true, transformation(origin = {24, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput y annotation(
    Placement(visible = true, transformation(origin = {110, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(vmppt, feedback.u1) annotation(
    Line(points = {{-120, 40}, {-64, 40}, {-64, 40}, {-62, 40}, {-62, 40}}, color = {0, 0, 127}));
  connect(feedback.u2, vdcmeas) annotation(
    Line(points = {{-54, 32}, {-54, 32}, {-54, -40}, {-120, -40}, {-120, -40}}, color = {0, 0, 127}));
  connect(feedback.y, gain.u) annotation(
    Line(points = {{-44, 40}, {-34, 40}, {-34, 58}, {-24, 58}}, color = {0, 0, 127}));
  connect(integrator.u, feedback.y) annotation(
    Line(points = {{-24, 24}, {-34, 24}, {-34, 40}, {-44, 40}}, color = {0, 0, 127}));
  connect(gain.y, add.u1) annotation(
    Line(points = {{0, 58}, {8, 58}, {8, 46}, {12, 46}, {12, 46}}, color = {0, 0, 127}));
  connect(integrator.y, add.u2) annotation(
    Line(points = {{0, 24}, {8, 24}, {8, 34}, {12, 34}, {12, 34}}, color = {0, 0, 127}));
  connect(add.y, y) annotation(
    Line(points = {{36, 40}, {104, 40}, {104, 40}, {110, 40}}, color = {0, 0, 127}));

annotation(
    uses(Modelica(version = "3.2.3")));
end dc_control;
