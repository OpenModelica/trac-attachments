model invtrafo2
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage annotation(
    Placement(visible = true, transformation(origin = {68, 6}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {92, -38}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {92, -4}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  m1testrafo m1testrafoh annotation(
    Placement(visible = true, transformation(origin = {-36, 28}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  m1testrafo m1testrafoj annotation(
    Placement(visible = true, transformation(origin = {-36, -12}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.CombiTimeTable PRef(extrapolation = Modelica.Blocks.Types.Extrapolation.HoldLastPoint, smoothness = Modelica.Blocks.Types.Smoothness.ConstantSegments, table = [0, -300000 / 6; 0.5, -500000 / 6]) annotation(
    Placement(visible = true, transformation(origin = {-126, 44}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.CombiTimeTable QRref(extrapolation = Modelica.Blocks.Types.Extrapolation.HoldLastPoint, smoothness = Modelica.Blocks.Types.Smoothness.ConstantSegments, table = [0, -50000 / 6; 0.5, -100000 / 6]) annotation(
    Placement(visible = true, transformation(origin = {-126, 12}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(sineVoltage.plug_n, star.plug_p) annotation(
    Line(points = {{78, 6}, {92, 6}, {92, 6}, {92, 6}}, color = {0, 0, 255}));
  connect(star.pin_n, ground.p) annotation(
    Line(points = {{92, -14}, {92, -14}, {92, -28}, {92, -28}}, color = {0, 0, 255}));
  connect(m1testrafoh.pref, PRef.y[1]) annotation(
    Line(points = {{-40, 40}, {-114, 40}, {-114, 44}, {-114, 44}}, color = {0, 0, 127}));
  connect(PRef.y[1], m1testrafoj.pref) annotation(
    Line(points = {{-114, 44}, {-56, 44}, {-56, 2}, {-40, 2}, {-40, 0}}, color = {0, 0, 127}));
  connect(QRref.y[1], m1testrafoj.qref) annotation(
    Line(points = {{-114, 12}, {-32, 12}, {-32, 0}, {-32, 0}}, color = {0, 0, 127}));
  connect(QRref.y[1], m1testrafoh.qref) annotation(
    Line(points = {{-114, 12}, {-70, 12}, {-70, 44}, {-32, 44}, {-32, 40}, {-32, 40}}, color = {0, 0, 127}));
  connect(m1testrafoh.positivePlug, sineVoltage.plug_p) annotation(
    Line(points = {{-18, 34}, {28, 34}, {28, 6}, {58, 6}, {58, 6}}, color = {0, 0, 255}));
  connect(m1testrafoj.positivePlug, sineVoltage.plug_p) annotation(
    Line(points = {{-18, -6}, {28, -6}, {28, 6}, {58, 6}, {58, 6}}, color = {0, 0, 255}));
  annotation(
    uses(Modelica(version = "3.2.3")));
end invtrafo2;
