model nc
  extends Modelica.Blocks.Interfaces.SISO;
equation
  y = if time < 0.1 then 100 else u;

end nc;
