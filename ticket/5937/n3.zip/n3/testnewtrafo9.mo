model testnewtrafo9
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage2(V = fill(20412, 3), freqHz = fill(50, 3))  annotation(
    Placement(visible = true, transformation(origin = {62, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  VSC_voltage_sourcet vSC_voltage_sourcet1 annotation(
    Placement(visible = true, transformation(origin = {-130, 78}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  trafo_three_w trafo_three_w7 annotation(
    Placement(visible = true, transformation(origin = {-74, 128}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  VSC_voltage_sourcet vSC_voltage_sourcet annotation(
    Placement(visible = true, transformation(origin = {-130, 50}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  VSC_voltage_sourcet vSC_voltage_sourcet2 annotation(
    Placement(visible = true, transformation(origin = {-130, 14}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  VSC_voltage_sourcet vSC_voltage_sourcet3 annotation(
    Placement(visible = true, transformation(origin = {-130, -50}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  VSC_voltage_sourcet vSC_voltage_sourcet4 annotation(
    Placement(visible = true, transformation(origin = {-130, -12}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  VSC_voltage_sourcet vSC_voltage_sourcet5 annotation(
    Placement(visible = true, transformation(origin = {-130, -74}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  VSC_voltage_sourcet vSC_voltage_sourcet6 annotation(
    Placement(visible = true, transformation(origin = {-130, -112}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  VSC_voltage_sourcet vSC_voltage_sourcet8 annotation(
    Placement(visible = true, transformation(origin = {-130, -138}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  trafo_three_w trafo_three_w4 annotation(
    Placement(visible = true, transformation(origin = {-72, 66}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  trafo_three_w trafo_three_w1 annotation(
    Placement(visible = true, transformation(origin = {-74, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  trafo_three_w trafo_three_w2 annotation(
    Placement(visible = true, transformation(origin = {-74, -60}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  trafo_three_w trafo_three_w3 annotation(
    Placement(visible = true, transformation(origin = {-74, -126}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Interfaces.Plug p annotation(
    Placement(visible = true, transformation(origin = {-36, 4.44089e-16}, extent = {{-6, -4}, {6, 4}}, rotation = 0), iconTransformation(origin = {-36, -4}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {100, -36}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {100, -10}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.MultiPhase.Basic.Inductor inductor(L = fill(0.000076, 3))  annotation(
    Placement(visible = true, transformation(origin = {-6, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor resistor(R = fill(0.005, 3))  annotation(
    Placement(visible = true, transformation(origin = {20, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  vsc vsc1 annotation(
    Placement(visible = true, transformation(origin = {-130, 140}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.CombiTimeTable combiTimeTable(extrapolation = Modelica.Blocks.Types.Extrapolation.HoldLastPoint, smoothness = Modelica.Blocks.Types.Smoothness.ConstantSegments, table = [0, -300000; 0.3, -150000; 0.5, 0; 0.8, 400000; 0.9, -200000]) annotation(
    Placement(visible = true, transformation(origin = {-172, 78}, extent = {{10, -10}, {-10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.CombiTimeTable combiTimeTable1(extrapolation = Modelica.Blocks.Types.Extrapolation.HoldLastPoint, smoothness = Modelica.Blocks.Types.Smoothness.ConstantSegments, table = [0, 0; 0.3, 500000; 0.5, -100000; 0.8, -400000; 0.9, -400000]) annotation(
    Placement(visible = true, transformation(origin = {-172, 106}, extent = {{10, -10}, {-10, 10}}, rotation = 0)));
  vsc vsc2 annotation(
    Placement(visible = true, transformation(origin = {-130, 112}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(trafo_three_w7.out3, p) annotation(
    Line(points = {{-64, 128}, {-36, 128}, {-36, 0}}, color = {0, 0, 255}));
  connect(trafo_three_w4.out3, p) annotation(
    Line(points = {{-62, 66}, {-36, 66}, {-36, 0}}, color = {0, 0, 255}));
  connect(trafo_three_w1.out3, p) annotation(
    Line(points = {{-64, 0}, {-36, 0}}, color = {0, 0, 255}));
  connect(trafo_three_w2.out3, p) annotation(
    Line(points = {{-64, -60}, {-36, -60}, {-36, 0}}, color = {0, 0, 255}));
  connect(trafo_three_w3.out3, p) annotation(
    Line(points = {{-64, -126}, {-36, -126}, {-36, 0}}, color = {0, 0, 255}));
  connect(trafo_three_w4.in2, vSC_voltage_sourcet.plug) annotation(
    Line(points = {{-82, 64}, {-94, 64}, {-94, 55}, {-141, 55}}, color = {0, 0, 255}));
  connect(trafo_three_w4.in1, vSC_voltage_sourcet1.plug) annotation(
    Line(points = {{-82, 68}, {-94, 68}, {-94, 84}, {-140, 84}, {-140, 82}}, color = {0, 0, 255}));
  connect(trafo_three_w1.in1, vSC_voltage_sourcet2.plug) annotation(
    Line(points = {{-84, 2}, {-140, 2}, {-140, 18}, {-140, 18}}));
  connect(trafo_three_w1.in2, vSC_voltage_sourcet4.plug) annotation(
    Line(points = {{-84, -2}, {-140, -2}, {-140, -8}, {-140, -8}}, color = {0, 0, 255}));
  connect(trafo_three_w2.in1, vSC_voltage_sourcet3.plug) annotation(
    Line(points = {{-84, -58}, {-140, -58}, {-140, -46}, {-140, -46}}, color = {0, 0, 255}));
  connect(trafo_three_w2.in2, vSC_voltage_sourcet5.plug) annotation(
    Line(points = {{-84, -62}, {-140, -62}, {-140, -70}, {-140, -70}}, color = {0, 0, 255}));
  connect(trafo_three_w3.in1, vSC_voltage_sourcet6.plug) annotation(
    Line(points = {{-84, -124}, {-140, -124}, {-140, -108}, {-140, -108}}, color = {0, 0, 255}));
  connect(trafo_three_w3.in2, vSC_voltage_sourcet8.plug) annotation(
    Line(points = {{-84, -128}, {-140, -128}, {-140, -134}, {-140, -134}}, color = {0, 0, 255}));
  connect(sineVoltage2.plug_n, star.plug_p) annotation(
    Line(points = {{72, 0}, {100, 0}, {100, 0}, {100, 0}}, color = {0, 0, 255}));
  connect(star.pin_n, ground.p) annotation(
    Line(points = {{100, -20}, {100, -20}, {100, -26}, {100, -26}, {100, -26}}, color = {0, 0, 255}));
  connect(resistor.plug_n, sineVoltage2.plug_p) annotation(
    Line(points = {{30, 0}, {52, 0}, {52, 0}, {52, 0}}, color = {0, 0, 255}));
  connect(resistor.plug_p, inductor.plug_n) annotation(
    Line(points = {{10, 0}, {4, 0}, {4, 0}, {4, 0}}, color = {0, 0, 255}));
  connect(inductor.plug_p, p) annotation(
    Line(points = {{-16, 0}, {-36, 0}}, color = {0, 0, 255}));
  connect(vsc1.plv, trafo_three_w7.in1) annotation(
    Line(points = {{-118, 140}, {-84, 140}, {-84, 130}, {-84, 130}}));
  connect(vsc1.qref, combiTimeTable.y[1]) annotation(
    Line(points = {{-142, 146}, {-194, 146}, {-194, 78}, {-182, 78}, {-182, 78}}, color = {0, 0, 127}));
  connect(vsc1.pref, combiTimeTable1.y[1]) annotation(
    Line(points = {{-142, 134}, {-190, 134}, {-190, 106}, {-182, 106}, {-182, 106}}, color = {0, 0, 127}));
  connect(vsc2.plv, trafo_three_w7.in2) annotation(
    Line(points = {{-118, 112}, {-92, 112}, {-92, 126}, {-84, 126}, {-84, 126}}));
  connect(combiTimeTable1.y[1], vsc2.pref) annotation(
    Line(points = {{-182, 106}, {-184, 106}, {-184, 104}, {-142, 104}, {-142, 106}}, color = {0, 0, 127}));
  connect(combiTimeTable.y[1], vsc2.qref) annotation(
    Line(points = {{-182, 78}, {-174, 78}, {-174, 118}, {-142, 118}, {-142, 118}}, color = {0, 0, 127}));
  annotation(
    uses(Modelica(version = "3.2.3")),
    Diagram(graphics = {Rectangle(origin = {-38, 12}, fillPattern = FillPattern.Solid, extent = {{-2, 120}, {2, -140}}), Rectangle(extent = {{-40, 118}, {-40, 118}})}, coordinateSystem(initialScale = 0.1)));
end testnewtrafo9;
