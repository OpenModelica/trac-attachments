model Outer_Control
  QRef_Computation qRef_Computations annotation(
    Placement(visible = true, transformation(origin = {-14, -34}, extent = {{-16, -16}, {16, 16}}, rotation = 0)));
  dc_control dc_controlg annotation(
    Placement(visible = true, transformation(origin = {-14, 32}, extent = {{-16, -16}, {16, 16}}, rotation = 0)));
  Modelica.Blocks.Nonlinear.Limiter limiter(homotopyType = Modelica.Blocks.Types.LimiterHomotopy.NoHomotopy, limitsAtInit = true, uMax = 1200, uMin = 800)  annotation(
    Placement(visible = true, transformation(origin = {-62, 66}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput vdcmeas annotation(
    Placement(visible = true, transformation(origin = {-104, 26}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, 28}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Vmppt annotation(
    Placement(visible = true, transformation(origin = {-106, 66}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, 80}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Vzq annotation(
    Placement(visible = true, transformation(origin = {-104, -24}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, -28}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput qref annotation(
    Placement(visible = true, transformation(origin = {-104, -66}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, -80}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput iqref annotation(
    Placement(visible = true, transformation(origin = {100, 32}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {120, 40}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput idref annotation(
    Placement(visible = true, transformation(origin = {100, -34}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {120, -40}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
equation
  connect(limiter.y, dc_controlg.vmppt) annotation(
    Line(points = {{-51, 66}, {-47.5, 66}, {-47.5, 38}, {-33, 38}}, color = {0, 0, 127}));
  connect(vdcmeas, dc_controlg.vdcmeas) annotation(
    Line(points = {{-104, 26}, {-34, 26}}, color = {0, 0, 127}));
  connect(Vmppt, limiter.u) annotation(
    Line(points = {{-106, 66}, {-74, 66}, {-74, 66}, {-74, 66}}, color = {0, 0, 127}));
  connect(Vzq, qRef_Computations.Vzq) annotation(
    Line(points = {{-104, -24}, {-34, -24}, {-34, -24}, {-34, -24}}, color = {0, 0, 127}));
  connect(qref, qRef_Computations.Qref) annotation(
    Line(points = {{-104, -66}, {-60, -66}, {-60, -44}, {-34, -44}, {-34, -44}}, color = {0, 0, 127}));
  connect(dc_controlg.y, iqref) annotation(
    Line(points = {{4, 32}, {100, 32}}, color = {0, 0, 127}));
  connect(qRef_Computations.idref, idref) annotation(
    Line(points = {{4, -34}, {100, -34}}, color = {0, 0, 127}));

annotation(
    uses(Modelica(version = "3.2.3")));
end Outer_Control;
