block P_a_I
  extends Modelica.Blocks.Interfaces.SI2SO;
  parameter Real eps = 0.001;
equation
  
  y = if noEvent(abs(u2)>0) then 2*u1/(3*u2) else 11.78;
annotation(
    Icon(graphics = {Text(origin = {-3, 5}, extent = {{-49, 33}, {49, -33}}, textString = "2/3vq")}));
end P_a_I;
