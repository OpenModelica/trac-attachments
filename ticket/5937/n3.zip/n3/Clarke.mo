block Clarke
  Modelica.Blocks.Interfaces.RealInput a annotation(
    Placement(visible = true, transformation(origin = {-102, 60}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-102, 60}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput b annotation(
    Placement(visible = true, transformation(origin = {-102, 0}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-102, 0}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput c annotation(
    Placement(visible = true, transformation(origin = {-102, -60}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-102, -60}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput alfa annotation(
    Placement(visible = true, transformation(origin = {110, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput beta annotation(
    Placement(visible = true, transformation(origin = {110, -40}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, -40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  alfa = 2 / 3 * (a - 0.5 * b - 0.5 * c);
  beta = 2 / 3 * ((-sqrt(3) / 2 * b) + sqrt(3) / 2 * c);
  annotation(
    uses(Modelica(version = "3.2.3")),
    Diagram,
    Icon(graphics = {Rectangle(origin = {5, -3}, extent = {{-77, 75}, {77, -75}}), Text(origin = {11, 0}, extent = {{-69, 32}, {55, -20}}, textString = "Clarke")}, coordinateSystem(initialScale = 0.1)));
end Clarke;
