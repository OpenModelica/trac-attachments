model inner_control_pllm2
  Modelica.Blocks.Interfaces.RealInput va annotation(
    Placement(visible = true, transformation(origin = {-120, 106}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-112, 98}, extent = {{-12, -12}, {12, 12}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput vb annotation(
    Placement(visible = true, transformation(origin = {-120, 76}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-113, 61}, extent = {{-13, -13}, {13, 13}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput vc annotation(
    Placement(visible = true, transformation(origin = {-120, 48}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-113, 21}, extent = {{-13, -13}, {13, 13}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput ia annotation(
    Placement(visible = true, transformation(origin = {-120, 16}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-113, -21}, extent = {{-13, -13}, {13, 13}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput ib annotation(
    Placement(visible = true, transformation(origin = {-120, -12}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-113, -57}, extent = {{-13, -13}, {13, 13}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput ic annotation(
    Placement(visible = true, transformation(origin = {-120, -40}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-114, -92}, extent = {{-12, -12}, {12, 12}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput theta annotation(
    Placement(visible = true, transformation(origin = {110, 36}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, 36}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput Vzq annotation(
    Placement(visible = true, transformation(origin = {110, 82}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, 82}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Park parkI annotation(
    Placement(visible = true, transformation(origin = {-64, -12}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Park ParkV annotation(
    Placement(visible = true, transformation(origin = {-18, 32}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  AntiPark antiPark annotation(
    Placement(visible = true, transformation(origin = {82, -60}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput Varef annotation(
    Placement(visible = true, transformation(origin = {118, -22}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, -18}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput Vbref annotation(
    Placement(visible = true, transformation(origin = {118, -60}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, -50}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput Vcref annotation(
    Placement(visible = true, transformation(origin = {116, -100}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, -82}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  PLL2 pll2 annotation(
    Placement(visible = true, transformation(origin = {0, 76}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Vzqmod vzqmod annotation(
    Placement(visible = true, transformation(origin = {70, 82}, extent = {{-6, -6}, {6, 6}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput idref annotation(
    Placement(visible = true, transformation(origin = {-120, -100}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-60,-120}, extent = {{-20, -20}, {20, 20}}, rotation = 90)));
  Modelica.Blocks.Interfaces.RealInput iqref annotation(
    Placement(visible = true, transformation(origin = {-120, -70}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {60,-120}, extent = {{-20, -20}, {20, 20}}, rotation = 90)));
  Inner_Current_Controller2 inner_Current_Controller2 annotation(
    Placement(visible = true, transformation(origin = {10, -72}, extent = {{-32, -32}, {32, 32}}, rotation = 0)));
equation
  connect(ia, parkI.a) annotation(
    Line(points = {{-120, 16}, {-88, 16}, {-88, -8}, {-75, -8}}, color = {0, 0, 127}));
  connect(ib, parkI.b) annotation(
    Line(points = {{-120, -12}, {-75, -12}}, color = {0, 0, 127}));
  connect(ic, parkI.c) annotation(
    Line(points = {{-120, -40}, {-84, -40}, {-84, -16}, {-75, -16}}, color = {0, 0, 127}));
  connect(va, ParkV.a) annotation(
    Line(points = {{-120, 106}, {-56, 106}, {-56, 36}, {-30, 36}, {-30, 36}}, color = {0, 0, 127}));
  connect(vb, ParkV.b) annotation(
    Line(points = {{-120, 76}, {-64, 76}, {-64, 32}, {-30, 32}, {-30, 32}}, color = {0, 0, 127}));
  connect(vc, ParkV.c) annotation(
    Line(points = {{-120, 48}, {-72, 48}, {-72, 28}, {-30, 28}, {-30, 28}}, color = {0, 0, 127}));
  connect(antiPark.b, Vbref) annotation(
    Line(points = {{94, -60}, {114, -60}, {114, -60}, {118, -60}}, color = {0, 0, 127}));
  connect(antiPark.a, Varef) annotation(
    Line(points = {{94, -56}, {104, -56}, {104, -22}, {118, -22}, {118, -22}}, color = {0, 0, 127}));
  connect(antiPark.c, Vcref) annotation(
    Line(points = {{94, -64}, {104, -64}, {104, -100}, {116, -100}, {116, -100}}, color = {0, 0, 127}));
  connect(va, pll2.Va_grid) annotation(
    Line(points = {{-120, 106}, {-56, 106}, {-56, 82}, {-12, 82}, {-12, 82}}, color = {0, 0, 127}));
  connect(pll2.Vb_grid, vb) annotation(
    Line(points = {{-12, 76}, {-104, 76}, {-104, 76}, {-120, 76}}, color = {0, 0, 127}));
  connect(vc, pll2.Vc_grid) annotation(
    Line(points = {{-120, 48}, {-56, 48}, {-56, 70}, {-12, 70}, {-12, 70}}, color = {0, 0, 127}));
  connect(pll2.theta, ParkV.theta) annotation(
    Line(points = {{12, 72}, {24, 72}, {24, 10}, {-18, 10}, {-18, 20}, {-18, 20}}, color = {0, 0, 127}));
  connect(pll2.theta, parkI.theta) annotation(
    Line(points = {{12, 72}, {24, 72}, {24, -14}, {-46, -14}, {-46, -24}, {-64, -24}, {-64, -24}}, color = {0, 0, 127}));
  connect(pll2.theta, antiPark.theta) annotation(
    Line(points = {{12, 72}, {58, 72}, {58, -78}, {82, -78}, {82, -72}, {82, -72}}, color = {0, 0, 127}));
  connect(pll2.Vzq, vzqmod.u) annotation(
    Line(points = {{12, 82}, {60, 82}, {60, 82}, {62, 82}, {62, 82}}, color = {0, 0, 127}));
  connect(vzqmod.y, Vzq) annotation(
    Line(points = {{76, 82}, {100, 82}, {100, 82}, {110, 82}}, color = {0, 0, 127}));
  connect(pll2.theta, theta) annotation(
    Line(points = {{12, 72}, {72, 72}, {72, 38}, {110, 38}, {110, 36}}, color = {0, 0, 127}));
  connect(inner_Current_Controller2.iqref, iqref) annotation(
    Line(points = {{-28, -45}, {-78, -45}, {-78, -70}, {-120, -70}}, color = {0, 0, 127}));
  connect(inner_Current_Controller2.idref, idref) annotation(
    Line(points = {{-28, -100}, {-120, -100}}, color = {0, 0, 127}));
  connect(inner_Current_Controller2.vlq, antiPark.q) annotation(
    Line(points = {{46, -44}, {64, -44}, {64, -56}, {70, -56}, {70, -56}}, color = {0, 0, 127}));
  connect(inner_Current_Controller2.vld, antiPark.d) annotation(
    Line(points = {{46, -96}, {66, -96}, {66, -64}, {70, -64}, {70, -64}}, color = {0, 0, 127}));
  connect(inner_Current_Controller2.vzq, ParkV.q) annotation(
    Line(points = {{20, -34}, {18, -34}, {18, 34}, {-6, 34}, {-6, 36}}, color = {0, 0, 127}));
  connect(inner_Current_Controller2.iq, parkI.q) annotation(
    Line(points = {{-28, -62}, {-42, -62}, {-42, -10}, {-52, -10}, {-52, -8}}, color = {0, 0, 127}));
  connect(inner_Current_Controller2.id, parkI.d) annotation(
    Line(points = {{-28, -78}, {-48, -78}, {-48, -14}, {-52, -14}, {-52, -14}}, color = {0, 0, 127}));
protected
  annotation(
    uses(Modelica(version = "3.2.3")),
    Icon);
end inner_control_pllm2;
