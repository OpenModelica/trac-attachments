block DC_ControltoP
  Modelica.Blocks.Math.Feedback feedback annotation(
    Placement(visible = true, transformation(origin = {-86, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput E2_ref annotation(
    Placement(visible = true, transformation(origin = {-142, 0}, extent = {{-14, -14}, {14, 14}}, rotation = 0), iconTransformation(origin = {-86, 0}, extent = {{-14, -14}, {14, 14}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput E2_dcsource annotation(
    Placement(visible = true, transformation(origin = {-86, -82}, extent = {{-20, -20}, {20, 20}}, rotation = 90), iconTransformation(origin = {-40, -82}, extent = {{-14, -14}, {14, 14}}, rotation = 90)));
  Modelica.Blocks.Math.Add add(k1 = +1)  annotation(
    Placement(visible = true, transformation(origin = {42, 6}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Pdc "Power available from source, mesured before the capacitor" annotation(
    Placement(visible = true, transformation(origin = {8, 78}, extent = {{-20, -20}, {20, 20}}, rotation = -90), iconTransformation(origin = {43, 81}, extent = {{-13, -13}, {13, 13}}, rotation = -90)));
  Modelica.Blocks.Interfaces.RealOutput Pref annotation(
    Placement(visible = true, transformation(origin = {120, 6}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {88, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Gain gain(k = 0.051)  annotation(
    Placement(visible = true, transformation(origin = {-50, 6}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  E2 e2 annotation(
    Placement(visible = true, transformation(origin = {-112, 4.44089e-16}, extent = {{-6, -6}, {6, 6}}, rotation = 180)));
  E2 e21 annotation(
    Placement(visible = true, transformation(origin = {-86, -34}, extent = {{-6, -6}, {6, 6}}, rotation = -90)));
equation
  connect(Pdc, add.u1) annotation(
    Line(points = {{8, 78}, {8, 12}, {30, 12}}, color = {0, 0, 127}));
  connect(feedback.y, gain.u) annotation(
    Line(points = {{-76, 0}, {-70, 0}, {-70, 6}, {-62, 6}}, color = {0, 0, 127}));
  connect(e2.y, feedback.u1) annotation(
    Line(points = {{-106, 0}, {-96, 0}, {-96, 0}, {-94, 0}}, color = {0, 0, 127}));
  connect(e2.u, E2_ref) annotation(
    Line(points = {{-120, 0}, {-132, 0}, {-132, 0}, {-142, 0}}, color = {0, 0, 127}));
  connect(e21.y, feedback.u2) annotation(
    Line(points = {{-86, -28}, {-86, -28}, {-86, -8}, {-86, -8}}, color = {0, 0, 127}));
  connect(e21.u, E2_dcsource) annotation(
    Line(points = {{-86, -42}, {-86, -42}, {-86, -82}, {-86, -82}}, color = {0, 0, 127}));
  connect(add.y, Pref) annotation(
    Line(points = {{54, 6}, {114, 6}, {114, 6}, {120, 6}}, color = {0, 0, 127}));
  connect(gain.y, add.u2) annotation(
    Line(points = {{-38, 6}, {-10, 6}, {-10, 0}, {30, 0}, {30, 0}}, color = {0, 0, 127}));
  annotation(
    uses(Modelica(version = "3.2.3")),
    Icon(graphics = {Rectangle(origin = {3, 0}, extent = {{-75, 68}, {75, -68}}), Text(origin = {4, 1}, extent = {{-52, 29}, {52, -29}}, textString = "DC V CONTROL")}, coordinateSystem(initialScale = 0.1)));
end DC_ControltoP;
