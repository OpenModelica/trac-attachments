model testnewtrafo2
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage2(V = fill(32600, 3), freqHz = fill(50, 3))  annotation(
    Placement(visible = true, transformation(origin = {64, 18}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {-72, -74}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {-72, -100}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  trafo6 trafo annotation(
    Placement(visible = true, transformation(origin = {-26, 16}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(ground.p, star.pin_n) annotation(
    Line(points = {{-72, -90}, {-72, -90}, {-72, -84}, {-72, -84}}, color = {0, 0, 255}));
  connect(star.plug_p, sineVoltage2.plug_n) annotation(
    Line(points = {{-72, -64}, {74, -64}, {74, 18}}, color = {0, 0, 255}));
  connect(trafo.O1, sineVoltage2.plug_p) annotation(
    Line(points = {{-16, 16}, {54, 16}, {54, 18}, {54, 18}}, color = {0, 0, 255}));
  connect(trafo.pin_n, star.pin_n) annotation(
    Line(points = {{-26, 6}, {-32, 6}, {-32, -84}, {-72, -84}, {-72, -84}}, color = {0, 0, 255}));
  annotation(
    uses(Modelica(version = "3.2.3")));
end testnewtrafo2;
