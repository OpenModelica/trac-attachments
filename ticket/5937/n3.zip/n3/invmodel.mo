model invmodel
  Modelica.Electrical.Analog.Interfaces.Pin D annotation(
    Placement(visible = true, transformation(origin = {-100, 80}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-100, 80}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Interfaces.NegativePin C annotation(
    Placement(visible = true, transformation(origin = {-100, -80}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-100, -80}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Sources.SignalCurrent idc annotation(
    Placement(visible = true, transformation(origin = {-80, -36}, extent = {{-10, 10}, {10, -10}}, rotation = 90)));
  Modelica.Electrical.Analog.Sensors.VoltageSensor Vdc annotation(
    Placement(visible = true, transformation(origin = {-60, 22}, extent = {{-10, -10}, {10, 10}}, rotation = 90)));
  Modelica.Blocks.Math.Product product annotation(
    Placement(visible = true, transformation(origin = {84, 50}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Blocks.Math.Product product1 annotation(
    Placement(visible = true, transformation(origin = {82, -56}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Blocks.Math.Add Pac(k1 = -1, k2 = +1)  annotation(
    Placement(visible = true, transformation(origin = {46, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Blocks.Math.Division division annotation(
    Placement(visible = true, transformation(origin = {-44, -36}, extent = {{-10, 10}, {10, -10}}, rotation = 180)));
  Modelica.Blocks.Math.Abs abs1 annotation(
    Placement(visible = true, transformation(origin = {-32, 22}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Basic.Ground ground1 annotation(
    Placement(visible = true, transformation(origin = {-100, -98}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Inductor inductor(L = fill(0.0054, 3))  annotation(
    Placement(visible = true, transformation(origin = {278, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Basic.Ground ground2 annotation(
    Placement(visible = true, transformation(origin = {350, -28}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {328, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage(V = fill(400, 3), freqHz = fill(50, 3), phase = {0, -2.0944, 2.0944})  annotation(
    Placement(visible = true, transformation(origin = {302, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Add add1 annotation(
    Placement(visible = true, transformation(origin = {2, 46}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.Constant const(k = 0.001)  annotation(
    Placement(visible = true, transformation(origin = {-38, 56}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Ia annotation(
    Placement(visible = true, transformation(origin = {120, 20}, extent = {{-20, -20}, {20, 20}}, rotation = 180), iconTransformation(origin = {41, -113}, extent = {{-13, -13}, {13, 13}}, rotation = 90)));
  Modelica.Blocks.Interfaces.RealInput Ic annotation(
    Placement(visible = true, transformation(origin = {120, -80}, extent = {{-20, -20}, {20, 20}}, rotation = 180), iconTransformation(origin = {-43, -113}, extent = {{-13, -13}, {13, 13}}, rotation = 90)));
  Modelica.Blocks.Interfaces.RealInput Vab annotation(
    Placement(visible = true, transformation(origin = {120, 80}, extent = {{-20, -20}, {20, 20}}, rotation = 180), iconTransformation(origin = {81, -113}, extent = {{-13, -13}, {13, 13}}, rotation = 90)));
  Modelica.Blocks.Interfaces.RealInput Vbc annotation(
    Placement(visible = true, transformation(origin = {120, -28}, extent = {{-20, -20}, {20, 20}}, rotation = 180), iconTransformation(origin = {-1, -113}, extent = {{-13, -13}, {13, 13}}, rotation = 90)));
  Modelica.Blocks.Math.Product Pdc annotation(
    Placement(visible = true, transformation(origin = {4, -88}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(idc.n, D) annotation(
    Line(points = {{-80, -26}, {-80, 80}, {-100, 80}}, color = {0, 0, 255}));
  connect(idc.p, C) annotation(
    Line(points = {{-80, -46}, {-80, -80}, {-100, -80}}, color = {0, 0, 255}));
  connect(D, Vdc.n) annotation(
    Line(points = {{-100, 80}, {-60, 80}, {-60, 32}, {-60, 32}}, color = {0, 0, 255}));
  connect(Vdc.p, C) annotation(
    Line(points = {{-60, 12}, {-60, 12}, {-60, -80}, {-100, -80}, {-100, -80}}, color = {0, 0, 255}));
  connect(Vdc.v, abs1.u) annotation(
    Line(points = {{-48, 22}, {-44, 22}}, color = {0, 0, 127}));
  connect(division.y, idc.i) annotation(
    Line(points = {{-55, -36}, {-68, -36}}, color = {0, 0, 127}));
  connect(ground1.p, C) annotation(
    Line(points = {{-100, -88}, {-100, -88}, {-100, -80}, {-100, -80}}, color = {0, 0, 255}));
  connect(star.pin_n, ground2.p) annotation(
    Line(points = {{338, 0}, {350, 0}, {350, -18}}, color = {0, 0, 255}));
  connect(sineVoltage.plug_p, inductor.plug_n) annotation(
    Line(points = {{292, 0}, {288, 0}}, color = {0, 0, 255}));
  connect(sineVoltage.plug_n, star.plug_p) annotation(
    Line(points = {{312, 0}, {318, 0}}, color = {0, 0, 255}));
  connect(product.y, Pac.u2) annotation(
    Line(points = {{73, 50}, {64, 50}, {64, 6}, {58, 6}}, color = {0, 0, 127}));
  connect(product1.y, Pac.u1) annotation(
    Line(points = {{71, -56}, {64, -56}, {64, -6}, {58, -6}}, color = {0, 0, 127}));
  connect(add1.u1, const.y) annotation(
    Line(points = {{-10, 52}, {-20, 52}, {-20, 56}, {-26, 56}}, color = {0, 0, 127}));
  connect(add1.u2, abs1.y) annotation(
    Line(points = {{-10, 40}, {-16, 40}, {-16, 22}, {-20, 22}, {-20, 22}}, color = {0, 0, 127}));
  connect(add1.y, division.u2) annotation(
    Line(points = {{14, 46}, {22, 46}, {22, -42}, {-32, -42}, {-32, -42}}, color = {0, 0, 127}));
  connect(Pac.y, division.u1) annotation(
    Line(points = {{36, 0}, {8, 0}, {8, -30}, {-32, -30}, {-32, -30}}, color = {0, 0, 127}));
  connect(Vab, product.u2) annotation(
    Line(points = {{120, 80}, {100, 80}, {100, 56}, {96, 56}, {96, 56}, {96, 56}}, color = {0, 0, 127}));
  connect(Ia, product.u1) annotation(
    Line(points = {{120, 20}, {100, 20}, {100, 42}, {96, 42}, {96, 44}}, color = {0, 0, 127}));
  connect(Vbc, product1.u2) annotation(
    Line(points = {{120, -28}, {98, -28}, {98, -50}, {94, -50}, {94, -50}}, color = {0, 0, 127}));
  connect(Ic, product1.u1) annotation(
    Line(points = {{120, -80}, {98, -80}, {98, -62}, {94, -62}, {94, -62}}, color = {0, 0, 127}));
  connect(idc.i, Pdc.u2) annotation(
    Line(points = {{-68, -36}, {-60, -36}, {-60, -94}, {-8, -94}, {-8, -94}}, color = {0, 0, 127}));
  connect(add1.y, Pdc.u1) annotation(
    Line(points = {{14, 46}, {22, 46}, {22, -68}, {-20, -68}, {-20, -82}, {-8, -82}, {-8, -82}}, color = {0, 0, 127}));
  annotation(
    uses(Modelica(version = "3.2.3")));
end invmodel;
