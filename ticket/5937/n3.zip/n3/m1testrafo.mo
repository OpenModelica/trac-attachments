model m1testrafo
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {-100, 42}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Sources.SignalVoltage Vca annotation(
    Placement(visible = true, transformation(origin = {-74, 70}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Electrical.Analog.Sources.SignalVoltage Vcb annotation(
    Placement(visible = true, transformation(origin = {-60, 52}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Electrical.Analog.Sources.SignalVoltage Vcc annotation(
    Placement(visible = true, transformation(origin = {-46, 34}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Electrical.MultiPhase.Basic.PlugToPins_p pp annotation(
    Placement(visible = true, transformation(origin = {-16, 52}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Electrical.MultiPhase.Basic.Resistor Rc(R = fill(0.5, 3))  annotation(
    Placement(visible = true, transformation(origin = {14, 52}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Inductor Lc(L = fill(0.0054, 3))  annotation(
    Placement(visible = true, transformation(origin = {46, 52}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.PotentialSensor PPCC annotation(
    Placement(visible = true, transformation(origin = {64, 30}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.MultiPhase.Sensors.CurrentSensor Cs annotation(
    Placement(visible = true, transformation(origin = {90, 52}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  inner_control_pllm3 inner_control_pllm annotation(
    Placement(visible = true, transformation(origin = {39, -45}, extent = {{-15, -15}, {15, 15}}, rotation = 0)));
  inverterMod inverterModd annotation(
    Placement(visible = true, transformation(origin = {-60, -22}, extent = {{-10, -10}, {10, 10}}, rotation = 90)));
  Modelica.Blocks.Sources.RealExpression va(y = inner_control_pllm.va)  annotation(
    Placement(visible = true, transformation(origin = {204, -40}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Blocks.Sources.RealExpression vb(y = inner_control_pllm.vb)  annotation(
    Placement(visible = true, transformation(origin = {204, -54}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Blocks.Sources.RealExpression vc(y = inner_control_pllm.vc)  annotation(
    Placement(visible = true, transformation(origin = {204, -70}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Blocks.Sources.RealExpression ia(y = inner_control_pllm.ia)  annotation(
    Placement(visible = true, transformation(origin = {204, -90}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Blocks.Sources.RealExpression ib(y = inner_control_pllm.ib)  annotation(
    Placement(visible = true, transformation(origin = {204, -104}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Blocks.Sources.RealExpression ic(y = inner_control_pllm.ic)  annotation(
    Placement(visible = true, transformation(origin = {204, -118}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Blocks.Sources.RealExpression theta1(y = inner_control_pllm.theta)  annotation(
    Placement(visible = true, transformation(origin = {156, -36}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Pac_Qac_Calculation pac_Qac_Calculation annotation(
    Placement(visible = true, transformation(origin = {156, -80}, extent = {{-14, -14}, {14, 14}}, rotation = -90)));
  Ref_Computation ref_Computation annotation(
    Placement(visible = true, transformation(origin = {-10, -120}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Sensors.CurrentSensor iameas annotation(
    Placement(visible = true, transformation(origin = {-56, 70}, extent = {{-6, -6}, {6, 6}}, rotation = 0)));
  Modelica.Electrical.Analog.Sensors.CurrentSensor icmeas annotation(
    Placement(visible = true, transformation(origin = {-26, 34}, extent = {{-6, -6}, {6, 6}}, rotation = 0)));
  Modelica.Electrical.Analog.Sensors.VoltageSensor vab annotation(
    Placement(visible = true, transformation(origin = {-36, 62}, extent = {{-6, -6}, {6, 6}}, rotation = -90)));
  Modelica.Electrical.Analog.Sensors.VoltageSensor vbc annotation(
    Placement(visible = true, transformation(origin = {-36, 46}, extent = {{-6, -6}, {6, 6}}, rotation = -90)));
  invmodel Average annotation(
    Placement(visible = true, transformation(origin = {-136, 52}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.RealExpression Ia(y = iameas.i)  annotation(
    Placement(visible = true, transformation(origin = {-170, 4}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.RealExpression Ic(y = icmeas.i)  annotation(
    Placement(visible = true, transformation(origin = {-170, 32}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.RealExpression Vab(y = vab.v)  annotation(
    Placement(visible = true, transformation(origin = {-170, -10}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.RealExpression Vbc(y = vbc.v)  annotation(
    Placement(visible = true, transformation(origin = {-170, 18}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Basic.Capacitor C(C = 0.001020)  annotation(
    Placement(visible = true, transformation(origin = {-158, 52}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Blocks.Sources.RealExpression vzq(y = inner_control_pllm.Vzq) annotation(
    Placement(visible = true, transformation(origin = {-58, -112}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Sources.ConstantVoltage constantVoltage(V = 800)  annotation(
    Placement(visible = true, transformation(origin = {-186, 52}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Blocks.Sources.RealExpression Udc(y = 800) annotation(
    Placement(visible = true, transformation(origin = {-82, -76}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage1(V = fill(3260, 3), freqHz = fill(50, 3)) annotation(
    Placement(visible = true, transformation(origin = {188, 56}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Basic.Ground ground1 annotation(
    Placement(visible = true, transformation(origin = {218, -4}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {218, 26}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Blocks.Sources.CombiTimeTable PRef(extrapolation = Modelica.Blocks.Types.Extrapolation.HoldLastPoint, smoothness = Modelica.Blocks.Types.Smoothness.ConstantSegments, table = [0, -3000; 0.3, -6000; 0.5, -1000; 0.8, -7000]) annotation(
    Placement(visible = true, transformation(origin = {-126, -108}, extent = {{10, -10}, {-10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.CombiTimeTable QRref(extrapolation = Modelica.Blocks.Types.Extrapolation.HoldLastPoint, smoothness = Modelica.Blocks.Types.Smoothness.ConstantSegments, table = [0, 0; 0.3, -5000; 0.5, 0; 0.8, 2000; 0.9, -7000]) annotation(
    Placement(visible = true, transformation(origin = {-126, -136}, extent = {{10, -10}, {-10, 10}}, rotation = 0)));
  Modelica.Electrical.Machines.BasicMachines.Transformers.Dy.Dy03 transformer(L1sigma = 0.003, L2sigma = 0.003, R1 = 0.05, R2 = 0.05, n = 0.1)  annotation(
    Placement(visible = true, transformation(origin = {136, 52}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.PowerSensor powerSensor annotation(
    Placement(visible = true, transformation(origin = {110, 70}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.PowerSensor powerSensor1 annotation(
    Placement(visible = true, transformation(origin = {162, 68}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(Vca.n, ground.p) annotation(
    Line(points = {{-84, 70}, {-100, 70}, {-100, 52}}, color = {0, 0, 255}));
  connect(Vcb.n, ground.p) annotation(
    Line(points = {{-70, 52}, {-100, 52}}, color = {0, 0, 255}));
  connect(Vcb.p, pp.pin_p[2]) annotation(
    Line(points = {{-50, 52}, {-18, 52}}, color = {0, 0, 255}));
  connect(pp.plug_p, Rc.plug_p) annotation(
    Line(points = {{-14, 52}, {4, 52}}, color = {0, 0, 255}));
  connect(Rc.plug_n, Lc.plug_p) annotation(
    Line(points = {{24, 52}, {36, 52}}, color = {0, 0, 255}));
  connect(ground.p, Vcc.n) annotation(
    Line(points = {{-100, 52}, {-100, 34}, {-56, 34}}, color = {0, 0, 255}));
  connect(PPCC.phi[1], inner_control_pllm.va) annotation(
    Line(points = {{64, 18}, {64, 18}, {64, -32}, {56, -32}, {56, -32}}, color = {0, 0, 127}));
  connect(PPCC.phi[2], inner_control_pllm.vb) annotation(
    Line(points = {{64, 18}, {64, 18}, {64, -36}, {56, -36}, {56, -36}}, color = {0, 0, 127}));
  connect(Cs.i[1], inner_control_pllm.ia) annotation(
    Line(points = {{90, 41}, {90, -48}, {56, -48}, {56, -50}}, color = {0, 0, 127}));
  connect(Cs.i[2], inner_control_pllm.ib) annotation(
    Line(points = {{90, 41}, {90, -54}, {56, -54}}, color = {0, 0, 127}));
  connect(inner_control_pllm.ic, Cs.i[3]) annotation(
    Line(points = {{56, -60}, {90, -60}, {90, 41}}, color = {0, 0, 127}));
  connect(inner_control_pllm.vc, PPCC.phi[3]) annotation(
    Line(points = {{56, -42}, {64, -42}, {64, 18}, {64, 18}}, color = {0, 0, 127}));
  connect(PPCC.plug_p, Lc.plug_n) annotation(
    Line(points = {{64, 40}, {64, 40}, {64, 52}, {56, 52}, {56, 52}}, color = {0, 0, 255}));
  connect(Vcb.v, inverterModd.vb) annotation(
    Line(points = {{-60, 40}, {-60, -11}}, color = {0, 0, 127}));
  connect(inverterModd.va, Vca.v) annotation(
    Line(points = {{-65, -11}, {-65, 18}, {-74, 18}, {-74, 58}}, color = {0, 0, 127}));
  connect(inverterModd.vc, Vcc.v) annotation(
    Line(points = {{-55, -11}, {-55, 18}, {-46, 18}, {-46, 22}}, color = {0, 0, 127}));
  connect(inverterModd.theta, inner_control_pllm.theta) annotation(
    Line(points = {{-48, -22}, {-13, -22}, {-13, -40}, {22, -40}}, color = {0, 0, 127}));
  connect(inner_control_pllm.vd, inverterModd.vdref) annotation(
    Line(points = {{22, -56}, {-54, -56}, {-54, -34}}, color = {0, 0, 127}));
  connect(inner_control_pllm.vq, inverterModd.vqref) annotation(
    Line(points = {{22, -50}, {-66, -50}, {-66, -34}}, color = {0, 0, 127}));
  connect(theta1.y, pac_Qac_Calculation.theta) annotation(
    Line(points = {{156, -46}, {156, -63}}, color = {0, 0, 127}));
  connect(va.y, pac_Qac_Calculation.Va_grid) annotation(
    Line(points = {{194, -40}, {182, -40}, {182, -68}, {172, -68}, {172, -68}}, color = {0, 0, 127}));
  connect(vb.y, pac_Qac_Calculation.Vb_grid) annotation(
    Line(points = {{194, -54}, {184, -54}, {184, -72}, {172, -72}, {172, -72}}, color = {0, 0, 127}));
  connect(pac_Qac_Calculation.Vc_grid, vc.y) annotation(
    Line(points = {{172, -76}, {186, -76}, {186, -70}, {194, -70}, {194, -70}, {194, -70}}, color = {0, 0, 127}));
  connect(ia.y, pac_Qac_Calculation.Ia_grid) annotation(
    Line(points = {{194, -90}, {186, -90}, {186, -82}, {172, -82}, {172, -82}}, color = {0, 0, 127}));
  connect(ib.y, pac_Qac_Calculation.Ib_grid) annotation(
    Line(points = {{194, -104}, {184, -104}, {184, -86}, {172, -86}, {172, -88}}, color = {0, 0, 127}));
  connect(pac_Qac_Calculation.Ic_grid, ic.y) annotation(
    Line(points = {{172, -92}, {182, -92}, {182, -118}, {194, -118}, {194, -118}}, color = {0, 0, 127}));
  connect(ref_Computation.idref, inner_control_pllm.idref) annotation(
    Line(points = {{1, -116}, {46, -116}, {46, -62}, {48, -62}}, color = {0, 0, 127}));
  connect(ref_Computation.iqref, inner_control_pllm.iqref) annotation(
    Line(points = {{1, -124}, {30, -124}, {30, -62}}, color = {0, 0, 127}));
  connect(Vca.p, vab.p) annotation(
    Line(points = {{-64, 70}, {-36, 70}, {-36, 68}}, color = {0, 0, 255}));
  connect(vab.n, Vcb.p) annotation(
    Line(points = {{-36, 56}, {-36, 52}, {-50, 52}}, color = {0, 0, 255}));
  connect(Vcb.p, vbc.p) annotation(
    Line(points = {{-50, 52}, {-36, 52}}, color = {0, 0, 255}));
  connect(vbc.n, Vcc.p) annotation(
    Line(points = {{-36, 40}, {-36, 34}}, color = {0, 0, 255}));
  connect(Vca.p, iameas.p) annotation(
    Line(points = {{-64, 70}, {-62, 70}}, color = {0, 0, 255}));
  connect(iameas.n, pp.pin_p[1]) annotation(
    Line(points = {{-50, 70}, {-18, 70}, {-18, 52}, {-18, 52}, {-18, 52}}, color = {0, 0, 255}));
  connect(pp.pin_p[3], icmeas.n) annotation(
    Line(points = {{-18, 52}, {-18, 52}, {-18, 34}, {-20, 34}, {-20, 34}}, color = {0, 0, 255}));
  connect(icmeas.p, Vcc.p) annotation(
    Line(points = {{-32, 34}, {-36, 34}, {-36, 34}, {-36, 34}}, color = {0, 0, 255}));
  connect(Ic.y, Average.Ic) annotation(
    Line(points = {{-159, 32}, {-140, 32}, {-140, 41}}, color = {0, 0, 127}));
  connect(Vbc.y, Average.Vbc) annotation(
    Line(points = {{-159, 18}, {-136, 18}, {-136, 41}}, color = {0, 0, 127}));
  connect(Ia.y, Average.Ia) annotation(
    Line(points = {{-159, 4}, {-132, 4}, {-132, 41}}, color = {0, 0, 127}));
  connect(Vab.y, Average.Vab) annotation(
    Line(points = {{-159, -10}, {-128, -10}, {-128, 41}}, color = {0, 0, 127}));
  connect(C.p, Average.D) annotation(
    Line(points = {{-158, 62}, {-146, 62}, {-146, 60}, {-146, 60}}, color = {0, 0, 255}));
  connect(C.n, Average.C) annotation(
    Line(points = {{-158, 42}, {-146, 42}, {-146, 44}, {-146, 44}}, color = {0, 0, 255}));
  connect(vzq.y, ref_Computation.Vzq) annotation(
    Line(points = {{-46, -112}, {-22, -112}}, color = {0, 0, 127}));
  connect(Lc.plug_n, Cs.plug_p) annotation(
    Line(points = {{56, 52}, {80, 52}}, color = {0, 0, 255}));
  connect(constantVoltage.p, C.p) annotation(
    Line(points = {{-186, 62}, {-158, 62}, {-158, 62}, {-158, 62}}, color = {0, 0, 255}));
  connect(C.n, constantVoltage.n) annotation(
    Line(points = {{-158, 42}, {-186, 42}, {-186, 42}, {-186, 42}}, color = {0, 0, 255}));
  connect(Udc.y, inverterModd.u) annotation(
    Line(points = {{-70, -76}, {-60, -76}, {-60, -34}, {-60, -34}}, color = {0, 0, 127}));
  connect(star.pin_n, ground1.p) annotation(
    Line(points = {{218, 16}, {218, 16}, {218, 6}, {218, 6}}, color = {0, 0, 255}));
  connect(star.plug_p, sineVoltage1.plug_n) annotation(
    Line(points = {{218, 36}, {218, 56}, {198, 56}}));
  connect(PRef.y[1], ref_Computation.Pref) annotation(
    Line(points = {{-136, -108}, {-92, -108}, {-92, -118}, {-22, -118}, {-22, -120}, {-22, -120}}, color = {0, 0, 127}));
  connect(ref_Computation.Qref, QRref.y[1]) annotation(
    Line(points = {{-22, -128}, {-94, -128}, {-94, -136}, {-136, -136}, {-136, -136}}, color = {0, 0, 127}));
  connect(powerSensor.pc, Cs.plug_n) annotation(
    Line(points = {{100, 70}, {100, 52}}, color = {0, 0, 255}));
  connect(powerSensor.nc, transformer.plug1) annotation(
    Line(points = {{120, 70}, {126, 70}, {126, 52}}, color = {0, 0, 255}));
  connect(powerSensor1.pc, transformer.plug2) annotation(
    Line(points = {{152, 68}, {146, 68}, {146, 52}, {146, 52}}, color = {0, 0, 255}));
  connect(powerSensor1.nc, sineVoltage1.plug_p) annotation(
    Line(points = {{172, 68}, {178, 68}, {178, 56}, {178, 56}}, color = {0, 0, 255}));
  connect(powerSensor1.pv, powerSensor1.nc) annotation(
    Line(points = {{162, 78}, {172, 78}, {172, 68}, {172, 68}}, color = {0, 0, 255}));
  connect(powerSensor.pv, powerSensor.pc) annotation(
    Line(points = {{110, 80}, {100, 80}, {100, 70}, {100, 70}}, color = {0, 0, 255}));
  connect(powerSensor.nv, star.plug_p) annotation(
    Line(points = {{110, 60}, {108, 60}, {108, 36}, {218, 36}, {218, 36}, {218, 36}}, color = {0, 0, 255}));
  connect(powerSensor1.nv, star.plug_p) annotation(
    Line(points = {{162, 58}, {162, 58}, {162, 36}, {218, 36}, {218, 36}}, color = {0, 0, 255}));
protected
  annotation(
    uses(iPSL(version = "1.1.0"), PVSystems(version = "0.6.3"), Modelica(version = "3.2.3"), PowerSystems(version = "1.0.0")),
  Diagram);
end m1testrafo;
