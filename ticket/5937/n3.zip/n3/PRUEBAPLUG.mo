model PRUEBAPLUG
  m1R m1 annotation(
    Placement(visible = true, transformation(origin = {-42, 6}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.RealExpression realExpression(y = 5000)  annotation(
    Placement(visible = true, transformation(origin = {-74, 62}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.RealExpression realExpression1(y = -2000)  annotation(
    Placement(visible = true, transformation(origin = {-74, 42}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  m1R ASD annotation(
    Placement(visible = true, transformation(origin = {-46, -52}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.RealExpression realExpression2(y = -2000) annotation(
    Placement(visible = true, transformation(origin = {-80, -22}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.RealExpression realExpression3(y = 5000) annotation(
    Placement(visible = true, transformation(origin = {-78, -4}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Interfaces.PositivePlug D annotation(
    Placement(visible = true, transformation(origin = {10, -12}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {10, -12}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage(V = fill(400, 3), freqHz = fill(50, 3))  annotation(
    Placement(visible = true, transformation(origin = {52, -8}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {90, -48}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {90, -18}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.MultiPhase.Sensors.CurrentSensor currentSensor annotation(
    Placement(visible = true, transformation(origin = {28, -30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  m1R SADF annotation(
    Placement(visible = true, transformation(origin = {-44, -94}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  m1R m annotation(
    Placement(visible = true, transformation(origin = {-52, -128}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(realExpression.y, m1.qref) annotation(
    Line(points = {{-62, 62}, {-38, 62}, {-38, 18}, {-38, 18}}, color = {0, 0, 127}));
  connect(realExpression1.y, m1.pref) annotation(
    Line(points = {{-62, 42}, {-46, 42}, {-46, 18}, {-46, 18}}, color = {0, 0, 127}));
  connect(realExpression3.y, ASD.qref) annotation(
    Line(points = {{-66, -4}, {-42, -4}, {-42, -40}, {-42, -40}}, color = {0, 0, 127}));
  connect(realExpression2.y, ASD.pref) annotation(
    Line(points = {{-68, -22}, {-50, -22}, {-50, -40}, {-50, -40}}, color = {0, 0, 127}));
  connect(m1.positivePlug, D) annotation(
    Line(points = {{-32, 0}, {12, 0}, {12, -12}, {10, -12}}, color = {0, 0, 255}));
  connect(ASD.positivePlug, D) annotation(
    Line(points = {{-36, -58}, {10, -58}, {10, -12}, {10, -12}}, color = {0, 0, 255}));
  connect(sineVoltage.plug_n, star.plug_p) annotation(
    Line(points = {{62, -8}, {90, -8}}, color = {0, 0, 255}));
  connect(star.pin_n, ground.p) annotation(
    Line(points = {{90, -28}, {90, -28}, {90, -38}, {90, -38}}, color = {0, 0, 255}));
  connect(D, currentSensor.plug_p) annotation(
    Line(points = {{10, -12}, {18, -12}, {18, -30}, {18, -30}}, color = {0, 0, 255}));
  connect(currentSensor.plug_n, sineVoltage.plug_p) annotation(
    Line(points = {{38, -30}, {42, -30}, {42, -8}, {42, -8}}, color = {0, 0, 255}));
  connect(realExpression2.y, SADF.pref) annotation(
    Line(points = {{-68, -22}, {-48, -22}, {-48, -82}, {-48, -82}}, color = {0, 0, 127}));
  connect(realExpression3.y, SADF.qref) annotation(
    Line(points = {{-66, -4}, {-40, -4}, {-40, -82}, {-40, -82}}, color = {0, 0, 127}));
  connect(SADF.positivePlug, D) annotation(
    Line(points = {{-34, -100}, {10, -100}, {10, -12}, {10, -12}}, color = {0, 0, 255}));
  connect(m.positivePlug, D) annotation(
    Line(points = {{-42, -134}, {10, -134}, {10, -12}, {10, -12}}, color = {0, 0, 255}));
  connect(realExpression2.y, m.pref) annotation(
    Line(points = {{-68, -22}, {-56, -22}, {-56, -116}, {-56, -116}}, color = {0, 0, 127}));
  connect(realExpression3.y, m.qref) annotation(
    Line(points = {{-66, -4}, {-46, -4}, {-46, -116}, {-48, -116}}, color = {0, 0, 127}));
  annotation(
    uses(Modelica(version = "3.2.3")));
end PRUEBAPLUG;
