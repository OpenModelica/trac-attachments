model mvhv
  Modelica.Electrical.Machines.BasicMachines.Components.IdealCore core(n12 = 15, n13 = 15) annotation(
    Placement(visible = true, transformation(origin = {0,2}, extent = {{-10, 10}, {10, -10}}, rotation = 180)));
  Modelica.Electrical.MultiPhase.Interfaces.NegativePlug out3 annotation(
    Placement(visible = true, transformation(origin = {96, 18}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {101, -1}, extent = {{-7, -7}, {7, 7}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Delta Delta3 annotation(
    Placement(visible = true, transformation(origin = {36, -8}, extent = {{10, -10}, {-10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor resistor2(R = fill(0.04, 3))  annotation(
    Placement(visible = true, transformation(origin = {44, 20}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Electrical.MultiPhase.Basic.Resistor resistor(R = fill(0.005, 3)) annotation(
    Placement(visible = true, transformation(origin = {-58, 44}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Interfaces.PositivePlug positivePlug annotation(
    Placement(visible = true, transformation(origin = {-100, 44}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-100, 2}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {-14, -50}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {-14, -78}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(Delta3.plug_n, core.plug_n1) annotation(
    Line(points = {{26, -8}, {10, -8}}, color = {0, 0, 255}));
  connect(core.plug_p1, resistor2.plug_n) annotation(
    Line(points = {{10, 12}, {20, 12}, {20, 20}, {34, 20}, {34, 20}}, color = {0, 0, 255}));
  connect(resistor2.plug_p, out3) annotation(
    Line(points = {{54, 20}, {94, 20}, {94, 18}, {96, 18}}, color = {0, 0, 255}));
  connect(Delta3.plug_p, resistor2.plug_p) annotation(
    Line(points = {{46, -8}, {54, -8}, {54, 20}}, color = {0, 0, 255}));
  connect(resistor.plug_n, core.plug_p2) annotation(
    Line(points = {{-48, 44}, {-16, 44}, {-16, 12}, {-10, 12}, {-10, 12}}, color = {0, 0, 255}));
  connect(core.plug_n2, core.plug_p3) annotation(
    Line(points = {{-10, 6}, {-10, 6}, {-10, -2}, {-10, -2}, {-10, -2}}, color = {0, 0, 255}));
  connect(positivePlug, resistor.plug_p) annotation(
    Line(points = {{-100, 44}, {-68, 44}, {-68, 44}, {-68, 44}}, color = {0, 0, 255}));
  connect(star.plug_p, core.plug_n3) annotation(
    Line(points = {{-14, -40}, {-14, -40}, {-14, -8}, {-10, -8}, {-10, -8}}, color = {0, 0, 255}));
  connect(star.pin_n, ground.p) annotation(
    Line(points = {{-14, -60}, {-14, -60}, {-14, -68}, {-14, -68}}, color = {0, 0, 255}));
protected
  annotation(
    uses(Modelica(version = "3.2.3")),
    Icon(graphics = {Ellipse(origin = {31, 0}, extent = {{-47, 46}, {45, -46}}, endAngle = 360), Ellipse(origin = {-33, 2}, extent = {{-47, 46}, {45, -46}}, endAngle = 360), Line(origin = {-88.9403, 2.38815}, points = {{-8, 0}, {8, 0}, {-8, 0}}), Line(origin = {83.7612, -0.432763}, points = {{-8, 0}, {12, 0}, {-8, 0}})}, coordinateSystem(initialScale = 0.1)));
end mvhv;
