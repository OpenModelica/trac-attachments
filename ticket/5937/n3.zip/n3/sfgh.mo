model sfgh
  Modelica.Electrical.MultiPhase.Basic.Transformer transformer(L1 = fill(0.002, 3), L2 = fill(0.004, 3), M = fill(4, 3))  annotation(
    Placement(visible = true, transformation(origin = {-8, 8}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {-82, -58}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {-82, -30}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage(V = fill(326, 3), freqHz = fill(50, 3))  annotation(
    Placement(visible = true, transformation(origin = {-82, 24}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.Analog.Basic.Ground ground1 annotation(
    Placement(visible = true, transformation(origin = {50, -58}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star1 annotation(
    Placement(visible = true, transformation(origin = {50, -30}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.MultiPhase.Basic.Resistor resistor(R = fill(4, 3))  annotation(
    Placement(visible = true, transformation(origin = {32, 18}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.VoltageSensor voltageSensor annotation(
    Placement(visible = true, transformation(origin = {60, 42}, extent = {{-10, -10}, {10, 10}}, rotation = 90)));
  Modelica.Electrical.MultiPhase.Basic.Resistor resistor1(R = fill(4, 3)) annotation(
    Placement(visible = true, transformation(origin = {-38, 18}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.CurrentSensor currentSensor annotation(
    Placement(visible = true, transformation(origin = {-60, 30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(sineVoltage.plug_n, star.plug_p) annotation(
    Line(points = {{-82, 14}, {-82, -20}}, color = {0, 0, 255}));
  connect(star.pin_n, ground.p) annotation(
    Line(points = {{-82, -40}, {-82, -40}, {-82, -48}, {-82, -48}}, color = {0, 0, 255}));
  connect(star1.pin_n, ground1.p) annotation(
    Line(points = {{50, -40}, {50, -48}}, color = {0, 0, 255}));
  connect(star1.plug_p, transformer.plug_n2) annotation(
    Line(points = {{50, -20}, {2, -20}, {2, -2}, {2, -2}}, color = {0, 0, 255}));
  connect(transformer.plug_p2, resistor.plug_p) annotation(
    Line(points = {{2, 18}, {22, 18}, {22, 18}, {22, 18}}, color = {0, 0, 255}));
  connect(resistor.plug_n, star1.plug_p) annotation(
    Line(points = {{42, 18}, {50, 18}, {50, -20}, {50, -20}}));
  connect(voltageSensor.plug_n, resistor.plug_p) annotation(
    Line(points = {{60, 52}, {22, 52}, {22, 18}, {22, 18}}, color = {0, 0, 255}));
  connect(voltageSensor.plug_p, star1.plug_p) annotation(
    Line(points = {{60, 32}, {50, 32}, {50, -20}, {50, -20}}, color = {0, 0, 255}));
  connect(resistor1.plug_n, transformer.plug_p1) annotation(
    Line(points = {{-28, 18}, {-18, 18}, {-18, 18}, {-18, 18}}, color = {0, 0, 255}));
  connect(transformer.plug_n1, star.plug_p) annotation(
    Line(points = {{-18, -2}, {-82, -2}, {-82, -20}, {-82, -20}}, color = {0, 0, 255}));
  connect(sineVoltage.plug_p, currentSensor.plug_p) annotation(
    Line(points = {{-82, 34}, {-70, 34}, {-70, 30}, {-70, 30}}, color = {0, 0, 255}));
  connect(currentSensor.plug_n, resistor1.plug_p) annotation(
    Line(points = {{-50, 30}, {-48, 30}, {-48, 18}, {-48, 18}}, color = {0, 0, 255}));
  annotation(
    uses(Modelica(version = "3.2.3")));
end sfgh;
