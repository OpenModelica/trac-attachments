model inverterMod
  Modelica.Blocks.Interfaces.RealInput vdref annotation(
    Placement(visible = true, transformation(origin = {-120, 14}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, -60}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput vqref annotation(
    Placement(visible = true, transformation(origin = {-120, 54}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, 60}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Math.Gain gain(k = 1)  annotation(
    Placement(visible = true, transformation(origin = {-80, -46}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Division division1 annotation(
    Placement(visible = true, transformation(origin = {-42, 48}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Division division2 annotation(
    Placement(visible = true, transformation(origin = {-40, 8}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Nonlinear.Limiter limiter(homotopyType = Modelica.Blocks.Types.LimiterHomotopy.NoHomotopy, limitsAtInit = true, uMax = 1, uMin = -1)  annotation(
    Placement(visible = true, transformation(origin = {4, 48}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Nonlinear.Limiter limiter1(homotopyType = Modelica.Blocks.Types.LimiterHomotopy.NoHomotopy, limitsAtInit = true, uMax = 1, uMin = 0) annotation(
    Placement(visible = true, transformation(origin = {6, 8}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  AntiPark antiPark annotation(
    Placement(visible = true, transformation(origin = {84, 28}, extent = {{-14, -14}, {14, 14}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput theta annotation(
    Placement(visible = true, transformation(origin = {84, -120}, extent = {{-20, -20}, {20, 20}}, rotation = 90), iconTransformation(origin = {0, -120}, extent = {{-20, -20}, {20, 20}}, rotation = 90)));
  Modelica.Blocks.Interfaces.RealOutput va annotation(
    Placement(visible = true, transformation(origin = {120, 44}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, 50}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput vb annotation(
    Placement(visible = true, transformation(origin = {120, 28}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput vc annotation(
    Placement(visible = true, transformation(origin = {120, 12}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, -50}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Product product annotation(
    Placement(visible = true, transformation(origin = {40, 42}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Product product1 annotation(
    Placement(visible = true, transformation(origin = {40, 14}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput u annotation(
    Placement(visible = true, transformation(origin = {-120, -46}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, 0}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
equation
  connect(vqref, division1.u1) annotation(
    Line(points = {{-120, 54}, {-54, 54}}, color = {0, 0, 127}));
  connect(division2.u1, vdref) annotation(
    Line(points = {{-52, 14}, {-120, 14}}, color = {0, 0, 127}));
  connect(division1.y, limiter.u) annotation(
    Line(points = {{-30, 48}, {-8, 48}}, color = {0, 0, 127}));
  connect(division2.y, limiter1.u) annotation(
    Line(points = {{-28, 8}, {-6, 8}}, color = {0, 0, 127}));
  connect(theta, antiPark.theta) annotation(
    Line(points = {{84, -120}, {84, 11}}, color = {0, 0, 127}));
  connect(antiPark.b, vb) annotation(
    Line(points = {{100, 28}, {110, 28}, {110, 28}, {120, 28}}, color = {0, 0, 127}));
  connect(va, antiPark.a) annotation(
    Line(points = {{120, 44}, {108, 44}, {108, 32}, {100, 32}, {100, 32}}, color = {0, 0, 127}));
  connect(antiPark.c, vc) annotation(
    Line(points = {{100, 24}, {108, 24}, {108, 12}, {120, 12}}, color = {0, 0, 127}));
  connect(gain.y, division1.u2) annotation(
    Line(points = {{-69, -46}, {-64, -46}, {-64, 44}, {-54, 44}, {-54, 42}}, color = {0, 0, 127}));
  connect(division2.u2, gain.y) annotation(
    Line(points = {{-52, 2}, {-64, 2}, {-64, -46}, {-69, -46}}, color = {0, 0, 127}));
  connect(product.y, antiPark.q) annotation(
    Line(points = {{52, 42}, {58, 42}, {58, 34}, {68, 34}, {68, 34}}, color = {0, 0, 127}));
  connect(product1.y, antiPark.d) annotation(
    Line(points = {{51, 14}, {60, 14}, {60, 22}, {68, 22}}, color = {0, 0, 127}));
  connect(product.u1, limiter.y) annotation(
    Line(points = {{28, 48}, {14, 48}, {14, 48}, {16, 48}}, color = {0, 0, 127}));
  connect(product1.u2, limiter1.y) annotation(
    Line(points = {{28, 8}, {16, 8}, {16, 8}, {18, 8}}, color = {0, 0, 127}));
  connect(product.u2, product1.u1) annotation(
    Line(points = {{28, 36}, {22, 36}, {22, 20}, {28, 20}, {28, 20}}, color = {0, 0, 127}));
  connect(u, gain.u) annotation(
    Line(points = {{-120, -46}, {-92, -46}}, color = {0, 0, 127}));
  connect(u, product1.u1) annotation(
    Line(points = {{-120, -46}, {-96, -46}, {-96, -80}, {22, -80}, {22, 20}, {28, 20}, {28, 20}}, color = {0, 0, 127}));
  annotation(
    uses(Modelica(version = "3.2.3")));
end inverterMod;
