model testtrafo3
  Modelica.Electrical.Analog.Basic.Ground ground1 annotation(
    Placement(visible = true, transformation(origin = {128, -40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.PowerSensor powerSensor annotation(
    Placement(visible = true, transformation(origin = {10, 36}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage1(V = fill(3260, 3), freqHz = fill(50, 3)) annotation(
    Placement(visible = true, transformation(origin = {98, 20}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {128, -10}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.MultiPhase.Sensors.PowerSensor powerSensor1 annotation(
    Placement(visible = true, transformation(origin = {72, 32}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  m1testrafo4 m1testrafo3 annotation(
    Placement(visible = true, transformation(origin = {-38, 32}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  trafo3 trafo36 annotation(
    Placement(visible = true, transformation(origin = {38, 38}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  m1testrafo4 m1testrafo5 annotation(
    Placement(visible = true, transformation(origin = {-42, 72}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.PowerSensor powerSensor2 annotation(
    Placement(visible = true, transformation(origin = {10, 76}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(m1testrafo3.ppi, powerSensor.pc) annotation(
    Line(points = {{-26, 37}, {0, 37}, {0, 36}}, color = {0, 0, 255}));
  connect(powerSensor.pv, powerSensor.pc) annotation(
    Line(points = {{10, 46}, {0, 46}, {0, 36}, {0, 36}}, color = {0, 0, 255}));
  connect(powerSensor1.nv, star.plug_p) annotation(
    Line(points = {{72, 22}, {80, 22}, {80, 0}, {128, 0}, {128, 0}, {128, 0}}, color = {0, 0, 255}));
  connect(powerSensor.nv, star.plug_p) annotation(
    Line(points = {{10, 26}, {10, 26}, {10, 0}, {128, 0}, {128, 0}}, color = {0, 0, 255}));
  connect(star.pin_n, ground1.p) annotation(
    Line(points = {{128, -20}, {128, -20}, {128, -30}, {128, -30}}, color = {0, 0, 255}));
  connect(powerSensor1.nc, sineVoltage1.plug_p) annotation(
    Line(points = {{82, 32}, {88, 32}, {88, 20}, {88, 20}}, color = {0, 0, 255}));
  connect(star.plug_p, sineVoltage1.plug_n) annotation(
    Line(points = {{128, 0}, {126, 0}, {126, 20}, {108, 20}, {108, 20}}, color = {0, 0, 255}));
  connect(powerSensor1.pv, powerSensor1.nc) annotation(
    Line(points = {{72, 42}, {82, 42}, {82, 32}, {82, 32}}, color = {0, 0, 255}));
  connect(powerSensor.nc, trafo36.I3) annotation(
    Line(points = {{20, 36}, {28, 36}, {28, 34}, {28, 34}}, color = {0, 0, 255}));
  connect(trafo36.O1, powerSensor1.pc) annotation(
    Line(points = {{48, 38}, {62, 38}, {62, 32}, {62, 32}}, color = {0, 0, 255}));
  connect(m1testrafo5.ppi, powerSensor2.pc) annotation(
    Line(points = {{-30, 78}, {0, 78}, {0, 76}, {0, 76}}, color = {0, 0, 255}));
  connect(powerSensor2.nv, star.plug_p) annotation(
    Line(points = {{10, 66}, {4, 66}, {4, 0}, {128, 0}, {128, 0}}, color = {0, 0, 255}));
  connect(powerSensor2.nc, trafo36.I2) annotation(
    Line(points = {{20, 76}, {26, 76}, {26, 40}, {28, 40}, {28, 42}}, color = {0, 0, 255}));
  connect(powerSensor2.pv, powerSensor2.pc) annotation(
    Line(points = {{10, 86}, {0, 86}, {0, 76}, {0, 76}}, color = {0, 0, 255}));

annotation(
    uses(Modelica(version = "3.2.3")));
end testtrafo3;
