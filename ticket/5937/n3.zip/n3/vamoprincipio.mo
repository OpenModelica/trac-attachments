model vamoprincipio
  VSC_voltage_sourcet vSC_voltage_sourcet annotation(
    Placement(visible = true, transformation(origin = {-68, 26}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage(V = fill(20412, 3), freqHz = fill(50, 3))  annotation(
    Placement(visible = true, transformation(origin = {34, 30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {56, 10}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {56, -20}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Machines.BasicMachines.Transformers.Dy.Dy03 transformer(L1sigma = 0.0071349, L2sigma = 0.13528, R1 = 0.001161, R2 = 3.458 * 2, n = 0.016754) annotation(
    Placement(visible = true, transformation(origin = {-18, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(sineVoltage.plug_n, star.plug_p) annotation(
    Line(points = {{44, 30}, {56, 30}, {56, 20}}, color = {0, 0, 255}));
  connect(star.pin_n, ground.p) annotation(
    Line(points = {{56, 0}, {56, -10}}, color = {0, 0, 255}));
  connect(vSC_voltage_sourcet.plug, transformer.plug1) annotation(
    Line(points = {{-78, 30}, {-28, 30}, {-28, 40}, {-28, 40}}));
  connect(transformer.plug2, sineVoltage.plug_p) annotation(
    Line(points = {{-8, 40}, {-8, 40}, {-8, 30}, {24, 30}, {24, 30}}, color = {0, 0, 255}));
  connect(transformer.starpoint2, star.pin_n) annotation(
    Line(points = {{-12, 30}, {-12, 30}, {-12, 0}, {56, 0}, {56, 0}}, color = {0, 0, 255}));

annotation(
    uses(Modelica(version = "3.2.3")));
end vamoprincipio;
