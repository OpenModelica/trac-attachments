block PI_PLL
  Modelica.Blocks.Continuous.Integrator integrator annotation(
    Placement(visible = true, transformation(origin = {20, -30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Add add annotation(
    Placement(visible = true, transformation(origin = {62, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput u annotation(
    Placement(visible = true, transformation(origin = {-100, 0}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-100, 0}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput y annotation(
    Placement(visible = true, transformation(origin = {100, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {90, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Gain gain(k = 1.5908)  annotation(
    Placement(visible = true, transformation(origin = {-6, 36}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Gain gain1(k = 353.45)  annotation(
    Placement(visible = true, transformation(origin = {-40, -30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(integrator.y, add.u2) annotation(
    Line(points = {{32, -30}, {44, -30}, {44, -6}, {50, -6}}, color = {0, 0, 127}));
  connect(add.y, y) annotation(
    Line(points = {{73, 0}, {100, 0}}, color = {0, 0, 127}));
  connect(gain1.y, integrator.u) annotation(
    Line(points = {{-28, -30}, {8, -30}, {8, -30}, {8, -30}}, color = {0, 0, 127}));
  connect(gain1.u, u) annotation(
    Line(points = {{-52, -30}, {-64, -30}, {-64, 0}, {-100, 0}, {-100, 0}}, color = {0, 0, 127}));
  connect(gain.y, add.u1) annotation(
    Line(points = {{6, 36}, {44, 36}, {44, 6}, {50, 6}, {50, 6}}, color = {0, 0, 127}));
  connect(gain.u, u) annotation(
    Line(points = {{-18, 36}, {-64, 36}, {-64, 0}, {-100, 0}, {-100, 0}}, color = {0, 0, 127}));
  annotation(
    uses(Modelica(version = "3.2.3")),
    Icon(graphics = {Rectangle(extent = {{-80, 80}, {80, -80}}), Text(origin = {0, 5}, extent = {{-60, 39}, {60, -39}}, textString = "PI"), Text(origin = {13, 110}, extent = {{-93, 46}, {49, -24}}, textString = "%name")}, coordinateSystem(initialScale = 0.1)));
end PI_PLL;
