model cable
  Modelica.Electrical.MultiPhase.Interfaces.PositivePlug pin annotation(
    Placement(visible = true, transformation(origin = {-100, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-100, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Interfaces.NegativePlug pout annotation(
    Placement(visible = true, transformation(origin = {100, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {100, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor resistor(R = fill(0.13 * 1.42, 3))  annotation(
    Placement(visible = true, transformation(origin = {-22, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Inductor inductor(L = fill(0.47712e-3, 3))  annotation(
    Placement(visible = true, transformation(origin = {22, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(inductor.plug_n, pout) annotation(
    Line(points = {{32, 0}, {100, 0}}, color = {0, 0, 255}));
  connect(inductor.plug_p, resistor.plug_n) annotation(
    Line(points = {{12, 0}, {-12, 0}}, color = {0, 0, 255}));
  connect(pin, resistor.plug_p) annotation(
    Line(points = {{-100, 0}, {-32, 0}}, color = {0, 0, 255}));
  annotation(
    uses(Modelica(version = "3.2.3")));
end cable;
