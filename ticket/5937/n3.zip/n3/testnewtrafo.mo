model testnewtrafo
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage2(V = fill(3260, 3), freqHz = fill(50, 3))  annotation(
    Placement(visible = true, transformation(origin = {64, 16}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {-72, -74}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {-72, -100}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  trafo4 trafo5 annotation(
    Placement(visible = true, transformation(origin = {6, 18}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  m1testrafo4 m1testrafo7 annotation(
    Placement(visible = true, transformation(origin = {-114, 52}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  m1testrafo4 m1testrafo41 annotation(
    Placement(visible = true, transformation(origin = {-112, -24}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Interfaces.Plug plug annotation(
    Placement(visible = true, transformation(origin = {34, 16}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {26, 14}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(ground.p, star.pin_n) annotation(
    Line(points = {{-72, -90}, {-72, -90}, {-72, -84}, {-72, -84}}, color = {0, 0, 255}));
  connect(star.plug_p, sineVoltage2.plug_n) annotation(
    Line(points = {{-72, -64}, {74, -64}, {74, 16}, {74, 16}}, color = {0, 0, 255}));
  connect(trafo5.negativePlug, plug) annotation(
    Line(points = {{16, 24}, {32, 24}, {32, 16}, {34, 16}}, color = {0, 0, 255}));
  connect(trafo5.negativePlug1, plug) annotation(
    Line(points = {{16, 12}, {34, 12}, {34, 16}, {34, 16}}, color = {0, 0, 255}));
  connect(sineVoltage2.plug_p, plug) annotation(
    Line(points = {{54, 16}, {36, 16}, {36, 16}, {34, 16}}, color = {0, 0, 255}));
  connect(m1testrafo7.negativePlug, trafo5.positivePlug) annotation(
    Line(points = {{-100, 58}, {-6, 58}, {-6, 24}, {-4, 24}}, color = {0, 0, 255}));
  connect(m1testrafo41.negativePlug, trafo5.positivePlug1) annotation(
    Line(points = {{-98, -18}, {-4, -18}, {-4, 12}, {-4, 12}}, color = {0, 0, 255}));
  annotation(
    uses(Modelica(version = "3.2.3")));
end testnewtrafo;
