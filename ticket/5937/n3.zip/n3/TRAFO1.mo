model TRAFO1
  VSC_voltage_sourcet vSC_voltage_sourcet6 annotation(
    Placement(visible = true, transformation(origin = {-76, 16}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Machines.BasicMachines.Transformers.Dy.Dy01 transformer(L1sigma = 0.000022711, L2sigma = 0.1352, R1 = 0.001161, R2 = 6.916, n = 0.01368)  annotation(
    Placement(visible = true, transformation(origin = {-20, 14}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage(V = fill(25000, 3), freqHz = fill(50, 3))  annotation(
    Placement(visible = true, transformation(origin = {12, 14}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {30, -4}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {30, -32}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(transformer.plug1, vSC_voltage_sourcet6.plug) annotation(
    Line(points = {{-30, 14}, {-86, 14}, {-86, 20}, {-86, 20}}, color = {0, 0, 255}));
  connect(star.pin_n, ground.p) annotation(
    Line(points = {{30, -14}, {30, -14}, {30, -22}, {30, -22}}, color = {0, 0, 255}));
  connect(star.plug_p, sineVoltage.plug_n) annotation(
    Line(points = {{30, 6}, {30, 6}, {30, 14}, {22, 14}, {22, 14}}, color = {0, 0, 255}));
  connect(sineVoltage.plug_p, transformer.plug2) annotation(
    Line(points = {{2, 14}, {-10, 14}, {-10, 14}, {-10, 14}}, color = {0, 0, 255}));
  connect(transformer.starpoint2, star.pin_n) annotation(
    Line(points = {{-14, 4}, {-16, 4}, {-16, -14}, {30, -14}, {30, -14}}, color = {0, 0, 255}));

annotation(
    uses(Modelica(version = "3.2.3")));
end TRAFO1;
