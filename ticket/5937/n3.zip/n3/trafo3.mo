model trafo3
  Modelica.Electrical.Machines.BasicMachines.Components.IdealCore core(n12 = 10, n13 = 10)  annotation(
    Placement(visible = true, transformation(origin = {-2.44249e-15, 3.55271e-15}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Interfaces.PositivePlug O1 annotation(
    Placement(visible = true, transformation(origin = {-100, 10}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {100, 0}, extent = {{-6, -6}, {6, 6}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Interfaces.NegativePlug I2 annotation(
    Placement(visible = true, transformation(origin = {102, 30}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-100, 30}, extent = {{-6, -6}, {6, 6}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Interfaces.NegativePlug I3 annotation(
    Placement(visible = true, transformation(origin = {102, -4}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-100, -30}, extent = {{-6, -6}, {6, 6}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Delta Delta1 annotation(
    Placement(visible = true, transformation(origin = {-52, -10}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor R1(R = fill(0.05, 3))  annotation(
    Placement(visible = true, transformation(origin = {-70, 10}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Inductor L1(L = fill(0.003, 3))  annotation(
    Placement(visible = true, transformation(origin = {-44, 10}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Delta Rot2 annotation(
    Placement(visible = true, transformation(origin = {30, 30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Inductor L2(L = fill(0.003, 3))  annotation(
    Placement(visible = true, transformation(origin = {56, 30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Inductor L3(L = fill(0.003, 3))  annotation(
    Placement(visible = true, transformation(origin = {56, -4}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Delta Rot3 annotation(
    Placement(visible = true, transformation(origin = {30, -4}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor R2(R = fill(0.05, 3))  annotation(
    Placement(visible = true, transformation(origin = {80, 30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor R3(R = fill(0.05, 3))  annotation(
    Placement(visible = true, transformation(origin = {80, -4}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {0, -60}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
equation
  connect(Delta1.plug_n, core.plug_n1) annotation(
    Line(points = {{-42, -10}, {-10, -10}, {-10, -10}, {-10, -10}}, color = {0, 0, 255}));
  connect(L1.plug_n, core.plug_p1) annotation(
    Line(points = {{-34, 10}, {-10, 10}, {-10, 10}, {-10, 10}}, color = {0, 0, 255}));
  connect(L1.plug_p, R1.plug_n) annotation(
    Line(points = {{-54, 10}, {-60, 10}, {-60, 10}, {-60, 10}}, color = {0, 0, 255}));
  connect(R1.plug_p, O1) annotation(
    Line(points = {{-80, 10}, {-100, 10}}));
  connect(Delta1.plug_p, R1.plug_p) annotation(
    Line(points = {{-62, -10}, {-80, -10}, {-80, 10}, {-80, 10}}, color = {0, 0, 255}));
  connect(R2.plug_p, L2.plug_n) annotation(
    Line(points = {{70, 30}, {66, 30}}, color = {0, 0, 255}));
  connect(L2.plug_p, Rot2.plug_n) annotation(
    Line(points = {{46, 30}, {40, 30}}, color = {0, 0, 255}));
  connect(Rot2.plug_p, core.plug_p2) annotation(
    Line(points = {{20, 30}, {16, 30}, {16, 10}, {10, 10}}, color = {0, 0, 255}));
  connect(core.plug_p3, Rot3.plug_p) annotation(
    Line(points = {{10, -4}, {18, -4}, {18, -4}, {20, -4}}, color = {0, 0, 255}));
  connect(R2.plug_n, I2) annotation(
    Line(points = {{90, 30}, {102, 30}, {102, 30}, {102, 30}}, color = {0, 0, 255}));
  connect(R3.plug_n, I3) annotation(
    Line(points = {{90, -4}, {100, -4}, {100, -4}, {102, -4}}, color = {0, 0, 255}));
  connect(R3.plug_p, L3.plug_n) annotation(
    Line(points = {{70, -4}, {66, -4}, {66, -4}, {66, -4}}, color = {0, 0, 255}));
  connect(L3.plug_p, Rot3.plug_n) annotation(
    Line(points = {{46, -4}, {40, -4}, {40, -4}, {40, -4}}, color = {0, 0, 255}));
  connect(core.plug_n3, star.plug_p) annotation(
    Line(points = {{10, -10}, {10, -10}, {10, -42}, {0, -42}, {0, -50}, {0, -50}}, color = {0, 0, 255}));
  connect(core.plug_n2, star.plug_p) annotation(
    Line(points = {{10, 4}, {18, 4}, {18, -42}, {0, -42}, {0, -50}, {0, -50}}, color = {0, 0, 255}));
  annotation(
    uses(Modelica(version = "3.2.3")),
    Icon(graphics = {Ellipse(origin = {-41, -47}, extent = {{55, 57}, {-25, -23}}, endAngle = 360), Ellipse(origin = {13, -17}, extent = {{55, 57}, {-25, -23}}, endAngle = 360), Ellipse(origin = {-43, 11}, extent = {{55, 57}, {-25, -23}}, endAngle = 360), Line(origin = {-83.5511, 29.281}, points = {{15, 0}, {-13, 0}, {15, 0}}), Line(origin = {-84.3175, -30.1169}, points = {{17, 0}, {-13, 0}, {17, 0}}), Line(origin = {87.3613, -0.226313}, points = {{13, 0}, {-19, 0}, {13, 0}})}, coordinateSystem(initialScale = 0.1)));
end trafo3;
