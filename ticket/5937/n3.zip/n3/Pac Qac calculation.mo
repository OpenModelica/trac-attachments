block Pac_Qac_Calculation
  Modelica.Blocks.Interfaces.RealInput Va_grid annotation(
    Placement(visible = true, transformation(origin = {-81, 111}, extent = {{-11, -11}, {11, 11}}, rotation = -90), iconTransformation(origin = {-81, 111}, extent = {{-11, -11}, {11, 11}}, rotation = -90)));
  Modelica.Blocks.Interfaces.RealInput Vb_grid annotation(
    Placement(visible = true, transformation(origin = {-53, 111}, extent = {{-11, -11}, {11, 11}}, rotation = -90), iconTransformation(origin = {-53, 111}, extent = {{-11, -11}, {11, 11}}, rotation = -90)));
  Modelica.Blocks.Interfaces.RealInput Vc_grid annotation(
    Placement(visible = true, transformation(origin = {-25, 111}, extent = {{-11, -11}, {11, 11}}, rotation = -90), iconTransformation(origin = {-23, 111}, extent = {{-11, -11}, {11, 11}}, rotation = -90)));
  Modelica.Blocks.Interfaces.RealInput Ia_grid annotation(
    Placement(visible = true, transformation(origin = {25, 111}, extent = {{-11, -11}, {11, 11}}, rotation = -90), iconTransformation(origin = {19, 111}, extent = {{-11, -11}, {11, 11}}, rotation = -90)));
  Modelica.Blocks.Interfaces.RealInput Ib_grid annotation(
    Placement(visible = true, transformation(origin = {55, 111}, extent = {{-11, -11}, {11, 11}}, rotation = -90), iconTransformation(origin = {51, 111}, extent = {{-11, -11}, {11, 11}}, rotation = -90)));
  Modelica.Blocks.Interfaces.RealInput Ic_grid annotation(
    Placement(visible = true, transformation(origin = {79, 111}, extent = {{-11, -11}, {11, 11}}, rotation = -90), iconTransformation(origin = {79, 111}, extent = {{-11, -11}, {11, 11}}, rotation = -90)));
  Park park annotation(
    Placement(visible = true, transformation(origin = {-53, 29}, extent = {{-17, -17}, {17, 17}}, rotation = -90)));
  Park park1 annotation(
    Placement(visible = true, transformation(origin = {55, 29}, extent = {{-17, -17}, {17, 17}}, rotation = -90)));
  Modelica.Blocks.Interfaces.RealInput theta annotation(
    Placement(visible = true, transformation(origin = {-120, 28}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, 0}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Math.Product vq_iq annotation(
    Placement(visible = true, transformation(origin = {-89, -51}, extent = {{-7, -7}, {7, 7}}, rotation = -90)));
  Modelica.Blocks.Math.Product vd_id annotation(
    Placement(visible = true, transformation(origin = {-31, -51}, extent = {{-7, -7}, {7, 7}}, rotation = -90)));
  Modelica.Blocks.Math.Product vd_iq annotation(
    Placement(visible = true, transformation(origin = {89, -51}, extent = {{-7, -7}, {7, 7}}, rotation = -90)));
  Modelica.Blocks.Interfaces.RealOutput Qac annotation(
    Placement(visible = true, transformation(origin = {50, -132}, extent = {{-10, -10}, {10, 10}}, rotation = -90), iconTransformation(origin = {52, -110}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Blocks.Math.Add vqiq_vdid annotation(
    Placement(visible = true, transformation(origin = {-51, -81}, extent = {{-7, -7}, {7, 7}}, rotation = -90)));
  Modelica.Blocks.Math.Add add1(k1 = -1, k2 = +1)  annotation(
    Placement(visible = true, transformation(origin = {49, -79}, extent = {{-7, -7}, {7, 7}}, rotation = -90)));
  Modelica.Blocks.Math.Product vq_id annotation(
    Placement(visible = true, transformation(origin = {31, -51}, extent = {{-7, -7}, {7, 7}}, rotation = -90)));
  Modelica.Blocks.Math.Gain gain1(k = 3 / 2) annotation(
    Placement(visible = true, transformation(origin = {50, -106}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Blocks.Interfaces.RealOutput Pac annotation(
    Placement(visible = true, transformation(origin = {-50, -132}, extent = {{-10, -10}, {10, 10}}, rotation = -90), iconTransformation(origin = {-50, -110}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Blocks.Math.Gain gain(k = 3 / 2) annotation(
    Placement(visible = true, transformation(origin = {-50, -106}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
equation
  connect(gain1.y, Qac) annotation(
    Line(points = {{50, -117}, {50, -132}}, color = {0, 0, 127}));
  connect(gain.y, Pac) annotation(
    Line(points = {{-50, -117}, {-50, -132}}, color = {0, 0, 127}));
  connect(gain.y, Pac) annotation(
    Line(points = {{-50, -117}, {-50, -132}}, color = {0, 0, 127}));
  connect(park.d, vd_id.u2) annotation(
    Line(points = {{-58, 18}, {-58, 18}, {-58, -28}, {-36, -28}, {-36, -42}, {-36, -42}}, color = {0, 0, 127}));
  connect(park.d, vd_iq.u2) annotation(
    Line(points = {{-58, 18}, {-58, 18}, {-58, -18}, {84, -18}, {84, -42}, {84, -42}}, color = {0, 0, 127}));
  connect(park.q, vq_id.u2) annotation(
    Line(points = {{-48, 18}, {-48, 18}, {-48, 0}, {26, 0}, {26, -42}, {26, -42}}, color = {0, 0, 127}));
  connect(park1.d, vq_id.u1) annotation(
    Line(points = {{50, 18}, {50, 18}, {50, 0}, {34, 0}, {34, -42}, {36, -42}}, color = {0, 0, 127}));
  connect(park1.d, vd_id.u1) annotation(
    Line(points = {{50, 18}, {50, 18}, {50, -28}, {-26, -28}, {-26, -42}, {-26, -42}}, color = {0, 0, 127}));
  connect(park1.q, vd_iq.u1) annotation(
    Line(points = {{60, 18}, {60, 18}, {60, -10}, {94, -10}, {94, -42}, {94, -42}}, color = {0, 0, 127}));
  connect(park1.q, vq_iq.u1) annotation(
    Line(points = {{60, 18}, {60, 18}, {60, -10}, {-86, -10}, {-86, -42}, {-84, -42}}, color = {0, 0, 127}));
  connect(park.q, vq_iq.u2) annotation(
    Line(points = {{-48, 18}, {-48, 18}, {-48, 0}, {-94, 0}, {-94, -42}, {-94, -42}}, color = {0, 0, 127}));
  connect(vq_iq.y, vqiq_vdid.u2) annotation(
    Line(points = {{-88, -58}, {-88, -66}, {-54, -66}, {-54, -73}, {-55, -73}}, color = {0, 0, 127}));
  connect(vd_id.y, vqiq_vdid.u1) annotation(
    Line(points = {{-30, -58}, {-32, -58}, {-32, -66}, {-47, -66}, {-47, -73}}, color = {0, 0, 127}));
  connect(vq_id.y, add1.u2) annotation(
    Line(points = {{32, -58}, {32, -66}, {45, -66}, {45, -71}}, color = {0, 0, 127}));
  connect(vd_iq.y, add1.u1) annotation(
    Line(points = {{90, -58}, {90, -66}, {53, -66}, {53, -71}}, color = {0, 0, 127}));
  connect(vqiq_vdid.y, gain.u) annotation(
    Line(points = {{-51, -89}, {-51, -103}, {-50, -103}, {-50, -94}}, color = {0, 0, 127}));
  connect(add1.y, gain1.u) annotation(
    Line(points = {{49, -87}, {48, -87}, {48, -94}, {50, -94}}, color = {0, 0, 127}));
  connect(theta, park.theta) annotation(
    Line(points = {{-120, 28}, {-74, 28}, {-74, 28}, {-72, 28}}, color = {0, 0, 127}));
  connect(park.b, Vb_grid) annotation(
    Line(points = {{-54, 48}, {-52, 48}, {-52, 112}, {-52, 112}}, color = {0, 0, 127}));
  connect(park.a, Va_grid) annotation(
    Line(points = {{-46, 48}, {-46, 62}, {-84, 62}, {-84, 111}, {-81, 111}}, color = {0, 0, 127}));
  connect(park1.c, Ic_grid) annotation(
    Line(points = {{48, 48}, {48, 60}, {80, 60}, {80, 111}, {79, 111}}, color = {0, 0, 127}));
  connect(park1.b, Ib_grid) annotation(
    Line(points = {{54, 48}, {55, 48}, {55, 111}}, color = {0, 0, 127}));
  connect(park1.a, Ia_grid) annotation(
    Line(points = {{62, 48}, {62, 48}, {62, 62}, {24, 62}, {24, 112}, {26, 112}}, color = {0, 0, 127}));
  connect(park.c, Vc_grid) annotation(
    Line(points = {{-60, 48}, {-60, 48}, {-60, 60}, {-26, 60}, {-26, 112}, {-24, 112}}, color = {0, 0, 127}));
  connect(theta, park1.theta) annotation(
    Line(points = {{-120, 28}, {-78, 28}, {-78, 4}, {26, 4}, {26, 28}, {36, 28}, {36, 28}}, color = {0, 0, 127}));
  annotation(
    uses(Modelica(version = "3.2.3")),
    Icon(coordinateSystem(initialScale = 0.1), graphics = {Text(origin = {11, 25}, rotation = 90, extent = {{-85, 69}, {43, -33}}, textString = "P Q"), Rectangle(extent = {{-100, 100}, {100, -100}})}));
end Pac_Qac_Calculation;
