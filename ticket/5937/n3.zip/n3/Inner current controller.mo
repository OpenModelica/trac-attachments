block Inner_Current_Controller
  Modelica.Blocks.Interfaces.RealInput Id_ref annotation(
    Placement(visible = true, transformation(origin = {-104, 84}, extent = {{-14, -14}, {14, 14}}, rotation = 0), iconTransformation(origin = {-88, 58}, extent = {{-8, -8}, {8, 8}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Iq annotation(
    Placement(visible = true, transformation(origin = {-104, -20}, extent = {{-14, -14}, {14, 14}}, rotation = 0), iconTransformation(origin = {-88, -16}, extent = {{-8, -8}, {8, 8}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Iq_ref annotation(
    Placement(visible = true, transformation(origin = {-104, -86}, extent = {{-16, -16}, {16, 16}}, rotation = 0), iconTransformation(origin = {-88, -52}, extent = {{-8, -8}, {8, 8}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput Vq_ref annotation(
    Placement(visible = true, transformation(origin = {108, -78}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {82, -50}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Add3 add3(k2 = +1, k3 = -1)  annotation(
    Placement(visible = true, transformation(origin = {55, 85}, extent = {{-7, -7}, {7, 7}}, rotation = 0)));
  Modelica.Blocks.Math.Add3 add31(k1 = +1, k2 = +1)  annotation(
    Placement(visible = true, transformation(origin = {68, -78}, extent = {{-6, -6}, {6, 6}}, rotation = 0)));
  Modelica.Blocks.Math.Feedback feedback annotation(
    Placement(visible = true, transformation(origin = {-70, 84}, extent = {{10, 10}, {-10, -10}}, rotation = 180)));
  Modelica.Blocks.Math.Feedback feedback1 annotation(
    Placement(visible = true, transformation(origin = {-62, -86}, extent = {{-10, 10}, {10, -10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Vld annotation(
    Placement(visible = true, transformation(origin = {19, 115}, extent = {{-9, -9}, {9, 9}}, rotation = -90), iconTransformation(origin = {-9, 87}, extent = {{-9, -9}, {9, 9}}, rotation = -90)));
  Modelica.Blocks.Interfaces.RealInput Vlq annotation(
    Placement(visible = true, transformation(origin = {47, -107}, extent = {{-11, -11}, {11, 11}}, rotation = 90), iconTransformation(origin = {51, 87}, extent = {{-9, -9}, {9, 9}}, rotation = -90)));
  Modelica.Blocks.Sources.Constant wl(k = 0.020295)  annotation(
    Placement(visible = true, transformation(origin = {-69, 3}, extent = {{-9, -9}, {9, 9}}, rotation = 0)));
  Modelica.Blocks.Math.Product product annotation(
    Placement(visible = true, transformation(origin = {-20, 24}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Product product1 annotation(
    Placement(visible = true, transformation(origin = {-20, -14}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Continuous.Integrator kiq(k = 5.98)  annotation(
    Placement(visible = true, transformation(origin = {-24, -100}, extent = {{-8, -8}, {8, 8}}, rotation = 0)));
  Modelica.Blocks.Continuous.Integrator kid(k = 5.98)  annotation(
    Placement(visible = true, transformation(origin = {-36, 68}, extent = {{-8, -8}, {8, 8}}, rotation = 0)));
  Modelica.Blocks.Math.Gain kd(k = 0.0646)  annotation(
    Placement(visible = true, transformation(origin = {-37, 101}, extent = {{-7, -7}, {7, 7}}, rotation = 0)));
  Modelica.Blocks.Math.Gain kq(k = 0.0646)  annotation(
    Placement(visible = true, transformation(origin = {-24, -60}, extent = {{-8, -8}, {8, 8}}, rotation = 0)));
  Modelica.Blocks.Math.Add add annotation(
    Placement(visible = true, transformation(origin = {18, -78}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Add add1 annotation(
    Placement(visible = true, transformation(origin = {0, 84}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput Vd_ref annotation(
    Placement(visible = true, transformation(origin = {110, 84}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {82, 50}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Id annotation(
    Placement(visible = true, transformation(origin = {-106, 32}, extent = {{-12, -12}, {12, 12}}, rotation = 0), iconTransformation(origin = {-88, 24}, extent = {{-8, -8}, {8, 8}}, rotation = 0)));
equation
  connect(Id_ref, feedback.u1) annotation(
    Line(points = {{-104, 84}, {-78, 84}}, color = {0, 0, 127}));
  connect(Iq_ref, feedback1.u1) annotation(
    Line(points = {{-104, -86}, {-70, -86}}, color = {0, 0, 127}));
  connect(feedback1.u2, Iq) annotation(
    Line(points = {{-62, -78}, {-62, -20}, {-104, -20}}, color = {0, 0, 127}));
  connect(Vld, add3.u1) annotation(
    Line(points = {{19, 115}, {19, 91}, {47, 91}}, color = {0, 0, 127}));
  connect(wl.y, product.u2) annotation(
    Line(points = {{-60, 4}, {-52, 4}, {-52, 18}, {-32, 18}}, color = {0, 0, 127}));
  connect(wl.y, product1.u1) annotation(
    Line(points = {{-60, 4}, {-52, 4}, {-52, -8}, {-32, -8}, {-32, -8}}, color = {0, 0, 127}));
  connect(Iq, product1.u2) annotation(
    Line(points = {{-104, -20}, {-32, -20}}, color = {0, 0, 127}));
  connect(feedback.y, kd.u) annotation(
    Line(points = {{-60, 84}, {-54, 84}, {-54, 100}, {-46, 100}, {-46, 102}}, color = {0, 0, 127}));
  connect(kd.y, add1.u1) annotation(
    Line(points = {{-30, 102}, {-20, 102}, {-20, 90}, {-12, 90}, {-12, 90}}, color = {0, 0, 127}));
  connect(add1.u2, kid.y) annotation(
    Line(points = {{-12, 78}, {-18, 78}, {-18, 68}, {-28, 68}, {-28, 68}}, color = {0, 0, 127}));
  connect(kid.u, feedback.y) annotation(
    Line(points = {{-46, 68}, {-54, 68}, {-54, 84}, {-60, 84}, {-60, 84}}, color = {0, 0, 127}));
  connect(add1.y, add3.u2) annotation(
    Line(points = {{12, 84}, {46, 84}, {46, 86}, {46, 86}}, color = {0, 0, 127}));
  connect(add3.u3, product1.y) annotation(
    Line(points = {{46, 80}, {34, 80}, {34, -14}, {-8, -14}, {-8, -14}}, color = {0, 0, 127}));
  connect(kq.u, feedback1.y) annotation(
    Line(points = {{-34, -60}, {-44, -60}, {-44, -86}, {-52, -86}}, color = {0, 0, 127}));
  connect(kiq.u, feedback1.y) annotation(
    Line(points = {{-34, -100}, {-44, -100}, {-44, -86}, {-52, -86}}, color = {0, 0, 127}));
  connect(kq.y, add.u1) annotation(
    Line(points = {{-16, -60}, {-4, -60}, {-4, -72}, {6, -72}, {6, -72}}, color = {0, 0, 127}));
  connect(add.u2, kiq.y) annotation(
    Line(points = {{6, -84}, {-2, -84}, {-2, -100}, {-15, -100}}, color = {0, 0, 127}));
  connect(add.y, add31.u2) annotation(
    Line(points = {{30, -78}, {60, -78}, {60, -78}, {60, -78}}, color = {0, 0, 127}));
  connect(Vlq, add31.u3) annotation(
    Line(points = {{48, -106}, {48, -106}, {48, -82}, {60, -82}, {60, -82}}, color = {0, 0, 127}));
  connect(product.y, add31.u1) annotation(
    Line(points = {{-8, 24}, {46, 24}, {46, -74}, {60, -74}, {60, -74}}, color = {0, 0, 127}));
  connect(Id, product.u1) annotation(
    Line(points = {{-106, 32}, {-34, 32}, {-34, 30}, {-32, 30}, {-32, 30}}, color = {0, 0, 127}));
  connect(Id, feedback.u2) annotation(
    Line(points = {{-106, 32}, {-70, 32}, {-70, 76}, {-70, 76}}, color = {0, 0, 127}));
  connect(add3.y, Vd_ref) annotation(
    Line(points = {{62, 86}, {100, 86}, {100, 84}, {110, 84}}, color = {0, 0, 127}));
  connect(add31.y, Vq_ref) annotation(
    Line(points = {{74, -78}, {102, -78}, {102, -78}, {108, -78}}, color = {0, 0, 127}));
  annotation(
    uses(Modelica(version = "3.2.3")),
    Icon(graphics = {Rectangle(origin = {-4, 1}, extent = {{-76, 77}, {76, -77}}), Text(origin = {6, 1}, extent = {{-36, 25}, {20, -23}}, textString = "Inner CC"), Text(origin = {-63, 58}, extent = {{-13, 6}, {13, -6}}, textString = "Id_ref"), Text(origin = {-65, 20}, extent = {{-13, 6}, {13, -6}}, textString = "Id"), Text(origin = {-67, -18}, extent = {{-13, 6}, {13, -6}}, textString = "Iq"), Text(origin = {-61, -54}, extent = {{-13, 6}, {13, -6}}, textString = "Iq_ref"), Text(origin = {-7, 72}, extent = {{-13, 6}, {13, -6}}, textString = "Vzd"), Text(origin = {59, -40}, extent = {{-13, 6}, {13, -6}}, textString = "Vlq"), Text(origin = {59, 42}, extent = {{-13, 6}, {13, -6}}, textString = "Vld"), Text(origin = {47, 70}, extent = {{-13, 6}, {13, -6}}, textString = "Vzq")}, coordinateSystem(initialScale = 0.1)),
  Diagram(graphics = {Text(origin = {26, 118}, extent = {{-6, 4}, {6, -4}}, textString = "Vzd"), Text(origin = {38, -108}, extent = {{-6, 4}, {6, -4}}, textString = "Vzq")}));
end Inner_Current_Controller;
