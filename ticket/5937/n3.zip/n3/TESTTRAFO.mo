model TESTTRAFO
  trafo trafo1 annotation(
    Placement(visible = true, transformation(origin = {0, -1.77636e-15}, extent = {{-16, -16}, {16, 16}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage(V = fill(400, 3), freqHz = fill(50, 3))  annotation(
    Placement(visible = true, transformation(origin = {-102, -16}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage1(V = fill(400, 3), freqHz = fill(50, 3))  annotation(
    Placement(visible = true, transformation(origin = {-102, 20}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {-158, -46}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {-158, -70}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage2(V = fill(40000, 3), freqHz = fill(50, 3))  annotation(
    Placement(visible = true, transformation(origin = {102, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Basic.Ground ground1 annotation(
    Placement(visible = true, transformation(origin = {116, -68}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star1 annotation(
    Placement(visible = true, transformation(origin = {116, -40}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.MultiPhase.Sensors.PotentialSensor mvp annotation(
    Placement(visible = true, transformation(origin = {-162, 44}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.PotentialSensor lvp annotation(
    Placement(visible = true, transformation(origin = {74, 36}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.PowerSensor psmv annotation(
    Placement(visible = true, transformation(origin = {30, 16}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.PowerSensor lvps annotation(
    Placement(visible = true, transformation(origin = {-28, -16}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.PowerSensor powerSensor annotation(
    Placement(visible = true, transformation(origin = {-32, 20}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Add add(k1 = -1, k2 = -1)  annotation(
    Placement(visible = true, transformation(origin = {30, -62}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(sineVoltage1.plug_p, star.plug_p) annotation(
    Line(points = {{-112, 20}, {-158, 20}, {-158, -34}, {-158, -34}, {-158, -36}}, color = {0, 0, 255}));
  connect(sineVoltage.plug_p, star.plug_p) annotation(
    Line(points = {{-112, -16}, {-158, -16}, {-158, -36}, {-158, -36}}, color = {0, 0, 255}));
  connect(star.pin_n, ground.p) annotation(
    Line(points = {{-158, -56}, {-158, -56}, {-158, -60}, {-158, -60}}, color = {0, 0, 255}));
  connect(star1.pin_n, ground1.p) annotation(
    Line(points = {{116, -50}, {116, -58}}, color = {0, 0, 255}));
  connect(sineVoltage2.plug_n, star1.plug_p) annotation(
    Line(points = {{112, 0}, {114, 0}, {114, -30}, {116, -30}}));
  connect(mvp.plug_p, sineVoltage1.plug_n) annotation(
    Line(points = {{-172, 44}, {-92, 44}, {-92, 20}}, color = {0, 0, 255}));
  connect(lvp.plug_p, sineVoltage2.plug_p) annotation(
    Line(points = {{64, 36}, {60, 36}, {60, 10}, {92, 10}, {92, 0}, {92, 0}}, color = {0, 0, 255}));
  connect(powerSensor.nc, trafo1.I2) annotation(
    Line(points = {{-22, 20}, {-16, 20}, {-16, 4}, {-16, 4}}, color = {0, 0, 255}));
  connect(trafo1.I3, lvps.nc) annotation(
    Line(points = {{-16, -4}, {-16, -4}, {-16, -16}, {-18, -16}, {-18, -16}}));
  connect(lvps.pv, lvps.pc) annotation(
    Line(points = {{-28, -6}, {-38, -6}, {-38, -16}, {-38, -16}}, color = {0, 0, 255}));
  connect(powerSensor.pv, powerSensor.pc) annotation(
    Line(points = {{-32, 30}, {-42, 30}, {-42, 20}, {-42, 20}}, color = {0, 0, 255}));
  connect(powerSensor.nv, star.plug_p) annotation(
    Line(points = {{-32, 10}, {-32, 10}, {-32, 2}, {-158, 2}, {-158, -36}, {-158, -36}}, color = {0, 0, 255}));
  connect(lvps.nv, star.plug_p) annotation(
    Line(points = {{-28, -26}, {-28, -26}, {-28, -36}, {-158, -36}, {-158, -36}}, color = {0, 0, 255}));
  connect(psmv.pc, trafo1.O1) annotation(
    Line(points = {{20, 16}, {16, 16}, {16, 0}}, color = {0, 0, 255}));
  connect(psmv.nv, star1.plug_p) annotation(
    Line(points = {{30, 6}, {30, -30}, {116, -30}}, color = {0, 0, 255}));
  connect(sineVoltage1.plug_n, powerSensor.pc) annotation(
    Line(points = {{-92, 20}, {-42, 20}, {-42, 20}, {-42, 20}}, color = {0, 0, 255}));
  connect(lvps.pc, sineVoltage.plug_n) annotation(
    Line(points = {{-38, -16}, {-92, -16}, {-92, -16}, {-92, -16}}, color = {0, 0, 255}));
  connect(sineVoltage2.plug_p, psmv.nc) annotation(
    Line(points = {{92, 0}, {50, 0}, {50, 16}, {40, 16}}, color = {0, 0, 255}));
  connect(add.u1, powerSensor.power) annotation(
    Line(points = {{18, -56}, {-42, -56}, {-42, 10}, {-42, 10}}, color = {0, 0, 127}));
  connect(add.u2, lvps.power) annotation(
    Line(points = {{18, -68}, {-38, -68}, {-38, -26}, {-38, -26}}, color = {0, 0, 127}));
  connect(psmv.pv, psmv.nc) annotation(
    Line(points = {{30, 26}, {40, 26}, {40, 16}, {40, 16}}, color = {0, 0, 255}));
  annotation(
    uses(Modelica(version = "3.2.3")));
end TESTTRAFO;
