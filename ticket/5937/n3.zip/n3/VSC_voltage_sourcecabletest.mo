model VSC_voltage_sourcecabletest
  Modelica.Electrical.MultiPhase.Sensors.CurrentSensor Cs annotation(
    Placement(visible = true, transformation(origin = {-30, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.PotentialSensor Vs annotation(
    Placement(visible = true, transformation(origin = {-54, 18}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.Analog.Sources.SignalVoltage Vca annotation(
    Placement(visible = true, transformation(origin = {64, 60}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Electrical.Analog.Sources.SignalVoltage Vcb annotation(
    Placement(visible = true, transformation(origin = {84, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Electrical.Analog.Sources.SignalVoltage Vcc annotation(
    Placement(visible = true, transformation(origin = {108, 20}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  inner_control_pllm inner_control_pllmx annotation(
    Placement(visible = true, transformation(origin = {4, -12}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Basic.Ground ground1 annotation(
    Placement(visible = true, transformation(origin = {120, 30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.PlugToPins_n pp1 annotation(
    Placement(visible = true, transformation(origin = {46, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor Rc(R = fill(0.00598, 3)) annotation(
    Placement(visible = true, transformation(origin = {24, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Inductor Lc(L = fill(0.0000646, 3)) annotation(
    Placement(visible = true, transformation(origin = {-4, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Ref_Computation ref_Computation annotation(
    Placement(visible = true, transformation(origin = {-36, -78}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.RealExpression ia(y = inner_control_pllmx.ia) annotation(
    Placement(visible = true, transformation(origin = {204, -90}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Blocks.Sources.RealExpression ib(y = inner_control_pllmx.ib) annotation(
    Placement(visible = true, transformation(origin = {204, -104}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Blocks.Sources.RealExpression vc(y = inner_control_pllmx.vc) annotation(
    Placement(visible = true, transformation(origin = {204, -70}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Blocks.Sources.RealExpression ic(y = inner_control_pllmx.ic) annotation(
    Placement(visible = true, transformation(origin = {204, -118}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Blocks.Sources.RealExpression vb(y = inner_control_pllmx.vb) annotation(
    Placement(visible = true, transformation(origin = {204, -54}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Pac_Qac_Calculation pac_Qac_Calculation annotation(
    Placement(visible = true, transformation(origin = {158, -82}, extent = {{-12, -12}, {12, 12}}, rotation = -90)));
  Modelica.Blocks.Sources.RealExpression theta_(y = inner_control_pllmx.theta) annotation(
    Placement(visible = true, transformation(origin = {158, -42}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Blocks.Sources.RealExpression va(y = inner_control_pllmx.va) annotation(
    Placement(visible = true, transformation(origin = {204, -40}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Blocks.Sources.CombiTimeTable combiTimeTable(extrapolation = Modelica.Blocks.Types.Extrapolation.HoldLastPoint, smoothness = Modelica.Blocks.Types.Smoothness.ConstantSegments, table = [0, -300000; 0.3, -150000; 0.5, 0; 0.8, 500000; 0.9, -300000]) annotation(
    Placement(visible = true, transformation(origin = {-142, -98}, extent = {{10, -10}, {-10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.CombiTimeTable combiTimeTable1(extrapolation = Modelica.Blocks.Types.Extrapolation.HoldLastPoint, smoothness = Modelica.Blocks.Types.Smoothness.ConstantSegments, table = [0, 0; 0.3, 500000; 0.5, -100000; 0.8, -400000; 0.9, -400000]) annotation(
    Placement(visible = true, transformation(origin = {-142, -70}, extent = {{10, -10}, {-10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Sensors.VoltageSensor UABL annotation(
    Placement(visible = true, transformation(origin = {6, 78}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage(V = fill(280, 3), freqHz = fill(50, 3))  annotation(
    Placement(visible = true, transformation(origin = {-226, 46}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {-240, 12}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {-240, -14}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor resistor(R = fill(0.000005, 3))  annotation(
    Placement(visible = true, transformation(origin = {-200, 46}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Inductor inductor1(L = fill(0.336e-7, 3)) annotation(
    Placement(visible = true, transformation(origin = {-172, 46}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor resistor1(R = fill(0.00013, 3)) annotation(
    Placement(visible = true, transformation(origin = {-130, 46}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Inductor inductor(L = fill(0.336e-6, 3)) annotation(
    Placement(visible = true, transformation(origin = {-104, 46}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star2 annotation(
    Placement(visible = true, transformation(origin = {-90, -2}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.MultiPhase.Basic.Capacitor capacitor1(C = fill(0.51e-9, 3))  annotation(
    Placement(visible = true, transformation(origin = {-88, 24}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.MultiPhase.Interfaces.Plug plug annotation(
    Placement(visible = true, transformation(origin = {-152, 56}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-152, 56}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Interfaces.Plug plug1 annotation(
    Placement(visible = true, transformation(origin = {-78, 58}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-78, 58}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(Cs.plug_p, Vs.plug_p) annotation(
    Line(points = {{-40, 40}, {-40, 28}, {-54, 28}}, color = {0, 0, 255}));
  connect(Vs.phi[1], inner_control_pllmx.va) annotation(
    Line(points = {{-54, 7}, {-54, -2}, {-7, -2}}, color = {0, 0, 127}));
  connect(Vs.phi[2], inner_control_pllmx.vb) annotation(
    Line(points = {{-54, 7}, {-54, -6}, {-7, -6}}, color = {0, 0, 127}));
  connect(Vs.phi[3], inner_control_pllmx.vc) annotation(
    Line(points = {{-54, 7}, {-54, -10}, {-7, -10}}, color = {0, 0, 127}));
  connect(Cs.i[1], inner_control_pllmx.ia) annotation(
    Line(points = {{-30, 30}, {-30, -14}, {-7, -14}}, color = {0, 0, 127}));
  connect(Cs.i[2], inner_control_pllmx.ib) annotation(
    Line(points = {{-30, 30}, {-30, -18}, {-7, -18}}, color = {0, 0, 127}));
  connect(Cs.i[3], inner_control_pllmx.ic) annotation(
    Line(points = {{-30, 30}, {-30, -21}, {-7, -21}}, color = {0, 0, 127}));
  connect(Vcc.v, inner_control_pllmx.Vcref) annotation(
    Line(points = {{108, 8}, {108, -20}, {15, -20}}, color = {0, 0, 127}));
  connect(Vca.p, ground1.p) annotation(
    Line(points = {{74, 60}, {120, 60}, {120, 40}}, color = {0, 0, 255}));
  connect(Vcc.p, ground1.p) annotation(
    Line(points = {{118, 20}, {120, 20}, {120, 40}, {120, 40}}, color = {0, 0, 255}));
  connect(Vcb.p, ground1.p) annotation(
    Line(points = {{94, 40}, {120, 40}, {120, 40}, {120, 40}}, color = {0, 0, 255}));
  connect(Vcc.n, pp1.pin_n[3]) annotation(
    Line(points = {{98, 20}, {48, 20}, {48, 40}}, color = {0, 0, 255}));
  connect(Vcb.n, pp1.pin_n[2]) annotation(
    Line(points = {{74, 40}, {48, 40}}, color = {0, 0, 255}));
  connect(Vca.n, pp1.pin_n[1]) annotation(
    Line(points = {{54, 60}, {48, 60}, {48, 40}}, color = {0, 0, 255}));
  connect(pp1.plug_n, Rc.plug_n) annotation(
    Line(points = {{44, 40}, {34, 40}}, color = {0, 0, 255}));
  connect(Lc.plug_p, Cs.plug_n) annotation(
    Line(points = {{-14, 40}, {-20, 40}, {-20, 40}, {-20, 40}}, color = {0, 0, 255}));
  connect(Rc.plug_p, Lc.plug_n) annotation(
    Line(points = {{14, 40}, {6, 40}}, color = {0, 0, 255}));
  connect(inner_control_pllmx.Vbref, Vcb.v) annotation(
    Line(points = {{15, -17}, {84, -17}, {84, 28}}, color = {0, 0, 127}));
  connect(inner_control_pllmx.Varef, Vca.v) annotation(
    Line(points = {{15, -14}, {64, -14}, {64, 48}}, color = {0, 0, 127}));
  connect(ref_Computation.Vzq, inner_control_pllmx.Vzq) annotation(
    Line(points = {{-48, -70}, {-56, -70}, {-56, -64}, {24, -64}, {24, -4}, {16, -4}, {16, -4}}, color = {0, 0, 127}));
  connect(ref_Computation.idref, inner_control_pllmx.idref) annotation(
    Line(points = {{-24, -74}, {-2, -74}, {-2, -24}, {-2, -24}}, color = {0, 0, 127}));
  connect(ref_Computation.iqref, inner_control_pllmx.iqref) annotation(
    Line(points = {{-24, -82}, {10, -82}, {10, -24}, {10, -24}}, color = {0, 0, 127}));
  connect(ia.y, pac_Qac_Calculation.Ia_grid) annotation(
    Line(points = {{193, -90}, {188, -90}, {188, -84}, {171, -84}}, color = {0, 0, 127}));
  connect(vc.y, pac_Qac_Calculation.Vc_grid) annotation(
    Line(points = {{193, -70}, {188, -70}, {188, -79}, {171, -79}}, color = {0, 0, 127}));
  connect(ic.y, pac_Qac_Calculation.Ic_grid) annotation(
    Line(points = {{193, -118}, {182, -118}, {182, -91}, {171, -91}}, color = {0, 0, 127}));
  connect(vb.y, pac_Qac_Calculation.Vb_grid) annotation(
    Line(points = {{193, -54}, {184, -54}, {184, -76}, {171, -76}}, color = {0, 0, 127}));
  connect(va.y, pac_Qac_Calculation.Va_grid) annotation(
    Line(points = {{193, -40}, {182, -40}, {182, -72}, {171, -72}}, color = {0, 0, 127}));
  connect(ib.y, pac_Qac_Calculation.Ib_grid) annotation(
    Line(points = {{193, -104}, {184, -104}, {184, -88}, {171, -88}}, color = {0, 0, 127}));
  connect(theta_.y, pac_Qac_Calculation.theta) annotation(
    Line(points = {{158, -53}, {158, -68}}, color = {0, 0, 127}));
  connect(combiTimeTable1.y[1], ref_Computation.Pref) annotation(
    Line(points = {{-152, -70}, {-86, -70}, {-86, -78}, {-48, -78}, {-48, -78}}, color = {0, 0, 127}));
  connect(ref_Computation.Qref, combiTimeTable.y[1]) annotation(
    Line(points = {{-48, -86}, {-86, -86}, {-86, -98}, {-152, -98}, {-152, -98}}, color = {0, 0, 127}));
  connect(UABL.p, Vca.n) annotation(
    Line(points = {{6, 88}, {54, 88}, {54, 60}, {54, 60}, {54, 60}}, color = {0, 0, 255}));
  connect(UABL.n, pp1.pin_n[2]) annotation(
    Line(points = {{6, 68}, {48, 68}, {48, 40}, {48, 40}}, color = {0, 0, 255}));
  connect(star.plug_p, sineVoltage.plug_p) annotation(
    Line(points = {{-240, 22}, {-240, 46}, {-236, 46}}, color = {0, 0, 255}));
  connect(star.pin_n, ground.p) annotation(
    Line(points = {{-240, 2}, {-240, -4}}, color = {0, 0, 255}));
  connect(sineVoltage.plug_n, resistor.plug_p) annotation(
    Line(points = {{-216, 46}, {-210, 46}}, color = {0, 0, 255}));
  connect(resistor.plug_n, inductor1.plug_p) annotation(
    Line(points = {{-190, 46}, {-182, 46}, {-182, 46}, {-182, 46}}, color = {0, 0, 255}));
  connect(resistor1.plug_n, inductor.plug_p) annotation(
    Line(points = {{-120, 46}, {-114, 46}}, color = {0, 0, 255}));
  connect(capacitor1.plug_n, star2.plug_p) annotation(
    Line(points = {{-88, 14}, {-90, 14}, {-90, 8}}, color = {0, 0, 255}));
  connect(inductor.plug_n, plug1) annotation(
    Line(points = {{-94, 46}, {-90, 46}, {-90, 56}, {-78, 56}, {-78, 58}}));
  connect(capacitor1.plug_p, plug1) annotation(
    Line(points = {{-88, 34}, {-76, 34}, {-76, 58}, {-78, 58}}, color = {0, 0, 255}));
  connect(plug1, Cs.plug_p) annotation(
    Line(points = {{-78, 58}, {-54, 58}, {-54, 40}, {-40, 40}, {-40, 40}}, color = {0, 0, 255}));
  connect(resistor1.plug_p, plug) annotation(
    Line(points = {{-140, 46}, {-152, 46}, {-152, 56}, {-152, 56}}, color = {0, 0, 255}));
  connect(inductor1.plug_n, plug) annotation(
    Line(points = {{-162, 46}, {-152, 46}, {-152, 56}, {-152, 56}}));
  annotation(
    uses(Modelica(version = "3.2.3")),
    Diagram(graphics = {Bitmap(extent = {{-52, -84}, {-52, -84}})}, coordinateSystem(initialScale = 0.1)));
end VSC_voltage_sourcecabletest;
