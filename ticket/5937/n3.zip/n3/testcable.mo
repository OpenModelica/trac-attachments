model testcable
equation

end testcable;
