model dale
  Modelica.Electrical.Machines.BasicMachines.Components.IdealCore Three_winding(n12 = 100, n13 = 100)  annotation(
    Placement(visible = true, transformation(origin = {-1, 7}, extent = {{-17, -17}, {17, 17}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {0, -42}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {0, -72}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor R1(R = fill(0.5, 3))  annotation(
    Placement(visible = true, transformation(origin = {-50, 20}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Inductor L1(L = fill(0.004, 3))  annotation(
    Placement(visible = true, transformation(origin = {-72, 22}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor R2(R = fill(0.5, 3))  annotation(
    Placement(visible = true, transformation(origin = {44, 26}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor R3(R = fill(3, 3))  annotation(
    Placement(visible = true, transformation(origin = {46, 2}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Inductor L2(L = fill(0.02, 3))  annotation(
    Placement(visible = true, transformation(origin = {66, 26}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Inductor L3(L = fill(0.02, 3))  annotation(
    Placement(visible = true, transformation(origin = {64, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Basic.Ground ground1 annotation(
    Placement(visible = true, transformation(origin = {110, -44}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star1 annotation(
    Placement(visible = true, transformation(origin = {110, -18}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.MultiPhase.Sensors.PotentialSensor LVP annotation(
    Placement(visible = true, transformation(origin = {66, 68}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage(V = fill(400, 3), freqHz = fill(50, 3)) annotation(
    Placement(visible = true, transformation(origin = {104, 24}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage1(V = fill(400, 3), freqHz = fill(50, 3)) annotation(
    Placement(visible = true, transformation(origin = {104, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.PowerSensor powerSensor1 annotation(
    Placement(visible = true, transformation(origin = {84, 42}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage2(V = fill(40000, 3), freqHz = fill(50, 3))  annotation(
    Placement(visible = true, transformation(origin = {-130, 26}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Basic.Ground ground2 annotation(
    Placement(visible = true, transformation(origin = {-140, -26}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star2 annotation(
    Placement(visible = true, transformation(origin = {-140, 2}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.MultiPhase.Sensors.CurrentSensor MV annotation(
    Placement(visible = true, transformation(origin = {-28, 10}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.CurrentSensor LV annotation(
    Placement(visible = true, transformation(origin = {36, -22}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  trafo trafo annotation(
    Placement(visible = true, transformation(origin = {-68, 60}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  iPSL.Electrical.Branches.PSAT.ThreeWindingTransformer.ThreeWindingTransformer threeWindingTransformer annotation(
    Placement(visible = true, transformation(origin = {-150, 72}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(ground.p, star.pin_n) annotation(
    Line(points = {{0, -62}, {0, -62}, {0, -52}, {0, -52}}, color = {0, 0, 255}));
  connect(Three_winding.plug_n1, star.plug_p) annotation(
    Line(points = {{-18, -10}, {-18, -20}, {0, -20}, {0, -32}}, color = {0, 0, 255}));
  connect(Three_winding.plug_n3, star.plug_p) annotation(
    Line(points = {{16, -10}, {16, -20}, {0, -20}, {0, -32}}, color = {0, 0, 255}));
  connect(L1.plug_n, R1.plug_p) annotation(
    Line(points = {{-62, 22}, {-58, 22}, {-58, 20}, {-60, 20}}, color = {0, 0, 255}));
  connect(Three_winding.plug_p3, R3.plug_p) annotation(
    Line(points = {{16, 0}, {25, 0}, {25, 2}, {36, 2}}));
  connect(Three_winding.plug_n2, star.plug_p) annotation(
    Line(points = {{16, 14}, {16, 6}, {0, 6}, {0, -32}}, color = {0, 0, 255}));
  connect(R2.plug_n, L2.plug_p) annotation(
    Line(points = {{54, 26}, {56, 26}}, color = {0, 0, 255}));
  connect(R3.plug_n, L3.plug_p) annotation(
    Line(points = {{56, 2}, {56, 1}, {54, 1}, {54, 0}}, color = {0, 0, 255}));
  connect(star1.pin_n, ground1.p) annotation(
    Line(points = {{110, -28}, {110, -28}, {110, -34}, {110, -34}}, color = {0, 0, 255}));
  connect(LVP.plug_p, Three_winding.plug_p2) annotation(
    Line(points = {{56, 68}, {14, 68}, {14, 24}, {16, 24}}, color = {0, 0, 255}));
  connect(sineVoltage.plug_n, star1.plug_p) annotation(
    Line(points = {{114, 24}, {114, 8}, {110, 8}, {110, -8}}, color = {0, 0, 255}));
  connect(L3.plug_n, sineVoltage1.plug_p) annotation(
    Line(points = {{74, 0}, {94, 0}, {94, 0}, {94, 0}}, color = {0, 0, 255}));
  connect(powerSensor1.pc, L2.plug_n) annotation(
    Line(points = {{74, 42}, {74, 34}, {76, 34}, {76, 26}}, color = {0, 0, 255}));
  connect(powerSensor1.pv, powerSensor1.nc) annotation(
    Line(points = {{84, 52}, {94, 52}, {94, 42}, {94, 42}}, color = {0, 0, 255}));
  connect(powerSensor1.nv, star1.plug_p) annotation(
    Line(points = {{84, 32}, {84, 32}, {84, -8}, {110, -8}, {110, -8}}, color = {0, 0, 255}));
  connect(sineVoltage.plug_p, powerSensor1.nc) annotation(
    Line(points = {{94, 24}, {94, 24}, {94, 42}, {94, 42}}, color = {0, 0, 255}));
  connect(sineVoltage2.plug_p, star2.plug_p) annotation(
    Line(points = {{-140, 26}, {-140, 26}, {-140, 12}, {-140, 12}}, color = {0, 0, 255}));
  connect(star2.pin_n, ground2.p) annotation(
    Line(points = {{-140, -8}, {-140, -8}, {-140, -16}, {-140, -16}}, color = {0, 0, 255}));
  connect(R1.plug_n, MV.plug_p) annotation(
    Line(points = {{-40, 20}, {-38, 20}, {-38, 10}, {-38, 10}}, color = {0, 0, 255}));
  connect(MV.plug_n, Three_winding.plug_p1) annotation(
    Line(points = {{-18, 10}, {-18, 10}, {-18, 24}, {-18, 24}}, color = {0, 0, 255}));
  connect(Three_winding.plug_p2, LV.plug_p) annotation(
    Line(points = {{16, 24}, {26, 24}, {26, -22}, {26, -22}}, color = {0, 0, 255}));
  connect(LV.plug_n, R2.plug_p) annotation(
    Line(points = {{46, -22}, {34, -22}, {34, 26}, {34, 26}}, color = {0, 0, 255}));
  connect(L1.plug_p, sineVoltage2.plug_n) annotation(
    Line(points = {{-82, 22}, {-120, 22}, {-120, 26}, {-120, 26}}, color = {0, 0, 255}));
  annotation(
    uses(Modelica(version = "3.2.3"), iPSL(version = "1.1.0")));
end dale;
