block DC_ControlP
  Modelica.Blocks.Math.Feedback feedback annotation(
    Placement(visible = true, transformation(origin = {-62, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput E_ref annotation(
    Placement(visible = true, transformation(origin = {-114, 0}, extent = {{-14, -14}, {14, 14}}, rotation = 0), iconTransformation(origin = {-86, 0}, extent = {{-14, -14}, {14, 14}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput E_dcsource annotation(
    Placement(visible = true, transformation(origin = {-62, -82}, extent = {{-20, -20}, {20, 20}}, rotation = 90), iconTransformation(origin = {-40, -82}, extent = {{-14, -14}, {14, 14}}, rotation = 90)));
  Modelica.Blocks.Math.Add add(k1 = +1)  annotation(
    Placement(visible = true, transformation(origin = {42, 6}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Pdc "Power available from source, mesured before the capacitor" annotation(
    Placement(visible = true, transformation(origin = {8, 78}, extent = {{-20, -20}, {20, 20}}, rotation = -90), iconTransformation(origin = {43, 81}, extent = {{-13, -13}, {13, 13}}, rotation = -90)));
  Modelica.Blocks.Interfaces.RealOutput Iq_ref annotation(
    Placement(visible = true, transformation(origin = {126, -2}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {88, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  P_a_I p_a_I annotation(
    Placement(visible = true, transformation(origin = {91, -3}, extent = {{-13, -13}, {13, 13}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Vq_grid annotation(
    Placement(visible = true, transformation(origin = {24, -82}, extent = {{-20, -20}, {20, 20}}, rotation = 90), iconTransformation(origin = {40, -82}, extent = {{-14, -14}, {14, 14}}, rotation = 90)));
  E2 e2 annotation(
    Placement(visible = true, transformation(origin = {-86, 4.44089e-16}, extent = {{-6, -6}, {6, 6}}, rotation = 180)));
  E2 e21 annotation(
    Placement(visible = true, transformation(origin = {-62, -32}, extent = {{-6, -6}, {6, 6}}, rotation = -90)));
  Modelica.Blocks.Math.Gain kdc(k = 7.65)  annotation(
    Placement(visible = true, transformation(origin = {-22, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(Pdc, add.u1) annotation(
    Line(points = {{8, 78}, {8, 12}, {30, 12}}, color = {0, 0, 127}));
  connect(Vq_grid, p_a_I.u2) annotation(
    Line(points = {{24, -82}, {24, -12}, {75, -12}, {75, -11}}, color = {0, 0, 127}));
  connect(add.y, p_a_I.u1) annotation(
    Line(points = {{53, 6}, {75, 6}, {75, 5}}, color = {0, 0, 127}));
  connect(p_a_I.y, Iq_ref) annotation(
    Line(points = {{105, -3}, {104, -3}, {104, -2}, {126, -2}}, color = {0, 0, 127}));
  connect(kdc.u, feedback.y) annotation(
    Line(points = {{-34, 0}, {-53, 0}}, color = {0, 0, 127}));
  connect(kdc.y, add.u2) annotation(
    Line(points = {{-11, 0}, {30, 0}}, color = {0, 0, 127}));
  connect(E_ref, e2.u) annotation(
    Line(points = {{-114, 0}, {-93, 0}}, color = {0, 0, 127}));
  connect(e2.y, feedback.u1) annotation(
    Line(points = {{-79, 0}, {-70, 0}}, color = {0, 0, 127}));
  connect(e21.y, feedback.u2) annotation(
    Line(points = {{-62, -26}, {-62, -26}, {-62, -8}, {-62, -8}}, color = {0, 0, 127}));
  connect(e21.u, E_dcsource) annotation(
    Line(points = {{-62, -40}, {-60, -40}, {-60, -82}, {-62, -82}}, color = {0, 0, 127}));
  annotation(
    uses(Modelica(version = "3.2.3")),
    Icon(graphics = {Rectangle(origin = {3, 0}, extent = {{-75, 68}, {75, -68}}), Text(origin = {4, 1}, extent = {{-52, 29}, {52, -29}}, textString = "DC V CONTROL")}, coordinateSystem(initialScale = 0.1)));
end DC_ControlP;
