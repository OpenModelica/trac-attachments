model Ref_Q_DC
  QRef_Computation qRef_Computation annotation(
    Placement(visible = true, transformation(origin = {-1, -49}, extent = {{-19, -19}, {19, 19}}, rotation = 0)));
  DC_ControlP dC_ControlP annotation(
    Placement(visible = true, transformation(origin = {2.22045e-16, 48}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput qref annotation(
    Placement(visible = true, transformation(origin = {-120, -74}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, -100}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Vq annotation(
    Placement(visible = true, transformation(origin = {-120, -38}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, -50}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Pdc annotation(
    Placement(visible = true, transformation(origin = {-120, 88}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, 100}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Eref annotation(
    Placement(visible = true, transformation(origin = {-120, 48}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, 52}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Iqref annotation(
    Placement(visible = true, transformation(origin = {100, 50}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {120, 60}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Idref annotation(
    Placement(visible = true, transformation(origin = {100, -50}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {120, -62}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput E2source annotation(
    Placement(visible = true, transformation(origin = {-120, 6}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, 0}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
equation
  connect(dC_ControlP.Iq_ref, Iqref) annotation(
    Line(points = {{18, 48}, {110, 48}, {110, 50}, {100, 50}}, color = {0, 0, 127}));
  connect(Vq, qRef_Computation.Vzq) annotation(
    Line(points = {{-120, -38}, {-24, -38}}, color = {0, 0, 127}));
  connect(Vq, dC_ControlP.Vq_grid) annotation(
    Line(points = {{-120, -38}, {-50, -38}, {-50, 26}, {8, 26}, {8, 32}}, color = {0, 0, 127}));
  connect(Pdc, dC_ControlP.Pdc) annotation(
    Line(points = {{-120, 88}, {9, 88}, {9, 64}}, color = {0, 0, 127}));
  
  connect(qref, qRef_Computation.Qref) annotation(
    Line(points = {{-120, -74}, {-48, -74}, {-48, -60}, {-24, -60}}, color = {0, 0, 127}));
 
  connect(qRef_Computation.idref, Idref) annotation(
    Line(points = {{20, -48}, {106, -48}, {106, -50}, {100, -50}}, color = {0, 0, 127}));
  connect(Eref, dC_ControlP.E_ref) annotation(
    Line(points = {{-120, 48}, {-18, 48}, {-18, 48}, {-18, 48}}, color = {0, 0, 127}));
 connect(E2source, dC_ControlP.E_dcsource) annotation(
    Line(points = {{-120, 6}, {-8, 6}, {-8, 32}, {-8, 32}}, color = {0, 0, 127}));

annotation(
    uses(Modelica(version = "3.2.3")));
end Ref_Q_DC;
