model VSC_voltage_sourcex_invmod
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {-138, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.CurrentSensor Cs annotation(
    Placement(visible = true, transformation(origin = {-30, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.PotentialSensor Vs annotation(
    Placement(visible = true, transformation(origin = {-54, 18}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.Analog.Sources.SineVoltage Vza(V = 326, freqHz = 50)  annotation(
    Placement(visible = true, transformation(origin = {-122, 56}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Sources.SineVoltage Vzb(V = 326, freqHz = 50, phase = -2.0944)  annotation(
    Placement(visible = true, transformation(origin = {-122, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Sources.SineVoltage Vzc(V = 326, freqHz = 50, phase = 2.0944)  annotation(
    Placement(visible = true, transformation(origin = {-122, 24}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.PlugToPins_p pp annotation(
    Placement(visible = true, transformation(origin = {-102, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Electrical.Analog.Sources.SignalVoltage Vca annotation(
    Placement(visible = true, transformation(origin = {74, 60}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Electrical.Analog.Sources.SignalVoltage Vcb annotation(
    Placement(visible = true, transformation(origin = {92, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Electrical.Analog.Sources.SignalVoltage Vcc annotation(
    Placement(visible = true, transformation(origin = {108, 20}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Electrical.Analog.Basic.Ground ground1 annotation(
    Placement(visible = true, transformation(origin = {120, 30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.PlugToPins_n pp1 annotation(
    Placement(visible = true, transformation(origin = {44, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor Rc(R = fill(0.5, 3)) annotation(
    Placement(visible = true, transformation(origin = {24, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Inductor Lc(L = fill(0.0051, 3)) annotation(
    Placement(visible = true, transformation(origin = {-4, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Ref_Computation ref_Computation annotation(
    Placement(visible = true, transformation(origin = {-36, -78}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.CombiTimeTable PRef(extrapolation = Modelica.Blocks.Types.Extrapolation.HoldLastPoint, smoothness = Modelica.Blocks.Types.Smoothness.ConstantSegments, table = [0, -3000; 0.3, -6000; 0.5, -1000; 0.8, -7000])  annotation(
    Placement(visible = true, transformation(origin = {-114, -66}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.CombiTimeTable QRref(extrapolation = Modelica.Blocks.Types.Extrapolation.HoldLastPoint, smoothness = Modelica.Blocks.Types.Smoothness.ConstantSegments, table = [0, 0])  annotation(
    Placement(visible = true, transformation(origin = {-114, -98}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.RealExpression ia(y = inner_control_pll.ia) annotation(
    Placement(visible = true, transformation(origin = {204, -90}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Blocks.Sources.RealExpression ib(y = inner_control_pll.ib) annotation(
    Placement(visible = true, transformation(origin = {204, -104}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Blocks.Sources.RealExpression vc(y = inner_control_pll.vc) annotation(
    Placement(visible = true, transformation(origin = {204, -70}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Blocks.Sources.RealExpression ic(y = inner_control_pll.ic) annotation(
    Placement(visible = true, transformation(origin = {204, -118}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Blocks.Sources.RealExpression vb(y = inner_control_pll.vb) annotation(
    Placement(visible = true, transformation(origin = {204, -54}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Pac_Qac_Calculation pac_Qac_Calculation annotation(
    Placement(visible = true, transformation(origin = {158, -82}, extent = {{-12, -12}, {12, 12}}, rotation = -90)));
  Modelica.Blocks.Sources.RealExpression theta_(y = inner_control_pll.theta) annotation(
    Placement(visible = true, transformation(origin = {158, -42}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Blocks.Sources.RealExpression va(y = inner_control_pll.va) annotation(
    Placement(visible = true, transformation(origin = {204, -40}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Electrical.Analog.Sensors.CurrentSensor icm annotation(
    Placement(visible = true, transformation(origin = {54, 20}, extent = {{-6, -6}, {6, 6}}, rotation = 0)));
  Modelica.Electrical.Analog.Sensors.CurrentSensor iameas annotation(
    Placement(visible = true, transformation(origin = {54, 60}, extent = {{-6, -6}, {6, 6}}, rotation = 0)));
  Modelica.Electrical.Analog.Sensors.VoltageSensor vab annotation(
    Placement(visible = true, transformation(origin = {64, 50}, extent = {{-6, -6}, {6, 6}}, rotation = -90)));
  Modelica.Electrical.Analog.Sensors.VoltageSensor vbc annotation(
    Placement(visible = true, transformation(origin = {64, 30}, extent = {{-6, -6}, {6, 6}}, rotation = -90)));
  invmodel invmodelx annotation(
    Placement(visible = true, transformation(origin = {150, 84}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.RealExpression Ia(y = iameas.i)  annotation(
    Placement(visible = true, transformation(origin = {194, 92}, extent = {{10, -10}, {-10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.RealExpression Ic(y = icm.i)  annotation(
    Placement(visible = true, transformation(origin = {194, 58}, extent = {{10, -10}, {-10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.RealExpression Vab(y = vab.v)  annotation(
    Placement(visible = true, transformation(origin = {194, 108}, extent = {{10, -10}, {-10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.RealExpression Vbc(y = vbc.v)  annotation(
    Placement(visible = true, transformation(origin = {194, 74}, extent = {{10, -10}, {-10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Basic.Capacitor C(C = 0.01)  annotation(
    Placement(visible = true, transformation(origin = {120, 84}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.Analog.Sources.ConstantVoltage Vdc(V = 800)  annotation(
    Placement(visible = true, transformation(origin = {92, 84}, extent = {{-10, 10}, {10, -10}}, rotation = -90)));
  Modelica.Blocks.Sources.RealExpression vzq(y = inner_control_pll.Vzq)  annotation(
    Placement(visible = true, transformation(origin = {-68, -70}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  inner_control_pllm inner_control_pll annotation(
    Placement(visible = true, transformation(origin = {14, -36}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.RealExpression t(y = inner_control_pll.theta) annotation(
    Placement(visible = true, transformation(origin = {50, -90}, extent = {{-10, -10}, {10, 10}}, rotation = 90)));
  Modelica.Blocks.Sources.RealExpression t_(y = inner_control_pll.theta) annotation(
    Placement(visible = true, transformation(origin = {88, -90}, extent = {{-10, -10}, {10, 10}}, rotation = 90)));
  Modelica.Blocks.Sources.RealExpression realExpression1(y = inner_control_pll.theta) annotation(
    Placement(visible = true, transformation(origin = {50, -90}, extent = {{-10, -10}, {10, 10}}, rotation = 90)));
  Modelica.Blocks.Sources.RealExpression udc(y = Vdc.v) annotation(
    Placement(visible = true, transformation(origin = {70, -90}, extent = {{-10, -10}, {10, 10}}, rotation = 90)));
  inverterMod inverterModd annotation(
    Placement(visible = true, transformation(origin = {88, -58}, extent = {{-8, -8}, {8, 8}}, rotation = 0)));
  Park park annotation(
    Placement(visible = true, transformation(origin = {50, -58}, extent = {{-8, -8}, {8, 8}}, rotation = 0)));
  inner_control_pllmxinv inner_control_pllmxinvv annotation(
    Placement(visible = true, transformation(origin = {12, -120}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  inverterMod inverterModds annotation(
    Placement(visible = true, transformation(origin = {54, -126}, extent = {{-8, -8}, {8, 8}}, rotation = 0)));
  Modelica.Blocks.Sources.RealExpression realExpression(y = inner_control_pll.theta) annotation(
    Placement(visible = true, transformation(origin = {54, -156}, extent = {{-10, -10}, {10, 10}}, rotation = 90)));
equation
  connect(Cs.plug_p, Vs.plug_p) annotation(
    Line(points = {{-40, 40}, {-40, 28}, {-54, 28}}, color = {0, 0, 255}));
  connect(Vza.p, ground.p) annotation(
    Line(points = {{-132, 56}, {-138, 56}, {-138, 10}}, color = {0, 0, 255}));
  connect(Vzb.p, ground.p) annotation(
    Line(points = {{-132, 40}, {-138, 40}, {-138, 10}}, color = {0, 0, 255}));
  connect(Vzc.p, ground.p) annotation(
    Line(points = {{-132, 24}, {-138, 24}, {-138, 10}}, color = {0, 0, 255}));
  connect(pp.pin_p[1], Vza.n) annotation(
    Line(points = {{-104, 40}, {-104, 56}, {-112, 56}}, color = {0, 0, 255}));
  connect(pp.pin_p[2], Vzb.n) annotation(
    Line(points = {{-104, 40}, {-112, 40}}, color = {0, 0, 255}));
  connect(pp.pin_p[3], Vzc.n) annotation(
    Line(points = {{-104, 40}, {-104, 24}, {-112, 24}}, color = {0, 0, 255}));
  connect(Vca.p, ground1.p) annotation(
    Line(points = {{84, 60}, {120, 60}, {120, 40}}, color = {0, 0, 255}));
  connect(Vcc.p, ground1.p) annotation(
    Line(points = {{118, 20}, {120, 20}, {120, 40}, {120, 40}}, color = {0, 0, 255}));
  connect(Vcb.p, ground1.p) annotation(
    Line(points = {{102, 40}, {120, 40}}, color = {0, 0, 255}));
  connect(Vcb.n, pp1.pin_n[2]) annotation(
    Line(points = {{82, 40}, {46, 40}}, color = {0, 0, 255}));
  connect(pp1.plug_n, Rc.plug_n) annotation(
    Line(points = {{42, 40}, {34, 40}}, color = {0, 0, 255}));
  connect(Lc.plug_p, Cs.plug_n) annotation(
    Line(points = {{-14, 40}, {-20, 40}, {-20, 40}, {-20, 40}}, color = {0, 0, 255}));
  connect(Rc.plug_p, Lc.plug_n) annotation(
    Line(points = {{14, 40}, {6, 40}}, color = {0, 0, 255}));
  connect(pp.plug_p, Cs.plug_p) annotation(
    Line(points = {{-100, 40}, {-40, 40}, {-40, 40}, {-40, 40}}, color = {0, 0, 255}));
  connect(PRef.y[1], ref_Computation.Pref) annotation(
    Line(points = {{-103, -66}, {-86, -66}, {-86, -78}, {-48, -78}}, color = {0, 0, 127}));
  connect(QRref.y[1], ref_Computation.Qref) annotation(
    Line(points = {{-102, -98}, {-86, -98}, {-86, -86}, {-48, -86}, {-48, -86}}, color = {0, 0, 127}));
  connect(ia.y, pac_Qac_Calculation.Ia_grid) annotation(
    Line(points = {{193, -90}, {188, -90}, {188, -84}, {171, -84}}, color = {0, 0, 127}));
  connect(vc.y, pac_Qac_Calculation.Vc_grid) annotation(
    Line(points = {{193, -70}, {188, -70}, {188, -79}, {171, -79}}, color = {0, 0, 127}));
  connect(ic.y, pac_Qac_Calculation.Ic_grid) annotation(
    Line(points = {{193, -118}, {182, -118}, {182, -91}, {171, -91}}, color = {0, 0, 127}));
  connect(vb.y, pac_Qac_Calculation.Vb_grid) annotation(
    Line(points = {{193, -54}, {184, -54}, {184, -76}, {171, -76}}, color = {0, 0, 127}));
  connect(va.y, pac_Qac_Calculation.Va_grid) annotation(
    Line(points = {{193, -40}, {182, -40}, {182, -72}, {171, -72}}, color = {0, 0, 127}));
  connect(ib.y, pac_Qac_Calculation.Ib_grid) annotation(
    Line(points = {{193, -104}, {184, -104}, {184, -88}, {171, -88}}, color = {0, 0, 127}));
  connect(theta_.y, pac_Qac_Calculation.theta) annotation(
    Line(points = {{158, -53}, {158, -68}}, color = {0, 0, 127}));
  connect(pp1.pin_n[3], icm.p) annotation(
    Line(points = {{46, 40}, {46, 20}, {48, 20}}, color = {0, 0, 255}));
  connect(icm.n, Vcc.n) annotation(
    Line(points = {{60, 20}, {98, 20}}, color = {0, 0, 255}));
  connect(iameas.n, Vca.n) annotation(
    Line(points = {{60, 60}, {64, 60}, {64, 60}, {64, 60}}, color = {0, 0, 255}));
  connect(iameas.p, pp1.pin_n[1]) annotation(
    Line(points = {{48, 60}, {46, 60}, {46, 40}, {46, 40}}, color = {0, 0, 255}));
  connect(Vca.n, vab.p) annotation(
    Line(points = {{64, 60}, {64, 60}, {64, 56}, {64, 56}, {64, 56}}, color = {0, 0, 255}));
  connect(vab.n, Vcb.n) annotation(
    Line(points = {{64, 44}, {64, 44}, {64, 40}, {82, 40}, {82, 40}}, color = {0, 0, 255}));
  connect(vbc.p, Vcb.n) annotation(
    Line(points = {{64, 36}, {64, 36}, {64, 40}, {82, 40}, {82, 40}}, color = {0, 0, 255}));
  connect(vbc.n, Vcc.n) annotation(
    Line(points = {{64, 24}, {64, 24}, {64, 20}, {98, 20}, {98, 20}}, color = {0, 0, 255}));
  connect(Ic.y, invmodelx.Ic) annotation(
    Line(points = {{183, 58}, {176, 58}, {176, 76}, {162, 76}}, color = {0, 0, 127}));
  connect(Vab.y, invmodelx.Vab) annotation(
    Line(points = {{183, 108}, {174, 108}, {174, 92}, {162, 92}}, color = {0, 0, 127}));
  connect(Ia.y, invmodelx.Ia) annotation(
    Line(points = {{182, 92}, {180, 92}, {180, 86}, {162, 86}, {162, 86}}, color = {0, 0, 127}));
  connect(Vbc.y, invmodelx.Vbc) annotation(
    Line(points = {{182, 74}, {180, 74}, {180, 82}, {162, 82}, {162, 82}}, color = {0, 0, 127}));
  connect(C.p, invmodelx.D) annotation(
    Line(points = {{120, 94}, {140, 94}, {140, 92}, {140, 92}}, color = {0, 0, 255}));
  connect(invmodelx.C, C.n) annotation(
    Line(points = {{140, 76}, {140, 76}, {140, 74}, {120, 74}, {120, 74}}, color = {0, 0, 255}));
  connect(Vdc.p, C.p) annotation(
    Line(points = {{92, 94}, {120, 94}, {120, 94}, {120, 94}}, color = {0, 0, 255}));
  connect(C.n, Vdc.n) annotation(
    Line(points = {{120, 74}, {92, 74}, {92, 74}, {92, 74}}, color = {0, 0, 255}));
  connect(vzq.y, ref_Computation.Vzq) annotation(
    Line(points = {{-56, -70}, {-50, -70}, {-50, -70}, {-48, -70}}, color = {0, 0, 127}));
  connect(inner_control_pll.idref, ref_Computation.idref) annotation(
    Line(points = {{8, -48}, {8, -48}, {8, -74}, {-24, -74}, {-24, -74}}, color = {0, 0, 127}));
  connect(ref_Computation.iqref, inner_control_pll.iqref) annotation(
    Line(points = {{-24, -82}, {20, -82}, {20, -48}, {20, -48}}, color = {0, 0, 127}));
  connect(inner_control_pll.ic, Cs.i[3]) annotation(
    Line(points = {{2, -46}, {-30, -46}, {-30, 30}, {-30, 30}}, color = {0, 0, 127}));
  connect(inner_control_pll.ib, Cs.i[2]) annotation(
    Line(points = {{2, -42}, {-30, -42}, {-30, 30}, {-30, 30}}, color = {0, 0, 127}));
  connect(inner_control_pll.ia, Cs.i[1]) annotation(
    Line(points = {{2, -38}, {-30, -38}, {-30, 30}, {-30, 30}}, color = {0, 0, 127}));
  connect(Vs.phi[1], inner_control_pll.va) annotation(
    Line(points = {{-54, 8}, {-54, 8}, {-54, -26}, {2, -26}, {2, -26}}, color = {0, 0, 127}));
  connect(inner_control_pll.vb, Vs.phi[2]) annotation(
    Line(points = {{2, -30}, {-54, -30}, {-54, 8}, {-54, 8}}, color = {0, 0, 127}));
  connect(inner_control_pll.vc, Vs.phi[3]) annotation(
    Line(points = {{2, -34}, {-54, -34}, {-54, 8}, {-54, 8}}, color = {0, 0, 127}));
  connect(udc.y, inverterModd.u) annotation(
    Line(points = {{70, -78}, {70, -78}, {70, -58}, {78, -58}, {78, -58}}, color = {0, 0, 127}));
  connect(t_.y, inverterModd.theta) annotation(
    Line(points = {{88, -78}, {88, -78}, {88, -68}, {88, -68}}, color = {0, 0, 127}));
  connect(park.c, inner_control_pll.Vcref) annotation(
    Line(points = {{40, -62}, {28, -62}, {28, -44}, {26, -44}, {26, -44}}, color = {0, 0, 127}));
  connect(park.b, inner_control_pll.Vbref) annotation(
    Line(points = {{40, -58}, {30, -58}, {30, -42}, {26, -42}, {26, -42}}, color = {0, 0, 127}));
  connect(park.a, inner_control_pll.Varef) annotation(
    Line(points = {{40, -54}, {32, -54}, {32, -38}, {26, -38}, {26, -38}}, color = {0, 0, 127}));
  connect(inverterModd.vdref, park.d) annotation(
    Line(points = {{78, -62}, {70, -62}, {70, -60}, {58, -60}, {58, -60}}, color = {0, 0, 127}));
  connect(park.q, inverterModd.vqref) annotation(
    Line(points = {{58, -56}, {70, -56}, {70, -52}, {78, -52}, {78, -54}}, color = {0, 0, 127}));
  connect(t.y, park.theta) annotation(
    Line(points = {{50, -78}, {50, -78}, {50, -68}, {50, -68}}, color = {0, 0, 127}));
  connect(Cs.i[1], inner_control_pllmxinvv.ia) annotation(
    Line(points = {{-30, 30}, {-30, 30}, {-30, -122}, {0, -122}, {0, -122}}, color = {0, 0, 127}));
  connect(Cs.i[2], inner_control_pllmxinvv.ib) annotation(
    Line(points = {{-30, 30}, {-30, 30}, {-30, -126}, {0, -126}, {0, -126}}, color = {0, 0, 127}));
  connect(Cs.i[3], inner_control_pllmxinvv.ic) annotation(
    Line(points = {{-30, 30}, {-30, 30}, {-30, -130}, {0, -130}, {0, -130}}, color = {0, 0, 127}));
  connect(inner_control_pllmxinvv.vc, Vs.phi[3]) annotation(
    Line(points = {{0, -118}, {-54, -118}, {-54, 8}, {-54, 8}}, color = {0, 0, 127}));
  connect(inner_control_pllmxinvv.vb, Vs.phi[2]) annotation(
    Line(points = {{0, -114}, {-54, -114}, {-54, 8}, {-54, 8}}, color = {0, 0, 127}));
  connect(inner_control_pllmxinvv.va, Vs.phi[1]) annotation(
    Line(points = {{0, -110}, {-54, -110}, {-54, 8}, {-54, 8}, {-54, 8}, {-54, 8}}, color = {0, 0, 127}));
  connect(inner_control_pllmxinvv.idref, ref_Computation.idref) annotation(
    Line(points = {{6, -132}, {6, -132}, {6, -142}, {-16, -142}, {-16, -74}, {-24, -74}, {-24, -74}}, color = {0, 0, 127}));
  connect(ref_Computation.iqref, inner_control_pllmxinvv.iqref) annotation(
    Line(points = {{-24, -82}, {-20, -82}, {-20, -148}, {18, -148}, {18, -132}, {18, -132}}, color = {0, 0, 127}));
  connect(realExpression.y, inverterModds.theta) annotation(
    Line(points = {{54, -144}, {54, -144}, {54, -136}, {54, -136}}, color = {0, 0, 127}));
  connect(inner_control_pllmxinvv.Vd, inverterModds.vdref) annotation(
    Line(points = {{24, -122}, {30, -122}, {30, -130}, {44, -130}, {44, -130}}, color = {0, 0, 127}));
  connect(inner_control_pllmxinvv.Vq, inverterModds.vqref) annotation(
    Line(points = {{24, -128}, {32, -128}, {32, -122}, {44, -122}, {44, -122}}, color = {0, 0, 127}));
  connect(udc.y, inverterModds.u) annotation(
    Line(points = {{70, -78}, {70, -78}, {70, -74}, {34, -74}, {34, -126}, {44, -126}, {44, -126}}, color = {0, 0, 127}));
  connect(inner_control_pll.Varef, Vca.v) annotation(
    Line(points = {{26, -38}, {74, -38}, {74, 48}, {74, 48}}, color = {0, 0, 127}));
  connect(inner_control_pll.Vbref, Vcb.v) annotation(
    Line(points = {{26, -42}, {92, -42}, {92, 28}, {92, 28}}, color = {0, 0, 127}));
  connect(inner_control_pll.Vcref, Vcc.v) annotation(
    Line(points = {{26, -44}, {108, -44}, {108, 8}, {108, 8}}, color = {0, 0, 127}));
  annotation(
    uses(Modelica(version = "3.2.3"), iPSL(version = "1.1.0"), PowerSystems(version = "1.0.0")),
    Diagram(graphics = {Bitmap(extent = {{-52, -84}, {-52, -84}})}, coordinateSystem(initialScale = 0.1)));
end VSC_voltage_sourcex_invmod;
