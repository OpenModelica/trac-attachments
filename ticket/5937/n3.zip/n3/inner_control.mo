model inner_control
  Inner_Current_Controller inner_Current_Controller annotation(
    Placement(visible = true, transformation(origin = {13, -67}, extent = {{-47, -47}, {47, 47}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput va annotation(
    Placement(visible = true, transformation(origin = {-120, 106}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-112, 98}, extent = {{-12, -12}, {12, 12}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput vb annotation(
    Placement(visible = true, transformation(origin = {-120, 76}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-113, 61}, extent = {{-13, -13}, {13, 13}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput vc annotation(
    Placement(visible = true, transformation(origin = {-120, 48}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-113, 21}, extent = {{-13, -13}, {13, 13}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput ia annotation(
    Placement(visible = true, transformation(origin = {-120, 16}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-113, -21}, extent = {{-13, -13}, {13, 13}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput ib annotation(
    Placement(visible = true, transformation(origin = {-120, -12}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-113, -57}, extent = {{-13, -13}, {13, 13}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput ic annotation(
    Placement(visible = true, transformation(origin = {-120, -40}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-114, -92}, extent = {{-12, -12}, {12, 12}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Iqref annotation(
    Placement(visible = true, transformation(origin = {-120, -96}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-60, -122}, extent = {{-20, -20}, {20, 20}}, rotation = 90)));
  Modelica.Blocks.Interfaces.RealInput Idref annotation(
    Placement(visible = true, transformation(origin = {-120, -68}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {60, -122}, extent = {{-20, -20}, {20, 20}}, rotation = 90)));
  Modelica.Blocks.Interfaces.RealOutput theta annotation(
    Placement(visible = true, transformation(origin = {110, 36}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, 36}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput Vzq annotation(
    Placement(visible = true, transformation(origin = {110, 82}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, 82}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Park parkI annotation(
    Placement(visible = true, transformation(origin = {-64, -12}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Park ParkV annotation(
    Placement(visible = true, transformation(origin = {-18, 32}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  AntiPark antiPark annotation(
    Placement(visible = true, transformation(origin = {82, -60}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput Varef annotation(
    Placement(visible = true, transformation(origin = {118, -22}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {112, -18}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput Vbref annotation(
    Placement(visible = true, transformation(origin = {118, -60}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {112, -50}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput Vcref annotation(
    Placement(visible = true, transformation(origin = {116, -100}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {112, -82}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  PLL pll annotation(
    Placement(visible = true, transformation(origin = {-8, 76}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(ia, parkI.a) annotation(
    Line(points = {{-120, 16}, {-88, 16}, {-88, -8}, {-75, -8}}, color = {0, 0, 127}));
  connect(ib, parkI.b) annotation(
    Line(points = {{-120, -12}, {-75, -12}}, color = {0, 0, 127}));
  connect(ic, parkI.c) annotation(
    Line(points = {{-120, -40}, {-84, -40}, {-84, -16}, {-75, -16}}, color = {0, 0, 127}));
  connect(Idref, inner_Current_Controller.Id_ref) annotation(
    Line(points = {{-120, -68}, {-44, -68}, {-44, -40}, {-28, -40}, {-28, -40}}, color = {0, 0, 127}));
  connect(Iqref, inner_Current_Controller.Iq_ref) annotation(
    Line(points = {{-120, -96}, {-50, -96}, {-50, -92}, {-28, -92}, {-28, -92}}, color = {0, 0, 127}));
  connect(parkI.d, inner_Current_Controller.Id) annotation(
    Line(points = {{-52, -16}, {-48, -16}, {-48, -58}, {-28, -58}, {-28, -58}}, color = {0, 0, 127}));
  connect(parkI.q, inner_Current_Controller.Iq) annotation(
    Line(points = {{-52, -8}, {-36, -8}, {-36, -74}, {-28, -74}, {-28, -74}}, color = {0, 0, 127}));
  connect(ParkV.q, inner_Current_Controller.Vlq) annotation(
    Line(points = {{-6, 36}, {36, 36}, {36, -26}, {36, -26}}, color = {0, 0, 127}));
  connect(ParkV.d, inner_Current_Controller.Vld) annotation(
    Line(points = {{-6, 28}, {10, 28}, {10, -26}, {8, -26}}, color = {0, 0, 127}));
  connect(va, ParkV.a) annotation(
    Line(points = {{-120, 106}, {-56, 106}, {-56, 36}, {-30, 36}, {-30, 36}}, color = {0, 0, 127}));
  connect(vb, ParkV.b) annotation(
    Line(points = {{-120, 76}, {-64, 76}, {-64, 32}, {-30, 32}, {-30, 32}}, color = {0, 0, 127}));
  connect(vc, ParkV.c) annotation(
    Line(points = {{-120, 48}, {-72, 48}, {-72, 28}, {-30, 28}, {-30, 28}}, color = {0, 0, 127}));
  connect(inner_Current_Controller.Vd_ref, antiPark.d) annotation(
    Line(points = {{52, -44}, {62, -44}, {62, -64}, {70, -64}, {70, -64}}, color = {0, 0, 127}));
  connect(inner_Current_Controller.Vq_ref, antiPark.q) annotation(
    Line(points = {{52, -90}, {64, -90}, {64, -56}, {70, -56}, {70, -56}}, color = {0, 0, 127}));
  connect(antiPark.b, Vbref) annotation(
    Line(points = {{94, -60}, {114, -60}, {114, -60}, {118, -60}}, color = {0, 0, 127}));
  connect(antiPark.a, Varef) annotation(
    Line(points = {{94, -56}, {104, -56}, {104, -22}, {118, -22}, {118, -22}}, color = {0, 0, 127}));
  connect(antiPark.c, Vcref) annotation(
    Line(points = {{94, -64}, {104, -64}, {104, -100}, {116, -100}, {116, -100}}, color = {0, 0, 127}));
  connect(pll.theta, antiPark.theta) annotation(
    Line(points = {{4, 72}, {60, 72}, {60, -78}, {82, -78}, {82, -72}, {82, -72}}, color = {0, 0, 127}));
  connect(pll.theta, parkI.theta) annotation(
    Line(points = {{4, 72}, {54, 72}, {54, -16}, {-44, -16}, {-44, -34}, {-64, -34}, {-64, -24}, {-64, -24}}, color = {0, 0, 127}));
  connect(pll.theta, theta) annotation(
    Line(points = {{4, 72}, {22, 72}, {22, 72}, {66, 72}, {66, 36}, {110, 36}, {110, 36}}, color = {0, 0, 127}));
  connect(pll.Vzq, Vzq) annotation(
    Line(points = {{4, 82}, {102, 82}, {102, 82}, {110, 82}}, color = {0, 0, 127}));
  connect(pll.theta, ParkV.theta) annotation(
    Line(points = {{4, 72}, {22, 72}, {22, 2}, {-18, 2}, {-18, 20}, {-18, 20}}, color = {0, 0, 127}));
  connect(pll.Vc_grid, vc) annotation(
    Line(points = {{-20, 70}, {-46, 70}, {-46, 48}, {-120, 48}, {-120, 48}}, color = {0, 0, 127}));
  connect(vb, pll.Vb_grid) annotation(
    Line(points = {{-120, 76}, {-20, 76}, {-20, 76}, {-20, 76}}, color = {0, 0, 127}));
  connect(va, pll.Va_grid) annotation(
    Line(points = {{-120, 106}, {-19, 106}, {-19, 82}}, color = {0, 0, 127}));
  connect(pll.Vc_grid, vc) annotation(
    Line(points = {{-28, 70}, {-36, 70}, {-36, 48}, {-102, 48}, {-102, 48}, {-120, 48}}, color = {0, 0, 127}));
  connect(pll.Vb_grid, vb) annotation(
    Line(points = {{-28, 76}, {-104, 76}, {-104, 76}, {-120, 76}}, color = {0, 0, 127}));
  connect(va, pll.Va_grid) annotation(
    Line(points = {{-120, 106}, {-19, 106}, {-19, 82}}, color = {0, 0, 127}));
  annotation(
    uses(Modelica(version = "3.2.3")),
    Icon);
end inner_control;
