block Park
  Modelica.Blocks.Interfaces.RealInput a annotation(
    Placement(visible = true, transformation(origin = {-120, 40}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-113, 39}, extent = {{-13, -13}, {13, 13}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput b annotation(
    Placement(visible = true, transformation(origin = {-120, 0}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-113, -1}, extent = {{-13, -13}, {13, 13}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput c annotation(
    Placement(visible = true, transformation(origin = {-120, -40}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-113, -41}, extent = {{-13, -13}, {13, 13}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput theta annotation(
    Placement(visible = true, transformation(origin = {0, -120}, extent = {{-20, -20}, {20, 20}}, rotation = 90), iconTransformation(origin = {1, -115}, extent = {{-15, -15}, {15, 15}}, rotation = 90)));
  Modelica.Blocks.Interfaces.RealOutput q annotation(
    Placement(visible = true, transformation(origin = {110, 20}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, 30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput d annotation(
    Placement(visible = true, transformation(origin = {110, -20}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, -30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  constant Real pi = Modelica.Constants.pi;
equation
  q = 2 / 3 * (a * cos(theta) + b * cos(theta - 2 * pi / 3) + c * cos(theta + 2 * pi / 3));
  d = 2 / 3 * (a * sin(theta) + b * sin(theta - 2 * pi / 3) + c * sin(theta + 2 * pi / 3));
  annotation(
    Diagram(coordinateSystem(initialScale = 0.1)),
    uses(Modelica(version = "3.2.3")),
    Icon(graphics = {Rectangle(origin = {-1, 9}, extent = {{-99, 91}, {101, -109}}), Text(origin = {-16.9714, -12.5}, rotation = -90, extent = {{-70.5, 58.9714}, {37.5, -37.0286}}, textString = "Park"), Text(origin = {-84, 40}, extent = {{-10, 8}, {10, -8}}, textString = "a"), Text(origin = {-84, 0}, extent = {{-10, 8}, {10, -8}}, textString = "b"), Text(origin = {-84, -38}, extent = {{-10, 8}, {10, -8}}, textString = "c"), Text(origin = {0, -88}, extent = {{-10, 8}, {10, -8}}, textString = "theta"), Text(origin = {86, -30}, extent = {{-10, 8}, {10, -8}}, textString = "d"), Text(origin = {88, 30}, extent = {{-10, 8}, {10, -8}}, textString = "q")}, coordinateSystem(initialScale = 0.1)));
end Park;
