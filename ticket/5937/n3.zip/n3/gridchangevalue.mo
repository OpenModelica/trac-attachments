class gridchange
  extends Modelica.Blocks.Interfaces.SignalSource;
  constant Real pi = Modelica.Constants.pi;
  parameter Real amplitude1;
  parameter Real amplitude2;
  parameter Modelica.SIunits.Frequency freqHz(start=0);
  parameter Modelica.SIunits.Angle phase = 0;
  parameter Real t1;
  parameter Real t2;
algorithm 
  
  
  if time < t1 then
    y := offset + amplitude1*Modelica.Math.sin(2*pi*freqHz*time+ phase);
  
  elseif  t1 <= time and time <= t2 then
    y :=  offset + amplitude2*Modelica.Math.sin(2*pi*freqHz*time + phase);
  else
    y := offset + amplitude1*Modelica.Math.sin(2*pi*freqHz*time + phase);
    
    
  
  end if;
  
  

end gridchange;
