model vhi
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage(V = fill(400, 3), freqHz = fill(50, 3))  annotation(
    Placement(visible = true, transformation(origin = {-58, 12}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {-94, -8}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {-94, -32}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor resistor(R = fill(4, 3))  annotation(
    Placement(visible = true, transformation(origin = {-34, 12}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor resistor1(R = fill(2, 3))  annotation(
    Placement(visible = true, transformation(origin = {44, 14}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.PotentialSensor potentialSensor annotation(
    Placement(visible = true, transformation(origin = {-44, 52}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Electrical.MultiPhase.Sensors.PotentialSensor potentialSensor1 annotation(
    Placement(visible = true, transformation(origin = {36, 54}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Basic.Ground ground1 annotation(
    Placement(visible = true, transformation(origin = {80, -44}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star1 annotation(
    Placement(visible = true, transformation(origin = {80, -10}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.Machines.BasicMachines.Components.IdealCore core(n12 = 10, n13 = 20)  annotation(
    Placement(visible = true, transformation(origin = {-10, 4}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor resistor2(R = fill(6, 3)) annotation(
    Placement(visible = true, transformation(origin = {30, -10}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Basic.Ground ground2 annotation(
    Placement(visible = true, transformation(origin = {56, -58}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star2 annotation(
    Placement(visible = true, transformation(origin = {56, -32}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.MultiPhase.Sensors.PotentialSensor potentialSensor2 annotation(
    Placement(visible = true, transformation(origin = {16, 34}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(sineVoltage.plug_p, star.plug_p) annotation(
    Line(points = {{-68, 12}, {-68, 7}, {-94, 7}, {-94, 2}}, color = {0, 0, 255}));
  connect(star.pin_n, ground.p) annotation(
    Line(points = {{-94, -18}, {-94, -22}}, color = {0, 0, 255}));
  connect(sineVoltage.plug_n, resistor.plug_p) annotation(
    Line(points = {{-48, 12}, {-44, 12}, {-44, 12}, {-44, 12}}, color = {0, 0, 255}));
  connect(star1.pin_n, ground1.p) annotation(
    Line(points = {{80, -20}, {80, -34}}, color = {0, 0, 255}));
  connect(resistor1.plug_n, star1.plug_p) annotation(
    Line(points = {{54, 14}, {80, 14}, {80, 0}}, color = {0, 0, 255}));
  connect(resistor.plug_n, core.plug_p1) annotation(
    Line(points = {{-24, 12}, {-20, 12}, {-20, 14}, {-20, 14}}, color = {0, 0, 255}));
  connect(resistor1.plug_p, core.plug_p2) annotation(
    Line(points = {{34, 14}, {0, 14}}, color = {0, 0, 255}));
  connect(star2.pin_n, ground2.p) annotation(
    Line(points = {{56, -42}, {56, -42}, {56, -48}, {56, -48}}, color = {0, 0, 255}));
  connect(star2.plug_p, resistor2.plug_n) annotation(
    Line(points = {{56, -22}, {56, -22}, {56, -10}, {40, -10}, {40, -10}}, color = {0, 0, 255}));
  connect(resistor2.plug_p, core.plug_p3) annotation(
    Line(points = {{20, -10}, {14, -10}, {14, 0}, {0, 0}, {0, 0}}, color = {0, 0, 255}));
  connect(potentialSensor.plug_p, core.plug_p1) annotation(
    Line(points = {{-34, 52}, {-20, 52}, {-20, 14}, {-20, 14}}, color = {0, 0, 255}));
  connect(potentialSensor1.plug_p, resistor1.plug_p) annotation(
    Line(points = {{26, 54}, {34, 54}, {34, 14}, {34, 14}}, color = {0, 0, 255}));
  connect(potentialSensor2.plug_p, resistor2.plug_p) annotation(
    Line(points = {{6, 34}, {20, 34}, {20, -10}, {20, -10}}, color = {0, 0, 255}));
  connect(core.plug_n3, star2.plug_p) annotation(
    Line(points = {{0, -6}, {22, -6}, {22, -22}, {56, -22}, {56, -22}}, color = {0, 0, 255}));
  connect(core.plug_n1, star.plug_p) annotation(
    Line(points = {{-20, -6}, {-94, -6}, {-94, 2}, {-94, 2}}, color = {0, 0, 255}));
  connect(core.plug_n2, star1.plug_p) annotation(
    Line(points = {{0, 8}, {80, 8}, {80, 0}, {80, 0}}, color = {0, 0, 255}));
  annotation(
    uses(Modelica(version = "3.2.3")));
end vhi;
