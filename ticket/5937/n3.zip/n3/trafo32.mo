model trafo32
  Modelica.Electrical.Machines.BasicMachines.Transformers.Yy.Yy00 transformer(L1sigma = 0.000022711, L2sigma = 0.13528, R1 = 0.001161, R2 = 6.916, n = 0.01368)  annotation(
    Placement(visible = true, transformation(origin = {-10, 6}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  VSC_voltage_sourcet vSC_voltage_sourcet6 annotation(
    Placement(visible = true, transformation(origin = {-66, 4}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {36, -48}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage(V = fill(20412, 3), freqHz = fill(50, 3))  annotation(
    Placement(visible = true, transformation(origin = {18, 6}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {36, -16}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
equation
  connect(transformer.plug1, vSC_voltage_sourcet6.plug) annotation(
    Line(points = {{-20, 6}, {-76, 6}, {-76, 8}, {-76, 8}}, color = {0, 0, 255}));
  connect(transformer.plug2, sineVoltage.plug_p) annotation(
    Line(points = {{0, 6}, {8, 6}, {8, 6}, {8, 6}}, color = {0, 0, 255}));
  connect(sineVoltage.plug_n, star.plug_p) annotation(
    Line(points = {{28, 6}, {36, 6}, {36, -6}, {36, -6}}));
  connect(star.pin_n, ground.p) annotation(
    Line(points = {{36, -26}, {36, -26}, {36, -38}, {36, -38}}, color = {0, 0, 255}));
  connect(star.pin_n, transformer.starpoint2) annotation(
    Line(points = {{36, -26}, {-4, -26}, {-4, -4}, {-4, -4}}, color = {0, 0, 255}));

annotation(
    uses(Modelica(version = "3.2.3")));
end trafo32;
