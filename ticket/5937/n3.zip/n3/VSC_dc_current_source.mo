model VSC_dc_current_source
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {-138, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.CurrentSensor Cs annotation(
    Placement(visible = true, transformation(origin = {-30, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.PotentialSensor Vs annotation(
    Placement(visible = true, transformation(origin = {-56, 8}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.Analog.Sources.SineVoltage Vza(V = 326, freqHz = 50)  annotation(
    Placement(visible = true, transformation(origin = {-122, 56}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Sources.SineVoltage Vzb(V = 326, freqHz = 50, phase = -2.0944)  annotation(
    Placement(visible = true, transformation(origin = {-122, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Sources.SineVoltage Vzc(V = 326, freqHz = 50, phase = 2.0944)  annotation(
    Placement(visible = true, transformation(origin = {-122, 24}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.PlugToPins_p pp annotation(
    Placement(visible = true, transformation(origin = {-102, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Electrical.Analog.Sources.SignalVoltage Vca annotation(
    Placement(visible = true, transformation(origin = {64, 60}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Electrical.Analog.Sources.SignalVoltage Vcb annotation(
    Placement(visible = true, transformation(origin = {84, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  Modelica.Electrical.Analog.Sources.SignalVoltage Vcc annotation(
    Placement(visible = true, transformation(origin = {108, 20}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
  inner_control_pllm inner_control_pllmx annotation(
    Placement(visible = true, transformation(origin = {4, -30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Basic.Ground ground1 annotation(
    Placement(visible = true, transformation(origin = {120, 30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.PlugToPins_n pp1 annotation(
    Placement(visible = true, transformation(origin = {46, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor Rc(R = fill(0.5, 3)) annotation(
    Placement(visible = true, transformation(origin = {24, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Inductor Lc(L = fill(0.0051, 3)) annotation(
    Placement(visible = true, transformation(origin = {-4, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Ref_Q_DC ref_Q_DC_ annotation(
    Placement(visible = true, transformation(origin = {-38, -94}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.Constant Eref(k = 800)  annotation(
    Placement(visible = true, transformation(origin = {-124, -88}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Pac_Qac_Calculation pac_Qac_Calculation annotation(
    Placement(visible = true, transformation(origin = {-48, -58}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  dcbusm1 dcbus annotation(
    Placement(visible = true, transformation(origin = {70, -92}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.CombiTimeTable Qref(extrapolation = Modelica.Blocks.Types.Extrapolation.HoldLastPoint, smoothness = Modelica.Blocks.Types.Smoothness.ConstantSegments, table = [0, 0; 0.3, 0; 0.5, -5000; 0.8, -5000; 0.9, 0])  annotation(
    Placement(visible = true, transformation(origin = {-96, -104}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.CombiTimeTable Idc(extrapolation = Modelica.Blocks.Types.Extrapolation.HoldLastPoint, smoothness = Modelica.Blocks.Types.Smoothness.ConstantSegments, table = [0, 3; 0.3, 10; 0.5, 5; 0.8, 7.5; 0.9, 10]) annotation(
    Placement(visible = true, transformation(origin = {112, -92}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
equation
  connect(Cs.plug_p, Vs.plug_p) annotation(
    Line(points = {{-40, 40}, {-40, 18}, {-56, 18}}, color = {0, 0, 255}));
  connect(Vza.p, ground.p) annotation(
    Line(points = {{-132, 56}, {-138, 56}, {-138, 10}}, color = {0, 0, 255}));
  connect(Vzb.p, ground.p) annotation(
    Line(points = {{-132, 40}, {-138, 40}, {-138, 10}}, color = {0, 0, 255}));
  connect(Vzc.p, ground.p) annotation(
    Line(points = {{-132, 24}, {-138, 24}, {-138, 10}}, color = {0, 0, 255}));
  connect(pp.pin_p[1], Vza.n) annotation(
    Line(points = {{-104, 40}, {-104, 56}, {-112, 56}}, color = {0, 0, 255}));
  connect(pp.pin_p[2], Vzb.n) annotation(
    Line(points = {{-104, 40}, {-112, 40}}, color = {0, 0, 255}));
  connect(pp.pin_p[3], Vzc.n) annotation(
    Line(points = {{-104, 40}, {-104, 24}, {-112, 24}}, color = {0, 0, 255}));
  connect(Vs.phi[1], inner_control_pllmx.va) annotation(
    Line(points = {{-56, -3}, {-56, -20}, {-7, -20}}, color = {0, 0, 127}));
  connect(Vs.phi[2], inner_control_pllmx.vb) annotation(
    Line(points = {{-56, -3}, {-56, -24}, {-7, -24}}, color = {0, 0, 127}));
  connect(Vs.phi[3], inner_control_pllmx.vc) annotation(
    Line(points = {{-56, -3}, {-56, -28}, {-7, -28}}, color = {0, 0, 127}));
  connect(Cs.i[1], inner_control_pllmx.ia) annotation(
    Line(points = {{-30, 30}, {-30, -32}, {-7, -32}}, color = {0, 0, 127}));
  connect(Cs.i[2], inner_control_pllmx.ib) annotation(
    Line(points = {{-30, 30}, {-30, -36}, {-7, -36}}, color = {0, 0, 127}));
  connect(Cs.i[3], inner_control_pllmx.ic) annotation(
    Line(points = {{-30, 30}, {-30, -39}, {-7, -39}}, color = {0, 0, 127}));
  connect(Vcc.v, inner_control_pllmx.Vcref) annotation(
    Line(points = {{108, 8}, {108, -38}, {15, -38}}, color = {0, 0, 127}));
  connect(Vca.p, ground1.p) annotation(
    Line(points = {{74, 60}, {120, 60}, {120, 40}}, color = {0, 0, 255}));
  connect(Vcc.p, ground1.p) annotation(
    Line(points = {{118, 20}, {120, 20}, {120, 40}, {120, 40}}, color = {0, 0, 255}));
  connect(Vcb.p, ground1.p) annotation(
    Line(points = {{94, 40}, {120, 40}, {120, 40}, {120, 40}}, color = {0, 0, 255}));
  connect(Vcc.n, pp1.pin_n[3]) annotation(
    Line(points = {{98, 20}, {48, 20}, {48, 40}}, color = {0, 0, 255}));
  connect(Vcb.n, pp1.pin_n[2]) annotation(
    Line(points = {{74, 40}, {48, 40}}, color = {0, 0, 255}));
  connect(Vca.n, pp1.pin_n[1]) annotation(
    Line(points = {{54, 60}, {48, 60}, {48, 40}}, color = {0, 0, 255}));
  connect(pp1.plug_n, Rc.plug_n) annotation(
    Line(points = {{44, 40}, {34, 40}}, color = {0, 0, 255}));
  connect(Lc.plug_p, Cs.plug_n) annotation(
    Line(points = {{-14, 40}, {-20, 40}, {-20, 40}, {-20, 40}}, color = {0, 0, 255}));
  connect(Rc.plug_p, Lc.plug_n) annotation(
    Line(points = {{14, 40}, {6, 40}}, color = {0, 0, 255}));
  connect(inner_control_pllmx.Vbref, Vcb.v) annotation(
    Line(points = {{16, -34}, {84, -34}, {84, 28}, {84, 28}}, color = {0, 0, 127}));
  connect(inner_control_pllmx.Varef, Vca.v) annotation(
    Line(points = {{16, -32}, {64, -32}, {64, 48}, {64, 48}}, color = {0, 0, 127}));
  connect(pp.plug_p, Cs.plug_p) annotation(
    Line(points = {{-100, 40}, {-40, 40}, {-40, 40}, {-40, 40}}, color = {0, 0, 255}));
  connect(inner_control_pllmx.theta, pac_Qac_Calculation.theta) annotation(
    Line(points = {{16, -26}, {34, -26}, {34, -12}, {-74, -12}, {-74, -58}, {-60, -58}}, color = {0, 0, 127}));
  connect(inner_control_pllmx.va, pac_Qac_Calculation.Va_grid) annotation(
    Line(points = {{-8, -20}, {-56, -20}, {-56, -47}}, color = {0, 0, 127}));
  connect(inner_control_pllmx.vb, pac_Qac_Calculation.Vb_grid) annotation(
    Line(points = {{-8, -24}, {-53, -24}, {-53, -47}}, color = {0, 0, 127}));
  connect(inner_control_pllmx.vc, pac_Qac_Calculation.Vc_grid) annotation(
    Line(points = {{-8, -28}, {-50, -28}, {-50, -47}}, color = {0, 0, 127}));
  connect(inner_control_pllmx.ia, pac_Qac_Calculation.Ia_grid) annotation(
    Line(points = {{-8, -32}, {-46, -32}, {-46, -47}}, color = {0, 0, 127}));
  connect(inner_control_pllmx.ib, pac_Qac_Calculation.Ib_grid) annotation(
    Line(points = {{-8, -36}, {-43, -36}, {-43, -47}}, color = {0, 0, 127}));
  connect(inner_control_pllmx.ic, pac_Qac_Calculation.Ic_grid) annotation(
    Line(points = {{-8, -40}, {-40, -40}, {-40, -47}}, color = {0, 0, 127}));
  connect(inner_control_pllmx.Vzq, ref_Q_DC_.Vq) annotation(
    Line(points = {{16, -22}, {24, -22}, {24, -114}, {-58, -114}, {-58, -98}, {-50, -98}, {-50, -98}}, color = {0, 0, 127}));
  connect(ref_Q_DC_.Pdc, dcbus.pdc) annotation(
    Line(points = {{-50, -84}, {-66, -84}, {-66, -122}, {76, -122}, {76, -102}, {76, -102}}, color = {0, 0, 127}));
  connect(dcbus.edc_source, ref_Q_DC_.E2source) annotation(
    Line(points = {{66, -102}, {64, -102}, {64, -118}, {-62, -118}, {-62, -94}, {-50, -94}, {-50, -94}}, color = {0, 0, 127}));
  connect(ref_Q_DC_.Eref, Eref.y) annotation(
    Line(points = {{-50, -88}, {-113, -88}}, color = {0, 0, 127}));
  connect(Qref.y[1], ref_Q_DC_.qref) annotation(
    Line(points = {{-84, -104}, {-52, -104}, {-52, -104}, {-50, -104}}, color = {0, 0, 127}));
  connect(Idc.y[1], dcbus.Idc) annotation(
    Line(points = {{102, -92}, {82, -92}, {82, -92}, {82, -92}}, color = {0, 0, 127}));
  connect(ref_Q_DC_.Iqref, inner_control_pllmx.iqref) annotation(
    Line(points = {{-26, -88}, {10, -88}, {10, -42}, {10, -42}}, color = {0, 0, 127}));
  connect(ref_Q_DC_.Idref, inner_control_pllmx.idref) annotation(
    Line(points = {{-26, -100}, {-2, -100}, {-2, -42}, {-2, -42}}, color = {0, 0, 127}));
  
  annotation(
    uses(Modelica(version = "3.2.3"), iPSL(version = "1.1.0")),
    Diagram(graphics = {Bitmap(extent = {{-52, -84}, {-52, -84}})}, coordinateSystem(initialScale = 0.1)));
end VSC_dc_current_source;
