model Power_Control
  Modelica.Blocks.Interfaces.RealInput PTSO annotation(
    Placement(visible = true, transformation(origin = {-120, 60}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, 80}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput QTSO annotation(
    Placement(visible = true, transformation(origin = {-120, -60}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, -80}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Ppvpp annotation(
    Placement(visible = true, transformation(origin = {-120, 20}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, 28}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Qpvpp annotation(
    Placement(visible = true, transformation(origin = {-120, -20}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, -28}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Math.Feedback feedback annotation(
    Placement(visible = true, transformation(origin = {-80, 60}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Feedback feedback1 annotation(
    Placement(visible = true, transformation(origin = {-80, -60}, extent = {{-10, 10}, {10, -10}}, rotation = 0)));
  Modelica.Blocks.Math.Gain kpp(k = 15)  annotation(
    Placement(visible = true, transformation(origin = {-50, 80}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Gain kpq(k = 15)  annotation(
    Placement(visible = true, transformation(origin = {-50, -40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Continuous.Integrator integrator(k = 2.5)  annotation(
    Placement(visible = true, transformation(origin = {-50, -80}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Continuous.Integrator integrator1(k = 2.5)  annotation(
    Placement(visible = true, transformation(origin = {-50, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Add add annotation(
    Placement(visible = true, transformation(origin = {-10, 60}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Add add1 annotation(
    Placement(visible = true, transformation(origin = {-10, -60}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Division division annotation(
    Placement(visible = true, transformation(origin = {52, 54}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Division division1 annotation(
    Placement(visible = true, transformation(origin = {52, -66}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.RealExpression Ngen(y = 10)  annotation(
    Placement(visible = true, transformation(origin = {6, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Nonlinear.Limiter Pminmax(limitsAtInit = true, uMax = 8360000, uMin = -8360000)  annotation(
    Placement(visible = true, transformation(origin = {22, 60}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Nonlinear.Limiter Qminmax(limitsAtInit = true, uMax = 8360000, uMin = -8360000)  annotation(
    Placement(visible = true, transformation(origin = {22, -60}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput Pref annotation(
    Placement(visible = true, transformation(origin = {110, 54}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, 50}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput Qref annotation(
    Placement(visible = true, transformation(origin = {110, -66}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, -50}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(QTSO, feedback1.u1) annotation(
    Line(points = {{-120, -60}, {-88, -60}}, color = {0, 0, 127}));
  connect(Qpvpp, feedback1.u2) annotation(
    Line(points = {{-120, -20}, {-80, -20}, {-80, -52}}, color = {0, 0, 127}));
  connect(Ppvpp, feedback.u2) annotation(
    Line(points = {{-120, 20}, {-80, 20}, {-80, 52}}, color = {0, 0, 127}));
  connect(feedback.u1, PTSO) annotation(
    Line(points = {{-88, 60}, {-120, 60}}, color = {0, 0, 127}));
  connect(kpp.u, feedback.y) annotation(
    Line(points = {{-62, 80}, {-68, 80}, {-68, 60}, {-70, 60}, {-70, 60}}, color = {0, 0, 127}));
  connect(kpq.u, feedback1.y) annotation(
    Line(points = {{-62, -40}, {-68, -40}, {-68, -60}, {-70, -60}, {-70, -60}}, color = {0, 0, 127}));
  connect(integrator.u, feedback1.y) annotation(
    Line(points = {{-62, -80}, {-68, -80}, {-68, -60}, {-70, -60}, {-70, -60}}, color = {0, 0, 127}));
  connect(integrator1.u, feedback.y) annotation(
    Line(points = {{-62, 40}, {-68, 40}, {-68, 60}, {-70, 60}, {-70, 60}}, color = {0, 0, 127}));
  connect(kpq.y, add1.u1) annotation(
    Line(points = {{-38, -40}, {-32, -40}, {-32, -54}, {-22, -54}, {-22, -54}}, color = {0, 0, 127}));
  connect(add1.u2, integrator.y) annotation(
    Line(points = {{-22, -66}, {-32, -66}, {-32, -80}, {-38, -80}, {-38, -80}}, color = {0, 0, 127}));
  connect(add.u1, kpp.y) annotation(
    Line(points = {{-22, 66}, {-30, 66}, {-30, 80}, {-38, 80}, {-38, 80}}, color = {0, 0, 127}));
  connect(integrator1.y, add.u2) annotation(
    Line(points = {{-38, 40}, {-30, 40}, {-30, 54}, {-22, 54}, {-22, 54}}, color = {0, 0, 127}));
  connect(add.y, Pminmax.u) annotation(
    Line(points = {{2, 60}, {10, 60}}, color = {0, 0, 127}));
  connect(add1.y, Qminmax.u) annotation(
    Line(points = {{2, -60}, {8, -60}, {8, -60}, {10, -60}}, color = {0, 0, 127}));
  connect(Pminmax.y, division.u1) annotation(
    Line(points = {{34, 60}, {38, 60}, {38, 60}, {40, 60}}, color = {0, 0, 127}));
  connect(Qminmax.y, division1.u1) annotation(
    Line(points = {{34, -60}, {40, -60}}, color = {0, 0, 127}));
  connect(Ngen.y, division.u2) annotation(
    Line(points = {{18, 0}, {36, 0}, {36, 48}, {40, 48}, {40, 48}}, color = {0, 0, 127}));
  connect(Ngen.y, division1.u2) annotation(
    Line(points = {{18, 0}, {36, 0}, {36, -72}, {40, -72}, {40, -72}}, color = {0, 0, 127}));
  connect(division.y, Pref) annotation(
    Line(points = {{64, 54}, {110, 54}}, color = {0, 0, 127}));
  connect(division1.y, Qref) annotation(
    Line(points = {{64, -66}, {100, -66}, {100, -66}, {110, -66}}, color = {0, 0, 127}));

annotation(
    uses(Modelica(version = "3.2.3")));
end Power_Control;
