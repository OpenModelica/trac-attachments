model trafo
  Modelica.Electrical.Machines.BasicMachines.Components.IdealCore core(n12 = 100, n13 = 100)  annotation(
    Placement(visible = true, transformation(origin = {-3.10862e-15, 6}, extent = {{-30, -30}, {30, 30}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor R2(R = fill(0.5, 3))  annotation(
    Placement(visible = true, transformation(origin = {96, 46}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor R3(R = fill(0.5, 3))  annotation(
    Placement(visible = true, transformation(origin = {96, 4}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Inductor L2(L = fill(0.005, 3))  annotation(
    Placement(visible = true, transformation(origin = {70, 46}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Inductor L3(L = fill(0.005, 3))  annotation(
    Placement(visible = true, transformation(origin = {70, 4}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {0, -60}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {0, -88}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Inductor Lm3(L = fill(1000, 3)) annotation(
    Placement(visible = true, transformation(origin = {46, -12}, extent = {{-6, -6}, {6, 6}}, rotation = 90)));
  Modelica.Electrical.MultiPhase.Basic.Resistor Rm3(R = fill(40000, 3)) annotation(
    Placement(visible = true, transformation(origin = {59, -12}, extent = {{-6, -5}, {6, 5}}, rotation = 90)));
  Modelica.Electrical.MultiPhase.Basic.Inductor Lm2(L = fill(1000, 3)) annotation(
    Placement(visible = true, transformation(origin = {46, 32}, extent = {{6, 6}, {-6, -6}}, rotation = -90)));
  Modelica.Electrical.MultiPhase.Basic.Resistor Rm2(R = fill(40000, 3)) annotation(
    Placement(visible = true, transformation(origin = {59, 32}, extent = {{6, 5}, {-6, -5}}, rotation = -90)));
  Modelica.Electrical.MultiPhase.Basic.Inductor L1(L = fill(0.05, 3))  annotation(
    Placement(visible = true, transformation(origin = {-77, 37}, extent = {{-9, -7}, {9, 7}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor resistor(R = fill(0.5, 3))  annotation(
    Placement(visible = true, transformation(origin = {-52, 36}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Interfaces.PositivePlug O1 annotation(
    Placement(visible = true, transformation(origin = {-106, 38}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {100, 0}, extent = {{-6, -6}, {6, 6}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Interfaces.NegativePlug I2 annotation(
    Placement(visible = true, transformation(origin = {114, 46}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-100, 30}, extent = {{-6, -6}, {6, 6}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Interfaces.NegativePlug I3 annotation(
    Placement(visible = true, transformation(origin = {114, 4}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-100, -30}, extent = {{-6, -6}, {6, 6}}, rotation = 0)));
equation
  connect(core.plug_n2, star.plug_p) annotation(
    Line(points = {{30, 18}, {100, 18}, {100, -46}, {0, -46}, {0, -50}}, color = {0, 0, 255}));
  connect(core.plug_n3, star.plug_p) annotation(
    Line(points = {{30, -24}, {100, -24}, {100, -46}, {0, -46}, {0, -50}, {0, -50}}, color = {0, 0, 255}));
  connect(core.plug_n1, star.plug_p) annotation(
    Line(points = {{-30, -24}, {-40, -24}, {-40, -46}, {0, -46}, {0, -50}, {0, -50}}, color = {0, 0, 255}));
  connect(star.pin_n, ground.p) annotation(
    Line(points = {{0, -70}, {0, -70}, {0, -78}, {0, -78}}, color = {0, 0, 255}));
  connect(core.plug_n3, Rm3.plug_p) annotation(
    Line(points = {{30, -24}, {52, -24}, {52, -18}, {60, -18}, {60, -18}}, color = {0, 0, 255}));
  connect(Lm3.plug_p, Rm3.plug_p) annotation(
    Line(points = {{46, -18}, {59, -18}}, color = {0, 0, 255}));
  connect(L2.plug_p, core.plug_p2) annotation(
    Line(points = {{60, 46}, {30, 46}, {30, 36}}, color = {0, 0, 255}));
  connect(R2.plug_p, L2.plug_n) annotation(
    Line(points = {{86, 46}, {80, 46}, {80, 46}, {80, 46}}, color = {0, 0, 255}));
  connect(L3.plug_p, Rm3.plug_n) annotation(
    Line(points = {{60, 4}, {52, 4}, {52, -6}, {60, -6}}, color = {0, 0, 255}));
  connect(L2.plug_p, Lm2.plug_n) annotation(
    Line(points = {{60, 46}, {52, 46}, {52, 38}, {46, 38}, {46, 38}}, color = {0, 0, 255}));
  connect(L2.plug_p, Rm2.plug_n) annotation(
    Line(points = {{60, 46}, {52, 46}, {52, 38}, {60, 38}, {60, 38}}, color = {0, 0, 255}));
  connect(Lm2.plug_p, Rm2.plug_p) annotation(
    Line(points = {{46, 26}, {60, 26}, {60, 26}, {60, 26}}, color = {0, 0, 255}));
  connect(core.plug_n2, Rm2.plug_p) annotation(
    Line(points = {{30, 18}, {52, 18}, {52, 26}, {60, 26}, {60, 26}}, color = {0, 0, 255}));
  connect(Lm3.plug_n, L3.plug_p) annotation(
    Line(points = {{46, -6}, {52, -6}, {52, 4}, {60, 4}}, color = {0, 0, 255}));
  connect(L3.plug_p, core.plug_p3) annotation(
    Line(points = {{60, 4}, {32, 4}, {32, -6}, {30, -6}}, color = {0, 0, 255}));
  connect(L3.plug_n, R3.plug_p) annotation(
    Line(points = {{80, 4}, {86, 4}, {86, 4}, {86, 4}}, color = {0, 0, 255}));
  connect(resistor.plug_n, core.plug_p1) annotation(
    Line(points = {{-42, 36}, {-30, 36}, {-30, 36}, {-30, 36}}, color = {0, 0, 255}));
  connect(L1.plug_n, resistor.plug_p) annotation(
    Line(points = {{-68, 37}, {-68, 36}, {-62, 36}}, color = {0, 0, 255}));
  connect(L1.plug_p, O1) annotation(
    Line(points = {{-86, 38}, {-104, 38}, {-104, 38}, {-106, 38}}, color = {0, 0, 255}));
  connect(R2.plug_n, I2) annotation(
    Line(points = {{106, 46}, {114, 46}, {114, 46}, {114, 46}}, color = {0, 0, 255}));
  connect(R3.plug_n, I3) annotation(
    Line(points = {{106, 4}, {114, 4}, {114, 4}, {114, 4}}, color = {0, 0, 255}));
  annotation(
    uses(Modelica(version = "3.2.3")),
    Icon(graphics = {Ellipse(origin = {-41, -47}, extent = {{55, 57}, {-25, -23}}, endAngle = 360), Ellipse(origin = {13, -17}, extent = {{55, 57}, {-25, -23}}, endAngle = 360), Ellipse(origin = {-43, 11}, extent = {{55, 57}, {-25, -23}}, endAngle = 360), Line(origin = {-83.5511, 29.281}, points = {{15, 0}, {-13, 0}, {15, 0}}), Line(origin = {-84.3175, -30.1169}, points = {{17, 0}, {-13, 0}, {17, 0}}), Line(origin = {87.3613, -0.226313}, points = {{13, 0}, {-19, 0}, {13, 0}})}, coordinateSystem(initialScale = 0.1)));
end trafo;
