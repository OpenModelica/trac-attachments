class plx
  extends Modelica.Blocks.Icons.Block;
  
  Modelica.Blocks.Interfaces.RealInput u1
    "Connector of Real input signals 1" annotation (Placement(transformation(
          extent={{-140,50},{-100,90}})));
  Modelica.Blocks.Interfaces.RealInput u2
    "Connector of Real input signals 2" annotation (Placement(transformation(
          extent={{-140,-20},{-100,20}})));
  Modelica.Blocks.Interfaces.RealInput u3
    "Connector of Real input signals 3" annotation (Placement(transformation(
          extent={{-140,-90},{-100,-50}})));
  Modelica.Blocks.Interfaces.RealVectorOutput y[3]
    "Connector of Real output signals" annotation (Placement(transformation(
          extent={{100,-10},{120,10}})));
  Real v[3];
algorithm
  v := {u1, u2, u3};
  y := v;
  


end plx;
