block AntiPark
  Modelica.Blocks.Interfaces.RealInput q annotation(
    Placement(visible = true, transformation(origin = {-120, 40}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, 40}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput d annotation(
    Placement(visible = true, transformation(origin = {-120, -40}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, -40}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput theta annotation(
    Placement(visible = true, transformation(origin = {0, -120}, extent = {{-20, -20}, {20, 20}}, rotation = 90), iconTransformation(origin = {0, -120}, extent = {{-20, -20}, {20, 20}}, rotation = 90)));
  Modelica.Blocks.Interfaces.RealOutput a annotation(
    Placement(visible = true, transformation(origin = {110, 28}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, 30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput b annotation(
    Placement(visible = true, transformation(origin = {110, -2}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput c annotation(
    Placement(visible = true, transformation(origin = {110, -32}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, -30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  constant Real pi = Modelica.Constants.pi;
equation
  a = q * cos(theta) + d * sin(theta);
  b = q * cos(theta - 2 * pi / 3) + d * sin(theta - 2 * pi / 3);
  c = q * cos(theta + 2 * pi / 3) + d * sin(theta + 2 * pi / 3);
  annotation(
    Diagram(coordinateSystem(initialScale = 0.1)),
    uses(Modelica(version = "3.2.3")),
  Icon(graphics = {Rectangle(origin = {-14, 11}, extent = {{-86, 89}, {114, -111}}), Text(origin = {6, -5}, extent = {{-52, 41}, {42, -33}}, textString = "AntiPark"), Text(origin = {-85, 41}, extent = {{-9, 9}, {9, -9}}, textString = "q"), Text(origin = {3, -87}, extent = {{-13, 9}, {9, -9}}, textString = "theta"), Text(origin = {-87, -39}, extent = {{-9, 9}, {9, -9}}, textString = "d"), Text(origin = {89, 1}, extent = {{-13, 9}, {9, -9}}, textString = "b"), Text(origin = {89, 31}, extent = {{-13, 9}, {9, -9}}, textString = "a"), Text(origin = {89, -29}, extent = {{-13, 9}, {9, -9}}, textString = "c")}, coordinateSystem(initialScale = 0.1)));
end AntiPark;
