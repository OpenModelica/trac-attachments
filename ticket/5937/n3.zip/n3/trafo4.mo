model trafo4
  Modelica.Electrical.Machines.BasicMachines.Transformers.Dy.Dy03 transformer(L1sigma = 0.003, L2sigma = 0.003, R1 = 0.05, R2 = 0.05, n = 0.1)  annotation(
    Placement(visible = true, transformation(origin = {-24, 22}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Machines.BasicMachines.Transformers.Dy.Dy03 transformer1(L1sigma = 0.003, L2sigma = 0.003, R1 = 0.05, R2 = 0.05, n = 0.1)  annotation(
    Placement(visible = true, transformation(origin = {-24, -22}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Interfaces.PositivePlug positivePlug annotation(
    Placement(visible = true, transformation(origin = {-94, 24}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-102, 66}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Interfaces.PositivePlug positivePlug1 annotation(
    Placement(visible = true, transformation(origin = {-94, -24}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-102, -52}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Interfaces.NegativePlug negativePlug annotation(
    Placement(visible = true, transformation(origin = {14, 24}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {94, 68}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Interfaces.NegativePlug negativePlug1 annotation(
    Placement(visible = true, transformation(origin = {16, -20}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {100, -52}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(positivePlug, transformer.plug1) annotation(
    Line(points = {{-94, 24}, {-34, 24}, {-34, 22}, {-34, 22}}, color = {0, 0, 255}));
  connect(positivePlug1, transformer1.plug1) annotation(
    Line(points = {{-94, -24}, {-34, -24}, {-34, -22}, {-34, -22}}, color = {0, 0, 255}));
  connect(transformer.plug2, negativePlug) annotation(
    Line(points = {{-14, 22}, {14, 22}, {14, 24}, {14, 24}}, color = {0, 0, 255}));
  connect(transformer1.plug2, negativePlug1) annotation(
    Line(points = {{-14, -22}, {16, -22}, {16, -20}, {16, -20}}, color = {0, 0, 255}));

annotation(
    uses(Modelica(version = "3.2.3")));
end trafo4;
