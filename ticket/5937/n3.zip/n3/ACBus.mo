model ACBus
  Modelica.Electrical.MultiPhase.Sources.SignalCurrent I2 annotation(
    Placement(visible = true, transformation(origin = {28, -74}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {0, -112}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {0, -86}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Blocks.Interfaces.RealInput bm2 annotation(
    Placement(visible = true, transformation(origin = {-106, 28}, extent = {{-6, -6}, {6, 6}}, rotation = 0), iconTransformation(origin = {-4, 68}, extent = {{-2, -2}, {2, 2}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput cm1 annotation(
    Placement(visible = true, transformation(origin = {-106, 60}, extent = {{-6, -6}, {6, 6}}, rotation = 0), iconTransformation(origin = {-4, 146}, extent = {{-2, -2}, {2, 2}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput am2 annotation(
    Placement(visible = true, transformation(origin = {-106, 38}, extent = {{-6, -6}, {6, 6}}, rotation = 0), iconTransformation(origin = {-4, 76}, extent = {{-2, -2}, {2, 2}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput cm2 annotation(
    Placement(visible = true, transformation(origin = {-106, 18}, extent = {{-6, -6}, {6, 6}}, rotation = 0), iconTransformation(origin = {-4, 60}, extent = {{-2, -2}, {2, 2}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput am1 annotation(
    Placement(visible = true, transformation(origin = {-106, 80}, extent = {{-6, -6}, {6, 6}}, rotation = 0), iconTransformation(origin = {-4, 162}, extent = {{-2, -2}, {2, 2}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput bm1 annotation(
    Placement(visible = true, transformation(origin = {-106, 70}, extent = {{-6, -6}, {6, 6}}, rotation = 0), iconTransformation(origin = {-4, 154}, extent = {{-2, -2}, {2, 2}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Interfaces.NegativePlug b annotation(
    Placement(visible = true, transformation(origin = {100, -74}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-1, -1}, extent = {{-1, -1}, {1, 1}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput am3 annotation(
    Placement(visible = true, transformation(origin = {-106, 5.55112e-16}, extent = {{-6, -6}, {6, 6}}, rotation = 0), iconTransformation(origin = {-5, -61}, extent = {{-3, -3}, {3, 3}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput am4 annotation(
    Placement(visible = true, transformation(origin = {-106, -48}, extent = {{-6, -6}, {6, 6}}, rotation = 0), iconTransformation(origin = {-5, -159}, extent = {{-3, -3}, {3, 3}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput bm3 annotation(
    Placement(visible = true, transformation(origin = {-106, -12}, extent = {{-6, -6}, {6, 6}}, rotation = 0), iconTransformation(origin = {-5, -71}, extent = {{-3, -3}, {3, 3}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput bm4 annotation(
    Placement(visible = true, transformation(origin = {-106, -58}, extent = {{-6, -6}, {6, 6}}, rotation = 0), iconTransformation(origin = {-5, -169}, extent = {{-3, -3}, {3, 3}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput cm4 annotation(
    Placement(visible = true, transformation(origin = {-106, -70}, extent = {{-6, -6}, {6, 6}}, rotation = 0), iconTransformation(origin = {-5, -179}, extent = {{-3, -3}, {3, 3}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput cm3 annotation(
    Placement(visible = true, transformation(origin = {-106, -24}, extent = {{-6, -6}, {6, 6}}, rotation = 0), iconTransformation(origin = {-5, -81}, extent = {{-3, -3}, {3, 3}}, rotation = 0)));
  Modelica.Blocks.Math.Sum ic(nin = 4)  annotation(
    Placement(visible = true, transformation(origin = {-30, -30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Sum ib(nin = 4)  annotation(
    Placement(visible = true, transformation(origin = {-30, 10}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Sum ia(nin = 4)  annotation(
    Placement(visible = true, transformation(origin = {-30, 50}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(star.plug_p, I2.plug_p) annotation(
    Line(points = {{0, -76}, {4.5, -76}, {4.5, -74}, {18, -74}}, color = {0, 0, 255}));
  connect(star.pin_n, ground.p) annotation(
    Line(points = {{0, -96}, {0, -102}}, color = {0, 0, 255}));
  connect(I2.plug_n, b) annotation(
    Line(points = {{38, -74}, {100, -74}}, color = {0, 0, 255}));
  connect(am1, ia.u[1]) annotation(
    Line(points = {{-106, 80}, {-80, 80}, {-80, 50}, {-42, 50}, {-42, 50}}, color = {0, 0, 127}));
  connect(ia.u[2], am2) annotation(
    Line(points = {{-42, 50}, {-80, 50}, {-80, 38}, {-106, 38}, {-106, 38}}, color = {0, 0, 127}));
  connect(ia.u[3], am3) annotation(
    Line(points = {{-42, 50}, {-80, 50}, {-80, 0}, {-106, 0}, {-106, 0}}, color = {0, 0, 127}));
  connect(ia.u[4], am4) annotation(
    Line(points = {{-42, 50}, {-80, 50}, {-80, -48}, {-106, -48}, {-106, -48}}, color = {0, 0, 127}));
  connect(ib.u[1], bm1) annotation(
    Line(points = {{-42, 10}, {-70, 10}, {-70, 70}, {-106, 70}, {-106, 70}}, color = {0, 0, 127}));
  connect(ib.u[2], bm2) annotation(
    Line(points = {{-42, 10}, {-70, 10}, {-70, 28}, {-106, 28}, {-106, 28}}, color = {0, 0, 127}));
  connect(ib.u[3], bm3) annotation(
    Line(points = {{-42, 10}, {-70, 10}, {-70, -12}, {-106, -12}, {-106, -12}}, color = {0, 0, 127}));
  connect(ib.u[4], bm4) annotation(
    Line(points = {{-42, 10}, {-70, 10}, {-70, -58}, {-106, -58}, {-106, -58}}, color = {0, 0, 127}));
  connect(cm1, ic.u[1]) annotation(
    Line(points = {{-106, 60}, {-60, 60}, {-60, -30}, {-42, -30}, {-42, -30}}, color = {0, 0, 127}));
  connect(cm2, ic.u[2]) annotation(
    Line(points = {{-106, 18}, {-60, 18}, {-60, -30}, {-42, -30}, {-42, -30}}, color = {0, 0, 127}));
  connect(cm3, ic.u[3]) annotation(
    Line(points = {{-106, -24}, {-60, -24}, {-60, -30}, {-42, -30}, {-42, -30}}, color = {0, 0, 127}));
  connect(cm4, ic.u[4]) annotation(
    Line(points = {{-106, -70}, {-60, -70}, {-60, -30}, {-42, -30}, {-42, -30}}, color = {0, 0, 127}));
  connect(ia.y, I2.i[1]) annotation(
    Line(points = {{-18, 50}, {28, 50}, {28, -62}, {28, -62}}, color = {0, 0, 127}));
  connect(ib.y, I2.i[2]) annotation(
    Line(points = {{-18, 10}, {28, 10}, {28, -62}, {28, -62}}, color = {0, 0, 127}));
  connect(ic.y, I2.i[3]) annotation(
    Line(points = {{-18, -30}, {28, -30}, {28, -62}, {28, -62}}, color = {0, 0, 127}));
protected
  annotation(
    uses(Modelica(version = "3.2.3")),
    Icon(graphics = {Rectangle(origin = {18, 4}, fillPattern = FillPattern.Solid, extent = {{-20, 208}, {-18, -266}})}, coordinateSystem(initialScale = 0.1)));
end ACBus;
