model testnewtrafo3
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage2(V = fill(32600, 3), freqHz = fill(50, 3))  annotation(
    Placement(visible = true, transformation(origin = {64, 16}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {-72, -74}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {-72, -100}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.PowerSensor powerSensor annotation(
    Placement(visible = true, transformation(origin = {-54, 58}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.PowerSensor powerSensor1 annotation(
    Placement(visible = true, transformation(origin = {24, 24}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sensors.PowerSensor powerSensor2 annotation(
    Placement(visible = true, transformation(origin = {-66, -6}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Add add annotation(
    Placement(visible = true, transformation(origin = {-34, -36}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  trafo_three_w trafo_three_ annotation(
    Placement(visible = true, transformation(origin = {-12, 24}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  invsinmod invsinmod1 annotation(
    Placement(visible = true, transformation(origin = {-122, 56}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  invsinmod invsinmod2 annotation(
    Placement(visible = true, transformation(origin = {-118, -2}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(ground.p, star.pin_n) annotation(
    Line(points = {{-72, -90}, {-72, -90}, {-72, -84}, {-72, -84}}, color = {0, 0, 255}));
  connect(star.plug_p, sineVoltage2.plug_n) annotation(
    Line(points = {{-72, -64}, {74, -64}, {74, 16}, {74, 16}}, color = {0, 0, 255}));
  connect(powerSensor1.nc, sineVoltage2.plug_p) annotation(
    Line(points = {{34, 24}, {54, 24}, {54, 16}, {54, 16}}, color = {0, 0, 255}));
  connect(powerSensor1.nv, star.plug_p) annotation(
    Line(points = {{24, 14}, {20, 14}, {20, -64}, {-72, -64}, {-72, -64}}, color = {0, 0, 255}));
  connect(powerSensor.nv, star.plug_p) annotation(
    Line(points = {{-54, 48}, {-52, 48}, {-52, -64}, {-72, -64}, {-72, -64}}, color = {0, 0, 255}));
  connect(powerSensor.pv, powerSensor.pc) annotation(
    Line(points = {{-54, 68}, {-64, 68}, {-64, 58}, {-64, 58}}, color = {0, 0, 255}));
  connect(powerSensor1.pv, powerSensor1.nc) annotation(
    Line(points = {{24, 34}, {34, 34}, {34, 24}, {34, 24}}, color = {0, 0, 255}));
  connect(powerSensor2.nv, star.plug_p) annotation(
    Line(points = {{-66, -16}, {-66, -16}, {-66, -64}, {-72, -64}, {-72, -64}}, color = {0, 0, 255}));
  connect(powerSensor2.pv, powerSensor2.pc) annotation(
    Line(points = {{-66, 4}, {-76, 4}, {-76, -6}, {-76, -6}}, color = {0, 0, 255}));
  connect(powerSensor.power, add.u1) annotation(
    Line(points = {{-64, 46}, {-60, 46}, {-60, -30}, {-46, -30}, {-46, -30}}, color = {0, 0, 127}));
  connect(add.u2, powerSensor2.power) annotation(
    Line(points = {{-46, -42}, {-76, -42}, {-76, -16}, {-76, -16}, {-76, -16}}, color = {0, 0, 127}));
  connect(powerSensor.nc, trafo_three_.in1) annotation(
    Line(points = {{-44, 58}, {-22, 58}, {-22, 28}, {-22, 28}}, color = {0, 0, 255}));
  connect(trafo_three_.in2, powerSensor2.nc) annotation(
    Line(points = {{-22, 20}, {-20, 20}, {-20, -6}, {-56, -6}, {-56, -6}}, color = {0, 0, 255}));
  connect(trafo_three_.out, powerSensor1.pc) annotation(
    Line(points = {{-2, 24}, {14, 24}, {14, 24}, {14, 24}}, color = {0, 0, 255}));
  connect(invsinmod1.negativePlug, powerSensor.pc) annotation(
    Line(points = {{-112, 56}, {-64, 56}, {-64, 58}, {-64, 58}}, color = {0, 0, 255}));
  connect(invsinmod2.negativePlug, powerSensor2.pc) annotation(
    Line(points = {{-108, -2}, {-76, -2}, {-76, -6}, {-76, -6}}, color = {0, 0, 255}));
  annotation(
    uses(Modelica(version = "3.2.3")));
end testnewtrafo3;
