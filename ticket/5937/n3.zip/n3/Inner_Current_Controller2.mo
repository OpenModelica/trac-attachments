block Inner_Current_Controller2
  Modelica.Blocks.Math.Add3 add3(k2 = -1, k3 = -1)  annotation(
    Placement(visible = true, transformation(origin = {55, 85}, extent = {{-7, -7}, {7, 7}}, rotation = 0)));
  Modelica.Blocks.Math.Feedback feedback annotation(
    Placement(visible = true, transformation(origin = {-70, 84}, extent = {{10, 10}, {-10, -10}}, rotation = 180)));
  Modelica.Blocks.Math.Feedback feedback1 annotation(
    Placement(visible = true, transformation(origin = {-62, -86}, extent = {{-10, 10}, {10, -10}}, rotation = 0)));
  Modelica.Blocks.Sources.Constant wl(k = 1.6964)  annotation(
    Placement(visible = true, transformation(origin = {-69, 3}, extent = {{-9, -9}, {9, 9}}, rotation = 0)));
  Modelica.Blocks.Math.Product product annotation(
    Placement(visible = true, transformation(origin = {-20, 24}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Product product1 annotation(
    Placement(visible = true, transformation(origin = {-20, -14}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Continuous.Integrator kiq(k = 500)  annotation(
    Placement(visible = true, transformation(origin = {-20, -100}, extent = {{-8, -8}, {8, 8}}, rotation = 0)));
  Modelica.Blocks.Continuous.Integrator kid(k = 500)  annotation(
    Placement(visible = true, transformation(origin = {-36, 68}, extent = {{-8, -8}, {8, 8}}, rotation = 0)));
  Modelica.Blocks.Math.Gain kd(k = 5.4)  annotation(
    Placement(visible = true, transformation(origin = {-37, 101}, extent = {{-7, -7}, {7, 7}}, rotation = 0)));
  Modelica.Blocks.Math.Gain kq(k = 5.4)  annotation(
    Placement(visible = true, transformation(origin = {-24, -60}, extent = {{-8, -8}, {8, 8}}, rotation = 0)));
  Modelica.Blocks.Math.Add add annotation(
    Placement(visible = true, transformation(origin = {18, -78}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Add add1 annotation(
    Placement(visible = true, transformation(origin = {0, 84}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Add add2(k2 = -1)  annotation(
    Placement(visible = true, transformation(origin = {66, -74}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput iqref annotation(
    Placement(visible = true, transformation(origin = {-120, 84}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, 84}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput iq annotation(
    Placement(visible = true, transformation(origin = {-120, 30}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, 30}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput id annotation(
    Placement(visible = true, transformation(origin = {-120, -20}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, -20}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput idref annotation(
    Placement(visible = true, transformation(origin = {-120, -86}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, -86}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput vzq annotation(
    Placement(visible = true, transformation(origin = {32, 120}, extent = {{-20, -20}, {20, 20}}, rotation = -90), iconTransformation(origin = {32, 120}, extent = {{-20, -20}, {20, 20}}, rotation = -90)));
  Modelica.Blocks.Interfaces.RealOutput vlq annotation(
    Placement(visible = true, transformation(origin = {110, 86}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, 86}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput vld annotation(
    Placement(visible = true, transformation(origin = {110, -74}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, -74}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(wl.y, product.u2) annotation(
    Line(points = {{-60, 4}, {-52, 4}, {-52, 18}, {-32, 18}}, color = {0, 0, 127}));
  connect(wl.y, product1.u1) annotation(
    Line(points = {{-60, 4}, {-52, 4}, {-52, -8}, {-32, -8}, {-32, -8}}, color = {0, 0, 127}));
  connect(feedback.y, kd.u) annotation(
    Line(points = {{-60, 84}, {-54, 84}, {-54, 100}, {-46, 100}, {-46, 102}}, color = {0, 0, 127}));
  connect(kd.y, add1.u1) annotation(
    Line(points = {{-30, 102}, {-20, 102}, {-20, 90}, {-12, 90}, {-12, 90}}, color = {0, 0, 127}));
  connect(add1.u2, kid.y) annotation(
    Line(points = {{-12, 78}, {-18, 78}, {-18, 68}, {-28, 68}, {-28, 68}}, color = {0, 0, 127}));
  connect(kid.u, feedback.y) annotation(
    Line(points = {{-46, 68}, {-54, 68}, {-54, 84}, {-60, 84}, {-60, 84}}, color = {0, 0, 127}));
  connect(add1.y, add3.u2) annotation(
    Line(points = {{12, 84}, {46, 84}, {46, 86}, {46, 86}}, color = {0, 0, 127}));
  connect(add3.u3, product1.y) annotation(
    Line(points = {{46, 80}, {34, 80}, {34, -14}, {-8, -14}, {-8, -14}}, color = {0, 0, 127}));
  connect(kq.u, feedback1.y) annotation(
    Line(points = {{-34, -60}, {-44, -60}, {-44, -86}, {-52, -86}}, color = {0, 0, 127}));
  connect(kiq.u, feedback1.y) annotation(
    Line(points = {{-30, -100}, {-44, -100}, {-44, -86}, {-52, -86}}, color = {0, 0, 127}));
  connect(kq.y, add.u1) annotation(
    Line(points = {{-16, -60}, {-4, -60}, {-4, -72}, {6, -72}, {6, -72}}, color = {0, 0, 127}));
  connect(add.u2, kiq.y) annotation(
    Line(points = {{6, -84}, {-2, -84}, {-2, -100}, {-12, -100}, {-12, -100}}, color = {0, 0, 127}));
  connect(add2.u1, product.y) annotation(
    Line(points = {{54, -68}, {44, -68}, {44, 24}, {-8, 24}, {-8, 24}}, color = {0, 0, 127}));
  connect(add.y, add2.u2) annotation(
    Line(points = {{30, -78}, {54, -78}, {54, -80}, {54, -80}}, color = {0, 0, 127}));
  connect(idref, feedback1.u1) annotation(
    Line(points = {{-120, -86}, {-72, -86}, {-72, -86}, {-70, -86}}, color = {0, 0, 127}));
  connect(id, feedback1.u2) annotation(
    Line(points = {{-120, -20}, {-62, -20}, {-62, -78}}, color = {0, 0, 127}));
  connect(id, product1.u2) annotation(
    Line(points = {{-120, -20}, {-32, -20}}, color = {0, 0, 127}));
  connect(iq, product.u1) annotation(
    Line(points = {{-120, 30}, {-32, 30}, {-32, 30}, {-32, 30}}, color = {0, 0, 127}));
  connect(iq, feedback.u2) annotation(
    Line(points = {{-120, 30}, {-70, 30}, {-70, 76}, {-70, 76}}, color = {0, 0, 127}));
  connect(iqref, feedback.u1) annotation(
    Line(points = {{-120, 84}, {-78, 84}, {-78, 84}, {-78, 84}}, color = {0, 0, 127}));
  connect(vzq, add3.u1) annotation(
    Line(points = {{32, 120}, {32, 120}, {32, 90}, {46, 90}, {46, 90}}, color = {0, 0, 127}));
  connect(add2.y, vld) annotation(
    Line(points = {{78, -74}, {110, -74}}, color = {0, 0, 127}));
  connect(add3.y, vlq) annotation(
    Line(points = {{62, 86}, {110, 86}}, color = {0, 0, 127}));
  annotation(
    uses(Modelica(version = "3.2.3")),
    Icon(coordinateSystem(initialScale = 0.1), graphics = {Text(origin = {2, 7}, extent = {{-66, 43}, {66, -43}}, textString = "icc2"), Rectangle(extent = {{-100, 100}, {100, -100}})}),
  Diagram);
end Inner_Current_Controller2;
