block divs
  extends Modelica.Blocks.Interfaces.SI2SO;
equation  
  y = if time > 0.01 then u1/u2 else 1;
end divs;
