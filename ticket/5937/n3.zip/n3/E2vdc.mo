block E2
  Modelica.Blocks.Interfaces.RealInput u annotation(
    Placement(visible = true, transformation(origin = {122, 0}, extent = {{-20, -20}, {20, 20}}, rotation = 180), iconTransformation(origin = {122, 0}, extent = {{-20, -20}, {20, 20}}, rotation = 180)));
  Modelica.Blocks.Interfaces.RealOutput y annotation(
    Placement(visible = true, transformation(origin = {-110, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 180), iconTransformation(origin = {-110, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
equation
  y = u ^ 2;
  annotation(
    uses(Modelica(version = "3.2.3")),
    Icon(coordinateSystem(initialScale = 0.1)));
end E2;
