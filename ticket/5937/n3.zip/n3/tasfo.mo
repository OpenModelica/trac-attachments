model tasfo
  Spot.ACabc.Transformers.Trafo3Stray trafo3Stray1(par = 0.5, stIni_en = true)  annotation(
    Placement(visible = true, transformation(origin = { -24, 12}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage annotation(
    Placement(visible = true, transformation(origin = {-56, 12}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {-72, -12}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {-72, -38}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(sineVoltage.plug_p, star.plug_p) annotation(
    Line(points = {{-66, 12}, {-72, 12}, {-72, -2}}, color = {0, 0, 255}));
  connect(star.pin_n, ground.p) annotation(
    Line(points = {{-72, -22}, {-72, -22}, {-72, -28}, {-72, -28}}, color = {0, 0, 255}));
  connect(sineVoltage.plug_n, trafo3Stray1.term_p) annotation(
    Line(points = {{-46, 12}, {-34, 12}}, color = {0, 0, 255}));
  annotation(
    uses(iPSL(version = "1.1.0"), Modelica(version = "3.2.3"), PowerSystems(version = "1.0.0"), Spot(version = "0.706.1"), OpenIPSL(version = "2.0.0-dev")));
end tasfo;
