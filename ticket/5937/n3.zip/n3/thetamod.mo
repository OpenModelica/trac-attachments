class thetamod
  extends Modelica.Blocks.Interfaces.SISO;
  
equation
  y = if time<0.001 then 1 else u;
end thetamod;
