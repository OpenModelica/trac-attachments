block PLL2
  Modelica.Blocks.Interfaces.RealInput Va_grid annotation(
    Placement(visible = true, transformation(origin = {-57, -113}, extent = {{-13, -13}, {13, 13}}, rotation = 90), iconTransformation(origin = {-113, 59}, extent = {{-13, -13}, {13, 13}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Vb_grid annotation(
    Placement(visible = true, transformation(origin = {1, -113}, extent = {{-13, -13}, {13, 13}}, rotation = 90), iconTransformation(origin = {-113, -1}, extent = {{-13, -13}, {13, 13}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Vc_grid annotation(
    Placement(visible = true, transformation(origin = {61, -113}, extent = {{-13, -13}, {13, 13}}, rotation = 90), iconTransformation(origin = {-113, -59}, extent = {{-13, -13}, {13, 13}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput theta annotation(
    Placement(visible = true, transformation(origin = {78, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, -48}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Park park annotation(
    Placement(visible = true, transformation(origin = {1, -33}, extent = {{-19, -19}, {19, 19}}, rotation = 90)));
  Modelica.Blocks.Continuous.Integrator integrator annotation(
    Placement(visible = true, transformation(origin = {4, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput Vzq annotation(
    Placement(visible = true, transformation(origin = {-86, -4}, extent = {{-10, -10}, {10, 10}}, rotation = 180), iconTransformation(origin = {110, 50}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Feedback feedback annotation(
    Placement(visible = true, transformation(origin = {-84, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Sources.Constant const0(k = 0)  annotation(
    Placement(visible = true, transformation(origin = {-128, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  PI_PLL pi_pll_kf annotation(
    Placement(visible = true, transformation(origin = {-34, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  modu m annotation(
    Placement(visible = true, transformation(origin = { 42, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(Vb_grid, park.b) annotation(
    Line(points = {{1, -113}, {1, -54}}, color = {0, 0, 127}));
  connect(park.q, Vzq) annotation(
    Line(points = {{-4, -12}, {-4, -4}, {-86, -4}}, color = {0, 0, 127}));
  connect(const0.y, feedback.u1) annotation(
    Line(points = {{-116, 40}, {-90, 40}, {-90, 40}, {-92, 40}}, color = {0, 0, 127}));
  connect(feedback.u2, park.d) annotation(
    Line(points = {{-84, 32}, {-84, 32}, {-84, 2}, {6, 2}, {6, -12}, {6, -12}}, color = {0, 0, 127}));
  connect(feedback.y, pi_pll_kf.u) annotation(
    Line(points = {{-74, 40}, {-46, 40}, {-46, 40}, {-44, 40}}, color = {0, 0, 127}));
  connect(pi_pll_kf.y, integrator.u) annotation(
    Line(points = {{-24, 40}, {-8, 40}}, color = {0, 0, 127}));
  connect(integrator.y, m.u) annotation(
    Line(points = {{16, 40}, {28, 40}, {28, 40}, {30, 40}}, color = {0, 0, 127}));
  connect(m.y, theta) annotation(
    Line(points = {{52, 40}, {72, 40}, {72, 40}, {78, 40}}, color = {0, 0, 127}));
  connect(Va_grid, park.a) annotation(
    Line(points = {{-57, -113}, {-58, -113}, {-58, -60}, {-6, -60}, {-6, -54}}, color = {0, 0, 127}));
  connect(park.c, Vc_grid) annotation(
    Line(points = {{8, -54}, {8, -60}, {61, -60}, {61, -113}}, color = {0, 0, 127}));
  connect(theta, park.theta) annotation(
    Line(points = {{78, 40}, {82, 40}, {82, -34}, {22, -34}, {22, -32}}, color = {0, 0, 127}));  protected
  annotation(
    uses(Modelica(version = "3.2.3")),
    Diagram,
  Icon(graphics = {Rectangle(origin = {-8, 1}, extent = {{-92, 99}, {108, -101}}), Text(origin = {29, -12}, extent = {{-65, 38}, {17, -12}}, textString = "PLL"), Text(origin = {-85, 59}, extent = {{-11, 5}, {11, -5}}, textString = "Va"), Text(origin = {81, -45}, extent = {{-11, 5}, {11, -5}}, textString = "theta"), Text(origin = {77, 51}, extent = {{-11, 5}, {11, -5}}, textString = "Vzq"), Text(origin = {-85, -59}, extent = {{-11, 5}, {11, -5}}, textString = "Vc"), Text(origin = {-85, 1}, extent = {{-11, 5}, {11, -5}}, textString = "Vb")}, coordinateSystem(initialScale = 0.1)));
end PLL2;
