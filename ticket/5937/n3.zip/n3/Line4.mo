model Line4
  Modelica.Electrical.MultiPhase.Interfaces.PositivePlug p annotation(
    Placement(visible = true, transformation(origin = {-100, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-100, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Interfaces.NegativePlug n annotation(
    Placement(visible = true, transformation(origin = {100, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {100, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Resistor resistor(R = fill(0.12272, 3))  annotation(
    Placement(visible = true, transformation(origin = {-22, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Inductor inductor(L = fill(0.317e-3, 3))  annotation(
    Placement(visible = true, transformation(origin = {20, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(resistor.plug_n, inductor.plug_p) annotation(
    Line(points = {{-12, 0}, {10, 0}, {10, 0}, {10, 0}}, color = {0, 0, 255}));
  connect(inductor.plug_n, n) annotation(
    Line(points = {{30, 0}, {100, 0}, {100, 0}, {100, 0}}, color = {0, 0, 255}));
  connect(resistor.plug_p, p) annotation(
    Line(points = {{-32, 0}, {-98, 0}, {-98, 0}, {-100, 0}}));
  annotation(
    uses(Modelica(version = "3.2.3")),
    Icon(graphics = {Rectangle(fillPattern = FillPattern.Solid, extent = {{-60, 20}, {60, -20}}), Line(origin = {1.17991, 15.2042}, points = {{90.8201, -15.2042}, {-91.1799, -15.2042}, {90.8201, -15.2042}})}, coordinateSystem(initialScale = 0.1)));
end Line4;
