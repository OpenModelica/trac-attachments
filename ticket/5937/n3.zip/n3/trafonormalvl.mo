model trafonormalvl
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage(V = fill(32600, 3), freqHz = fill(50, 3))  annotation(
    Placement(visible = true, transformation(origin = { 50, 22}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star annotation(
    Placement(visible = true, transformation(origin = {64, -34}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
  trafo_three_w trafo_three_w6 annotation(
    Placement(visible = true, transformation(origin = {-16, 22}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage1(V = fill(326, 3), freqHz = fill(50, 3)) annotation(
    Placement(visible = true, transformation(origin = {-68, 54}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Sources.SineVoltage sineVoltage2(V = fill(326, 3), freqHz = fill(50, 3)) annotation(
    Placement(visible = true, transformation(origin = {-72, -14}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Basic.Ground ground annotation(
    Placement(visible = true, transformation(origin = {64, -62}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.Analog.Basic.Ground ground1 annotation(
    Placement(visible = true, transformation(origin = {-100, -62}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Electrical.MultiPhase.Basic.Star star1 annotation(
    Placement(visible = true, transformation(origin = {-100, -34}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
equation
  connect(sineVoltage.plug_n, star.plug_p) annotation(
    Line(points = {{60, 22}, {64, 22}, {64, -24}}, color = {0, 0, 255}));
  connect(trafo_three_w6.out, sineVoltage.plug_p) annotation(
    Line(points = {{-6, 22}, {40, 22}, {40, 22}, {40, 22}}, color = {0, 0, 255}));
  connect(trafo_three_w6.pin_n, star.pin_n) annotation(
    Line(points = {{-18, 12}, {-14, 12}, {-14, -46}, {54, -46}, {54, -44}, {64, -44}, {64, -44}}, color = {0, 0, 255}));
  connect(sineVoltage2.plug_n, trafo_three_w6.in2) annotation(
    Line(points = {{-62, -14}, {-26, -14}, {-26, 20}, {-26, 20}}, color = {0, 0, 255}));
  connect(trafo_three_w6.in1, sineVoltage1.plug_n) annotation(
    Line(points = {{-26, 24}, {-22, 24}, {-22, 54}, {-58, 54}, {-58, 54}}, color = {0, 0, 255}));
  connect(star.pin_n, ground.p) annotation(
    Line(points = {{64, -44}, {64, -52}}, color = {0, 0, 255}));
  connect(star1.plug_p, sineVoltage2.plug_p) annotation(
    Line(points = {{-100, -24}, {-100, -24}, {-100, -14}, {-82, -14}, {-82, -14}}, color = {0, 0, 255}));
  connect(star1.plug_p, sineVoltage1.plug_p) annotation(
    Line(points = {{-100, -24}, {-98, -24}, {-98, 54}, {-78, 54}, {-78, 54}}, color = {0, 0, 255}));
  connect(star1.pin_n, ground1.p) annotation(
    Line(points = {{-100, -44}, {-100, -44}, {-100, -52}, {-100, -52}}, color = {0, 0, 255}));
  annotation(
    uses(Modelica(version = "3.2.3")));
end trafonormalvl;
