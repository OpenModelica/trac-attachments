import java.io.IOException;
import java.io.InputStream;

public class OmcCrash 
{
	public static void main(String[] args) throws IOException 
	{
		Process p = Runtime.getRuntime().
			exec(new String[]
		             {"c:\\OpenModelica13\\omc.exe", "+d=interactiveCorba"},
				 new String[]
				     { "MODELICAPATH=c:\\OpenModelica13\\ModelicaLibrary"});
		
		int meep;
		InputStream err = p.getErrorStream();
		
		
		while (-1 != (meep = err.read()))
		{
			System.err.print((char)meep);
		}

		InputStream in = p.getInputStream();
		
		while (-1 != (meep = in.read()))
		{
			System.out.print((char)meep);
		}
	}
}
