package Testing

  model Test
    import load = ModelicaServices.ExternalReferences.loadResource;
    parameter String fileName1 = Modelica.Utilities.Files.loadResource("modelica://Testing/Resources/Data/TestFile.txt");
    Modelica.Blocks.Sources.CombiTimeTable 
      combiTimeTable1(
        extrapolation = Modelica.Blocks.Types.Extrapolation.Periodic, 
        fileName = fileName1, 
        smoothness = Modelica.Blocks.Types.Smoothness.ConstantSegments, 
        tableName = "TestTable", 
        tableOnFile = true);
        
    parameter String fileName2 = load("modelica://Testing/Folder/TestFile.txt");
    Modelica.Blocks.Sources.CombiTimeTable 
      combiTimeTable2(
        extrapolation = Modelica.Blocks.Types.Extrapolation.Periodic, 
        fileName = fileName2,
        smoothness = Modelica.Blocks.Types.Smoothness.ConstantSegments, 
        tableName = "TestTable", 
        tableOnFile = true);
  end Test;

end Testing;
