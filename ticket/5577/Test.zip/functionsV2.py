import numpy as np

def multiply(a,b):
    #print("Will compute", a, "times", b)
    #print("Result shoud be", a*b)
    return a*b
    
def sinus(a,b):
    #print("Computing sin(",a,")")
    #print("Result shoud be", np.sin(a))
    return np.sin(a)

    
def call_the_right_function(a,b,c):
    if c == 0:
      return multiply(a,b)
    elif c == 1:
      return sinus(a,b)