within Test;
package pack1
  extends Modelica.Icons.VariantsPackage;

end pack1;
