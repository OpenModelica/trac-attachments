within Test;
package pack2
  extends Modelica.Icons.TypesPackage;

end pack2;