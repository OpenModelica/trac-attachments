package Test
  extends Modelica.Icons.Package;
  // test 

end Test;
