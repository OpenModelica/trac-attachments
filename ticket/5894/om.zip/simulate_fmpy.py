# -*- coding: utf-8 -*-
# @Author: Claire-Eleutheriane Gerrer
# @Date:   2019-09-10 13:58:45
# @Last Modified by:   gerrer
# @Last Modified time: 2020-03-24 11:15:07

""" Simulate a simple model many times.
"""

import fmpy
sample_size = 1200

for ii in range(sample_size):
    print("Run number {}".format(ii))
    tmp = fmpy.simulate_fmu(
        filename="epid_recompiled.fmu")