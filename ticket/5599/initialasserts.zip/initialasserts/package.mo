within ;
package initialasserts
annotation (uses(Modelica(version="3.2.2")));
end initialasserts;
