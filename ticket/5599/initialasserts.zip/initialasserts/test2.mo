within initialasserts;
model test2
  test test1 annotation (Placement(transformation(extent={{-24,-6},{-4,14}})));
  Modelica.Blocks.Sources.Ramp ramp(
    height=-2,
    duration=1,
    offset=1) annotation (Placement(visible = true, transformation(extent = {{-62, -4}, {-42, 16}}, rotation = 0)));
equation
  connect(ramp.y, test1.u) annotation(
    Line(points = {{-40, 6}, {-24, 6}, {-24, 4}, {-24, 4}}, color = {0, 0, 127}));
  annotation (Icon(coordinateSystem(preserveAspectRatio=false)), Diagram(coordinateSystem(preserveAspectRatio=false)));
end test2;
