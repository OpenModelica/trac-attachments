within initialasserts;
model test
  Real a;
  Real b (start=0, fixed=false, stateSelect=StateSelect.always);

  Modelica.Blocks.Interfaces.RealInput u annotation (Placement(transformation(extent={{-120,-20},{-80,20}})));

initial equation
  if a <= -0.2 then
    assert(b >= 0,"u has to be greater 0 at t = 0");
  end if;
  
  b = 1;
  
equation
  der(b) = a;
  a = u;
  when a <= -0.2 then
   reinit(b, 0.0);
  end when;

  annotation (Icon(coordinateSystem(preserveAspectRatio=false)), Diagram(coordinateSystem(preserveAspectRatio=false)));
end test;
