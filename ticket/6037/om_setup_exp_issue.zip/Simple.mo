model Simple
output Real x;
initial equation
x = 0.0;
equation
der(x) = 1.0;
end Simple;
