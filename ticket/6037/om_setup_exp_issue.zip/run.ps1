
$Config = ".\cosim_scenario.json"

Remove-Item .\*.log

java -jar ".\coe_without_stop_time.jar" -v --configuration "$Config" --oneshot --starttime 0.0 --endtime 0.02 -v -r output_without_stop_time.csv
Move-Item .\coe.log .\coe_without_stop_time.log

java -jar ".\coe_with_stop_time.jar" -v --configuration "$Config" --oneshot --starttime 0.0 --endtime 0.02 -v -r output_with_stop_time.csv
Move-Item .\coe.log .\output_with_stop_time.log

