package Array1

function fromList
  input List<Integer> list;
  output Array<Integer> array;
algorithm
  array := listArray(list);
end fromList;

function toList
  input Array<Integer> array;
  output List<Integer> list;
algorithm
  list := arrayList(array);
end toList;

function test2
  input List<Integer> list;
  output List<Integer> olist;
algorithm
  // No error message.
  // olist := arrayList(fromList(list));

  // No error message.
  // olist := toList(listArray(list));

  // Produces error message
  olist := toList(fromList(list));
end test2;

end Array1;
