within TestLibraryIndentation;

package IndentationPackage
  model IndentationModel1
    Modelica.Mechanics.MultiBody.Parts.Fixed fixed1 annotation(
      Placement(visible = true, transformation(origin = {-40, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    Modelica.Mechanics.MultiBody.Parts.FixedTranslation fixedTranslation1(r = {0, 0, 0}) annotation(
      Placement(visible = true, transformation(origin = {0, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    Modelica.Mechanics.MultiBody.Parts.Body body1 annotation(
      Placement(visible = true, transformation(origin = {34, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  equation
    connect(fixed1.frame_b, fixedTranslation1.frame_a) annotation(
      Line(points = {{-30, 0}, {-10, 0}, {-10, 0}, {-10, 0}}, color = {95, 95, 95}));
    connect(fixedTranslation1.frame_b, body1.frame_a) annotation(
      Line(points = {{10, 0}, {24, 0}, {24, 0}, {24, 0}}, color = {95, 95, 95}));
  end IndentationModel1;

  model IndentationModel2
    Modelica.Mechanics.MultiBody.Parts.Fixed fixed1 annotation(
      Placement(visible = true, transformation(origin = {-40, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    Modelica.Mechanics.MultiBody.Parts.FixedTranslation fixedTranslation1(r = {0, 0, 0}) annotation(
      Placement(visible = true, transformation(origin = {0, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    Modelica.Mechanics.MultiBody.Parts.Body body1 annotation(
      Placement(visible = true, transformation(origin = {28, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  equation
    connect(fixed1.frame_b, fixedTranslation1.frame_a) annotation(
      Line(points = {{-30, 0}, {-10, 0}, {-10, 0}, {-10, 0}}, color = {95, 95, 95}));
    connect(fixedTranslation1.frame_b, body1.frame_a) annotation(
      Line(points = {{10, 0}, {18, 0}, {18, 0}, {18, 0}}, color = {95, 95, 95}));
  end IndentationModel2;

  package InnerPackage
    model InnerIndentationIssue
      Modelica.Mechanics.MultiBody.Parts.Fixed fixed1 annotation(
        Placement(visible = true, transformation(origin = {-40, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
      Modelica.Mechanics.MultiBody.Parts.FixedTranslation fixedTranslation1(r = {0, 0, 0}) annotation(
        Placement(visible = true, transformation(origin = {-6, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    Modelica.Mechanics.MultiBody.Parts.Body body1 annotation(
        Placement(visible = true, transformation(origin = {32, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    equation
      connect(fixed1.frame_b, fixedTranslation1.frame_a) annotation(
        Line(points = {{-30, 0}, {-10, 0}, {-10, 0}, {-10, 0}}, color = {95, 95, 95}));
    connect(fixedTranslation1.frame_b, body1.frame_a) annotation(
        Line(points = {{4, 0}, {22, 0}, {22, 0}, {22, 0}}, color = {95, 95, 95}));
    end InnerIndentationIssue;
  end InnerPackage;
end IndentationPackage;
