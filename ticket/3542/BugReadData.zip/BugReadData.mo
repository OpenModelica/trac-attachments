model BugReadData
  constant String Path = Modelica.Utilities.Files.loadResource("modelica://BugReadData/");
  Modelica.Blocks.Tables.CombiTable1Ds Data(tableOnFile = true, tableName = "data", fileName = Path + "FileToRead.txt", columns = 1:4, smoothness = Modelica.Blocks.Types.Smoothness.ContinuousDerivative) "Data reader" annotation(Placement(visible = true, transformation(origin = {-10, 10}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  Data.u = 2;
end BugReadData;