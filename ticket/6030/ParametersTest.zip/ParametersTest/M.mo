within ParametersTest;

model M
  inner Config config annotation(
    Placement(visible = true, transformation(origin = {78, 64}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation

end M;
