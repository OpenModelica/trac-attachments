within ParametersTest;

record Config
  extends Modelica.Icons.Record;
  import SI = Modelica.SIunits;
  constant String paramFile = Modelica.Utilities.Files.loadResource("modelica://ParametersTest/Resources/Parameters.txt");
  parameter Real a = Modelica.Utilities.Examples.readRealParameter(paramFile, "a");
  annotation(
    defaultComponentName = "config",
    defaultComponentPrefixes = "inner",
    missingInnerMessage = "No \"config\" component is defined");
end Config;
