within EmbeddedFunctions;
partial function Integrand
  input  Real u;
  output Real y;
end Integrand;
