within EmbeddedFunctions;
model UseQuadratureDefault

  Modelica.Blocks.Interfaces.RealOutput area annotation (Placement(transformation(extent={{90,-10},{110,10}})));
equation
area = quadrature(0, 1);
  annotation (Icon(coordinateSystem(preserveAspectRatio=false)), Diagram(coordinateSystem(preserveAspectRatio=false)));
end UseQuadratureDefault;
