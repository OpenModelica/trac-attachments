within EmbeddedFunctions;
function Parabola
   extends Integrand;
algorithm
   y :=x*x;
end Parabola;
