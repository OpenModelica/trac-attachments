within EmbeddedFunctions;
model UseQuadrature
function Parabola
   extends Integrand;
algorithm
   y :=u*u;
end Parabola;

  Modelica.Blocks.Interfaces.RealOutput area annotation (Placement(transformation(extent={{90,-10},{110,10}})));
equation
area = quadrature(0, 1, Parabola);
  annotation (Icon(coordinateSystem(preserveAspectRatio=false)), Diagram(coordinateSystem(preserveAspectRatio=false)));
end UseQuadrature;
