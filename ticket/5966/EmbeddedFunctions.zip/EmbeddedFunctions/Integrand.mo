within EmbeddedFunctions;
partial function Integrand
  input  Real x;
  output Real y;
end Integrand;
