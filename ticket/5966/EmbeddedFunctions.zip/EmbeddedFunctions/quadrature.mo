within EmbeddedFunctions;
function quadrature "Integrate function y=integrand(x) from x1 to x2"
  input  Real x1;
  input  Real x2;
  // input Integrand integrand; // WORK
  input Integrand integrand =  Modelica.Math.sin; // NOT WORK
  output Real integral;
algorithm
  integral :=(x2-x1)*(integrand(x1) + integrand(x2))/2;
end quadrature;
