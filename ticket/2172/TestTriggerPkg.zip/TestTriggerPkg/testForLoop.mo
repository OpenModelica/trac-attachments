within TestTriggerPkg;
model testForLoop
  TestTriggerPkg.testForLoopBlock block1(nValues=2);

  Modelica.Blocks.Sources.Pulse pulse(
    period=0.5,
    amplitude=2,
    offset=-1) annotation (Placement(transformation(extent={{-34,4},{-14,24}})));
  Modelica.Blocks.Math.RealToInteger realToInteger
    annotation (Placement(transformation(extent={{10,4},{30,24}})));
equation
  block1.triggerInput = realToInteger.y;
  connect(pulse.y, realToInteger.u) annotation (Line(
      points={{-13,14},{8,14}},
      color={0,0,127},
      smooth=Smooth.None));
  annotation (Diagram(coordinateSystem(preserveAspectRatio=false, extent={{-100,
            -100},{100,100}}), graphics));
end testForLoop;
