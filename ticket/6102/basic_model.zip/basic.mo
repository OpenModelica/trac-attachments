model basic

parameter Real mu = 2;
parameter Real lambda = -1;

Real y(start=2);

equation
der(y) = mu*y + 3*lambda;

end basic;