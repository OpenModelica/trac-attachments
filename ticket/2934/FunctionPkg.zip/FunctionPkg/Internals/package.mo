within FunctionPkg;
package Internals 
end Internals;
