within FunctionPkg.Internals;
type LiquidName "Liquid name"
  extends String;
  annotation(choices(choice = "TILMedia.Water", choice = "TILMedia.Glysantin_30"));
end LiquidName;
