within FunctionPkg;
model testFctFromFct
  replaceable parameter LiquidTypes.TILMedia_Water liquidType constrainedby
    LiquidTypes.BaseLiquid "type record of the liquid";

  parameter Modelica.SIunits.AbsolutePressure p = 1e5;
  Modelica.SIunits.SpecificEnthalpy h;

  Modelica.SIunits.SpecificEntropy s;

equation
  h = time * 100;
  s = specificEntropy_phxi(liquidType, p, h, liquidType.xi_default);

end testFctFromFct;
