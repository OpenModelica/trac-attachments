TEMPLATE=subdirs

SUBDIRS = modpar mos runtime absyn_builder omc


mos.file    = mos.pro
mos.depends = modpar

runtime.subdir  = runtime
runtime.depends = #??? something above

absyn_builder.subdir  = absyn_builder
absyn_builder.depends = mos modpar #flat_modelica_parser -- from above

omc.file   = omc.pro
omc.depend = 

