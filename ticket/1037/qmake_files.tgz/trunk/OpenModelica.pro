TEMPLATE=subdirs

SUBDIRS  = c_runtime OMShell OMNotebook 
SUBDIRS += modelica_parser flat_modelica_parser 
SUBDIRS += Compiler

c_runtime.subdir    = c_runtime

OMShell.subdir      = OMShell
OMNotebook.subdir   = OMNotebook

modelica_parser.subdir = modelica_parser

flat_modelica_parser.subdir  = flat_modelica_parser
flat_modelica_parser.depends = modelica_parser

Compiler.subdir    = Compiler
Compiler.depends   = flat_modelica_parser


#OMShell.file    = tests/proj.pro
#sub_tests.depends = sub_lib
#sub_app.subdir    = app
#sub_app.depends   = sub_lib


#SUBDIRS += c_runtime/c_runtime.pro
#
#SUBDIRS += OMShell/OMShell.pro
#SUBDIRS += OMNotebook/OMNotebook.pro


######################################################################
# here are some helpful notes...
######################################################################

# http://doc.trolltech.com/3.3/qmake-manual-5.html
# http://doc.trolltech.com/4.4/qmake-tutorial.html

# http://forums.nvidia.com/index.php?showtopic=29539

# http://paulf.free.fr/undocumented_qmake.html

# *** http://wiki.qtcentre.org/index.php?title=Undocumented_qmake

#TEMPLATE = subdirs
#SUBDIRS  = sub_lib sub_tests sub_app
# 
#sub_lib.subdir    = lib
#sub_tests.file    = tests/proj.pro
#sub_tests.depends = sub_lib
#sub_app.subdir    = app
#sub_app.depends   = sub_lib
