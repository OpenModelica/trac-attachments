TEMPLATE=subdirs

SUBDIRS  = f2c sendData sim c_runtime

f2c.subdir        = libf2c

sendData.subdir   = sendData

c_runtime.file    = libc_runtime.pro
c_runtime.depends = sendData

sim.file          = libc_runtime.pro
sim.depends       = sendData f2c
