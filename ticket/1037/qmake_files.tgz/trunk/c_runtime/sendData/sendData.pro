######################################################################

TEMPLATE     = lib
DEPENDPATH  += .
INCLUDEPATH += .

win32: CONFIG += dll
unix:  CONFIG += staticlib

QT += network core gui

SANDBOX = ../../build

INCLUDEPATH += $${SANDBOX}/include
DESTDIR      = $${SANDBOX}

CONFIG += debug_and_release
CONFIG(debug, debug|release) {
  TARGET = lib/sendData_debug
} else {
  TARGET = lib/sendData
}
CONFIG      += warn_on

# Input
NEWHS   += sendData.h
HEADERS += $${NEWHS}
SOURCES += sendData.cpp humbug.cpp

# this is a little trick to force copying the header files to the sandbox
!exists(.FORCE.) {
  system(mkdir -p $${SANDBOX}/include)
  system(cp -a $${NEWHS} $${SANDBOX}/include)
}
