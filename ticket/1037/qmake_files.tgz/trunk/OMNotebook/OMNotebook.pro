TEMPLATE=subdirs

SUBDIRS+=./ext/ext.pro
SUBDIRS+=./OMNotebookQT4/OMNotebook.pro

