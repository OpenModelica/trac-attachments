TEMPLATE=subdirs

SUBDIRS = src
