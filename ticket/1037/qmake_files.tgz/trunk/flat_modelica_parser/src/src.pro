
# hand generated file for libflat_modelica_parser

TEMPLATE = lib

DEPENDPATH  += .
INCLUDEPATH += .

win32: CONFIG += dll
unix:  CONFIG += staticlib

SANDBOX      = ../../build
INCLUDEPATH += $${SANDBOX}/include
DESTDIR      = $${SANDBOX}

CONFIG += debug_and_release
CONFIG(debug, debug|release) {
  TARGET = lib/flat_modelica_parser_debug
} else {
  TARGET = lib/flat_modelica_parser
}
CONFIG += warn_on


#############################################################
# ANTLR scripts and tools (gratis of Ken Cecka)
#############################################################

ANTLR_GRAMMARS = flat_modelica_lexer.g  flat_modelica_parser.g

# find the class path and set up the antlr command
CLASSPATH = "$(CLASSPATH):$$system(java-config -p antlr)"
isEmpty(CLASSPATH) {
  error (Could not find antlr! )
}

#global defaults
isEmpty(ANTLR_DIR):ANTLR_DIR = $${SANDBOX}/include
isEmpty(ANTLR_CMD):ANTLR_CMD = java -cp $${CLASSPATH} antlr.Tool $${ANTLRFLAGS}

#dependency to generate *.cpp from *.g
antlr_cpp.name         = ANTLR_CPP ${QMAKE_FILE_IN}
antlr_cpp.commands     = $${ANTLR_CMD} -o $${ANTLR_DIR} ${QMAKE_FILE_NAME}
antlr_cpp.variable_out = SOURCES
antlr_cpp.output       = $${ANTLR_DIR}/${QMAKE_FILE_BASE}.cpp
antlr_cpp.input        = ANTLR_GRAMMARS
antlr_cpp.clean        = $${ANTLR_DIR}/${QMAKE_FILE_BASE}.cpp
QMAKE_EXTRA_COMPILERS += antlr_cpp

#dependency to generate *.hpp from *.g
antlr_hpp.name         = ANTLR_HPP ${QMAKE_FILE_IN}
antlr_hpp.commands     = $${ANTLR_CMD} -o $${ANTLR_DIR} ${QMAKE_FILE_NAME}
antlr_hpp.CONFIG      += no_link
antlr_hpp.variable_out = HEADERS
antlr_hpp.output       = $${ANTLR_DIR}/${QMAKE_FILE_BASE}.hpp
antlr_hpp.input        = ANTLR_GRAMMARS
antlr_hpp.clean        = $${ANTLR_DIR}/${QMAKE_FILE_BASE}.hpp
QMAKE_EXTRA_COMPILERS += antlr_hpp

#dependency to generate *TokenTypes.hpp from *.g
antlrTokenTypes_hpp.name     = ANTLRTOKENTYPES_HPP ${QMAKE_FILE_IN}
antlrTokenTypes_hpp.commands = $${ANTLR_CMD} -o $${ANTLR_DIR} ${QMAKE_FILE_NAME}
antlrTokenTypes_hpp.CONFIG  += no_link
antlr_hpp.variable_out       = HEADERS
antlrTokenTypes_hpp.output   = $${ANTLR_DIR}/${QMAKE_FILE_BASE}TokenTypes.hpp
antlrTokenTypes_hpp.input    = ANTLR_GRAMMARS
antlrTokenTypes_hpp.clean    = $${ANTLR_DIR}/${QMAKE_FILE_BASE}TokenTypes.hpp
QMAKE_EXTRA_COMPILERS       += antlrTokenTypes_hpp

#dependency to generate *TokenTypes.txt from *.g
antlrTokenTypes_txt.name     = ANTLRTOKENTYPES_TXT ${QMAKE_FILE_IN}
antlrTokenTypes_txt.commands = $${ANTLR_CMD} -o $${ANTLR_DIR} ${QMAKE_FILE_NAME}
antlrTokenTypes_txt.CONFIG  += no_link
antlrTokenTypes_txt.output   = $${ANTLR_DIR}/${QMAKE_FILE_BASE}TokenTypes.txt
antlrTokenTypes_txt.input    = ANTLR_GRAMMARS
antlrTokenTypes_txt.clean    = $${ANTLR_DIR}/${QMAKE_FILE_BASE}TokenTypes.txt
QMAKE_EXTRA_COMPILERS       += antlrTokenTypes_txt


# hand generated file for libflat_modelica_parser

#TEMPLATE = lib
#
#DEPENDPATH  += .
#INCLUDEPATH += .
#
#win32: CONFIG += dll
#unix:  CONFIG += staticlib
#
#SANDBOX = ../../build
#
#DESTDIR = $${SANDBOX}
#
#CONFIG += debug_and_release
#CONFIG(debug, debug|release) {
#  TARGET = lib/flat_modelica_parser_debug
#} else {
#  TARGET = lib/flat_modelica_parser
#}
#CONFIG      += warn_on
#
#isEmpty(ANTLR_DIR):ANTLR_DIR = .
#
#!exists(flat_modelica_lexer.hpp) {
#  message("The following missing file messages can be ignored.  They will be generatede by ANTLR.")
#}
##
#
## set ANTLR up to generate the lexer and parser.
#CLASSPATH   = /usr/share/antlr/lib/antlr.jar
#CFLAGS_FILE = . # needed to force qmake to run the generation commands
#
#INCLUDEPATH += ../../modelica_parser/src
#
## generate the lexer source and header files
#lexer_c.output = flat_modelica_lexer.cpp flat_modelica_lexer.hpp \
#               flat_modelicaTokenTypes.hpp flat_modelicaTokenTypes.txt
#lexer_c.input = CFLAGS_FILE
#lexer_c.commands = java -cp $${CLASSPATH} antlr.Tool $${ANTLRFLAGS} \
#                   flat_modelica_lexer.g
#lexer_c.variable_out = JUNK
#lexer_c.name = flat_modelica_lexer.hpp
#lexer_c.CONFIG = no_link
#QMAKE_EXTRA_COMPILERS += lexer_c
#
#
## generate the parser source and header files
#parser_c.output = flat_modelica_parser.cpp flat_modelica_parser.hpp \
#           flat_modelica_parserTokenTypes.hpp flat_modelica_parserTokenTypes.txt
#parser_c.input = CFLAGS_FILE
#parser_c.commands = java -cp $${CLASSPATH} antlr.Tool $${ANTLRFLAGS} \
#                   flat_modelica_parser.g modelica_lexer.g
#parser_c.variable_out = JUNK
#parser_c.name = flat_modelica_lexer.hpp
#parser_c.CONFIG = no_link
#QMAKE_EXTRA_COMPILERS += parser_c
#
#
## these are the generated header and source files for the lexer and parser
#HEADERS += flat_modelica_lexer.hpp \
#           flat_modelicaTokenTypes.hpp flat_modelicaTokenTypes.txt
#HEADERS += flat_modelica_parser.hpp \
#           flat_modelica_parserTokenTypes.hpp flat_modelica_parserTokenTypes.txt
#SOURCES += flat_modelica_lexer.cpp
#SOURCES += flat_modelica_parser.cpp
#
#
## the generated header and source files can be cleaned up afterwards...
#QMAKE_CLEAN += flat_modelica_lexer.hpp \
#               flat_modelicaTokenTypes.hpp flat_modelicaTokenTypes.txt
#QMAKE_CLEAN += flat_modelica_parser.hpp \
#               flat_modelica_parserTokenTypes.hpp flat_modelica_parserTokenTypes.txt
#QMAKE_CLEAN += modelicaTokenTypes.hpp modelicaTokenTypes.txt
#QMAKE_CLEAN += flat_modelica_lexer.cpp
#QMAKE_CLEAN += flat_modelica_parser.cpp#
#
#QMAKE_DISTCLEAN += release/* debug/*

