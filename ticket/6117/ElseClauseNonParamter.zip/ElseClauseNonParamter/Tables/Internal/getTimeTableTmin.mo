within ElseClauseNonParamter.Tables.Internal;
function getTimeTableTmin
  "Return minimum abscissa value of 1-dim. table where first column is time"
  extends Modelica.Icons.Function;
  input Modelica.Blocks.Types.ExternalCombiTimeTable tableID;
  output Real timeMin "Minimum abscissa value in table";
  external"C" timeMin = ModelicaStandardTables_CombiTimeTable_minimumTime(tableID)
    annotation (Library={"ModelicaStandardTables", "ModelicaIO", "ModelicaMatIO", "zlib"});
end getTimeTableTmin;
