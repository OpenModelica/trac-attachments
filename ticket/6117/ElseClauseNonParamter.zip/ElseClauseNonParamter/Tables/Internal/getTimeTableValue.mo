within ElseClauseNonParamter.Tables.Internal;
function getTimeTableValue
  "Interpolate 1-dim. table where first column is time"
  extends Modelica.Icons.Function;
  input Modelica.Blocks.Types.ExternalCombiTimeTable tableID;
  input Integer icol;
  input Real timeIn;
  discrete input Real nextTimeEvent;
  discrete input Real pre_nextTimeEvent;
  output Real y;
  external"C" y = ModelicaStandardTables_CombiTimeTable_getValue(tableID, icol, timeIn, nextTimeEvent, pre_nextTimeEvent)
    annotation (Library={"ModelicaStandardTables", "ModelicaIO", "ModelicaMatIO", "zlib"});
  annotation (derivative(
      noDerivative=nextTimeEvent,
      noDerivative=pre_nextTimeEvent) = getDerTimeTableValue);
end getTimeTableValue;
