within ElseClauseNonParamter.Tables.Internal;
function getNextTimeEvent
  "Return next time event value of 1-dim. table where first column is time"
  extends Modelica.Icons.Function;
  input Modelica.Blocks.Types.ExternalCombiTimeTable tableID;
  input Real timeIn;
  output Real nextTimeEvent "Next time event in table";
  external"C" nextTimeEvent = ModelicaStandardTables_CombiTimeTable_nextTimeEvent(tableID, timeIn)
    annotation (Library={"ModelicaStandardTables", "ModelicaIO", "ModelicaMatIO", "zlib"});
end getNextTimeEvent;
