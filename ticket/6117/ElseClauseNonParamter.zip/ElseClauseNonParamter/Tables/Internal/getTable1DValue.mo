within ElseClauseNonParamter.Tables.Internal;
function getTable1DValue "Interpolate 1-dim. table defined by matrix"
  extends Modelica.Icons.Function;
  input Modelica.Blocks.Types.ExternalCombiTable1D tableID;
  input Integer icol;
  input Real u;
  output Real y;
  external"C" y = ModelicaStandardTables_CombiTable1D_getValue(tableID, icol, u)
    annotation (Library={"ModelicaStandardTables", "ModelicaIO", "ModelicaMatIO", "zlib"});
  annotation (derivative = getDerTable1DValue);
end getTable1DValue;
