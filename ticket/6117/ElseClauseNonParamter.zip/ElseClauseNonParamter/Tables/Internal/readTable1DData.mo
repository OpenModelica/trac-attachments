within ElseClauseNonParamter.Tables.Internal;
function readTable1DData "Read table data from text or MATLAB MAT-file"
  extends Modelica.Icons.Function;
  input Modelica.Blocks.Types.ExternalCombiTable1D tableID;
  input Boolean forceRead = false
    "= true: Force reading of table data; = false: Only read, if not yet read.";
  input Boolean verboseRead = true
    "= true: Print info message; = false: No info message";
  output Real readSuccess "Table read success";
  external"C" readSuccess = ModelicaStandardTables_CombiTable1D_read(tableID, forceRead, verboseRead)
    annotation (Library={"ModelicaStandardTables", "ModelicaIO", "ModelicaMatIO", "zlib"});
  annotation(__ModelicaAssociation_Impure=true);
end readTable1DData;
