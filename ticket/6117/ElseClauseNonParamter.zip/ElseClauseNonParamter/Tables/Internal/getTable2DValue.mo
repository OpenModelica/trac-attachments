within ElseClauseNonParamter.Tables.Internal;
function getTable2DValue "Interpolate 2-dim. table defined by matrix"
  extends Modelica.Icons.Function;
  input Modelica.Blocks.Types.ExternalCombiTable2D tableID;
  input Real u1;
  input Real u2;
  output Real y;
  external"C" y = ModelicaStandardTables_CombiTable2D_getValue(tableID, u1, u2)
    annotation (Library={"ModelicaStandardTables", "ModelicaIO", "ModelicaMatIO", "zlib"});
  annotation (derivative(zeroDerivative=tableID) = getDerTable2DValue);
end getTable2DValue;
