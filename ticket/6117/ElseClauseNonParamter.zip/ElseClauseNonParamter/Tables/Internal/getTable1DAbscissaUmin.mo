within ElseClauseNonParamter.Tables.Internal;
function getTable1DAbscissaUmin
  "Return minimum abscissa value of 1-dim. table defined by matrix"
  extends Modelica.Icons.Function;
  input Modelica.Blocks.Types.ExternalCombiTable1D tableID;
  output Real uMin "Minimum abscissa value in table";
  external"C" uMin = ModelicaStandardTables_CombiTable1D_minimumAbscissa(tableID)
    annotation (Library={"ModelicaStandardTables", "ModelicaIO", "ModelicaMatIO", "zlib"});
end getTable1DAbscissaUmin;
