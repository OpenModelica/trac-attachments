within ElseClauseNonParamter.Tables.Internal;
function getDerTimeTableValue
  "Derivative of interpolated 1-dim. table where first column is time"
  extends Modelica.Icons.Function;
  input Modelica.Blocks.Types.ExternalCombiTimeTable tableID;
  input Integer icol;
  input Real timeIn;
  discrete input Real nextTimeEvent;
  discrete input Real pre_nextTimeEvent;
  input Real der_timeIn;
  output Real der_y;
  external"C" der_y = ModelicaStandardTables_CombiTimeTable_getDerValue(tableID, icol, timeIn, nextTimeEvent, pre_nextTimeEvent, der_timeIn)
    annotation (Library={"ModelicaStandardTables", "ModelicaIO", "ModelicaMatIO", "zlib"});
end getDerTimeTableValue;
