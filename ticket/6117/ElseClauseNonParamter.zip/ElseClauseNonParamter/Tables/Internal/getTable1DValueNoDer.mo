within ElseClauseNonParamter.Tables.Internal;
function getTable1DValueNoDer
  "Interpolate 1-dim. table defined by matrix (but do not provide a derivative function)"
  extends Modelica.Icons.Function;
  input Modelica.Blocks.Types.ExternalCombiTable1D tableID;
  input Integer icol;
  input Real u;
  output Real y;
  external"C" y = ModelicaStandardTables_CombiTable1D_getValue(tableID, icol, u)
    annotation (Library={"ModelicaStandardTables", "ModelicaIO", "ModelicaMatIO", "zlib"});
end getTable1DValueNoDer;
