within ElseClauseNonParamter.Tables.Internal;
function getDerTable2DValue
  "Derivative of interpolated 2-dim. table defined by matrix"
  extends Modelica.Icons.Function;
  input Modelica.Blocks.Types.ExternalCombiTable2D tableID;
  input Real u1;
  input Real u2;
  input Real der_u1;
  input Real der_u2;
  output Real der_y;
  external"C" der_y = ModelicaStandardTables_CombiTable2D_getDerValue(tableID, u1, u2, der_u1, der_u2)
    annotation (Library={"ModelicaStandardTables", "ModelicaIO", "ModelicaMatIO", "zlib"});
    annotation (derivative(zeroDerivative=tableID, order=2)= getDer2Table2DValue);
end getDerTable2DValue;
