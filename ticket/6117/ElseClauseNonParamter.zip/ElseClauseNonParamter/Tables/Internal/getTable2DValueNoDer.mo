within ElseClauseNonParamter.Tables.Internal;
function getTable2DValueNoDer
  "Interpolate 2-dim. table defined by matrix (but do not provide a derivative function)"
  extends Modelica.Icons.Function;
  input Modelica.Blocks.Types.ExternalCombiTable2D tableID;
  input Real u1;
  input Real u2;
  output Real y;
  external"C" y = ModelicaStandardTables_CombiTable2D_getValue(tableID, u1, u2)
    annotation (Library={"ModelicaStandardTables", "ModelicaIO", "ModelicaMatIO", "zlib"});
end getTable2DValueNoDer;
