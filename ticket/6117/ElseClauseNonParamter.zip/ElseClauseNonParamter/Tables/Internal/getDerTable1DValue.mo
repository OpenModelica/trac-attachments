within ElseClauseNonParamter.Tables.Internal;
function getDerTable1DValue
  "Derivative of interpolated 1-dim. table defined by matrix"
  extends Modelica.Icons.Function;
  input Modelica.Blocks.Types.ExternalCombiTable1D tableID;
  input Integer icol;
  input Real u;
  input Real der_u;
  output Real der_y;
  external"C" der_y = ModelicaStandardTables_CombiTable1D_getDerValue(tableID, icol, u, der_u)
    annotation (Library={"ModelicaStandardTables", "ModelicaIO", "ModelicaMatIO", "zlib"});
end getDerTable1DValue;
