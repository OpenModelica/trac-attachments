within ElseClauseNonParamter.Tables.Internal;
function getDer2Table2DValue "Second derivative of interpolated 2-dim. table defined by matrix"
  extends Modelica.Icons.Function;
  input Modelica.Blocks.Types.ExternalCombiTable2D tableID;
  input Real u1;
  input Real u2;
  input Real der_u1;
  input Real der_u2;
  input Real der_2_u1;
  input Real der_2_u2;
  output Real der_2_y;
algorithm
  der_2_y := -1.0;
//   external"C" der_y = ModelicaStandardTables_CombiTable2D_getDerValue(tableID, u1, u2, der_u1, der_u2)
//     annotation (Library={"ModelicaStandardTables", "ModelicaIO", "ModelicaMatIO", "zlib"});
end getDer2Table2DValue;
