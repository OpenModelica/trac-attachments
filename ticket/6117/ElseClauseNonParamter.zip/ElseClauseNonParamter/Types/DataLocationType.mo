within ElseClauseNonParamter.Types;
type DataLocationType = enumeration(
    onFile "data resides in a file",
    onTable "data resides in a table",
    onRecord "data resides in a record");
