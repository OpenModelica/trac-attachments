within ElseClauseNonParamter;
model ConstrainedMotionTableCustom2Test_onRecord
  import SI = Modelica.SIunits;
  ElseClauseNonParamter.Mechanics.MultiBody.Joints.ConstrainedMotionTableCustom2 constrMot(
    imposed_motion={false,true}) annotation (Placement(visible=true, transformation(
        origin={2,0},
        extent={{-10,-10},{10,10}},
        rotation=0)));
equation
end ConstrainedMotionTableCustom2Test_onRecord;
