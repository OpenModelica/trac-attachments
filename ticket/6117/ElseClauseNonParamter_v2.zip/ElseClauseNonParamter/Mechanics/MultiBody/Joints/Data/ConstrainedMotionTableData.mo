within ElseClauseNonParamter.Mechanics.MultiBody.Joints.Data;
record ConstrainedMotionTableData

  parameter Real X[:,:] = [0, 0, 1; 0, 1.1, 1.2; 1, 2.1, 2.2];
  parameter Real Y[:,:] = [0, 0, 1; 0, 1.1, 1.2; 1, 2.1, 2.2];
  parameter Real Z[:,:] = [0, 0, 1; 0, 1.1, 1.2; 1, 2.1, 2.2];
  parameter Real EulZ[:,:] = [0, 0, 1; 0, 1.1, 1.2; 1, 2.1, 2.2];
  parameter Real EulY[:,:] = [0, 0, 1; 0, 1.1, 1.2; 1, 2.1, 2.2];
  parameter Real EulX[:,:] = [0, 0, 1; 0, 1.1, 1.2; 1, 2.1, 2.2];

  annotation (Icon(coordinateSystem(preserveAspectRatio=false)), Diagram(coordinateSystem(preserveAspectRatio=false)));
end ConstrainedMotionTableData;
