within P;
package P2
  model M
    Real x = 2;
  end M;
end P2;