within P;
package P1
  model M
    Real x = 2;
    Real yy = 12;
  end M;
end P1;
