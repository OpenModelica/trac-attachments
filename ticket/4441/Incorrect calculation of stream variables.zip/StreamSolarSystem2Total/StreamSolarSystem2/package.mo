package StreamSolarSystem2

  connector FluidConnector
    Real p;
    flow Real mDot;
    stream Real hOut;
    annotation (Icon(coordinateSystem(preserveAspectRatio=false), graphics={
            Ellipse(
            extent={{-100,100},{100,-100}},
            lineColor={0,0,0},
            fillColor={255,255,255},
            fillPattern=FillPattern.Solid)}), Diagram(coordinateSystem(
            preserveAspectRatio=false)));
  end FluidConnector;

  model Boundary

    parameter Real p=1e5;
    parameter Real T=300;

    FluidConnector port annotation (Placement(transformation(extent={{-10,-10},
              {10,10}}), iconTransformation(extent={{-10,-10},{10,10}})));

    TILMedia.VLEFluid_pT fluid(
      p=port.p,
      T=T,
      redeclare TILMedia.VLEFluidTypes.TILMedia_Water vleFluidType)
      annotation (Placement(transformation(extent={{-30,-50},{-10,-30}})));

  equation

    port.p = p;

    port.hOut = fluid.h;

    annotation (Icon(graphics={Line(points={{0,80},{0,-80}}, color={0,0,0})}));
  end Boundary;

  model Pump

    parameter Real mDot0=0.1;
    parameter Real dp0=2e5;

    FluidConnector portA(mDot(start=0.05)) annotation (Placement(transformation(
            extent={{-90,-10},{-70,10}}), iconTransformation(extent={{-90,-10},
              {-70,10}})));
    FluidConnector portB annotation (Placement(transformation(extent={{70,-10},
              {90,10}}), iconTransformation(extent={{70,-10},{90,10}})));
  equation

    portA.mDot + portB.mDot = 0;

    portB.p - portA.p = dp0*(1 - abs(portA.mDot)*portA.mDot/mDot0^2);

    portB.hOut = inStream(portA.hOut);
    portA.hOut = inStream(portB.hOut);

    annotation (Placement(transformation(extent={{30,-12},{50,8}})), Icon(
          graphics={Ellipse(
            extent={{-80,80},{80,-80}},
            lineColor={0,0,0},
            fillColor={255,255,255},
            fillPattern=FillPattern.Solid), Line(points={{0,80},{80,0},{0,-80}},
              color={0,0,0})}));
  end Pump;

  model HeatExchanger

    parameter Real kA=1000;
    parameter Real Ta=300;

    Real h(start=100e3);

    FluidConnector portA annotation (Placement(transformation(extent={{-110,-10},
              {-90,10}}), iconTransformation(extent={{-110,-10},{-90,10}})));
    FluidConnector portB annotation (Placement(transformation(extent={{90,-10},
              {110,10}}), iconTransformation(extent={{90,-10},{110,10}})));

    TILMedia.VLEFluid_ph fluid(
      p=portB.p,
      h=h,
      redeclare TILMedia.VLEFluidTypes.TILMedia_Water vleFluidType)
      annotation (Placement(transformation(extent={{-10,40},{10,60}})));
  equation

    portA.mDot + portB.mDot = 0;

    portA.p - portB.p = 0;

    portA.mDot*actualStream(portA.hOut) + portB.mDot*actualStream(portB.hOut)
       + kA*(Ta - fluid.T) = 0;

    portB.hOut = h;
    portA.hOut = h;

    annotation (Diagram(coordinateSystem(preserveAspectRatio=false, extent={{-100,
              -100},{100,100}})), Icon(graphics={Rectangle(
            extent={{-100,60},{100,-60}},
            lineColor={0,0,0},
            fillColor={255,255,255},
            fillPattern=FillPattern.Solid), Line(points={{-40,-98},{-40,30},{0,
                -32},{40,30},{40,-98}}, color={0,0,0})}));
  end HeatExchanger;

  model Sensor

    Real T;
    Real h;
    Real p;

    FluidConnector port annotation (Placement(transformation(extent={{-10,-50},
              {10,-30}}), iconTransformation(extent={{-10,-50},{10,-30}})));

    TILMedia.VLEFluid_ph fluid(
      final p=port.p,
      h=inStream(port.hOut),
      redeclare TILMedia.VLEFluidTypes.TILMedia_Water vleFluidType)
      annotation (Placement(transformation(extent={{-10,-12},{10,8}})));

  equation

    T = fluid.T;
    h = fluid.h;
    p = fluid.p;

    port.mDot = 0;

    port.hOut = 0;

    annotation (Icon(coordinateSystem(preserveAspectRatio=false, initialScale=
              0.1), graphics={Ellipse(
            extent={{-40,40},{40,-40}},
            lineColor={0,0,0},
            fillColor={255,255,255},
            fillPattern=FillPattern.Solid), Text(
            extent={{-80,100},{80,40}},
            lineColor={0,0,0},
            fillColor={255,255,255},
            fillPattern=FillPattern.Solid,
            textString=String(T))}), Diagram(coordinateSystem(
            preserveAspectRatio=false, initialScale=0.1)));
  end Sensor;

  model System1

    Pump pump annotation (Placement(transformation(
          extent={{-10,-10},{10,10}},
          rotation=90,
          origin={-40,10})));
    HeatExchanger hx annotation (Placement(transformation(
          extent={{-10,10},{10,-10}},
          rotation=180,
          origin={0,-20})));
    Boundary boundary1(T=350)
      annotation (Placement(transformation(extent={{38,-30},{58,-10}})));
    Boundary boundary2(p=2e5) annotation (Placement(transformation(
          extent={{-10,-10},{10,10}},
          rotation=90,
          origin={-40,40})));
    Sensor sensor1 annotation (Placement(transformation(
          extent={{-10,-10},{10,10}},
          rotation=180,
          origin={30,-30})));
    Sensor sensor2 annotation (Placement(transformation(
          extent={{-10,-10},{10,10}},
          rotation=180,
          origin={-28,-30})));
    Sensor sensor3 annotation (Placement(visible=true, transformation(
          origin={-50,30},
          extent={{-10,-10},{10,10}},
          rotation=90)));
  equation
    connect(sensor3.port, pump.portB)
      annotation (Line(points={{-46,30},{-40,30},{-40,18}}));
    connect(hx.portB, pump.portA) annotation (Line(points={{-10,-20},{-10,-20},
            {-40,-20},{-40,2}}, color={0,0,0}));
    connect(hx.portA, boundary1.port)
      annotation (Line(points={{10,-20},{48,-20}}, color={0,0,0}));
    connect(boundary2.port, pump.portB)
      annotation (Line(points={{-40,40},{-40,40},{-40,18}}, color={0,0,0}));
    connect(sensor1.port, boundary1.port)
      annotation (Line(points={{30,-26},{30,-20},{48,-20}}, color={0,0,0}));
    connect(sensor2.port, pump.portA) annotation (Line(points={{-28,-26},{-28,-20},
            {-40,-20},{-40,2}}, color={0,0,0}));
    annotation (Icon(coordinateSystem(preserveAspectRatio=false)), Diagram(
          coordinateSystem(preserveAspectRatio=false, extent={{-100,-100},{100,
              100}})));
  end System1;

  model System1_withoutSensor
    Pump pump annotation (Placement(transformation(
          extent={{-10,-10},{10,10}},
          rotation=90,
          origin={-40,10})));
    HeatExchanger hx annotation (Placement(transformation(
          extent={{-10,10},{10,-10}},
          rotation=180,
          origin={0,-20})));
    Boundary boundary1(T=350)
      annotation (Placement(transformation(extent={{38,-30},{58,-10}})));
    Boundary boundary2(p=2e5) annotation (Placement(transformation(
          extent={{-10,-10},{10,10}},
          rotation=90,
          origin={-40,40})));
    Sensor sensor1 annotation (Placement(transformation(
          extent={{-10,-10},{10,10}},
          rotation=180,
          origin={30,-30})));
    Sensor sensor2 annotation (Placement(transformation(
          extent={{-10,-10},{10,10}},
          rotation=180,
          origin={-28,-30})));
  equation
    connect(hx.portB, pump.portA) annotation (Line(points={{-10,-20},{-10,-20},
            {-40,-20},{-40,2}}, color={0,0,0}));
    connect(hx.portA, boundary1.port)
      annotation (Line(points={{10,-20},{48,-20}}, color={0,0,0}));
    connect(boundary2.port, pump.portB)
      annotation (Line(points={{-40,40},{-40,40},{-40,18}}, color={0,0,0}));
    connect(sensor1.port, boundary1.port)
      annotation (Line(points={{30,-26},{30,-20},{48,-20}}, color={0,0,0}));
    connect(sensor2.port, pump.portA) annotation (Line(points={{-28,-26},{-28,-20},
            {-40,-20},{-40,2}}, color={0,0,0}));
    annotation (Icon(coordinateSystem(preserveAspectRatio=false)), Diagram(
          coordinateSystem(preserveAspectRatio=false, extent={{-100,-100},{100,
              100}})));
  end System1_withoutSensor;

  annotation (uses(Modelica(version="3.2.2"), TILMedia(version="1.2.1 ClaRa")));
end StreamSolarSystem2;
