package TILMedia
  "TILMedia-Library with thermophysical properties of Fluids and Solids"
import SI = Modelica.SIunits;

model VLEFluid_ph
  "VLE-Fluid model describing super-critical, subcooled, superheated fluid including the vapour liquid equilibrium (p, h and xi as independent variables)"
  replaceable parameter TILMedia.VLEFluidTypes.BaseVLEFluid vleFluidType
    constrainedby TILMedia.VLEFluidTypes.BaseVLEFluid
    "type record of the VLE fluid or VLE fluid mixture"
    annotation (choicesAllMatching=true);

  parameter Boolean stateSelectPreferForInputs=false
    "=true, StateSelect.prefer is set for input variables"
    annotation (Evaluate=true, Dialog(tab="Advanced", group "StateSelect"));
  parameter Boolean computeTransportProperties=false
    "=true, if transport properties are calculated";
  parameter Boolean interpolateTransportProperties=true
    "Interpolate transport properties in vapor dome"
    annotation (Dialog(tab="Advanced"));
  parameter Boolean computeSurfaceTension=true
    annotation (Dialog(tab="Advanced"));
  parameter Boolean computeVLEAdditionalProperties=false
    "Compute detailed vapour liquid equilibrium properties"
    annotation (Evaluate=true);
  parameter Boolean computeVLETransportProperties=false
    "Compute detailed vapour liquid equilibrium transport properties"
    annotation (Evaluate=true);
  parameter Boolean deactivateTwoPhaseRegion=false
    "Deactivate calculation of two phase region" annotation (Evaluate=true);

  //Base Properties
  Modelica.SIunits.Density d "Density";
  input Modelica.SIunits.SpecificEnthalpy h(stateSelect=if (
        stateSelectPreferForInputs) then StateSelect.prefer else StateSelect.default)
    "Specific enthalpy" annotation (Dialog);
  input Modelica.SIunits.AbsolutePressure p(stateSelect=if (
        stateSelectPreferForInputs) then StateSelect.prefer else StateSelect.default)
    "Pressure" annotation (Dialog);
  Modelica.SIunits.SpecificEntropy s "Specific entropy";
  Modelica.SIunits.Temperature T "Temperature";
  input Modelica.SIunits.MassFraction[vleFluidType.nc - 1] xi(each stateSelect=
        if (stateSelectPreferForInputs) then StateSelect.prefer else
        StateSelect.default) = vleFluidType.xi_default
    "Mass Fraction of Component i" annotation (Dialog);
  SI.MoleFraction x[vleFluidType.nc - 1] "Mole fraction";
  SI.MolarMass M "Average molar mass";

  //Additional Properties
  SI.MassFraction q "Steam mass fraction (quality)";
  SI.SpecificHeatCapacity cp "Specific isobaric heat capacity cp";
  SI.SpecificHeatCapacity cv "Specific isochoric heat capacity cv";
  SI.LinearExpansionCoefficient beta "Isobaric thermal expansion coefficient";
  SI.Compressibility kappa "Isothermal compressibility";
  SI.Velocity w "Speed of sound";
  SI.DerDensityByEnthalpy drhodh_pxi
    "1st derivative of density wrt specific enthalpy at constant pressure and mass fraction";
  SI.DerDensityByPressure drhodp_hxi
    "1st derivative of density wrt pressure at specific enthalpy and mass fraction";
  TILMedia.Internals.Units.DensityDerMassFraction drhodxi_ph[vleFluidType.nc -
    1]
    "1st derivative of density wrt mass fraction of water at constant pressure and specific enthalpy";
  Real gamma "Heat capacity ratio aka isentropic expansion factor";

  SI.MolarMass M_i[vleFluidType.nc] "Molar mass of component i";

  TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer=
      TILMedia.VLEFluidObjectFunctions.VLEFluidPointer(
        vleFluidType.concatVLEFluidName,
        computeFlags,
        vleFluidType.mixingRatio_propertyCalculation[1:end - 1]/sum(
        vleFluidType.mixingRatio_propertyCalculation),
        vleFluidType.nc_propertyCalculation,
        vleFluidType.nc,
        redirectorOutput) "Pointer to external medium memory";

  TILMedia.Internals.CriticalDataRecord crit "Critical data record" annotation
    (Placement(transformation(extent={{-80,60},{-60,80}}, rotation=0)));
  TILMedia.Internals.TransportPropertyRecord transp(eta(min=if
          computeTransportProperties then 0 else -1))
    "Transport property record" annotation (Placement(transformation(extent={{-80,
            -100},{-60,-80}}, rotation=0)));
  TILMedia.Internals.VLERecord VLE(final nc=vleFluidType.nc) annotation (
      Placement(transformation(extent={{-80,20},{-60,40}}, rotation=0)));
  TILMedia.Internals.AdditionalVLERecord VLEAdditional annotation (Placement(
        transformation(extent={{-80,-20},{-60,0}}, rotation=0)));
  TILMedia.Internals.VLETransportPropertyRecord VLETransp(eta_l(min=if
          computeVLETransportProperties then 0 else -1), eta_v(min=if
          computeVLETransportProperties then 0 else -1)) annotation (Placement(
        transformation(extent={{-80,-60},{-60,-40}}, rotation=0)));
protected
  constant Real invalidValue=-1;
  final parameter Integer computeFlags=TILMedia.Internals.calcComputeFlags(
        computeTransportProperties,
        interpolateTransportProperties,
        computeSurfaceTension,
        deactivateTwoPhaseRegion);
  parameter Integer redirectorOutput=
      TILMedia.Internals.redirectModelicaFormatMessage();
public
  function getProperties = TILMedia.Internals.getPropertiesVLE (
      d=d,
      h=h,
      p=p,
      s=s,
      T=T,
      cp=cp,
      q=q,
      d_l=VLE.d_l,
      h_l=VLE.h_l,
      p_l=VLE.p_l,
      s_l=VLE.s_l,
      T_l=VLE.T_l,
      d_v=VLE.d_v,
      h_v=VLE.h_v,
      p_v=VLE.p_v,
      s_v=VLE.s_v,
      T_v=VLE.T_v,
      d_crit=crit.d,
      h_crit=crit.h,
      p_crit=crit.p,
      s_crit=crit.s,
      T_crit=crit.T,
      Pr=transp.Pr,
      lambda=transp.lambda,
      eta=transp.eta,
      sigma=transp.sigma,
      Pr_l=VLETransp.Pr_l,
      Pr_v=VLETransp.Pr_v,
      lambda_l=VLETransp.lambda_l,
      lambda_v=VLETransp.lambda_v,
      eta_l=VLETransp.eta_l,
      eta_v=VLETransp.eta_v);

  equation
  M_i = TILMedia.Internals.VLEFluidObjectFunctions.molarMass_nc(vleFluidType.nc,
    vleFluidPointer);
  (crit.d,crit.h,crit.p,crit.s,crit.T) =
    TILMedia.Internals.VLEFluidObjectFunctions.cricondenbar_xi(xi,
    vleFluidPointer);
  //calculate molar mass
  M = 1/sum(cat(
      1,
      xi,
      {1 - sum(xi)}) ./ M_i);
  //calculate mole fraction
  xi = x .* M_i[1:end - 1]*(sum(cat(
      1,
      xi,
      {1 - sum(xi)}) ./ M_i));
  //xi = x.*M_i/M

  //Calculate Main Properties of state
  d = TILMedia.Internals.VLEFluidObjectFunctions.density_phxi(
      p,
      h,
      xi,
      vleFluidPointer);
  s = TILMedia.Internals.VLEFluidObjectFunctions.specificEntropy_phxi(
      p,
      h,
      xi,
      vleFluidPointer);
  T = TILMedia.Internals.VLEFluidObjectFunctions.temperature_phxi(
      p,
      h,
      xi,
      vleFluidPointer);

  //Calculate Additional Properties of state
  (q,cp,cv,beta,kappa,drhodp_hxi,drhodh_pxi,drhodxi_ph,w,gamma) =
    TILMedia.Internals.VLEFluidObjectFunctions.additionalProperties_phxi(
      p,
      h,
      xi,
      vleFluidPointer);

  //Calculate VLE Properties
  if (vleFluidType.nc == 1) then
    //VLE only depends on p or T
    (VLE.d_l,VLE.h_l,VLE.p_l,VLE.s_l,VLE.T_l,VLE.xi_l,VLE.d_v,VLE.h_v,VLE.p_v,
      VLE.s_v,VLE.T_v,VLE.xi_v) =
      TILMedia.Internals.VLEFluidObjectFunctions.VLEProperties_phxi(
        p,
        -1,
        zeros(0),
        vleFluidPointer);
  else
    //VLE of a mixture also depends on density/enthalpy/entropy/temperature
    (VLE.d_l,VLE.h_l,VLE.p_l,VLE.s_l,VLE.T_l,VLE.xi_l,VLE.d_v,VLE.h_v,VLE.p_v,
      VLE.s_v,VLE.T_v,VLE.xi_v) =
      TILMedia.Internals.VLEFluidObjectFunctions.VLEProperties_phxi(
        p,
        h,
        xi,
        vleFluidPointer);
  end if;

  //Calculate Transport Properties
  if computeTransportProperties then
    transp =
      TILMedia.Internals.VLEFluidObjectFunctions.transportPropertyRecord_phxi(
        p,
        h,
        xi,
        vleFluidPointer);
  else
    transp = TILMedia.Internals.TransportPropertyRecord(
        invalidValue,
        invalidValue,
        invalidValue,
        invalidValue);
  end if;

  //compute VLE Additional Properties
  if computeVLEAdditionalProperties then
    if (vleFluidType.nc == 1) then
      //VLE only depends on p or T
      (VLEAdditional.cp_l,VLEAdditional.beta_l,VLEAdditional.kappa_l,
        VLEAdditional.cp_v,VLEAdditional.beta_v,VLEAdditional.kappa_v) =
        TILMedia.Internals.VLEFluidObjectFunctions.VLEAdditionalProperties_phxi(
          p,
          -1,
          zeros(vleFluidType.nc - 1),
          vleFluidPointer);
    else
      //VLE of a mixture also depends on density/enthalpy/entropy/temperature
      (VLEAdditional.cp_l,VLEAdditional.beta_l,VLEAdditional.kappa_l,
        VLEAdditional.cp_v,VLEAdditional.beta_v,VLEAdditional.kappa_v) =
        TILMedia.Internals.VLEFluidObjectFunctions.VLEAdditionalProperties_phxi(
          p,
          h,
          xi,
          vleFluidPointer);
    end if;
  else
    VLEAdditional.cp_l = invalidValue;
    VLEAdditional.beta_l = invalidValue;
    VLEAdditional.kappa_l = invalidValue;
    VLEAdditional.cp_v = invalidValue;
    VLEAdditional.beta_v = invalidValue;
    VLEAdditional.kappa_v = invalidValue;
  end if;

  //compute VLE Transport Properties
  if computeVLETransportProperties then
    if (vleFluidType.nc == 1) then
      //VLE only depends on p or T
      (VLETransp.Pr_l,VLETransp.Pr_v,VLETransp.lambda_l,VLETransp.lambda_v,
        VLETransp.eta_l,VLETransp.eta_v) =
        TILMedia.Internals.VLEFluidObjectFunctions.VLETransportPropertyRecord_phxi(
          p,
          -1,
          zeros(0),
          vleFluidPointer);
    else
      //VLE of a mixture also depends on density/enthalpy/entropy/temperature
      (VLETransp.Pr_l,VLETransp.Pr_v,VLETransp.lambda_l,VLETransp.lambda_v,
        VLETransp.eta_l,VLETransp.eta_v) =
        TILMedia.Internals.VLEFluidObjectFunctions.VLETransportPropertyRecord_phxi(
          p,
          h,
          xi,
          vleFluidPointer);
    end if;
  else
    VLETransp.Pr_l = invalidValue;
    VLETransp.Pr_v = invalidValue;
    VLETransp.lambda_l = invalidValue;
    VLETransp.lambda_v = invalidValue;
    VLETransp.eta_l = invalidValue;
    VLETransp.eta_v = invalidValue;
  end if;

  /*
    Documentation(info="<html>
<p>
Standard refrigerant model that can be used in most applications. This model contains all three data records:
<b>CriticalDataRecord</b>, <b>SaturationPropertyRecord</b> and <b>TransportPropertyRecord</b>. <p> For ppf-media 
data transport properties are roughly estimated. For R245fa no transport properties are implemented yet.</p>
More information on this model can be found in the
<a href=\"Modelica:TILMedia.UsersGuide\">Users Guide</a>.
</p>
</html>")*/
  annotation (
    Placement(transformation(extent={{-80,20},{-60,40}}, rotation=0)),
    defaultComponentName="vleFluid",
    Icon(graphics={Text(
            extent={{-120,-60},{120,-100}},
            lineColor={153,204,0},
            textString="%name"),Bitmap(
            extent={{-100,-100},{100,100}},
            imageSource=
            "iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAIAAAAiOjnJAAAABnRSTlMA/wAAAACkwsAdAAAACXBIWXMAAAsTAAALEwEAmpwYAAAXp0lEQVR42u2dbWxb13nHH76LFElRpCyb1BszvdhJrYi14NTOHJdGURtFUIRBjK1OFoPonBXbPkRF+2ELUFRYgSIDOkAZ0AVbsoFJi2TDEpQGmhT2h41JjNiJY1W2VFempZmSJdKW+P7+zn2gTV9d3nt5eXnfSJ0/7gebIi8PeX58nuc85znnSCqABKH0QiLnC2UWACCQ8ABAIudL5H0NX6hTWnUqKwCY1Dal3GDR2pVyg0ljE89HW/auLN9eWd/wb4fC6xubhM8ZHhzYYzIOD1oOjI8dmBhj5X0luxOsQNwTyiz4E55E3hdKL7B+f5PGZlLb+jQ2k9pm1tv5/4CXLn85f2Pp2vVFBq+dnpo89OTBY0efQmDRhcmf9AQSHn/Cw/NbW3R2s85u0dp5gOztd9/77MpVVm71zJHDx448xcyGdT5Y3qDLn/D4ou58KSp4Y5Qyg9XgsOjsE31O1l3ebz66sHx7hfU2Hxgfe/7ZU83i1bFg+SJub8jli7pF20KrwTFhclp7HVxbKblcZjQYenRavU6nUMhxfy0UivFEIpZIhqPRYrFEYb3OnX1x94KVzPkW78/dCrnEYJ9o2rD9Jufk3hmtysrg5fPXF9969/10JlP/J5VKOWQx9/b06LTdNO+WSKYisVjg/nYqna7/q0atfuXsmUNTk7sLLF/EvbQ111L8JAOQP7wAQEXjJTkAACg+vEotxWEH+2eaMmBkhmqPyWjZ29/drWHcmFg8sRUMbYfCjE1XJ4DlDbqu+WfpZAfqftQACgAlgAygi6XWZAFKAHmAwkPsmpFOaZ22zNKJwH7y81/Upw96dLrBgX0qpZKVj5LL5zc278USifr0xM9e+3Eng8UEKRXm4kE5zMUeXvVUKeTyAfM+bQtWijS6SKU3A/cKxSKOrZdOOygi+nYFqzmkJABqACWAGkAqUIvLABmAPEAGoNISXn/9o9dwQZVO293fZ5JKufps5XJ5KxhKJFO4kOvVH3yfjK32AysQ91wLzNKNpVQAagC1yD5DBiBD14ZZdPZp82wtAVZvq0y9BvrheStKJFOhSJSm3WozsDx3nN6Qi1YYrgHoApCJ+MOUHhJGI+SfMDntj7lwVEkkkj3GXoVCwVuTC4XCdjhSqVQaxlttA5Yv4vb4nI2TCAqAbr7iJxbjsBRAocGzbn96cmvla1iqenv0Crmc58YWisVILI5li3CcKG+Lb/7iisO36qCFVHU81F52WAmgBMhT4RVaG8VSBQB6nVYikRRLJZ4bK5FI9DptLP5oqPjZlauHri/i8ltit1i0DFUVKQV0ggoEeBVzqq/++/ul/KOMiLqrS6kU8gPn84VMNosN5N/8p5+3DViX12cWt+aoniEF0HUKUji8EgBlYicol8vUKnbSbuOj1ld/8JePvO3qnTf+9T/ojkByWewUEM4hitQVJnO+C6uOEAVVEsxwr/PmO+UAvQ9C+5h/EBdaKeSKUrnMzvihvOO7q0CF/p0VckWpVK4FW59duXrMu1IbIYoRLF/E7blpo3J/CgAtgKQTkcKqC0AF6x8f2dmd8kqlgo2dW1FlJ0aVCpSbQVYhl+cLj9z2bz668PeitVhL9+c+p4jTJQCa9ozQGSl2dzAeGMKaK4Dm+r4BWHhAK83eXCKR1G6CLdqRiup79Nxxfn53hspQ6QEUAJXdcm0tPYH9AmRSablSYffCW6wmXy7bme5/+933RGexLq44fBTJTzUGqd2hYk61dXNHdFWpdj57qnepDJws1mh9duXqOVGB9eFNW4isKE/6cI5vl9Xnh1ZGcVEA/V4fHrQcevIgAKTTmfkbS8FwpFnUDoyPHhgfrd5heWV1fcNPEZ5gm3Xp8pfHjj4lFwtVZCsaqgUtkl1HFQCEV0frux37v/3jo3/36t/U/rt8e+Uf33hzaHDg3F/8+fDgQO3xMy88N39j6e1f/2cmnWkYY0Gl8u0Txx3fOanR7JhhXb69+t6H5++SrPPBav7G0jEA2ayYqZKzVybVhvJeeBbncnBP6DMZjx05XPtvMBwGgB/97V/16PW4Z5r39p/406OLN5dxxVW4O6QzmcnH9588cbx+/rHPZPzGIVv9HeoVuL/1/NUrUvFSVZ3oqOzSK7Yx2OyX2Wc0vvgC6YBao1Gfe/l7GnUXpQMdoKg81mjUL55+jk5Llr0rcvFSJduN7u9RoqEOrIaBdp/JCACpdObi/366fHtFo1afPHH8cUxNy/DgwLftx90fX6AO1bdDYffHF4KhcJ/JePLE8RGMVz0wPmYy9gaJSpZ3+k3hwLq44iCN1pW7MVTHKRXcw+RV6czrc79c3/TXwp1zL3/vmSOPlp6ePLEDrHqtbWy+PvfLdCYLAHB7df764i/+4SfdmHhreMDSEKz1Db8wrtBzx0m6MEvxMFTf3Vcurmfwxb73gbtGVe0R7JqIbo26OlqkuMMDqh5EXVncWkXssIBM26GwAGAt3Z8jLdaTI6oeXKlQP4Pvdv4Gfk19OpOd37nQnpqM5dur9ean2Wasb2zy7Qp9ETfpjE212rMMSMy0trGJNTZkZAwPWsju8EcvawupeQUrmfN5btpIs6Cw2+OqFpVOZwgfr6YhHg3u1HwsAeAVrAurDuKaBQmiaoeySX27fwT+wLq8PkNVX4WowqirO47AohtaLVIUwyCq2NDjJEv8cNE6zjNyJJ5GhR6fE3U8DxoesBCBZWlxlCdSsC6uONpl75d2l+PZU7hHNOquQ0/umKVZ9q50Ali+iFvMm1SJVt3GLQavmp6aPHniOJaqcy+fwebN1zY2cRlUTgzn4ADnMRZygsyk0sZTYSY50pdOO44dOTx/fUmj7jo0NbnHZMT+1f3RBR4av8dk5BYszx1nns6KeKR6i2XaDq83tztjOp2pFlGNDA6MEKXXP7vy5fyNJT5CvUELh64wEPd4EVVM1bNvA/eIhEg7ovLNzbd/9T5ZmvTSlav//uv/or6DRAKN3oT4Obj3OjA+xqHFuhaYRXwwB8u8weBVl774avn26osvPIctq1rf2HR/fJHQVqXTGewcM+GAMRgKY5/TsLQBAA5McAaWN+jyo+iqNRmHV5r1hgAQDEf++S2XRq2uZhmC4QgFCuub/tffeLMhrJe++KqpAQRwlyC95kfmqmWwRlZxYOE9F0jqvWX1X5ls9tbK/xG+inXhqgWrZTmcxFjeoIvJjqBIO2UaXqUOs6AOGIkQwrWheqSFFJkr0UquyvWP/QFnGKg7VRCqcHtlVf8hReZKzDJ/7ffY/5bLZalEUrvqx3TYv/Jz4Zbk1zackSNzJWZpTdv6fXfj94ZqRqsCldomtlJJXYwllfDZvHK5jDVXB8YfRYQsWyxfxI3MFbsa/voV7H+LxZJUIpFKpVKpFIeRRAJSPiWR4I5IeR4zU8nyxmu/vWXn/2ytjhd+4zWZrKtL+F1Ws9kcdqNKDjdeS+Z8/kUr4oB1PfaNT0Lro7WtIoulUqlUUioE3SqyUMBSpVGrcfvbsukKF+/PIQg4Gh6OP3MR+0gmm6sAyARSuVLJZHfsUv/K2TP4NrP4+W+hmUHuclojq/1jf8A6xEQyZejRK+R872RfKJaSqR1ngz1z5HD9wnzWwPJF3PlVByKAO40fv5gK76nV0lQqlWgs3tfbW38EIXfK5fPRnZu8Dw8OEB4GxlrwfnHFgQr6uFYxp1r63WlcnZax16Dj4GymeiVS6XDdkSdkx4CxBta/fYX6nZexWEK/cP4l7J7vAKDr7u4zGWUyroqgSqVyMBROpPCHNOH2dmcfLG/QRVYpatZ+k/q1geQnbH1+6vfKl6KhzHXxIKKU9ZjUNiZ2K6+67D58/96OQEchl1v29Xdr2DddqXTaf2+r/lg56iML2XHPFLmryb0zVgNV7PXhTRsr/a1Vjnx3v4fiCZ/fncG+kUk9dXSIdBgbSi9c3vght/G42kbdYAqdHN2xqwwAFIrFtQ2/XqcdNO9TsnQQZj6f3wjciyeSuMfpHITJDlgU0ZUv6qYGa8LkZKULqd+lvpFKmcGis7epQ+zWqH/22o/fevf9S1/sOLo3nkjeTKz0GXv3mEw9ei3j+8fiye1QiHDnUppH97IAViDuyXvtDJirAcEKWBMmJzVVyfxah8Vbr5w9c2jq4Nu/eh+3F0gwHAmGI90a9b7+PYYeva6b9mHjqVQ0Ft8I3Mvl8vV/beqwcRbA8ic9lJFNjNpo6VRWk3qqRW+oVY70aWzMbGpba3pq8sD42HsfuHGmCwBS6cyqbx0A5DJZr6FHr9Oqu7rqt4pMZ7KZbDaeSEaiMYqzxB4YKvJonQOL1WhykAdvSH3/XDHawamQbo36lbNnjh057P74Qv3uVgBQLJW2Q+HtEMOV9QfGx55/9hTF8c+cWaxGYHlD7xwdnFPJDdx5w4Z+MF+KdXYa4vGJsccnxtY2Ni/+z6f11ouZHoVTzXdOq2AF4h7wNg6BfVH3fvIz2Vv0hib1FLUf3D2r0EYGB145e+bF0475G4vz15eYrSI0Dq+cPPryd775Z/AvzFvSKlihzALNYSMFWC16Q2pzlcj5WEyVtYtzfObIU9U9bf/oXVm+vbq+sRkMhckW13cbt1TaeLdpu2ffRnXZ2dDQt1psQ6tgBdO0wFqLnc8Voxx5Q+oAq02jq2B64TLFeVVN9fEY/MkYDJaiQ7R9As1uFd5icecNTeopncpK8YQGZ7SKVflSVEBDS79bydTq7FKINtoNAx1qj8bsVcH0Quelr/gAKy0oWE29fSD5SSLnY+zRmL1qaQvVHgrDVktgUYPSbLhT9Ybs+kFUycPcFxejgoHVrCdm3Rui9BV3op5Q4RasZqEOZa6z6w2pn38r6EJ8CCVeLVZDo9WUNxzpeY7CD+aK0bXYedTBjBVobRkf32fp3GLPG1KbK7TnWxtbrGaDdwBI5teok2/0vSECi1Mx6Fz2wGK0mp4VbzjS8xxFHj+R84mqCrktwWptqwQBDsL0Rd1PD81Re8OG0zvU5mqx/dNXOqV12vxTthDxht7huf0CgFX1hhT1CHTmDTtyfhBnuacts+wkDhIe/sES5oRV6oR4Q29I7Qc7sgp5dwXvrXjDVsaGHW+udjVYrcwlVQvhmaGjlPVQ/DVXjPJv9pHYBMuksbXyxoznDa0GB7UfRJ26e10hLW9IUrzVIH0VdtFtgUTo716CwGr2+6Jx5csx6iy8tcdR/yqlnMoPPqhCptcAtj4I84tniPltjFTAX6Ev1rQ3ZM1cIXFsPuUCNrFhIfyEyXl584d4M0auW2FXE1+QhO/vuqn7+xOe366c4K9T2D49WSrs74TaaOEwoh4PoirkzomxdEpri6GJL97IG2qmak9uUIUcnGMzypHwcgneAPKWEHcuT2CprC1yvRY7n6M8LnrC6KTpB6mNHxLPnSvYqLB2UUfctbGhVjlCAdatsCtfjrE8KBN8VCioxRLSFZrZ2F+KGiyd0mrqmkLmin+12LlsW6zmBxeh7HXq0p+qN8T6RJxypeha/DwTy9pZI3yeO45DsIi30GzeDjccG2qVI33k23V6q1mGtvNE4naFFq1wFos4vmuefW+0gTec3jvL+OVIzMyVkjy/yL3FIpyHrjT9cwllrwcpF/zsJ/eDwcxCKHudE5sheMjMm7mq0O5c3mIsgrdn5K29EYZWh/ELkSi6rEWqWACLII1WYRRmJRgO67xRVxvnJ0USYFXoRc98gkWwozUji5UsrAWbX/7qi7vzZbSInn2L1deyxWp1EpoY7QoTYr1RV5+6udU1voSbo0G7TmGd7v8pW3e7FXUlC2sCNqCqRMHnjdaV15ZpdyufYJn1dqg/RafMBCxfwv20uQmwcqUowdfEFlhK63T/LFt386c8TYPFagNqzaAJlllvb/G9WEiQEnjDMkNvSD0nTWCu2iU/KRG6ARQq0+hQQcAyk4HFcQi/FJprmwJOEEEDCJtBBJZZJGARp2hLTG5FH6xE3hfKoUX0LatEu0MFsFh6u1JmIDBazVuRfCVGky1vzNVOVecisZr1LakzV0qZofUAC9iahCYowSsxvBVNsG7FXMjccGGxmO0EyxVYxOFekYkV8cbfoS79AwB/2pMsriGL1WozirS7UiiwiNcAMjZaSXdjP4jETYA1QXmASBMMc3vYuKbDl2W2sSoAaQI/eHKMnZJJ1gr9iLfxKPK+KABdNK8i7U4UFixrr4NgbFhAlkGsKhCMB629DtGBBQD763mvIKMlVnNVodF9IgFrcu8MnV8GkgjNFWn3iQEsrcpKMFgtAZSQkRDTVSIYD1p0dm3Lq0S5AgsADvYTUZ9DJkJMytHuODGkG2p6/4aVYDlXtyD76CIRjdNT+Md0SuuZJ33svg/7K6GJ9/rNoi4Vh7K0u0xsYE30OQkK4UvEiRMkvs1VicBcsZVt5xYs0l9ABgXOQl8ZnswVV2ARG60yiuKFjtnLPJkr4G7jNdJIq4IshxBXhb/oiluwJvqcxCvD0sh0CKE0QardorNzZK6A060ip81Ev4YCQAGZEH6vAnGqnbiDxA+WWW8nni1PMVzGg8REZYLEFQBMmJyslCDzlyDFyfV7Q76+IlQBoEd9zovixIUMzq9HOX1bzndNtltdxA4RpUz5SYcWaHdKe4Fl7XUQ1+enmdcuI9FSiXioZDU4WKy7EswVUjlEGUCP4FvNd25oFSP46fLgBHmyWFS2twSQRAhwoySxQ+DBCfIKlrXXMUlYmJEHSKGMANtXCiBP8GVP9s/w4AR5dYVVfXjTRnx8pg6gCxkZ9gL2BMHDJo3thScWeGsFr2Alc74PbtryhOtRewBUCIqWlQMg2ohOKTOcfmKB3RpRUbjCqrQq66lRN/10C1JzKgDESWNcPqkC/odkZr396SGi3dUqAFG0pKe1hTdR4n06nx6a4y20EgwsADi4d4Z4qqcCEEF2i6mtihBTNWFyHtw7w3+LeI2xsCJekg8AEgAjKpBvRkWAMClV9sdcgjRKMLCoBokSgB40TqQ9BoyRngDA5zBQRGBRsVUdJ6oROJTKEI8BBadKeLAasKUB6EH4kChGWjUpOFWiAKsBWyoAA5pP3KkyQJR0AYEYqBILWA3YkgP0AigQUJgBYFHUVIF4TMELTyyQ7n5ZBAiiYnkAAEgDBEmpshocIqFKRBarKs8dpzdEPjzuAujdrW6xDBChqo4UMLPQBmABwNL9uc/vkif0JAC9u2+0mCHNf1b19NCcIFnQdgILAHwRt8fnzFPsnbx7TFcjQ6WUGU6NujldFtE5YAFAMue7sOogDeerpksPoOtoqhIAcSpDZdLYTo26eZ5dbm+wqrq8PrO4RXkemAzA2In1NjmAcIM1AZP9M0eH50T7CUQNFi23CAAqAH2nTAFlAeINNrlQygx2q4v/goWOAqsq0hnrTsKLBlLA6lbsCCzapquKlw5A01ZIpQESjZFqC0PVfmBV1SDRhY29tKLfn7K6a2OS1vpKsaWpOg0sAAjEPdcCs/6Eh9az1QAagG6RfYYUQJp4G7R6WXT2afOsCBMKnQZWVd6g65p/lmAXXbLchAagC0AjXParDJAGyBLvKEQondI6bZnlbqchBBZLeNWCsK6HFz8hefVqZjfDtkaqE8BijldVXQBKACWAnD3OsgBFgDxAnsnGJx2AVOeAVRs2Lm3N0Y29CCXHXEAPtezDMLx2MZVFZz/I40plBFZzSuZ8i/fnboVcjRMT4pBSZthvck7unRHnzAwCi8CAeUOuxmlV4WQ1OCZMzo4xUbsFLGwE5k94fFG3GGyYUmawGhyc7iqLwOJbgbjHn/QEEp6W4jCm8ZNZZ7do7W2XjkJgNQ1ZKLMQTC+EMgtUxTlMZdLYTGpbn8ZmUtt2D0wILLxC6YV8MepPegAgkPAAQCLno5O/0CmtOpUVAMw6OwBYtHal3GDS2NBXisBC4kRowR4SAgsJgYWEwEJCQmAhIbCQEFhISAgsJAQWEgILCQmBhYTAQkJgISEhsJAQWEgILCQkBBYSAgsJgYWEhMBCQmAhIbCQkBBYSAgsJAQWEhICCwmBhYTAQkJCYCEhsJAQWEhICCwkBBYSAgsJCYGFhMBCQmAhISGwkBBYSB2s/wddz7oTNC1T0gAAAABJRU5ErkJggg==",
            fileName="modelica://TILMedia/Images/VLE_ph.png")}),
    Documentation(info="<html>
                   <p>
                   The VLE-fluid model VLEFluid_ph calculates the thermopyhsical property data with given inputs: pressure (p), enthalpy (h), massfraction (xi) and the parameter vleFluidType.<br>
                   The interface and the way of using, is demonstrated in the Testers -> <a href=\"Modelica:TILMedia.Testers.TestVLEFluid\">TestVLEFluid</a>.
                   </p>
                   <hr>
                   </html>"));
  end VLEFluid_ph;

model VLEFluid_pT
  "VLE-Fluid model describing super-critical, subcooled, superheated fluid including the vapour liquid equilibrium (p, T and xi as independent variables)"
  replaceable parameter TILMedia.VLEFluidTypes.BaseVLEFluid vleFluidType
    constrainedby TILMedia.VLEFluidTypes.BaseVLEFluid
    "type record of the VLE fluid or VLE fluid mixture"
    annotation (choicesAllMatching=true);

  parameter Boolean stateSelectPreferForInputs=false
    "=true, StateSelect.prefer is set for input variables"
    annotation (Evaluate=true, Dialog(tab="Advanced", group "StateSelect"));
  parameter Boolean computeTransportProperties=false
    "=true, if transport properties are calculated";
  parameter Boolean interpolateTransportProperties=true
    "Interpolate transport properties in vapor dome"
    annotation (Dialog(tab="Advanced"));
  parameter Boolean computeSurfaceTension=true
    annotation (Dialog(tab="Advanced"));
  parameter Boolean computeVLEAdditionalProperties=false
    "Compute detailed vapour liquid equilibrium properties"
    annotation (Evaluate=true);
  parameter Boolean computeVLETransportProperties=false
    "Compute detailed vapour liquid equilibrium transport properties"
    annotation (Evaluate=true);
  parameter Boolean deactivateTwoPhaseRegion=false
    "Deactivate calculation of two phase region" annotation (Evaluate=true);

  //Base Properties
  Modelica.SIunits.Density d "Density";
  Modelica.SIunits.SpecificEnthalpy h "Specific enthalpy";
  input Modelica.SIunits.AbsolutePressure p(stateSelect=if (
        stateSelectPreferForInputs) then StateSelect.prefer else StateSelect.default)
    "Pressure" annotation (Dialog);
  Modelica.SIunits.SpecificEntropy s "Specific entropy";
  input Modelica.SIunits.Temperature T(stateSelect=if (
        stateSelectPreferForInputs) then StateSelect.prefer else StateSelect.default)
    "Temperature" annotation (Dialog);
  input Modelica.SIunits.MassFraction[vleFluidType.nc - 1] xi(each stateSelect=
        if (stateSelectPreferForInputs) then StateSelect.prefer else
        StateSelect.default) = vleFluidType.xi_default
    "Mass Fraction of Component i" annotation (Dialog);
  SI.MoleFraction x[vleFluidType.nc - 1] "Mole fraction";
  SI.MolarMass M "Average molar mass";

  //Additional Properties
  SI.MassFraction q "Steam mass fraction (quality)";
  SI.SpecificHeatCapacity cp "Specific isobaric heat capacity cp";
  SI.SpecificHeatCapacity cv "Specific isochoric heat capacity cv";
  SI.LinearExpansionCoefficient beta "Isobaric thermal expansion coefficient";
  SI.Compressibility kappa "Isothermal compressibility";
  SI.Velocity w "Speed of sound";
  SI.DerDensityByEnthalpy drhodh_pxi
    "1st derivative of density wrt specific enthalpy at constant pressure and mass fraction";
  SI.DerDensityByPressure drhodp_hxi
    "1st derivative of density wrt pressure at specific enthalpy and mass fraction";
  TILMedia.Internals.Units.DensityDerMassFraction drhodxi_ph[vleFluidType.nc -
    1]
    "1st derivative of density wrt mass fraction of water at constant pressure and specific enthalpy";
  Real gamma "Heat capacity ratio aka isentropic expansion factor";

  SI.MolarMass M_i[vleFluidType.nc] "Molar mass of component i";

  TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer=
      TILMedia.VLEFluidObjectFunctions.VLEFluidPointer(
        vleFluidType.concatVLEFluidName,
        computeFlags,
        vleFluidType.mixingRatio_propertyCalculation[1:end - 1]/sum(
        vleFluidType.mixingRatio_propertyCalculation),
        vleFluidType.nc_propertyCalculation,
        vleFluidType.nc,
        redirectorOutput) "Pointer to external medium memory";

  TILMedia.Internals.CriticalDataRecord crit "Critical data record" annotation
    (Placement(transformation(extent={{-80,60},{-60,80}}, rotation=0)));
  TILMedia.Internals.TransportPropertyRecord transp(eta(min=if
          computeTransportProperties then 0 else -1))
    "Transport property record" annotation (Placement(transformation(extent={{-80,
            -100},{-60,-80}}, rotation=0)));
  TILMedia.Internals.VLERecord VLE(final nc=vleFluidType.nc) annotation (
      Placement(transformation(extent={{-80,20},{-60,40}}, rotation=0)));
  TILMedia.Internals.AdditionalVLERecord VLEAdditional annotation (Placement(
        transformation(extent={{-80,-20},{-60,0}}, rotation=0)));
  TILMedia.Internals.VLETransportPropertyRecord VLETransp(eta_l(min=if
          computeVLETransportProperties then 0 else -1), eta_v(min=if
          computeVLETransportProperties then 0 else -1)) annotation (Placement(
        transformation(extent={{-80,-60},{-60,-40}}, rotation=0)));
protected
  constant Real invalidValue=-1;
  final parameter Integer computeFlags=TILMedia.Internals.calcComputeFlags(
        computeTransportProperties,
        interpolateTransportProperties,
        computeSurfaceTension,
        deactivateTwoPhaseRegion);
  parameter Integer redirectorOutput=
      TILMedia.Internals.redirectModelicaFormatMessage();
public
  function getProperties = TILMedia.Internals.getPropertiesVLE (
      d=d,
      h=h,
      p=p,
      s=s,
      T=T,
      cp=cp,
      q=q,
      d_l=VLE.d_l,
      h_l=VLE.h_l,
      p_l=VLE.p_l,
      s_l=VLE.s_l,
      T_l=VLE.T_l,
      d_v=VLE.d_v,
      h_v=VLE.h_v,
      p_v=VLE.p_v,
      s_v=VLE.s_v,
      T_v=VLE.T_v,
      d_crit=crit.d,
      h_crit=crit.h,
      p_crit=crit.p,
      s_crit=crit.s,
      T_crit=crit.T,
      Pr=transp.Pr,
      lambda=transp.lambda,
      eta=transp.eta,
      sigma=transp.sigma,
      Pr_l=VLETransp.Pr_l,
      Pr_v=VLETransp.Pr_v,
      lambda_l=VLETransp.lambda_l,
      lambda_v=VLETransp.lambda_v,
      eta_l=VLETransp.eta_l,
      eta_v=VLETransp.eta_v);
  equation
  M_i = TILMedia.Internals.VLEFluidObjectFunctions.molarMass_nc(vleFluidType.nc,
    vleFluidPointer);
  (crit.d,crit.h,crit.p,crit.s,crit.T) =
    TILMedia.Internals.VLEFluidObjectFunctions.cricondenbar_xi(xi,
    vleFluidPointer);
  //calculate molar mass
  M = 1/sum(cat(
      1,
      xi,
      {1 - sum(xi)}) ./ M_i);
  //calculate mole fraction
  xi = x .* M_i[1:end - 1]*(sum(cat(
      1,
      xi,
      {1 - sum(xi)}) ./ M_i));
  //xi = x.*M_i/M

  //Calculate Main Properties of state
  d = TILMedia.Internals.VLEFluidObjectFunctions.density_pTxi(
      p,
      T,
      xi,
      vleFluidPointer);
  h = TILMedia.Internals.VLEFluidObjectFunctions.specificEnthalpy_pTxi(
      p,
      T,
      xi,
      vleFluidPointer);
  s = TILMedia.Internals.VLEFluidObjectFunctions.specificEntropy_pTxi(
      p,
      T,
      xi,
      vleFluidPointer);

  //Calculate Additional Properties of state
  (q,cp,cv,beta,kappa,drhodp_hxi,drhodh_pxi,drhodxi_ph,w,gamma) =
    TILMedia.Internals.VLEFluidObjectFunctions.additionalProperties_phxi(
      p,
      h,
      xi,
      vleFluidPointer);

  //Calculate VLE Properties
  if (vleFluidType.nc == 1) then
    //VLE only depends on p or T
    (VLE.d_l,VLE.h_l,VLE.p_l,VLE.s_l,VLE.T_l,VLE.xi_l,VLE.d_v,VLE.h_v,VLE.p_v,
      VLE.s_v,VLE.T_v,VLE.xi_v) =
      TILMedia.Internals.VLEFluidObjectFunctions.VLEProperties_phxi(
        p,
        -1,
        zeros(0),
        vleFluidPointer);
  else
    //VLE of a mixture also depends on density/enthalpy/entropy/temperature
    (VLE.d_l,VLE.h_l,VLE.p_l,VLE.s_l,VLE.T_l,VLE.xi_l,VLE.d_v,VLE.h_v,VLE.p_v,
      VLE.s_v,VLE.T_v,VLE.xi_v) =
      TILMedia.Internals.VLEFluidObjectFunctions.VLEProperties_phxi(
        p,
        h,
        xi,
        vleFluidPointer);
  end if;

  //Calculate Transport Properties
  if computeTransportProperties then
    transp =
      TILMedia.Internals.VLEFluidObjectFunctions.transportPropertyRecord_phxi(
        p,
        h,
        xi,
        vleFluidPointer);
  else
    transp = TILMedia.Internals.TransportPropertyRecord(
        invalidValue,
        invalidValue,
        invalidValue,
        invalidValue);
  end if;

  //compute VLE Additional Properties
  if computeVLEAdditionalProperties then
    if (vleFluidType.nc == 1) then
      //VLE only depends on p or T
      (VLEAdditional.cp_l,VLEAdditional.beta_l,VLEAdditional.kappa_l,
        VLEAdditional.cp_v,VLEAdditional.beta_v,VLEAdditional.kappa_v) =
        TILMedia.Internals.VLEFluidObjectFunctions.VLEAdditionalProperties_phxi(
          p,
          -1,
          zeros(vleFluidType.nc - 1),
          vleFluidPointer);
    else
      //VLE of a mixture also depends on density/enthalpy/entropy/temperature
      (VLEAdditional.cp_l,VLEAdditional.beta_l,VLEAdditional.kappa_l,
        VLEAdditional.cp_v,VLEAdditional.beta_v,VLEAdditional.kappa_v) =
        TILMedia.Internals.VLEFluidObjectFunctions.VLEAdditionalProperties_phxi(
          p,
          h,
          xi,
          vleFluidPointer);
    end if;
  else
    VLEAdditional.cp_l = invalidValue;
    VLEAdditional.beta_l = invalidValue;
    VLEAdditional.kappa_l = invalidValue;
    VLEAdditional.cp_v = invalidValue;
    VLEAdditional.beta_v = invalidValue;
    VLEAdditional.kappa_v = invalidValue;
  end if;

  //compute VLE Transport Properties
  if computeVLETransportProperties then
    if (vleFluidType.nc == 1) then
      //VLE only depends on p or T
      (VLETransp.Pr_l,VLETransp.Pr_v,VLETransp.lambda_l,VLETransp.lambda_v,
        VLETransp.eta_l,VLETransp.eta_v) =
        TILMedia.Internals.VLEFluidObjectFunctions.VLETransportPropertyRecord_phxi(
          p,
          -1,
          zeros(0),
          vleFluidPointer);
    else
      //VLE of a mixture also depends on density/enthalpy/entropy/temperature
      (VLETransp.Pr_l,VLETransp.Pr_v,VLETransp.lambda_l,VLETransp.lambda_v,
        VLETransp.eta_l,VLETransp.eta_v) =
        TILMedia.Internals.VLEFluidObjectFunctions.VLETransportPropertyRecord_phxi(
          p,
          h,
          xi,
          vleFluidPointer);
    end if;
  else
    VLETransp.Pr_l = invalidValue;
    VLETransp.Pr_v = invalidValue;
    VLETransp.lambda_l = invalidValue;
    VLETransp.lambda_v = invalidValue;
    VLETransp.eta_l = invalidValue;
    VLETransp.eta_v = invalidValue;
  end if;

  /*Documentation(info="<html>
<p>
Standard refrigerant model that can be used in most applications. This model contains all three data records:
<b>CriticalDataRecord</b>, <b>SaturationPropertyRecord</b> and <b>TransportPropertyRecord</b>. <p> For ppf-media 
data transport properties are roughly estimated. For R245fa no transport properties are implemented yet.</p>
More information on this model can be found in the
<a href=\"Modelica:TILMedia.UsersGuide\">Users Guide</a>.
</p>
</html>"),*/
  annotation (
    defaultComponentName="vleFluid",
    Icon(graphics={Text(
            extent={{-120,-60},{120,-100}},
            lineColor={153,204,0},
            textString="%name"),Bitmap(
            extent={{-100,-100},{100,100}},
            imageSource=
            "iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAHvRJREFUeNrsXXtsW9d9/pGiqCdFvaxYjmQp8yPp0lRqnG5t0MzyPymKrbW6dcDaoqlSdA2Sfyq1wV7ZELUpsKIYUAXrA30godtt2dBHpKBJ4QBrqSBu6sVN5VptY1luJUeWFUuUSFEUxffu7+pchSLv49zLey/PJc9nHBCmyPvi7zvf9ztPF3BYhm9egAHhpV8og+StIfLaT4oeLJCCmBFKWChBfH3oHrjo1Gf0wCNjJ8lzGSx4VkqYIc8BX4Pf/fpXpq28PhcPY9PIcJL8uEOUP7TZmMkvAmmmGSWEX3gZzitmYFIqAmEinCDsEGIor7CIoFTKTRiBGKimo0IZsfhUASxmKQsnCD0hpJpviLy2OuwWwqSWRcJMCoSJ2EQMrEjGy1CJ4H2Ol0oUThBtYpwmtd5whd0akiUgEGXKQis1QaMYHk8NtLe2gt/XDC0+H9TWemQ/l0qlYTMahUh0C9bDYUinM7SKMmrUenGCyJOiL88OtFb47YZJEE0IZFk0iRynyTEVn11dnRd6D3VDm98PvuYmQ+eJbsVgIxKBG2+uQmx7W+seRwSSTHGClK4Wo6bbgRqsJvOKGCE6j5Egr+m8kjH9EQQJUaZKIMfTaqpxoKMdDt3SBU1NjaZeeGQzCjfXQrAaWldVE4EkD3KC6CfGJ4hP7i/5YBj4tULxEmLUW3zxO4QoSfQgeUQqDQv4PASinNFpqZBgsq13fsE69dx6EOq8XksfRyKZhKXrK4INiyp9BFv5hmgtl4sTo0Ri1BUUFpAoKBYTRSBHH8lpishR6/HArd0HodlkxdDCVmwbrt9YgVQ6XRJJXJwYBkxpA1EIfHUzfrNZocSJwuBrzlyiEHLMyOUbmFt0dXaA212eh5TNZkXbhbmKQl4yKJBkkRPkLWIYb3KsI4RocPhDiJNiTFmChCjTWraqo63VcPJtNpAgoY2wISVxVQkxqJsci5LrRpJH1FTYQ8nkkUV/sh/AxoxzT40VkcPlcsGB9jaora1l6nZTqRSsrm9ALlckoTMCQd5ZtQQhLVMB0NNci79tE0M5hR05S4wk+ZS48tL9cHP+TigkR5u/Rcw7WATmIxuRTTmSKLZuuSqYGH5CjGHdxPBCdSJJR5TQ4hF4/X8/WPS+v8UHnhq2pTadyYhNwjIYlusncVUoOfSphkSMWuAAQhAFoqQTdXDh+5+ETHJ/+3VDfT14vc54gMlkCuI7O3JJe39hPuKpMGL4SRI+SvUFbFzx5REjx7mxFxV+QhCsbLNv/ekP508WkQOHiqByZDNZZ9yecK14zQVDVVpJnvpgRSoIGR4i2xYvaywroUXKLpBkPrLcA7M/+euivKO+rk58tQLHjtwGn334U6Ye8+FHHxPzkJ1EQi4fGcof4OipEHLQWypUi2ZCEq4YdKjfbbC49sK7ix+nkJBjkMkEminIZc1XpSw5Jl57MlXkI9GBnMo3GU4nx2eIcrRqqkYTIYdkp3ihLpE3emDzRm+RekgBZ1WxgnjSsfPvIV9ByNwV5yuIQA7VgXH7VKORq0YpuDn7x0Xv1bjdkM1Z+0CtOH7+MfEesGWrAKNSLuJyKDHom3AbeOtUqcCWq/PfeKRIPewYQtLYUA+9tx5S/PtH/vKDcLjn1n3vvXz+VTh3/oLidy7P/75IUWSUqhVbtDwOJUdQMxl3w1tjpbhqlITQ/BFZx5rLWf9gY9txeP3KVcW/b8eLmmthLbSh+h3Zeyl+GyvfM56KJIc0zJxbKlOwfvWIQgZt7OH2CjX+3e94OwnwOLz261kIqc/jUEvj5d8rnbzOIgg1OTzw1hARTg5zCPL7o1Rhibjj2BH4h8/st2OvX5mHLz35DTgsWKVPffxviizRR//qNLx28RJ85z/+W1YRzKKNAYI4oxWLmhxeUnirk3mtV0s9pvyG7/3Te+AL//i5InJIuHvgLvi3z/+zSCJWgAtOuCuKHDU8oO0iiNT3IVcK0dneLqiEdntKY2ODqDA4bEXt+PuLvPOj/75qH86QEyxWgIocPBm3JkleO1DyMTo72vcS7hd/9pJouRobGuD+U38Gbzu+376hwuD7ky+cZeH2B5kmCOnnUK96ankybiUSmy2mtUZ9aeJrcO368t57mJyjYtz37j/Z91mGCNLvZpgc2EM+opmQu7gNsrLEQl2m/J7/9YPJfeTIf79wJZImwWpJrVzlVhA3o+TAsVUTqh+Sph1kebG0mITXfn1J9n1stcIWrEIoJfN2w8MgOfpI3qEMN2/GdRIWl66rNt9eW1qWIcghThCFFiv1gYcuTg67sLNlTv6xvR1X/fvaenEnISbxnCDFGAea+RycHLagvmmz6p8BMwTJW/aTk4ODGbgZIYdfM+/gcCwK+zpoEnI521W1BAG9y/JwOA5qQ0jkEnK5xL0qCUKs1TAPITbR1H7TlOMM//n7ZN/H+R53v+Ouovdfn5tn4fZn3GUmB7dWjKOu2ZxE/cTAXWIPeSE5PvXxj4gdg/nAZmG5TsUyYKHcSfoEt1aMK0jHKqxfO2rKsT724WF477vfBa9dnN1VDoE0B8g4rXxMPn+WldufKRtByELSIzwE2Yb/4BK8IfO+0jI/cu9jP0gjUYk+ISHvU+klf/kXr8KvLv2GehkhuY/he3qXIVIY0Rssp8Ua5+HnAIJ0L5V8jGvXr8N3vveMZochkgMnTbECXB+rLApC9ucY4uHnDLQfni/ZZr18/gK8Pv97cfZg4UDEa0LOMfnCi+LoXt3kE1u79qsFzkk3ATiio2wdhVw9nESQvquyBJGzMS7ZhXJc4mdD6xvw798OiPmH1PexFlqHtfUNVdumhmd+9By11dNpr8pDEKIe/TzsnIOOw1dhnjYIXaAZsPGdxL6ld6xattSRBOHq4Tx46hLQdfQ3+/YDkYKqMLj1JO8sQGHKbUBa5d1WgnD1cC667/xV0YY5uOBa4WY5srZLeMvNKEFSGdnttfbmItmtIFw9HIrmjlVoOfgGbK707q99hX/5KyzKE0HIQdzsEURhRcWgoB4XbScIGVLC1cPBOPzOX8DsT/YvYI17bNTX1ex1SMgRQVQQN2OTVwViJNMZzUrcTgUZ5SHmbGCfiFwukkqlob6+jiiIW1ZBahgjyM5OQin3mKZoczBdPXAa7QIPMedDeQu2OvDWOmQLtlRKbEkrQFm3YOPqUSHAFq1j971YtIknBhxu/cz6Jp64060MORAjcvul20WQER5alYOOvqtFVgsR3YpBq7gNdA2j5MjAVmxb7k8BuR1ubbFYJDmf5GFVeZiZ/BjE1rsKEnIXdLa1CWrC1nIHiWQS1sMRubxjRiDHOxUVk6sHh1G8/f0/gNmffHgfSTAAV9fXob2tFXxNjUxcZ1RQjfWNsCzHQWNMoKUKQiZEhXkoVS52oi0wM/WxoqQd4WtqEtflrakpTwtWJpMVx3pFYzG5P8sm5XYriOZU2u7mk9QHu7E1bflDpb2eZCYMofhFxwa2t8YPHQ2DpR+oGaD3k1fhlcl3wZsr2wU1d0zcavnQwS5oarRXTWLb27C8clNMypWUQ4scdhBkSOsDd90yCv2tdFPSf/jbQUuDstnbBx+4PUj12Z+/MVp0LR0NA/Ce3gnN74a2Z+CVpbHyJtoCOWjvlQb3HylenHo3MU7D4tIytPiaoaf7IHi9XkvvKynkGks3VmAzuqWYOtGSgwkFWQhPUhPkeMeIpYFFex3SdRfXyq1wyDcE1QicV/7EPz0K3/7uM+ImmoXAgP1tdB4629vgQEcH+FuaTT1/ZHMLVkOhvaHzCsDWqgf1HNcygpApta1GAk0tgK0kCBKQlhxbyUWegMjgbx/4CNw98PbdGYRyG2wKAYwFCXWw64DYLIy5irHkOwbhyKaoGIlEUu2jmG+MKDXllktBqKrSZCZCrSK+un7Rxlhhs9BedTYOUhOEQxm4gskdx46KWxvIqclujhCHqwvXdoOwpgbaWv2iDcPdpXBClRyQcPGdHVGNNsIRuf3NZVVDKKO0loo5grBis2jPn0iHOUEoLReqCa5igpvhqG3LjIGOe4SshkxdTRETrPHCsVWOJMhc6Ay8p2cC6jytVIFsBUH02CtUPQ464LKjWHCtqxd/+pKiopgIVIyJ/CHrzBGE5B+6gIF3e6d2kFphs/B4tPZqLhTgUW8AuNQPKspHPzwsbqaDa2MZWaRBDrioRDpZN7650jth1ErZrSCDVhHECptFqx7RxIItfTGVbr1wT0JpX8Lfzc2L9gtXNsFOPa0VFXEpVFztERe0wzW78pYlCj90D5gu7cwQZDEyJfr7ctgs2vyjGnOPNeyzecPawdieowB/JJSeTBh6jTuDQUuujRWClMtm4XHweDS4dHOi6giCIwYcopqWEMTN0sXq8fe0tsis42BNyvs+OEHMSNAHjH4Xayr0+WbaIrOOM1uF6uE0lBJ7dipIfylfpvX5ks2yy17xvg9HoNUJBClJ6uy0Wbzvo+Iw5ASClMRiTLztslm037+8FuChV6VgTkH0qEgpNqvPf5rKXmHTMzZBc3AFYQaXbbBZtOrBe865gjCVpCOwORWbVa20WZwgFYn+qiCI1TYL7RVNjz3mQk6eVssJUjo8rN4pthzd20vX96B3bBatelzifR/g8/bDie7HLT1HNLkgjuhmEcwSRLJZNKNs9Y7N4mOvdBBEUOgTh8YtPcdyNMgsQdws/zi0vdd6bBatveLTajmYJ4ieGpy2NYurB0fZCGL2WBhpvrpZgY9rQdF8Dvs+WJV8DgcT5KF7wPQmHzPHZiE5aO0VBwfzFku3zdKYS0Ld97EeMHaxLgf98i4e/OwRxKW/JLMR6p71fv+w4nG8Hjp7tTet1sC1Wv0sTC0sEpbBa3c7ocZaiJRusyxXDw4m1O+BR8bEYhY8rNyYGvTMVxc7Da+PyasLBS4jQVw23J+L3SDLB/ZR/Hj+FFuxkdP+iESS7379K5Wdg+hVETki0LZe8Wm1lYdSFcUKgixY4bsXNnXYrMaBfd+lnla7NmGPt3cxUpx0rXTXvaClKGwTpASINitDtxfP8fYRQ/aKVqU42DUaNLarolqx8gttAp3fmoWLUtMQBHMPbDGzrWXISa1YzlEQuPOOY+D3+UyzXFYQJGgVv2gJgiNQO+oHuHpUH4IugUG9t3ZDf28P1Ho8JauJfQqSK/0QoZ2L4tBoPTar0G7JAa3b4qYJ02p5R2HZYwl3s8WCu+we7jkEvuamkkhiBUFmrJRqPa1Z4p4fFPvwzUlNu9VkWyrTYgVTqRRIJZPJQEdbq1iMksTeJN0EFZkL09usE7eMm3pMDrbVQ0A4lUpDYamvq4OujnZxD/eyJ+mqAxZzpdceaLPW4nTz1W+nsFd4LDym7TWzU5p5WVMQFYLMP/fFi+l0GuQKkqPN3yJLEjUVsSoHmbFKQcQaf8O8Gt/MY3GUVUFmcKcqtYLkwG3e9FgtqwiyYJWCiHlI1LwWJ9FeVWvnmxPzjxIIIu1piPsg0pLEKoIErVSQrdQitc1SZfHm5G7fB0dFKEg2kwWagpuGejw1VKezarDijOoNmkBLrPk7G0pbdURUojI0d/pq++FE1+OWn+ey8IywMnHCtUqIphaE31ZhNmdWPea++uUnqM7x8KOPQa2nFjICWXK5XJGK5A9wtIQgQqI+/c0LoHyTJhAEg/vebuMEwb4PxR/CaoJgC1vXuOXnWY4FSyeITdeaf81GCPLpEznqXX6y2d0DYUdiMpWytxVL02ZlzbNZtAMYFdXDbLDW+eZy0LVSRbbOWFMhiEQSrVat8hGkzMn6bGii8mfpgcOuVe2azSSIYKukUuN2lyUHUb/ojDlnNkoQHK4SSvAlRR2FDH2s4V7s585fUE6DC/IOVBGlXMQygpA8BMent8qqiAm1WDIXEUnS79O3gPVcJGBNLcqixXI50GK5dNmrcGH+sRbaELeW1nO6XBlyEMSkgdrAchW5jAThqBQFkQmAHMoEfSlTkq5us9Lm+P65zTPUE6nEVpLtIGylF6tjtZBKyZnS+mMsp7OUiyCTBj2lPhXZoleROa4elZZ/WDaRB/MQy+sRIQ95VniRTxIagS9gxqEOrN63lclxn+/Kh952/Oi+N599/ixMvnDWlNPbsexPQJEgKJ1eHgMcKkhpxpalsHxG4UP3AE7VCxu4eQ4OtRgJn3tqzPLdVe1aOA6ZPiorn6gitTwOOBTIkSufetiiIAQTBiWUg6uH/phyGkEEm4Uj5oKyf8yQ4uKFl7wixYU8goK9WqwYgmgyPsErSw5dMWHb7qq2EYQk6wtcRXgpUT0W7EjOy6EgiHHFv+zwSpODKhbG7bwUWwkiqMgZVRVJ89ioeqQ11cPWWW7l2Ccda4CA7F/iQmnhMVLViLOjHuWwWOoqkuUJe9Un5ll21KNcCqKuIug/veCgrX04TEGWrdyjbAqSpyJB2T+qD07jqFRsg1qvebAc6lFOBZFqBHmSpEjhAxmrA0nQ6jUfV1pXV+5tfE/vOrw5hYlT5TQy06A2niYGpq2AwsG4tYqpfiLw86c/O12OS7N0Troa8tbMwgGMOBS+VdZq4YPjrVqVjZiqtQqD3CDXPFxbWobCSUU4J70SLBYC1/0cAaVZYSmSuNXzOKpI7Ghaq5FXAp+LqLmlZ370nIL1ordYOZV56bZbLJkVF6dAbdokJm8ZHksVhwxoNcZM/uLMo1MY6FYXlhVkr6aA3b4ReasVFYofeNNvJeUdUU1rNWJkwxu9QPWQUxBpfV5bQ+6bFzStlnJts8XjqmKwpekKRl793t9F3AJBrC7SEqSsK4hktSYUk7IkSeiaeXw5nhxJ1U9MXPjPv59y2VB1IznU1MNWgqioRz7GhTIkFPmdN+PkinnS7tykXH2sFW6bMe5228AOgRjJtHZy62HsEaLVGiYPSn5r0igxhnU83hyFBPntQDXvGL74P49Famzgx85OQlM9bCMIpXpIWCQkCSp+YpPQhy/24AykyG+mjpHZ7//Loh3kwD1BpO3YnKYgEqZJLiI/tTJH6ps2ThJHkCMMWtvvjf7uR+NTNTU2XE46DfEd+SHjherBMkEQT5JcZESRJBucJMyTY0OTHIErzz3xpMdjBzkysBXbpiYHwo6lR0uF8tKl0h20M071agTODFzXJscfnv/XB21JgZJJWA9HqPIOpyjInjcl+cigopLgD4Edibx1iw1ga1VEkxzYEDNaW2t9CEYF1VjfCBv6rqUKYoJ6SPCrkiT/Uw08PsuKOCEHaJJj6M2fTVi6BzfuYrsWWhcIojxcWE09mFCQ7uaTNB+L3NiaHtIkSYT4Xj+P07IAn/82HTk2Xv5axGth7hjb3obllZtiUm6UHEwQ5K5bRqG/lWoLtci3funSJok0uBGbgfnYLXuAozXQwSToyBH7v29HvBZNhksKucbSjRXYjKqPTaIhBxMEWQhP0hIE3tPzlcgrS2PaJMEfKgS8hcsOSC1VaTpyXJ78QuRARxL8LeaOGYpsbsFqKARr6xumEMPyHIQ2//DW+GFkkC6BiiYW4JnZ26RsIwBqrVvS3eEnG3kcW4JtqmQcgdMZRs49NbaXczQ1NsDBrgPQ6m8BX1OTweQ7BuHIpqgYiURS8/N6ycEEQRD3H3mWWkV++NtBCMX3tnB+GtRGAUuoJ2rCLZd5lgorarrVMAMCMVSbcj01NdDW6ocWXzM01NdDY4N8c+R2fAfiOzuifdoIR6h7w42SgwmLpddmHe8YAcFmSf99kEi3+mLG+EOuEJLwVq7SEAeazj8Jo/f5rjwZOnZWdVtmDPTV0LpYzIZRYjClIIhPDGxAnadVj83Kx2liubQPwNXEDtUQBx7m71++uHQdXvzpS/Dy+VdtudxSiWEpQYz0f5zsexpu7xyh+myBzZLQR7zuINVd42IQPh73dGYfdgcb0qnGDCGH7P4dse04vPbrS/DaxVnhddaUy2s/PA/pZB1srvSaRgzmCNLnPw3vO0q3o++lNyfybVY+MCUfB42VMPaAg+NwmAofOi8PbA1E10Nv9dHqjgvkoO4A/N3cvGi/rgkKg516164vq36+qf0m1DVvQlPHKvgPLoG/e2nvbw/dY/4jYIYgJtgsY5YLCEFagA9Vyc/ZNkHPOsniHPLu5pMl7duRzITlnAE1rCAIU2OxMFmnsVm+un7oaBhQe5j4Q/UDTVOwVFOucqIYIAYQW4s/Go52qLhHwlSqOhcKUH8WW7M0gDL/IUIQuo4WiSg3SWtNtezoFCf3vKpbNYbJM45Uap1hOkFKGaCINRDaJxrQNgsXqAm9914TynXy01fixj5pcm/Xyb3qU40AeaZTLN2SiYNj2VQQyWbRQLJZlMBQwD6TIVCbyluIDPnmMqldYxVAjBi5l2Vyb/oW5QuSZ/hgJasG0wQx2WYVAk3yKXhroTp6oA3B8V1vkFdpTVnW7ZO0xnH+tcf111vkmZ0iz7BqwBxBMPG2wGYVAveauM0QUQoDboW4cZY2Id0h17QiQ2hjxLiNPLOqA5P9ybQqotNm7QP2u3z6RO6MUIwRJT9fQbPxJuyux4KvGyQgEzYoRIKca6PgGiJQynZ2IjHw2fzF8Z9VJTEkMDnl9rJAkBOHxqltlkKnIbX6IFGwhvzWL13YfzJKfLbx2ntH5innF0S9geNKyXV+MReYY0wIz2MKONglyFZyEda2Z6CzcZAq0EslSB5RMDCmBKL0EaKgsrSWfEPWBLNZQDMWIMRY5JRwAEEkm9XZOEFts/T0wKK9UuuxJ4EyJuRCY8/M3naaEGW4wn57bC4McLVwKEGwuffe3gmqz+q1WbTJ/aWb4vmnSPETkgyB0q5YbCNMSIE2arK7+WTkA7cHtSsgbz+c6H7c0guLJheECvEMJwgrNouWIAV9MhHSkoMF+wFOErIMlZSzWItgXjHUPIsKTZsPGsVyNMgJYgSzQg0+1B8w1WZp2at8ciBJVTBNyufJ/5EwgwXFTswUlKrqr6hKgtD2quuxWQbVgwbTgm2ZzrctQrI/QKyYpDDSaz8puh4HvNUUHcx7Ret0kYeyAwhi9liYZCZCPR2XxmbhAhE0x0qkw6ZIvpAAX8xTG5DUBi3Fj+dO8ehzAEztKLRiPL6ZY7OQHLT2ioPDdIKU3WZpzCWhtVdz6wFjF+ty0C/v4sHPHkEMDKVIZiNizzoN+v3DisfxeujsFY4DEyf+GBn2YfGzMLWwSFgGr93thBprIVK6zbJcPTiYUL8HHhkTC5NJulUkWYxMiYkzTf4gtmZdH5NXFwpcRoK4bLg/F7tBlg+xQWH+FFuxQTEqWSJJqaucOGZ1KFoVkSMCbesVdkxq9H1wOAylKgrzOYhUFjZ12KzGgX3fpbVXs2sT9nh7ViZTOelaS8xBjJLEMQoi2qwM3doLx9tHDNkrWpXicK6aVKyCYKFNoPNbs5q9fVQEwdwDW8xsq9mcVAs7SEHuvOMY+H0+0yyXo1aopSUIjkDtqB/g6lGVDVwu6L21G/p7e6BWZetcWpLYR5Bc6YcI7VwUh0brsVmFdksOaN0WN6fM+HWcFEnOhUos4W62WHBz0MM9h8DX3FQSSRxlscRkXUdrFtqrzgbtQbVzUtNuNdmWCrVYqVRqr2QyGehoaxWLUZK4WWE+tc0K09usE7eMm3pMDrbVY5cg6aJSX1cHXR3t4HLpl03TCaI6YNGEdaTQZq3FZ6iu5XYKe4XHwmPaXjM7qbmUtXW+FDD/3BchnU7LFiRHm79FliRqKuI4BRFr/A3zanwzj8VR3hjCnarUCpIDt3nTY7XsJ4gZeUjUvBYn0V5Va+ebE/OPEggi7WmI+yDSksSRCrKVWqS2WWrA3nmx74OjIhQkm8lSFdw01OOpoTqdpyw3aAItsebvbJgojSCoRGVo7vTV9sOJrsctP89l4RlhZeKEa5UQTS0Iv63CbM6s+ne/+uUnqM7x8KOPQa2nFjICWXK5XJGK5A9wtIQgmKgrTr/NmkMQDO57u40TBPs+FH8IqwmCLWxd45afZzkWLJ0gNl1r/jUbIcinT9Dbk2x290DYkZhMpextxdK+OvNsFu0ARkX1MBusdb65HHStNsYOEkQiiVarVvkIUuZkfTY0Ufmz9MBh16p2zWYSRLBVUqlxuxnLQRAZc85slCA4XCWU4CvlOAo6NvrBvdjPnVdeYqcw70AVUcpFLCOIZh5iQi2WzEVEkvT79C2bOxcJWFOLsmixXA60WK7S8o+10Ia4tbSe0+WYyUF01gZWqMhlJAhHxSqIGO45HYWpJF1C2hzfP7d5hnoildhKsh2ErfRidawWUik5k4GtI3I6C3sEMVNFtuhVZI6rR4Wrh3nAPMTyekR1OdJG4AuYcWhLwbbyn+/zXYG3HT+6771nnz8Lky+cNeX05V28GqXTy2OAQwWp8p7ecoulOvw9xX9/DuMEOffUmOWnL6+C5IiK1PI44FAgR668l+Bm4iFwcDAaG7YQRNVmZUhx8cJLXpHiooz2ig0FQSR4ZcnBZkzYRhCuIrw4TT3YURDEDq80OdiLBVsJoqkiaR4bVY80O+qBYGuX27hQWniMVDXibF2O7RZLVUWyPGGv+sQ8y456sKcgkv/0gsOW1eYoGVk289D/F2AAG0K14Ttoh/wAAAAASUVORK5CYII=",
            fileName="modelica://TILMedia/Images/VLE_pT.png")}),
    Documentation(info="<html>
                   <p>
                   The VLE-fluid model VLEFluid_pT calculates the thermopyhsical property data with given inputs: pressure (p), temperature (T), massfraction (xi) and the parameter vleFluidType.<br>
                   The interface and the way of using, is demonstrated in the Testers -> <a href=\"Modelica:TILMedia.Testers.TestVLEFluid\">TestVLEFluid</a>.
                   </p>
                   <hr>
                   </html>"));
  end VLEFluid_pT;

  package VLEFluidObjectFunctions
  "Package for calculation of VLEFLuid properties with a functional call, referencing existing external objects for highspeed evaluation"
extends TILMedia.Internals.ClassTypes.ModelPackage;

class VLEFluidPointer
    extends ExternalObject;
    function constructor "get memory"
      input String vleFluidName;
      input Integer flags;
      input Real[:] xi;
      input Integer nc_propertyCalculation;
      input Integer nc;
      input Integer redirectorDummy;
      output VLEFluidPointer vleFluidPointer;
    external"C" vleFluidPointer = TILMedia_VLEFluid_createExternalObject(
              vleFluidName,
              flags,
              xi,
              nc_propertyCalculation,
              nc) annotation (
        __iti_dllNoExport=true,
        Include=
            "void* TILMedia_VLEFluid_createExternalObject(const char*, int, double*, int, int);",

        Library="TILMedia121ClaRa");
      end constructor;

    function destructor "free memory"
      input VLEFluidPointer vleFluidPointer;
    external"C" TILMedia_VLEFluid_destroyExternalObject(vleFluidPointer)
        annotation (
        __iti_dllNoExport=true,
        Include="void TILMedia_VLEFluid_destroyExternalObject(void*);",
        Library="TILMedia121ClaRa");
      end destructor;
    end VLEFluidPointer;
  end VLEFluidObjectFunctions;

  package VLEFluidTypes
  "VLEFluids and VLEFluid mixtures, that can be used or composed in TILMedia"
extends TILMedia.Internals.ClassTypes.ModelPackage;

record BaseVLEFluid "Base record for VLE Fluid definitions"
    extends Internals.ClassTypes.Record;
    constant Boolean fixedMixingRatio
      "Treat medium as pseudo pure in Modelica if it is a mixture"
      annotation (HideResult=true);
    constant Integer nc_propertyCalculation(min=1)
      "Number of components for fluid property calculations"
      annotation (HideResult=true);
    final constant Integer nc=if fixedMixingRatio then 1 else
        nc_propertyCalculation "Number of components in Modelica models"
      annotation (Evaluate=true, HideResult=true);
    constant Internals.VLEFluidName[nc_propertyCalculation] vleFluidNames
      "Array of VLEFluid names e.g. {\"vleFluidName\"} for pure component"
      annotation (choices);
    constant String concatVLEFluidName=TILMedia.Internals.concatNames(
        vleFluidNames);
    constant Real[nc_propertyCalculation] mixingRatio_propertyCalculation
      "Mixing ratio for fluid property calculation (={1} for pure components)"
      annotation (HideResult=true);
    constant Real[nc] defaultMixingRatio=if fixedMixingRatio then {1} else
        mixingRatio_propertyCalculation
      "Default composition for models in Modelica (={1} for pure components)"
      annotation (HideResult=true);
    constant Real xi_default[nc - 1]=defaultMixingRatio[1:end - 1]/sum(
        defaultMixingRatio) "Default mass fractions"
      annotation (HideResult=true);
    constant Integer ID=0
      "ID is used to map the selected VLEFluid to the sim.cumulatedVLEFluidMass array item"
      annotation (HideResult=true);
    annotation (Documentation(info="<html>
<p><br>Every VLEFluid substance model contains a substance record as replaceable parameter extending from this base VLEFluid model. The substance record contains the following parameters: </p>
<ul>
<li>fixedMixingRatio - Boolean = true, if mixing ratio is fixed during simulation. </li>
<li>nc_propertyCalculation - Integer with number of components which are calculated. </li>
<li>&QUOT;substanceNames&QUOT; - VLEFluidName 1, VLEFluidName 2, and so on. Array which lists the substance names. </li>
<li>mixingRatio_propertyCalculation - Array with the mixing ratio of all substances. </li>
</ul>
<p><b>Access additional substances:</b> </p>
<p>To acces the properties of an additional substance, it is possible to create a new substance reccord. For more information on the acces of additional propeties see the <a href=\"Modelica:TILMedia.UsersGuide.SubstanceRecord\">substance record documentation</a>. </p>
<p>Furthermore it is possible to parameterize this VLEFluide base record, using a VLEFluid substance name, listed in the <a href=\"Modelica:TILMedia.UsersGuide.SubstanceNames\">substance names documentation</a>. An example how to parameterize the base VLEFluid model is shown below. However note that this is only a local configuration and therefore only accesible in the corresponding model.</p>
<p><img src=\"modelica://TILMedia/Images/Base_VLE_Parameter_frame.png\"/> </p>
</html>"));
    end BaseVLEFluid;

record TILMedia_Water "TILMedia.Water"
    extends TILMedia.VLEFluidTypes.BaseVLEFluid(
      final fixedMixingRatio=true,
      final nc_propertyCalculation=1,
      final vleFluidNames={""},
      final mixingRatio_propertyCalculation={1},
      final concatVLEFluidName="TILMedia.Water");
    end TILMedia_Water;
  end VLEFluidTypes;

  package Internals "Internal functions"

    package ClassTypes "Icon definitions"

partial class ModelPackage

      annotation (Icon(graphics={Rectangle(
                    extent={{-100,-100},{80,50}},
                    lineColor={0,0,0},
                    fillColor={255,204,0},
                    fillPattern=FillPattern.Solid),Polygon(
                    points={{-100,50},{-80,70},{100,70},{80,50},{-100,50}},
                    lineColor={0,0,0},
                    fillColor={255,204,0},
                    fillPattern=FillPattern.Solid),Polygon(
                    points={{100,70},{100,-80},{80,-100},{80,50},{100,70}},
                    lineColor={0,0,0},
                    fillColor={255,204,0},
                    fillPattern=FillPattern.Solid)}));
      end ModelPackage;

partial record Record "Partial Record"

      annotation (Icon(graphics={Bitmap(
                    extent={{-100,-100},{100,60}},
                    imageSource=
                "iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAAEH5aXCAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA2dJREFUeNpilBKX/s9AADx7+ZQRmc8CIp6+eEJI339GIEDRBAIHXv/BqcNBlIXhPxDANDIxkABAGlFsAplGrEainIfuVJKcBwNkaSLZT0QH+RDzE0AAMZKcYP8TAZANZSEmxECpX1pC5j/IJqI9D9IEsokRllJJCimaRiLJGkakHwACCBx71AD4EjFKXiA2wHAlN1D6B6ZTjCKciYHKAGQZ1pxEDQDyAbaogBcIRFRGFAGqxQmuxE6TOCHoE1IKXppXB6NxQtM4AQggoipOIsAHYFEiSL0SFXdux2kR1eIEWGoIAEPlPVXaToQsAvrqPbqPaFEKY/iIJkkY3SKa5RNki2hanwAB2CKqJGFCltO3WKFV4Ui3AnLUEtp3rEaDazSfjOaTIeoTgADsmVEKgDAMQ/vhpdwxhJ1y4BUniJ86jWwlHckNHum6tD3DXdmLMShv+TUoNi1JaTUWXdGtokC3BdW7wfzcCEBAixELAaIGQYBCgHwBCgXSAnLZQY2W21wyTX5wzShM/wgSfKdzRCAC8XzsI4cTOaL2q9ISiEDUfmkdebjWhNIhALt2dIMgDEVhmH0g0WUMz0b3UccgLIORReoE0j7xgNI2JZxr/m7w0ZJ77m1L3b6WWsepbX1mQxQmjW/nqsv5mo2R6tlnRzwZI/ezn9ow/x2mD3wwDbk/blkYydDoMX71Xe8xUcdMto6k7ox0QUzByFf2WIyJiBKDMZO11jCmQuMvjLn0+w1jMsYvYeQ6qIyWIhTNYg/A91rjawxPtM13iHVTM0UBsvnwQS3Gry1mv0CAAAECBEhKZeeiBwgQYjwxnqMFBAgQIECI8ewIEOP/yD+8oPsI0M4d3SAIQ2EYJcYBHMEFnMgh1MllBNOILyYSlBvyg+cbgZO2cq2m3aBLq29736+3+maBrP2Hb9W9rbbFYHYe/XjDtYRD9/w2//7tBUUgxbW7Im33WAoGSBjM5DMkfV5X3fl07Maey/Vyazd5y88YKyRsxQAJgwESBgMkDAZIGAyQMBggYTBAwmD2HtF4C430XzC9aW8YvC0rLCBABGRFTf6U9W/j9+qmXkqyQmxZAgJEQIAICBAB8aZe+6YpKwSIgABR+KFu/D4v43dbloAAERAgAiIgQFT7pm78boUAERB9OkO28G9sW+gB4BfZ2hOOJl8AAAAASUVORK5CYII=",
                    fileName="modelica://TILMedia/Images/recordIcon.png"),Text(
                    extent={{-100,110},{100,70}},
                    lineColor={0,0,0},
                    textString="%name")}));

      end Record;
annotation (Icon(graphics={Rectangle(
                extent={{-100,-100},{80,50}},
                lineColor={85,170,255},
                fillColor={255,255,255},
                fillPattern=FillPattern.Solid),Polygon(
                points={{-100,50},{-80,70},{100,70},{80,50},{-100,50}},
                lineColor={85,170,255},
                fillColor={255,255,255},
                fillPattern=FillPattern.Solid),Polygon(
                points={{100,70},{100,-80},{80,-100},{80,50},{100,70}},
                lineColor={85,170,255},
                fillColor={255,255,255},
                fillPattern=FillPattern.Solid)}));
    end ClassTypes;

    package VLEFluidObjectFunctions
extends TILMedia.Internals.ClassTypes.ModelPackage;

function additionalProperties_phxi
      input Modelica.SIunits.AbsolutePressure p "Pressure";
      input Modelica.SIunits.SpecificEnthalpy h "Specific enthalpy";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      output Modelica.SIunits.MassFraction x "Steam mass fraction";
      output Modelica.SIunits.SpecificHeatCapacity cp
        "Specific heat capacity cp";
      output Modelica.SIunits.SpecificHeatCapacity cv
        "Specific heat capacity cv";
      output Modelica.SIunits.LinearExpansionCoefficient beta
        "Isobaric expansion coefficient";
      output Modelica.SIunits.Compressibility kappa
        "Isothermal compressibility";
      output TILMedia.Internals.Units.DensityDerPressure drhodp
        "Derivative of density wrt pressure";
      output TILMedia.Internals.Units.DensityDerSpecificEnthalpy drhodh
        "Derivative of density wrt specific enthalpy";
      output Real[size(xi, 1)] drhodxi
        "Derivative of density wrt mass fraction";
      output Modelica.SIunits.Velocity a "Speed of sound";
      output Real gamma "Heat capacity ratio";
    external"C" TILMedia_VLEFluid_additionalProperties_phxi(
              p,
              h,
              xi,
              vleFluidPointer,
              x,
              cp,
              cv,
              beta,
              kappa,
              drhodp,
              drhodh,
              drhodxi,
              a,
              gamma) annotation (
        __iti_dllNoExport=true,
        Include=
            "void TILMedia_VLEFluid_additionalProperties_phxi(double, double, double*, void*, double*, double*, double*, double*, double*, double*, double*, double*, double*, double*);",

        Library="TILMedia121ClaRa");
      annotation (Impure=false, deriXvative=der_additionalProperties_phxi);
      end additionalProperties_phxi;

function transportPropertyRecord_phxi
      input Modelica.SIunits.AbsolutePressure p "Pressure";
      input Modelica.SIunits.SpecificEnthalpy h "Specific enthalpy";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      output TILMedia.Internals.TransportPropertyRecord transp
        "Transport property record";
    external"C" TILMedia_VLEFluid_transportProperties_phxi(
              p,
              h,
              xi,
              vleFluidPointer,
              transp.Pr,
              transp.lambda,
              transp.eta,
              transp.sigma) annotation (
        __iti_dllNoExport=true,
        Include=
            "void TILMedia_VLEFluid_transportProperties_phxi(double, double, double*, void*, double*, double*, double*, double*);",

        Library="TILMedia121ClaRa");
      annotation (Impure=false, derivXative=der_transportPropertyRecord_phxi);
      end transportPropertyRecord_phxi;

function VLETransportPropertyRecord_phxi
      input Modelica.SIunits.AbsolutePressure p "Pressure";
      input Modelica.SIunits.SpecificEnthalpy h "Specific enthalpy";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      output Modelica.SIunits.PrandtlNumber Pr_l "Prandtl number";
      output Modelica.SIunits.PrandtlNumber Pr_v "Prandtl number";
      output Modelica.SIunits.ThermalConductivity lambda_l
        "Thermal conductivity";
      output Modelica.SIunits.ThermalConductivity lambda_v
        "Thermal conductivity";
      output Modelica.SIunits.DynamicViscosity eta_l "Dynamic viscosity";
      output Modelica.SIunits.DynamicViscosity eta_v "Dynamic viscosity";
    external"C" TILMedia_VLEFluid_VLETransportProperties_phxi(
              p,
              h,
              xi,
              vleFluidPointer,
              Pr_l,
              Pr_v,
              lambda_l,
              lambda_v,
              eta_l,
              eta_v) annotation (
        __iti_dllNoExport=true,
        Include=
            "void TILMedia_VLEFluid_VLETransportProperties_phxi(double, double, double*, void*, double*, double*, double*, double*, double*, double*);",

        Library="TILMedia121ClaRa");
      annotation (Impure=false);
      end VLETransportPropertyRecord_phxi;

function VLEAdditionalProperties_phxi
      input Modelica.SIunits.AbsolutePressure p "Pressure";
      input Modelica.SIunits.SpecificEnthalpy h "Specific enthalpy";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      output Modelica.SIunits.SpecificHeatCapacity cp_l
        "Specific heat capacity cp";
      output Modelica.SIunits.LinearExpansionCoefficient beta_l
        "Isobaric expansion coefficient";
      output Modelica.SIunits.Compressibility kappa_l
        "Isothermal compressibility";
      output Modelica.SIunits.SpecificHeatCapacity cp_v
        "Specific heat capacity cp";
      output Modelica.SIunits.LinearExpansionCoefficient beta_v
        "Isobaric expansion coefficient";
      output Modelica.SIunits.Compressibility kappa_v
        "Isothermal compressibility";
    external"C" TILMedia_VLEFluid_VLEAdditionalProperties_phxi(
              p,
              h,
              xi,
              vleFluidPointer,
              cp_l,
              beta_l,
              kappa_l,
              cp_v,
              beta_v,
              kappa_v) annotation (
        __iti_dllNoExport=true,
        Include=
            "void TILMedia_VLEFluid_VLEAdditionalProperties_phxi(double, double, double*, void*,double*, double*, double*, double*, double*, double*);",

        Library="TILMedia121ClaRa");
      annotation (Impure=false);
      end VLEAdditionalProperties_phxi;

function VLEProperties_phxi
      input Modelica.SIunits.AbsolutePressure p "Pressure";
      input Modelica.SIunits.SpecificEnthalpy h "Specific enthalpy";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      output Modelica.SIunits.Density d_l "Density";
      output Modelica.SIunits.SpecificEnthalpy h_l "Specific enthalpy";
      output Modelica.SIunits.AbsolutePressure p_l "Pressure";
      output Modelica.SIunits.SpecificEntropy s_l "Specific entropy";
      output Modelica.SIunits.Temperature T_l "Temperature";
      output Modelica.SIunits.MassFraction[size(xi, 1)] xi_l "Mass fractions";
      output Modelica.SIunits.Density d_v "Density";
      output Modelica.SIunits.SpecificEnthalpy h_v "Specific enthalpy";
      output Modelica.SIunits.AbsolutePressure p_v "Pressure";
      output Modelica.SIunits.SpecificEntropy s_v "Specific entropy";
      output Modelica.SIunits.Temperature T_v "Temperature";
      output Modelica.SIunits.MassFraction[size(xi, 1)] xi_v "Mass fractions";
    external"C" TILMedia_VLEFluid_VLEProperties_phxi(
              p,
              h,
              xi,
              vleFluidPointer,
              d_l,
              h_l,
              p_l,
              s_l,
              T_l,
              xi_l,
              d_v,
              h_v,
              p_v,
              s_v,
              T_v,
              xi_v) annotation (
        __iti_dllNoExport=true,
        Include="void TILMedia_VLEFluid_VLEProperties_phxi(double, double, double*, void*, double*, double*, double*, double*, double*, double*,
		double*, double*, double*, double*, double*, double*);",
        Library="TILMedia121ClaRa");
      annotation (Impure=false, deXrivative=der_VLEProperties_phxi);
      end VLEProperties_phxi;

function molarMass_nc
      input Integer nc "Number of components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      output SI.MolarMass mm_i[nc] "Molar mass";
    external"C" TILMedia_VLEFluid_Cached_molarMass(vleFluidPointer, mm_i)
        annotation (
        __iti_dllNoExport=true,
        Include="void TILMedia_VLEFluid_Cached_molarMass(void*,double*);",
        Library="TILMedia121ClaRa");
      annotation (Impure=false);
      end molarMass_nc;

function specificEnthalpy_pTxi
      input SI.AbsolutePressure p "Pressure";
      input SI.Temperature T "Temperature";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      output SI.SpecificEnthalpy h "Specific Enthalpy";
    external"C" h = TILMedia_VLEFluid_Cached_specificEnthalpy_pTxi(
              p,
              T,
              xi,
              vleFluidPointer) annotation (
        __iti_dllNoExport=true,
        Include=
            "double TILMedia_VLEFluid_Cached_specificEnthalpy_pTxi(double, double, double*, void*);",

        Library="TILMedia121ClaRa");
      annotation (
        derivative=der_specificEnthalpy_pTxi,
        inverse(T=temperature_phxi(
                    p,
                    h,
                    xi,
                    vleFluidPointer)),
        Impure=false);
      end specificEnthalpy_pTxi;

function density_pTxi
      input SI.AbsolutePressure p "Pressure";
      input SI.Temperature T "Temperature";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      output SI.Density d "Density";
    external"C" d = TILMedia_VLEFluid_Cached_density_pTxi(
              p,
              T,
              xi,
              vleFluidPointer) annotation (
        __iti_dllNoExport=true,
        Include=
            "double TILMedia_VLEFluid_Cached_density_pTxi(double, double, double*, void*);",

        Library="TILMedia121ClaRa");
      annotation (derivative=der_density_pTxi);
      end density_pTxi;

function specificEntropy_pTxi
      input SI.AbsolutePressure p "Pressure";
      input SI.Temperature T "Temperature";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      output SI.SpecificEntropy s "Specific Entropy";
    external"C" s = TILMedia_VLEFluid_Cached_specificEntropy_pTxi(
              p,
              T,
              xi,
              vleFluidPointer) annotation (
        __iti_dllNoExport=true,
        Include=
            "double TILMedia_VLEFluid_Cached_specificEntropy_pTxi(double, double, double*, void*);",

        Library="TILMedia121ClaRa");
      annotation (
        derivative=der_specificEntropy_pTxi,
        inverse(T=temperature_psxi(
                    p,
                    s,
                    xi,
                    vleFluidPointer)),
        Impure=false);
      end specificEntropy_pTxi;

function density_phxi
      input SI.AbsolutePressure p "Pressure";
      input SI.SpecificEnthalpy h "Specific Enthalpy";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      output SI.Density d "Density";
    external"C" d = TILMedia_VLEFluid_Cached_density_phxi(
              p,
              h,
              xi,
              vleFluidPointer) annotation (
        __iti_dllNoExport=true,
        Include=
            "double TILMedia_VLEFluid_Cached_density_phxi(double, double, double*, void*);",

        Library="TILMedia121ClaRa");
      annotation (derivative=der_density_phxi, Impure=false);
      end density_phxi;

function specificEntropy_phxi
      input SI.AbsolutePressure p "Pressure";
      input SI.SpecificEnthalpy h "Specific Enthalpy";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      output SI.SpecificEntropy s "Specific Entropy";
    external"C" s = TILMedia_VLEFluid_Cached_specificEntropy_phxi(
              p,
              h,
              xi,
              vleFluidPointer) annotation (
        __iti_dllNoExport=true,
        Include=
            "double TILMedia_VLEFluid_Cached_specificEntropy_phxi(double, double, double*, void*);",

        Library="TILMedia121ClaRa");
      annotation (
        derivative=der_specificEntropy_phxi,
        inverse(h=specificEnthalpy_psxi(
                    p,
                    s,
                    xi,
                    vleFluidPointer)),
        Impure=false);
      end specificEntropy_phxi;

function temperature_phxi
      input SI.AbsolutePressure p "Pressure";
      input SI.SpecificEnthalpy h "Specific Enthalpy";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      output SI.Temperature T "Temperature";
    external"C" T = TILMedia_VLEFluid_Cached_temperature_phxi(
              p,
              h,
              xi,
              vleFluidPointer) annotation (
        __iti_dllNoExport=true,
        Include=
            "double TILMedia_VLEFluid_Cached_temperature_phxi(double, double, double*, void*);",

        Library="TILMedia121ClaRa");
      annotation (
        derivative=der_temperature_phxi,
        inverse(h=specificEnthalpy_pTxi(
                    p,
                    T,
                    xi,
                    vleFluidPointer)),
        Impure=false);
      end temperature_phxi;

function specificEnthalpy_psxi
      input SI.AbsolutePressure p "Pressure";
      input SI.SpecificEntropy s "Specific Entropy";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      output SI.SpecificEnthalpy h "Specific Enthalpy";
    external"C" h = TILMedia_VLEFluid_Cached_specificEnthalpy_psxi(
              p,
              s,
              xi,
              vleFluidPointer) annotation (
        __iti_dllNoExport=true,
        Include=
            "double TILMedia_VLEFluid_Cached_specificEnthalpy_psxi(double, double, double*, void*);",

        Library="TILMedia121ClaRa");
      annotation (
        derivative=der_specificEnthalpy_psxi,
        inverse(s=specificEntropy_phxi(
                    p,
                    h,
                    xi,
                    vleFluidPointer)),
        Impure=false);
      end specificEnthalpy_psxi;

function temperature_psxi
      input SI.AbsolutePressure p "Pressure";
      input SI.SpecificEntropy s "Specific Entropy";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      output SI.Temperature T "Temperature";
    external"C" T = TILMedia_VLEFluid_Cached_temperature_psxi(
              p,
              s,
              xi,
              vleFluidPointer) annotation (
        __iti_dllNoExport=true,
        Include=
            "double TILMedia_VLEFluid_Cached_temperature_psxi(double, double, double*, void*);",

        Library="TILMedia121ClaRa");
      annotation (
        derivative=der_temperature_psxi,
        inverse(s=specificEntropy_pTxi(
                    p,
                    T,
                    xi,
                    vleFluidPointer)),
        Impure=false);
      end temperature_psxi;

function der_specificEnthalpy_pTxi
      input SI.AbsolutePressure p "Pressure";
      input SI.Temperature T "Temperature";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      input Real der_p "Derivative of Pressure";
      input Real der_T "Derivative of Temperature";
      input Real[:] der_xi
        "Derivative of Mass fractions of the first nc-1 components";
      output Real der_h "Derivative of Specific Enthalpy";
    external"C" der_h = TILMedia_VLEFluid_Cached_der_specificEnthalpy_pTxi(
              p,
              T,
              xi,
              der_p,
              der_T,
              der_xi,
              vleFluidPointer) annotation (
        __iti_dllNoExport=true,
        Include=
            "double TILMedia_VLEFluid_Cached_der_specificEnthalpy_pTxi(double, double, double*, double, double, double*, void*);",

        Library="TILMedia121ClaRa");
      annotation (Impure=false);
      end der_specificEnthalpy_pTxi;

function der_density_pTxi
      input SI.AbsolutePressure p "Pressure";
      input SI.Temperature T "Temperature";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      input Real der_p "Derivative of Pressure";
      input Real der_T "Derivative of Temperature";
      input Real[:] der_xi
        "Derivative of Mass fractions of the first nc-1 components";
      output Real der_d "Derivative of Density";
    external"C" der_d = TILMedia_VLEFluid_Cached_der_density_pTxi(
              p,
              T,
              xi,
              der_p,
              der_T,
              der_xi,
              vleFluidPointer) annotation (
        __iti_dllNoExport=true,
        Include=
            "double TILMedia_VLEFluid_Cached_der_density_pTxi(double, double, double*, double, double, double*, void*);",

        Library="TILMedia121ClaRa");
      annotation (Impure=false);
      end der_density_pTxi;

function der_specificEntropy_pTxi
      input SI.AbsolutePressure p "Pressure";
      input SI.Temperature T "Temperature";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      input Real der_p "Derivative of Pressure";
      input Real der_T "Derivative of Temperature";
      input Real[:] der_xi
        "Derivative of Mass fractions of the first nc-1 components";
      output Real der_s "Derivative of Specific Entropy";
    external"C" der_s = TILMedia_VLEFluid_Cached_der_specificEntropy_pTxi(
              p,
              T,
              xi,
              der_p,
              der_T,
              der_xi,
              vleFluidPointer) annotation (
        __iti_dllNoExport=true,
        Include=
            "double TILMedia_VLEFluid_Cached_der_specificEntropy_pTxi(double, double, double*, double, double, double*, void*);",

        Library="TILMedia121ClaRa");
      annotation (Impure=false);
      end der_specificEntropy_pTxi;

function der_density_phxi
      input SI.AbsolutePressure p "Pressure";
      input SI.SpecificEnthalpy h "Specific Enthalpy";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      input Real der_p "Derivative of Pressure";
      input Real der_h "Derivative of Specific Enthalpy";
      input Real[:] der_xi
        "Derivative of Mass fractions of the first nc-1 components";
      output Real der_d "Derivative of Density";
    external"C" der_d = TILMedia_VLEFluid_Cached_der_density_phxi(
              p,
              h,
              xi,
              der_p,
              der_h,
              der_xi,
              vleFluidPointer) annotation (
        __iti_dllNoExport=true,
        Include=
            "double TILMedia_VLEFluid_Cached_der_density_phxi(double, double, double*, double, double, double*, void*);",

        Library="TILMedia121ClaRa");
      annotation (Impure=false);
      end der_density_phxi;

function der_specificEntropy_phxi
      input SI.AbsolutePressure p "Pressure";
      input SI.SpecificEnthalpy h "Specific Enthalpy";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      input Real der_p "Derivative of Pressure";
      input Real der_h "Derivative of Specific Enthalpy";
      input Real[:] der_xi
        "Derivative of Mass fractions of the first nc-1 components";
      output Real der_s "Derivative of Specific Entropy";
    external"C" der_s = TILMedia_VLEFluid_Cached_der_specificEntropy_phxi(
              p,
              h,
              xi,
              der_p,
              der_h,
              der_xi,
              vleFluidPointer) annotation (
        __iti_dllNoExport=true,
        Include=
            "double TILMedia_VLEFluid_Cached_der_specificEntropy_phxi(double, double, double*, double, double, double*, void*);",

        Library="TILMedia121ClaRa");
      annotation (Impure=false);
      end der_specificEntropy_phxi;

function der_temperature_phxi
      input SI.AbsolutePressure p "Pressure";
      input SI.SpecificEnthalpy h "Specific Enthalpy";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      input Real der_p "Derivative of Pressure";
      input Real der_h "Derivative of Specific Enthalpy";
      input Real[:] der_xi
        "Derivative of Mass fractions of the first nc-1 components";
      output Real der_T "Derivative of Temperature";
    external"C" der_T = TILMedia_VLEFluid_Cached_der_temperature_phxi(
              p,
              h,
              xi,
              der_p,
              der_h,
              der_xi,
              vleFluidPointer) annotation (
        __iti_dllNoExport=true,
        Include=
            "double TILMedia_VLEFluid_Cached_der_temperature_phxi(double, double, double*, double, double, double*, void*);",

        Library="TILMedia121ClaRa");
      annotation (Impure=false);
      end der_temperature_phxi;

function der_specificEnthalpy_psxi
      input SI.AbsolutePressure p "Pressure";
      input SI.SpecificEntropy s "Specific Entropy";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      input Real der_p "Derivative of Pressure";
      input Real der_s "Derivative of Specific Entropy";
      input Real[:] der_xi
        "Derivative of Mass fractions of the first nc-1 components";
      output Real der_h "Derivative of Specific Enthalpy";
    external"C" der_h = TILMedia_VLEFluid_Cached_der_specificEnthalpy_psxi(
              p,
              s,
              xi,
              der_p,
              der_s,
              der_xi,
              vleFluidPointer) annotation (
        __iti_dllNoExport=true,
        Include=
            "double TILMedia_VLEFluid_Cached_der_specificEnthalpy_psxi(double, double, double*, double, double, double*, void*);",

        Library="TILMedia121ClaRa");
      annotation (Impure=false);
      end der_specificEnthalpy_psxi;

function der_temperature_psxi
      input SI.AbsolutePressure p "Pressure";
      input SI.SpecificEntropy s "Specific Entropy";
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      input Real der_p "Derivative of Pressure";
      input Real der_s "Derivative of Specific Entropy";
      input Real[:] der_xi
        "Derivative of Mass fractions of the first nc-1 components";
      output Real der_T "Derivative of Temperature";
    external"C" der_T = TILMedia_VLEFluid_Cached_der_temperature_psxi(
              p,
              s,
              xi,
              der_p,
              der_s,
              der_xi,
              vleFluidPointer) annotation (
        __iti_dllNoExport=true,
        Include=
            "double TILMedia_VLEFluid_Cached_der_temperature_psxi(double, double, double*, double, double, double*, void*);",

        Library="TILMedia121ClaRa");
      annotation (Impure=false);
      end der_temperature_psxi;

function cricondenbar_xi
      input Modelica.SIunits.MassFraction[:] xi
        "Mass fractions of the first nc-1 components";
      input TILMedia.VLEFluidObjectFunctions.VLEFluidPointer vleFluidPointer;
      output Real d, h, p, s, T;
    external"C" TILMedia_VLEFluid_cricondenbar_xi(
              xi,
              vleFluidPointer,
              d,
              h,
              p,
              s,
              T) annotation (
        __iti_dllNoExport=true,
        Include=
            "void TILMedia_VLEFluid_cricondenbar_xi(double*, void*, double*, double*, double*, double*, double*);",

        Library="TILMedia121ClaRa");
      annotation (Impure=false);
      end cricondenbar_xi;
    end VLEFluidObjectFunctions;

    package Units "Unit definitions"
extends TILMedia.Internals.ClassTypes.ModelPackage;

type DensityDerPressure = Real (final unit="kg/(N.m)");

type DensityDerSpecificEnthalpy = Real (final unit="kg2/(m3.J)");

type DensityDerMassFraction = Real (final unit="kg/(m3)");
    end Units;

type VLEFluidName "VLE Fluid name"
    extends String;
    annotation (choices(
        choice="TILMedia.CO2",
        choice="TILMedia.GERGCO2",
        choice="TILMedia.SPANCO2",
        choice="TILMedia.R134A",
        choice="TILMedia.ASTINASATOR134A",
        choice="TILMedia.R113",
        choice="TILMedia.R116",
        choice="TILMedia.R12",
        choice="TILMedia.R1234YF",
        choice="TILMedia.R1234ZEZ",
        choice="TILMedia.R1234ZE",
        choice="TILMedia.R124",
        choice="TILMedia.R125",
        choice="TILMedia.R141B",
        choice="TILMedia.R142B",
        choice="TILMedia.R143A",
        choice="TILMedia.R161",
        choice="TILMedia.R218",
        choice="TILMedia.R227EA",
        choice="TILMedia.R23",
        choice="TILMedia.R245FA",
        choice="TILMedia.R32",
        choice="TILMedia.R365MFC",
        choice="TILMedia.R404APPF",
        choice="TILMedia.R407CPPF",
        choice="TILMedia.R410APPF",
        choice="TILMedia.R507APPF",
        choice="TILMedia.RC318",
        choice="TILMedia.AMMONIA",
        choice="TILMedia.ARGON",
        choice="TILMedia.1-BUTENE",
        choice="TILMedia.CARBONDIOXIDE",
        choice="TILMedia.CARBONYLSULFIDE",
        choice="TILMedia.D4",
        choice="TILMedia.D5",
        choice="TILMedia.DEUTERIUM",
        choice="TILMedia.DIMETHYLCARBONATE",
        choice="TILMedia.DIMETHYLETHER",
        choice="TILMedia.ETHANE",
        choice="TILMedia.ETHANOL",
        choice="TILMedia.ETHYLBENZENE",
        choice="TILMedia.ETHYLENE",
        choice="TILMedia.HEAVYWATER",
        choice="TILMedia.HELIUM",
        choice="TILMedia.HYDROGENSULFIDE",
        choice="TILMedia.ISOBUTANE",
        choice="TILMedia.ISOPENTANE",
        choice="TILMedia.KRYPTON",
        choice="TILMedia.MD4M",
        choice="TILMedia.METHANE",
        choice="TILMedia.METHYLLINOLEATE",
        choice="TILMedia.METHYLOLEATE",
        choice="TILMedia.METHYLPALMITATE",
        choice="TILMedia.METHYLSTEARATE",
        choice="TILMedia.N-BUTANE",
        choice="TILMedia.N-DODECANE",
        choice="TILMedia.N-NONANE",
        choice="TILMedia.N-PROPANE",
        choice="TILMedia.NEON",
        choice="TILMedia.NEOPENTANE",
        choice="TILMedia.NITROGEN",
        choice="TILMedia.NITROUSOXIDE",
        choice="TILMedia.OXYGEN",
        choice="TILMedia.PARAHYDROGEN",
        choice="TILMedia.PROPANE",
        choice="TILMedia.PROPYLENE",
        choice="TILMedia.SULFURHEXAFLUORIDE",
        choice="TILMedia.TOLUENE",
        choice="TILMedia.WATER",
        choice="TILMedia.XENON",
        choice="TILMedia.O-XYLENE",
        choice="TILMedia.M-XYLENE",
        choice="TILMedia.P-XYLENE",
        choice="TILMediaRT.CO2",
        choice="TILMediaRT.R1234YF",
        choice="TILMediaRT.R134A",
        choice="TILMediaRT.R407C",
        choice="TILMediaRT.R410A",
        choice="TILMediaRT.WATER",
        choice="Refprop.CO2",
        choice="Refprop.R134A",
        choice="Refprop.1BUTENE.FLD",
        choice="Refprop.ACETONE.FLD",
        choice="Refprop.AIR.MIX",
        choice="Refprop.AIR.PPF",
        choice="Refprop.AMARILLO.MIX",
        choice="Refprop.AMMONIA.FLD",
        choice="Refprop.ARGON.FLD",
        choice="Refprop.BENZENE.FLD",
        choice="Refprop.BUTANE.FLD",
        choice="Refprop.C11.FLD",
        choice="Refprop.C12.FLD",
        choice="Refprop.C1CC6.FLD",
        choice="Refprop.C2BUTENE.FLD",
        choice="Refprop.C3CC6.FLD",
        choice="Refprop.C4F10.FLD",
        choice="Refprop.C5F12.FLD",
        choice="Refprop.CF3I.FLD",
        choice="Refprop.CO.FLD",
        choice="Refprop.CO2.FLD",
        choice="Refprop.COS.FLD",
        choice="Refprop.CYCLOHEX.FLD",
        choice="Refprop.CYCLOPEN.FLD",
        choice="Refprop.CYCLOPRO.FLD",
        choice="Refprop.D2.FLD",
        choice="Refprop.D2O.FLD",
        choice="Refprop.D4.FLD",
        choice="Refprop.D5.FLD",
        choice="Refprop.D6.FLD",
        choice="Refprop.DECANE.FLD",
        choice="Refprop.DEE.FLD",
        choice="Refprop.DMC.FLD",
        choice="Refprop.DME.FLD",
        choice="Refprop.EBENZENE.FLD",
        choice="Refprop.EKOFISK.MIX",
        choice="Refprop.ETHANE.FLD",
        choice="Refprop.ETHANOL.FLD",
        choice="Refprop.ETHYLENE.FLD",
        choice="Refprop.FLUORINE.FLD",
        choice="Refprop.GLFCOAST.MIX",
        choice="Refprop.H2S.FLD",
        choice="Refprop.HCL.FLD",
        choice="Refprop.HELIUM.FLD",
        choice="Refprop.HEPTANE.FLD",
        choice="Refprop.HEXANE.FLD",
        choice="Refprop.HIGHCO2.MIX",
        choice="Refprop.HIGHN2.MIX",
        choice="Refprop.HYDROGEN.FLD",
        choice="Refprop.IBUTENE.FLD",
        choice="Refprop.IHEXANE.FLD",
        choice="Refprop.IOCTANE.FLD",
        choice="Refprop.IPENTANE.FLD",
        choice="Refprop.ISOBUTAN.FLD",
        choice="Refprop.KRYPTON.FLD",
        choice="Refprop.MD2M.FLD",
        choice="Refprop.MD3M.FLD",
        choice="Refprop.MD4M.FLD",
        choice="Refprop.MDM.FLD",
        choice="Refprop.METHANE.FLD",
        choice="Refprop.METHANOL.FLD",
        choice="Refprop.MLINOLEA.FLD",
        choice="Refprop.MLINOLEN.FLD",
        choice="Refprop.MM.FLD",
        choice="Refprop.MOLEATE.FLD",
        choice="Refprop.MPALMITA.FLD",
        choice="Refprop.MSTEARAT.FLD",
        choice="Refprop.MXYLENE.FLD",
        choice="Refprop.N2O.FLD",
        choice="Refprop.NEON.FLD",
        choice="Refprop.NEOPENTN.FLD",
        choice="Refprop.NF3.FLD",
        choice="Refprop.NGSAMPLE.MIX",
        choice="Refprop.NITROGEN.FLD",
        choice="Refprop.NONANE.FLD",
        choice="Refprop.Novec 7000.FLD",
        choice="Refprop.NOVEC649.FLD",
        choice="Refprop.OCTANE.FLD",
        choice="Refprop.ORTHOHYD.FLD",
        choice="Refprop.OXYGEN.FLD",
        choice="Refprop.OXYLENE.FLD",
        choice="Refprop.PARAHYD.FLD",
        choice="Refprop.PENTANE.FLD",
        choice="Refprop.PROPANE.FLD",
        choice="Refprop.PROPYLEN.FLD",
        choice="Refprop.PROPYNE.FLD",
        choice="Refprop.PXYLENE.FLD",
        choice="Refprop.R11.FLD",
        choice="Refprop.R113.FLD",
        choice="Refprop.R114.FLD",
        choice="Refprop.R115.FLD",
        choice="Refprop.R116.FLD",
        choice="Refprop.R12.FLD",
        choice="Refprop.R1216.FLD",
        choice="Refprop.R123.FLD",
        choice="Refprop.R1233ZD.FLD",
        choice="Refprop.R1234YF.FLD",
        choice="Refprop.R1234ZE.FLD",
        choice="Refprop.R124.FLD",
        choice="Refprop.R125.FLD",
        choice="Refprop.R13.FLD",
        choice="Refprop.R134A.FLD",
        choice="Refprop.R14.FLD",
        choice="Refprop.R141B.FLD",
        choice="Refprop.R142B.FLD",
        choice="Refprop.R143A.FLD",
        choice="Refprop.R152A.FLD",
        choice="Refprop.R161.FLD",
        choice="Refprop.R21.FLD",
        choice="Refprop.R218.FLD",
        choice="Refprop.R22.FLD",
        choice="Refprop.R227EA.FLD",
        choice="Refprop.R23.FLD",
        choice="Refprop.R236EA.FLD",
        choice="Refprop.R236FA.FLD",
        choice="Refprop.R245CA.FLD",
        choice="Refprop.R245FA.FLD",
        choice="Refprop.R32.FLD",
        choice="Refprop.R365MFC.FLD",
        choice="Refprop.R40.FLD",
        choice="Refprop.R401A.MIX",
        choice="Refprop.R401B.MIX",
        choice="Refprop.R401C.MIX",
        choice="Refprop.R402A.MIX",
        choice="Refprop.R402B.MIX",
        choice="Refprop.R403A.MIX",
        choice="Refprop.R403B.MIX",
        choice="Refprop.R404A.MIX",
        choice="Refprop.R404A.PPF",
        choice="Refprop.R405A.MIX",
        choice="Refprop.R406A.MIX",
        choice="Refprop.R407A.MIX",
        choice="Refprop.R407B.MIX",
        choice="Refprop.R407C.MIX",
        choice="Refprop.R407C.PPF",
        choice="Refprop.R407D.MIX",
        choice="Refprop.R407E.MIX",
        choice="Refprop.R407F.MIX",
        choice="Refprop.R408A.MIX",
        choice="Refprop.R409A.MIX",
        choice="Refprop.R409B.MIX",
        choice="Refprop.R41.FLD",
        choice="Refprop.R410A.MIX",
        choice="Refprop.R410A.PPF",
        choice="Refprop.R410B.MIX",
        choice="Refprop.R411A.MIX",
        choice="Refprop.R411B.MIX",
        choice="Refprop.R412A.MIX",
        choice="Refprop.R413A.MIX",
        choice="Refprop.R414A.MIX",
        choice="Refprop.R414B.MIX",
        choice="Refprop.R415A.MIX",
        choice="Refprop.R415B.MIX",
        choice="Refprop.R416A.MIX",
        choice="Refprop.R417A.MIX",
        choice="Refprop.R418A.MIX",
        choice="Refprop.R419A.MIX",
        choice="Refprop.R420A.MIX",
        choice="Refprop.R421A.MIX",
        choice="Refprop.R421B.MIX",
        choice="Refprop.R422A.MIX",
        choice="Refprop.R422B.MIX",
        choice="Refprop.R422C.MIX",
        choice="Refprop.R422D.MIX",
        choice="Refprop.R423A.MIX",
        choice="Refprop.R424A.MIX",
        choice="Refprop.R425A.MIX",
        choice="Refprop.R426A.MIX",
        choice="Refprop.R427A.MIX",
        choice="Refprop.R428A.MIX",
        choice="Refprop.R429A.MIX",
        choice="Refprop.R430A.MIX",
        choice="Refprop.R431A.MIX",
        choice="Refprop.R432A.MIX",
        choice="Refprop.R433A.MIX",
        choice="Refprop.R434A.MIX",
        choice="Refprop.R435A.MIX",
        choice="Refprop.R436A.MIX",
        choice="Refprop.R436B.MIX",
        choice="Refprop.R437A.MIX",
        choice="Refprop.R438A.MIX",
        choice="Refprop.R441A.MIX",
        choice="Refprop.R442A.MIX",
        choice="Refprop.R443A.MIX",
        choice="Refprop.R444A.MIX",
        choice="Refprop.R500.MIX",
        choice="Refprop.R501.MIX",
        choice="Refprop.R502.MIX",
        choice="Refprop.R503.MIX",
        choice="Refprop.R504.MIX",
        choice="Refprop.R507A.MIX",
        choice="Refprop.R507A.PPF",
        choice="Refprop.R508A.MIX",
        choice="Refprop.R508B.MIX",
        choice="Refprop.R509A.MIX",
        choice="Refprop.R510A.MIX",
        choice="Refprop.R512A.MIX",
        choice="Refprop.RC318.FLD",
        choice="Refprop.RE143A.FLD",
        choice="Refprop.RE245CB2.FLD",
        choice="Refprop.RE245FA2.FLD",
        choice="Refprop.RE347MCC.FLD",
        choice="Refprop.SF6.FLD",
        choice="Refprop.SO2.FLD",
        choice="Refprop.T2BUTENE.FLD",
        choice="Refprop.TOLUENE.FLD",
        choice="Refprop.WATER.FLD",
        choice="Refprop.XENON.FLD"));
    end VLEFluidName;

record CriticalDataRecord "Critical data record"
    extends TILMedia.Internals.ClassTypes.Record;

    Modelica.SIunits.Density d "Critical density";
    Modelica.SIunits.SpecificEnthalpy h "Critical specific enthalpy";
    Modelica.SIunits.AbsolutePressure p "Critical pressure";
    Modelica.SIunits.SpecificEntropy s "Critical specific entropy";
    Modelica.SIunits.Temperature T "Critical temperature";
    annotation (defaultComponentName="crit");
    end CriticalDataRecord;

record PropertyRecord "Property record"
    extends TILMedia.Internals.ClassTypes.Record;
    SI.Density d "Density";
    SI.SpecificEnthalpy h "Specific enthalpy";
    SI.AbsolutePressure p "Pressure";
    SI.SpecificEntropy s "Specific entropy";
    SI.Temperature T "Temperature";
    SI.MassFraction q=0 "Steam mass fraction (quality)";
    SI.SpecificHeatCapacity cp=0 "Specific isobaric heat capacity cp";

    TILMedia.Internals.CriticalDataRecord crit=
        TILMedia.Internals.CriticalDataRecord(
            d=0.0,
            T=0.0,
            p=0.0,
            h=0.0,
            s=0.0) "Critical data record";
    TILMedia.Internals.VLERecordSimple VLE=TILMedia.Internals.VLERecordSimple(
            d_l=0.0,
            h_l=0.0,
            p_l=0.0,
            s_l=0.0,
            T_l=0.0,
            d_v=0.0,
            h_v=0.0,
            p_v=0.0,
            s_v=0.0,
            T_v=0.0) "Saturation property record";
    TILMedia.Internals.VLETransportPropertyRecord VLETransp=
        TILMedia.Internals.VLETransportPropertyRecord(
            Pr_l=0.0,
            Pr_v=0.0,
            eta_l=0.0,
            eta_v=0.0,
            lambda_l=0.0,
            lambda_v=0.0) "Saturation property record";
    TILMedia.Internals.TransportPropertyRecord transp=
        TILMedia.Internals.TransportPropertyRecord(
            Pr=0.0,
            lambda=0.0,
            eta=0.0,
            sigma=0.0) "Transport property record";

    annotation (defaultComponentName="properties");
    end PropertyRecord;

record VLERecord "VLE property record"
    extends TILMedia.Internals.ClassTypes.Record;
    SI.Density d_l "Density of liquid phase";
    SI.Density d_v "Density of vapour phase";
    SI.SpecificEnthalpy h_l "Specific enthalpy of liquid phase";
    SI.SpecificEnthalpy h_v "Specific enthalpy of vapour phase";
    SI.AbsolutePressure p_l "Pressure of liquid phase";
    SI.AbsolutePressure p_v "Pressure of vapour phase";
    SI.SpecificEntropy s_l "Specific entropy of liquid phase";
    SI.SpecificEntropy s_v "Specific entropy of vapour phase";
    SI.Temperature T_l "Temperature of liquid phase";
    SI.Temperature T_v "Temperature of vapour phase";
    SI.MassFraction[nc - 1] xi_l "Mass fraction of liquid phase";
    SI.MassFraction[nc - 1] xi_v "Mass fraction of vapour phase";
    parameter Integer nc;
    end VLERecord;

record VLERecordSimple "VLE property record"
    extends TILMedia.Internals.ClassTypes.Record;
    SI.Density d_l "Density of liquid phase";
    SI.Density d_v "Density of vapour phase";
    SI.SpecificEnthalpy h_l "Specific enthalpy of liquid phase";
    SI.SpecificEnthalpy h_v "Specific enthalpy of vapour phase";
    SI.AbsolutePressure p_l "Pressure of liquid phase";
    SI.AbsolutePressure p_v "Pressure of vapour phase";
    SI.SpecificEntropy s_l "Specific entropy of liquid phase";
    SI.SpecificEntropy s_v "Specific entropy of vapour phase";
    SI.Temperature T_l "Temperature of liquid phase";
    SI.Temperature T_v "Temperature of vapour phase";
    end VLERecordSimple;

record AdditionalVLERecord "Additional VLE property record"
    extends TILMedia.Internals.ClassTypes.Record;
    Modelica.SIunits.SpecificHeatCapacity cp_l
      "Specific heat capacity cp of liquid phase";
    Modelica.SIunits.SpecificHeatCapacity cp_v
      "Specific heat capacity cp of vapour phase";
    Modelica.SIunits.LinearExpansionCoefficient beta_l
      "Isobaric expansion coefficient of liquid phase";
    Modelica.SIunits.LinearExpansionCoefficient beta_v
      "Isobaric expansion coefficient of vapour phase";
    Modelica.SIunits.Compressibility kappa_l
      "Isothermal compressibility of liquid phase";
    Modelica.SIunits.Compressibility kappa_v
      "Isothermal compressibility of vapour phase";
    end AdditionalVLERecord;

record VLETransportPropertyRecord "Transport property record"
    extends TILMedia.Internals.ClassTypes.Record;
    SI.PrandtlNumber Pr_l "Prandtl number of liquid phase";
    SI.PrandtlNumber Pr_v "Prandtl number of vapour phase";
    SI.ThermalConductivity lambda_l "Thermal conductivity of liquid phase";
    SI.ThermalConductivity lambda_v "Thermal conductivity of vapour phase";
    SI.DynamicViscosity eta_l(min=-1) "Dynamic viscosity of liquid phase";
    SI.DynamicViscosity eta_v(min=-1) "Dynamic viscosity of vapour phase";

    annotation (defaultComponentName="transp");
    end VLETransportPropertyRecord;

record TransportPropertyRecord "Transport property record"
    extends TILMedia.Internals.ClassTypes.Record;
    Modelica.SIunits.PrandtlNumber Pr "Prandtl number";
    Modelica.SIunits.ThermalConductivity lambda "Thermal conductivity";
    Modelica.SIunits.DynamicViscosity eta(min=-1) "Dynamic viscosity";
    Modelica.SIunits.SurfaceTension sigma "Surface tension";
    annotation (defaultComponentName="transp");
    end TransportPropertyRecord;

function calcComputeFlags
    input Boolean computeTransportProperties;
    input Boolean interpolateTransportProperties;
    input Boolean computeSurfaceTension;
    input Boolean deactivateTwoPhaseRegion;
    output Integer flags;
    algorithm
    flags := array(
          1,
          2,
          4,
          8)*array(
          if (computeTransportProperties) then 1 else 0,
          if (interpolateTransportProperties) then 1 else 0,
          if (computeSurfaceTension) then 1 else 0,
          if (deactivateTwoPhaseRegion) then 1 else 0);
    //  flags := 0;
    /*  if computeTransportProperties then
    flags := flags + 1;
  end if;
  if interpolateTransportProperties then
    flags := flags + 2;
  end if;
  if computeSurfaceTension then
    flags := flags + 4;
  end if;*/

    annotation (Inline=true);
    end calcComputeFlags;

function redirectModelicaFormatMessage
    input Real y=0;
    //protected
    output Integer x;
  external"C" x = TILMedia_redirectModelicaFormatMessage_wrapper() annotation (
      __iti_dllNoExport=true,
      Library="TILMedia121ClaRa",
      Include="
#ifndef TILMEDIAMODELICAFORMATMESSAGE
#define TILMEDIAMODELICAFORMATMESSAGE
#if defined(DYMOLA_STATIC) || (defined(ITI_CRT_INCLUDE) && !defined(ITI_COMP_SIM))
int TILMedia_redirectModelicaFormatMessage(void* _str);
int TILMedia_redirectModelicaFormatError(void* _str);
int TILMedia_redirectDymolaErrorFunction(void* _str);
#if defined(DYMOLA_STATIC)
#ifndef _WIN32
#define __stdcall
#endif
double __stdcall TILMedia_DymosimErrorLevWrapper(const char* message, int level) {
    return DymosimErrorLev(message, level);
}
#endif
int TILMedia_redirectModelicaFormatMessage_wrapper(void) {
    TILMedia_redirectModelicaFormatMessage((void*)ModelicaFormatMessage);
    TILMedia_redirectModelicaFormatError((void*)ModelicaFormatError);
#if defined(DYMOLA_STATIC)
    TILMedia_redirectDymolaErrorFunction((void*)TILMedia_DymosimErrorLevWrapper);
#endif
    return 0;
}
#endif
#endif
");
    end redirectModelicaFormatMessage;

function concatNames
    input String names[:];
    output String concatName;
    algorithm
    concatName := "";
    if (size(names, 1) > 0) then
      concatName := names[1];
    end if;

    for i in 2:size(names, 1) loop
      concatName := concatName + "|" + names[i];
    end for;
    end concatNames;

function getPropertiesVLE
    input Real d, h, p, s, T, cp, q;
    input Real d_crit, h_crit, p_crit, s_crit, T_crit;
    input Real d_l, h_l, p_l, s_l, T_l, d_v, h_v, p_v, s_v, T_v;
    input Real Pr, lambda, eta, sigma;
    input Real Pr_l, Pr_v, lambda_l, lambda_v, eta_l, eta_v;
    output TILMedia.Internals.PropertyRecord properties;
    algorithm
    properties.d := d;
    properties.h := h;
    properties.p := p;
    properties.s := s;
    properties.T := T;
    properties.cp := cp;
    properties.q := q;
    properties.VLE := TILMedia.Internals.VLERecordSimple(
          d_l=d_l,
          h_l=h_l,
          p_l=p_l,
          s_l=s_l,
          T_l=T_l,
          d_v=d_v,
          h_v=h_v,
          p_v=p_v,
          s_v=s_v,
          T_v=T_v);
    properties.VLETransp := TILMedia.Internals.VLETransportPropertyRecord(
          Pr_l=Pr_l,
          Pr_v=Pr_v,
          lambda_l=lambda_l,
          lambda_v=lambda_v,
          eta_l=eta_l,
          eta_v=eta_v);
    properties.transp := TILMedia.Internals.TransportPropertyRecord(
          Pr=Pr,
          lambda=lambda,
          eta=eta,
          sigma=sigma);
    properties.crit := TILMedia.Internals.CriticalDataRecord(
          d=d_crit,
          h=h_crit,
          p=p_crit,
          s=s_crit,
          T=T_crit);
    end getPropertiesVLE;
annotation (Icon(graphics={Rectangle(
            extent={{-100,-100},{80,50}},
            lineColor={85,170,255},
            fillColor={255,255,255},
            fillPattern=FillPattern.Solid),Polygon(
            points={{-100,50},{-80,70},{100,70},{80,50},{-100,50}},
            lineColor={85,170,255},
            fillColor={255,255,255},
            fillPattern=FillPattern.Solid),Polygon(
            points={{100,70},{100,-80},{80,-100},{80,50},{100,70}},
            lineColor={85,170,255},
            fillColor={255,255,255},
            fillPattern=FillPattern.Solid)}));
  end Internals;
annotation (
  preferedView="info",
  version="1.2.1 ClaRa",
  uses(Modelica(version="3.2.2")),
  Documentation(info="<html>
<br>
<img src=\"modelica://TILMedia/Images/infoTILMedia.png\" ><br>
<br>
  <hr>
</html>"),
  Icon(coordinateSystem(
      preserveAspectRatio=true,
      extent={{-100,-100},{100,100}},
      grid={1,1}), graphics={Text(
        extent={{-120,143},{120,94}},
        lineColor={255,0,0},
        textString="%name"), Bitmap(
        extent={{-100,-100},{100,100}},
        imageSource=
            "iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAIAAAB7GkOtAAAABnRSTlMA/wD/AP83WBt9AAAgAElEQVR42u3deXCU953n8a+6n+fpS5iWOQQ2RhLYgGMMkq/gZDAtO07imWEtMpPauXaQpuasrVlQ1e7+i/TPbG3VJsI7sZNsxVG7YieeyoGwY+P4gAbsgO2AGkHMEUAtDgsBhhaoJfW9fzxPtxpxSUJSP8/T71dRFGBSaZ5+nt/ndz3fX1k2mxUAQOlxcAkAgAAAABAAAAACAABAAAAACAAAAAEAACAAAAAEAACAAAAAEAAAAAIAAEAAAAAIAAAAAQAAIAAAAAQAAIAAAAAQAAAAAgAAQAAAAAgAAAABAAAgAACAAAAAEAAAAAIAAEAAAAAIAAAAAQAAIAAAAAQAAIAAAAAQAAAAAgAAQAAAAAgAAAABAAAgAAAABAAAgAAAABAAAAACAABAAAAACAAAAAEAACAAAIAAAAAQAAAAAgAAQAAAAAgAAAABAAAgAAAABAAAgAAAABAAAAACAABAAAAACAAAAAEAACAAAAAEAACAAAAAEAAAAAIAAEAAAAAIAAAAAQAAIAAAAAQAABAAAAACAABAAAAACAAAAAEAACAAAAAEAACAAAAAEAAAAAIAAEAAAAAIAAAAAQAAIAAAAAQAAIAAAAAQAAAAAgAAQAAAAAgAAAABAAAgAAAABAAAEAAAAAIAAEAAAAAIAAAAAQAAIAAAAAQAAIAAAAAQAAAAAgAAQAAAAAgAAAABAAAgAAAABAAAgAAAABAAAAACAABAAAAACAAAAAEAACAAAAAEAACAAAAAAgAAQAAAAAgAAAABAAAgAAAABAAAgAAAABAAAAACAABAAAAACAAAAAEAACAAAAAEAACAAAAAEAAAAAIAAEAAAAAIAAAAAQAAIAAAAAQAAIAAAAACAABAAAAACAAAAAEAACAAAAAEAACAAAAAEAAAAAIAAEAAAAAIAAAAAQAAIAAAAAQAAIAAAAAQAAAAAgAAQAAAAAgAAAABAAAgAAAABAAAgAAAABAAAEAAAAAIAAAAAQAAIAAAAAQAAIAAAAAQAAAAAgAAQAAAAAgAAAABAAAgAAAABAAAgAAAABAAAAACAABAAAAACAAAAAEAACAAAAAEAACAAAAAEAAAQAAAAAgAAAABAAAgAAAABAAAgAAAABAAAAACAABAAAAACAAAAAEAACAAAAAEAABgeilcApSai32hm/2n2ZUBrg9KR1k2m+UqoARb/x++WF/45//0X3eQASAAAFvp6Q5FukP90Z5oNNJ/ORKNRkSkTL/7y4y/oz8E+pNQVRMQkarqNW63f978Wv23AAEAWEA0GunpDvV07+zpDvVHI2VlImVSlmvur/95JACu/TkrIlnJZqVyfm1VTaCqes3SBxu4vCAAADO2+wf2B48d2Xr+XFjKxFEmIuJwGD/K9D/J/aznQWEAGD/yv85IJiuZjGRzP+s/ljzYsPTB51fWNXLBQQAAxXegM/jJnhfOnwvrbbrDIU5n7ucycTrF4RSnngSFGVBmTATpjb7kWv98o5/JSDot6YxkMpLJ/yIjmaxkM7KyrnFF3XomiEAAAMXp8u/e3nrsSMdwPKo39PoPRf9ZEWe+3XdIWW4QkO/153+RHwToMrnuvz4OSOsxkJZUWlIp49fptJEEM++qXv30JgYEIACAaW36u8JBvXHXm3tFEVURRRHFKU4lN/lTJg6H0dzfrOm/YQyMTAplJZOVdNoYBKRSkkxKKjWSB5mM3EUMgAAApsG725o/3bM53+6riqiqqKrR9Odne/It/i2a+7EYWRPOGpNCqbSk05JMSjIpyZQkk8aYgBgAAQBMlU9+u3l3qDWRiDqdRqOvqcYvCmd77rzRv0UY5JNAHwHoMZBISDJlDAjuqwo8+1zbvPm1fF8gAIBJcK43/OstTRfOhx0OUVXRNHFpoqmiqMaM/5S2+zdLgsIYSCQkkZBEUlIpSWfk8VUbv/5cG18cCADgTjv+7/2mWXGKooimisslmiaqKqoy5V3+28aAiLFTSB8KxOOSSEoiIamUzJlbu3ZdeyVDARAAwMS82l5/uiekKqJq4tLE5TKmffK7+4suHwOptKSSkkjK8LDEE8bawNe+0fbEVzbyPYIAAMahrzf8arA+lYyqqrg0cbtF00RTjQkfMzT9o2LAmBRKSSIh8YQMxyURl2RKlq9sXLuunS8UBAAwJgc6gx+805xKRV0ucbnE4xJNM7b2i5iu9R8VA+m0JJISjxtDgURCZs+t/ft/6eRrBQEA3EZXZ/CtrU16x9/jMaZ9zNnxv1kMZDLGyvCQHgNxUVX/XzfuYEkABABwU29uaTp0IKjP+bjdI62/mTv+N8uAdFoSCRmOy9CwxOPidJIBIACAm7f+nx0Mapq4XUbfX9/qY6GmvzADRIxNosNxGRqS4bg4nf6/Wk8GgAAARrX+HU2fdQVdmrg94nGLyyWK06qt/6ihgL41SM8Ah4MMgFlwJjBMoasz+FlX0OUSr1d8HvG4Ldz3v6aHVSYOh2iqeNzi9YrbJZlM9Kev1Pf1hvnSQQAA0tUZ3PZmk8slXo8x86Mo15Rvs0EGqKq43eL1isctmUz0ra1NfO8gAFDq+s6Ft7/X7NJyrb9mq9b/mgxQxO0Wj0fcLrn0RfjHP6jj2wcBgJL2y9fXZTNRY94/1/rbT2EGeD3idsuli+H332nmBgABgBL1WrB+eDDiduVWfW3a+t9gHOAWl0v2f7r56JEObgMQACg5n+zZ3Hs25Mrt+NQ3+9tb4XqAPhe07Y2m/miEmwEEAEpIfzSy58NW411fTRSn3eb9b50Bmmq86ZZlQRgEAErN2280ZTNR/V1fvbpnKbT++QxwOnMZ4JLes6FP927mlgABgJLw6d7NvWdCbpe4XaKVWOt/TQZo4naLS5M9H7ZyV4AAQEnY82Gr5jIqPDudJdf65zNAcYrLxUQQCACUjA9DLdlM1O0yWv+Sld8U5NLEpcmR3wdZDQYBADvrj0Y+/m2r3uTZo9jDHWaA0ylq7qSzbW8wCAABAPv6aGerpopLE7WEJ39GUXKLAb2fh05FQlwQEACwZ/f/yGdB/VR3xcn1MAYB+kSQpoqmyv5PX+CagACADR06ENQ00bSS2/d52wzITwRFTnSwEgACADZ0oPMFV671x6gMUJyiqqJp8tvdbAkFAQDbdf8zqaiqsvZ780GAKqoqkRNUBwIBAHs5fOgVWv/bDgI0VdLp6KEDQS4ICADYRH800vt5SFNFUZj/uWkAOByiqKKpcvL4Vi4ICADYxPFjHaoiilrSb37d/ml0GCsBkZPMAoEAgF0c+f0rWimV/Jwwp1MURVRFDnUFuRogAGAHl78IK07e/LoNPR31QUA3s0AgAGADx491KLnZfwLgthmgDwI+PxPiaoAAgOWdPb1TVcThZPl3TAHgcIjTKZl09HxfmAsCAgDW1nsmpDjFyb025gxQnKIocuYUgwAQALC4S5fCevef+Z+xDwIURb64cICrAQIAFna6J6TQ+o8/AJxOufwFU0AgAGBlV69EnOz/mVAGXCIAQADABgHgoPWf0CDgAuvAIABgXb1nd+rzP4wAxhsADofE41GuBggAWPYOK2MBYILXzemUixcYAYAAgGXFBiJ0/ycwAtAHAQlGACAAYOEAiEUcBMBEM4DrBgIAFm/IuMsmeukGrvZwHUAAwLJ3WJnQi51gAIhcvRrhOoAAgIWbMeYxJtb9lzK2z4IAgNUbMiEDJn7pAAIA1h0AYIKtfxkZAAIAKNnwdLn8XAYQAEApunvOSi4CCABYlUYf9k5kuQQgAGBZFbNquQgTafmzIlnJEgAgAIDS7P3PvzfAdQABAKu6e1Ztlp7shEYAXDQQALA2X3kV7diEhwD3LGAEAAIA1h0BzK7NZrgME+Etr+YigACAhc2/N5AVZjPG3/vPiv9u1s9BAMDqPVlfNQEw3tY/m5WKu3kJAAQAbiIajbzxq6Y3ftVk8s85tzJAAEwgA+bND5j8Q/77d2oOdAb5sggATLdd21tefqnu4IHglf6I2QNg/hr2tIxXJiPzzL0HtO9c+MqVyK+3NP3kx/U93SG+MitSuASWc6AzuHtH69UrEYdDNFUGTF8yft49gQyt/zhb/zmVZu/+x4ejqiIicvZ06NVgaMXKxtVPb/L7q/n6CABMiXO94fffaT4VCTmd4nKJqkiZQ+LDZg+A8hnVHm91KhGhtuUYZbNy78LnTf4hz5wOedxSVibpjCQTcqgreOxox+Nf3vDU0y18g1bBFJBlvPmrppd/UHfmVMjlEo9HfF4p94nPIy6XnD5l9gH4vQsbmAIae+ufzcp91Q0m/5ypZL/HIz6flPvE6xWPW9Kp6Ee7Wr/33Zqjhzv4HhkBYHLs2t7y6d4XEomoSxVVE00Vl0s0TRRFMhnJiiTiUZP/ExY9sP7k0c0OBwXux+Quf235jGqTf8hLX4RVVTRNJCuKIqoqSlwSCYkNRH75+rr7qgLPPtc2bz47WRkBYKKOHu743ndrPtrVmk5H3W7xeKQ81+Fyu0RTRXGK0yEXz4dN/g+5e1atx1fNFzoWmYxUL15v/s956WJYcYqqiKaJxy1er5SXi88nHo9ompw9HXr5B3Vvmn6LGgEAM4pGIz/5cf0vX18XG4i4NPHqTX+5eD3idouqiN6bLiuTMof0nt1p/n/RAw9uyPBK8O1ks5LJyIIqs8//XOmPpFPRMoeUlYnDIYoiLk08bmNGyOcVt1s0VQ51Bb/zbxWf/HYz3ywBgLF6d1vzi201Z0+HNE08HvH6xJebZtU0cTolP5eiP34x028EEpEFCxvYDDoW8xc0mH/+50p/JN8Fyd+HqipuV8E41SNut6TT0Q/ebf7ed2vYKmpCrAGYyye/3bw71JpIRDVVVFVcmjHdryrXtPt5+hMYi1kgAMpnVC9c1Hi2J8i3fAuZjCz50gbzf86zp0MOhzjKrrkVRUTfmqw4jVWBRELiuYWB14L191UF1n6rna2ijAAwWk936Hvfrfng3eZUKup25+Z8fOLxiNslqio3XEHVe14Oh5w4ZoF9F0uYBbqlbFbu8tdWmv4FYBH5/MzOwhHAqBvS6RxZGPD5xOszBq9nT4debKt5d1sz3zUBAEM0Gvn5T9e9FqzPT/frWzy9uYnUGz5pI19hmTgdcuFC2Pz/0opZtbPnUhbiVgFw/7INlviol74I6z2PGypcGNDvZ1/B/bzv480sDBAAEBHZtb3lxbaa48c6jB6TT8rLxecVj0c09cbTPjd42JzSe2anJf69D67YRADcrPX3eKsXPdBo/o96vi+cSkYdt2s88gsDxh6hgoWBVCr6wbvNP3qpjoWB4mINoGgOdAbf39ZsTPcrornEpYmmjbXdL3zGHA7p/dwaD1Ll/MCsOYFLF0O8EHB9ADz2lXZLfNSzp0KKIrcYARTen5JbGHA6RFFEVSSeEMUpyaR8cTH8arB+ydKGZ/+4jYUBRgCloqc79KOX6t7qaEqlosZrvQWvU95suv9W36JDnA453WONDHj8q+0MAq5v/WfNDcydF7DEp9UXAJxjbjzyM0KamnuJvdxYGHCpcvxYx4ttNbu2t3AbEAA2p0/3vxqs/+Ji2OUaWen1+YwXu2493X+z1l9/us6etkYA+MqrFy/dSAaMCoCVj7VZ5dN+fjbkdI77Ri0rE6dTFEX0O99XuD6syke7Wr/zbxUUlyYAbGvX9paXv193/FiHSxW3O1fMxytej2iqKIpMuFKC0yFOp3Sf2GqVS1H7eJvHy5B/pPVfvHRjhUXO/zrfF06no86J3quFbwzoCwP6y8Mul6RS0bc6ml5tp7g0AWAvBzqDRkWHVNRY6dXve6+4XHfU9EvuVQCnQy5/EbbQNVnxaBuDAJ3HV137uGW6/yf+0KE4x7QAcJs71imaKm6XMf+prw+7XHLmVOjVYP2bv2qKRiPcG1PN2dLSwlWYOj3doV93NP1u7wupVFTTRK/no2+E0Nd+jXIOd7Yims1KJiuplHi81XMrrdGRvGvmsthAT//lcImvBmezsuqpLT7rnP/+4fbmTPqc/kb6nXx3+m2fn8B0OnN7HxxSJnKuN9zV+UoqOVxVE6AZmTplWbphU+bNXzV1HQg6HaJe+1qv4pQJTKHeuhFJJCUWk7nzG9Z+a4uFLtG2jprhwdLt6GWzsmz5pi+ttFIn7MXvlM2YIR63KMqkXQQRyWQklZZkQhJJ4+XhRFLSaZlxV/Wzz7UtfbCB9oQAsIx8AWdVEVXL7e+8eUWHO3+EUikZGpJ40v+P/3rZQhcqeim8+4P6VDJagjdJNiuz5waeenaHhT7z77uCH+5oKi8XlyZO5yRfDRFJpyWVkkRSEgmJJySRkGRS0mmhuPQUYQ1gkhUWcM6//+LzGgWcJ7DFc4yjaYdDnIqkU9HjR610Fof/7tqHHynRxQBV81ur9ReRk8e3jvENgAncw8bCgCaFDw7FpacUawCT5lxveMvP/3LvR/87lYpqqjHdr1fy0ad9JrDFc3x9qIyk0pLNehYvsdJ42X93bSLRf+ni3pJaDFBU/+pndrg986z1sd976y/1qj5TdLZPfmFA39jmLBgx6wsDn/z2BRYGJvOCMwU0KfLT/YpizPa4CuZ8prTdz4+gUymJDcrVAflv/8N63+nv9jSd7g6WyN2Szcojq9qrFzda62Mf6gp+uL2pvFzcrkme/7nhJZKChYG4XlU0acwIsTBAAJhFvoCzXv/2tgWcp046LUPDcnVAnnq6ffnKRstdyQ/errsSDdv+hrFo6y8ir7XXDcXCPq8xApiea6WfkDOyMBCXREKSKWNhgOLSBEDR9HSH3tzSdPVKxOkUVTWO6nVpoqjGiV0i03oEbiYjiYQMxMQ/K/Dtv9phxUtq+wzIZuXRVe1VFmz9+6ORn/yoRj+TTlGm9cbWYyCdlmRqZHE4kZBUStIZeXzVxq8/1yYgAKZNNBp581dNp3tCztyZqHqvv/CF3umf0dZngQaH5OpV+dt/6J5pzZ6RjTPAuq2/iOx4r/no7zdPz/zPza5eJlMQA3GJJySZlFRKNM2/OrDpia9spGkiAKbcu9uaP9272ZkrbpWv4jlt0/23kE7LcFwGBmTpQxvrn7Vqt2jvrnW9ZzpsdttYuvUXke9vrtDUqNcrLq1od3h+YSCZklRyZGEgkZBMRmbcVb12XTvrwwTAVMkXcNan+/MrveMq4DzVT0g8IYODkkj6/2XjZete6n17mk7ZaE1YUf2rntoyp9KqbdOhA8Gd7zeVlxvvfxX3Ps8vDCRTI+vDyaSxMPAAxaXHg22gY9LTHfrFz9aF9/1QZNjlErdLvPoWT7e4NOORMMsuxqxkMjIcH/b6qufOs+qLM/fc16Cq/vO9v7HBzePxVn/16W2zZq+y7j9h5wfNiXjE7R5Z3Cpmp7VsZLeoUUNCEYdTHGUiZXLxwpFP9rwgWWEowAhgEkSjkffebj52tEM/5zq/0qtOQUWHSZFOSzwhsZhUzAp8+693WPriX+gL7d21ztLvCc9f0LDqqS2W/hbOnwu//pO6GT7xekVVzXW35xcGRl4ejksyZSwMfO25tpV1jTRiBMAE7dresntnq6NM8hUdjOl+1XgZ0oTvLmWzkkzK4KBcjUnDt3csrLZ8P2j3+/UXz4es+MkffqTt/mWWX5l8582m7uNBff7HhPd84cJAMmksDudrSMytrH32uTZGAwTA+BzoDO7e0Xr1SkQ/xG5kpVcdeafXnPQ+0dCwDAzI/PsaGv58iw2+juNHNh851JpMWGYocJe/9rEn22dWWL52TX800v7Dmhnl4vUaBxaZ9rbXt4qm0sYmUX19OJWSVFpWrGxc/fQmFgYIgNvr6Q7tDrWeioSM3f2a8W6X3vTrG+BMXrQgk5GEPggYkKZ/sup+0FEGY5Gufc3m3x2kav5lyzfZoOOv2/5u8+GDm02y/DvG3k8mI8ncjFA8IcmEJFOiufyPf3nDU0+30MQRADcWjUZ2b2+dngLOU/0YpFLGftBFDzR+c227bb6jC32h/XubBmMRc368hTWNjz7ZbqeH4qXNFaoz6vOJSzNv93/UzS/5GhIFLw/ni0uvrt/EwgABMNqu7S2ffvxCIh610HT/rQcB+lJwLCZN/2yTQcDIKO1k8MjBVlPFwOzKwKOr2r0+W13nj3a2dP6udYZPPB4LdP+vj4GbFZdeWB1YHdjEwgABICJy9HDHe9ua9YoOmpp7rVc19vlMf0WHSRwE6CsBi5Y0Pre23X5fnEliYOGixvuXbrDBdP/1Xmwb6f4X5e3fO38K8jUk8uvDSb2iXEZWrGxc+y0bPhcEwFid6w2/t63ZqOhw7YtdRazoMFn0vXGxmAzE5O9sNwjIu9AXOtX9yqmTwWn+//X6qhcuWl+1qNFmvf68D37T/FnXZr34j9l2f443BgprSCQKFwY0/+OrSnphoHQDYFQB5/xKrxkqOkzmIGBIrsZk9pzAX/ztDnt/ocePbD7V/Ur/5amtI6Rq/vkLGubf+/w999m5FnF/NPLySzX6ce0ul/WmQK9/FoRTJwkAXf68xqIXcJ7OQcCf/YUd3gkYi1MngxfO77zYF5rE2aGZFbVzKgPz7n3euuUcxuXtrU0n/xD0+Szf/R8VA7cuLl2Cp06WVgDcrICzpaf7bz8IGJaBASm/q3b9P3SW1M09GItc7AvFYpGL53cODkTGlQezKwOq6p9ZsXLO3MDs0mj0RxI0EvrFz+r1Exlt0P2/YQxQXLq0AsCcBZyngb4daHBQBmLyzDfaH65tlBI2GIsMDhgxcKHg7WJV9ftzq7il1txf7/Wf1F88H7Li5p9xxQDFpUslAMxcwHl6BgHDcRmISTrt/9f/flmAm+sKB7e/0+Tzic9nlLm18aMhJV9c2uYBMOq8Rk0zjmi333T/rQcB+ovBAzFZvnLjM9/g+CTc1L//nwqnI+rzWePV30mJgZGFgeuKS9v+1EnbBkBPd+i9bc0XzocdDmOqx1jpLdJ5jcW9xfWDYmIxiQ3K3/xdZ+W80lrpwhh98JvmQwc2l/vE65m+g3/NEwNp/eXhpFFVVC8lZO+FARsGQGEBZ1Xf52PuAs7Tc38nkjI0KAMxKZ9Z2/SPpbUajDH1mSKhX/y03ucVn88497EEH5PRxaULFgZsWVzabgFQWMBZ03LT/apVKzpM7p0dj0tsUGKD8tiqTasDLTR5KPTDf69JDEfKfeLxiqaW7pMiBcWlEwULA7YsLm2fALjmvMaCAs7mOa+x6He2viU0FpPBQfkvf89EEEa8/07zofBmn0/0U39L/HkpLC6dP3UyX1x6iY1OnbRDAOjT/ef7wtYt4Dw9MhlJJGRwSGIxmeFnIgi5JygS+vlr9V6v+LylsvY79nHzDYtLZ7Kyes0mG9SQsHYA5As4F57XqGnWK+A8bTd0/sDI2KA8/iQTQRAR+cH/rUnEI+U+8XhMfepLEWNgpLh0wamTNigubeEAsFkB52m7m/UCQQMxGRqSb//NjqrSqA+Bm/nl6+tORTp8Xnu+9ztZT41IbkboulMnLV1c2pIBkD+v8ZoCzgXnNQpzPje/lbPZkYmgjPg3/k9eDStdXZ3Bd99uYvJn7M9O/tTJ64tLW/HUSYsFwLne8PvvNI86rzFf0YHp/jHex/mJoMEhmTsv8NeNO7gsJajvXPj1n9Q7JOpj8mc8j4+dTp20UgDkCzgXntdopwLO03kTGzuCBmVwUL78lU2r61u4LKWm/Yd1/dGwz8vOn3E/PmKX4tLWCIB8AWd9un/ktV6FLZ4TH8wmUzI0KLFBGRqW//TnW5Yua+DKlI5fvr6u52SHNzf1z+TPxB4iqxeXNnsAFJ7XqBdwdrstf16jeUayeo2g2KBkxf+Xf7uDNwNKxO4dLR9/1OrxSL7mD5M/dxIDo06dzBeXNv+pk+YNgGvOayylAs7Tee/qNYIGB2VwSNye6n/Z0M1lsb2uzuA7v27yuMXrNc57YQw9Kd2pmxWXNvOpkyYNgGsKOGsji71M90/6jasXi47FZGhI/HfX/t0/83aYnfWdCwf/X53bLV6PeD3s+5zMR0luVFw6mVsYMGdxadMFwKgCzjY+r9E8A9hkSoaHJRaToWFZ9lDjnza0c2Xs2vr/7JV6yUY9HmPhl6n/qXigbrEwYLbi0iYKgPx5jYUFnF2aKKVXwHn6R6/JpAwNy+CgDA3LsuWNa8kAO3ppc83wUMTrEa9X3Cz8TnEMXHPqpFmLS5siAEad15gv4KxpTPdPXwYkkjI0JLGYDMcl8LW2J57cyJWxkx//oO7ypbDHIz6PuHPvfPFYTfVjlY+B4fg1xaVNcupk8QNAL+A8+rxGVVSV6f5pvVnTaeMN4cEhGR6W59a2r7Bd9fOS9fL36y5fCusLvx6PqLT+0/VYyU2KS2cyMmdu8YtLFzMAerpDv/jZusLzGingXNybNZWSeEKGhmRwSOJxMsBGrf8XYbfe+rvZ9lOEJ+v64tL6qZN6celv/9WWYn02pYjXxe3xp1JRfY3XXarnNZpHWZko+u2QNW7Zt99oEhEywOqt/6Uvwm6XeDzipvUv0pOl/3A4RK9brKq5hYGEXL0SKeJnK2YAVM6rnVtZnRiOuF0lfV6jCTMgK6IPDMkAe7T+Xq/xBiWtfxEfLn1iw+EQRRH93CqnU2ofWV/ET1Xk9/8e//IGr8coRJVf70VxOZ3i0sTjFo9bXC55+42mrs4gl8XqrT/VfkwSAw6HqKq4XaJvx3rkiWIuBRc5AKoXN6gaTb/phquKIvqkQT4D3tzSxMWh9cdkPWJ6bZtF9xe5AJdS3P/78hnVcyoD/ZdC3JqmukFFRFHEXfCHnx0MisjadbwfYHZ9veHXgvXpdJTW3/xP2YKq54v7MYpfAqpm8fpMhvvBvOMAfeOgS5PPDgZfba/n4phZT3fotWB9htbf9LJZcSr+xUsaSz0AFi1pdCp+6x9Nb+cM8HmM1uTs6dCPvl/X1xvm+phQV2fwp6/UZx7XYVkAABEQSURBVDJRfccnrb/JA6BqUWPRP4YpisDes6CBADBzBrhc4vGI1yMet1y6GH4tWN/THeL6mMqbW5re2tqkaeJxiy83aKP1N23rn81K9f3ri/5JTBEAD3xpg35FYN4M0ESvIOZxSyYd/ekr9Z/s2cz1MYkfvVT3+66gkdNecXvY8Wl2M2bW3j2r+MdvmCIA7p5VO2MmR5GYOgauyQCPaJp88JvmX/xsHRenuHq6Q9/5XxVfXDQ2/Pg8RqUHWn8zy2TkgQc3mOGTmOUcoAce3MAIwOQZoL8f4M1lgMslJ/7Q8b22GpYEimXX9hZ9ydfjFp/PqPJG629y+vLvogcaCYARix5odDhZCjZ7BujvsHg8Ypwk7pLBgcjLP6jbtb2F6zOdotHIq+31H+1qdblEb/31SFZV3qW3gHvuM8v52yY6D2D/J82RP2zm3jV//0WvbBVPyPCwDA8bp9/dVxX403XmOuzCro4e7vh1R1MqGdXPSfW4xOUeOSwPJn98Mhn5ZkN3+QxTPCkmCoCBq5F3OmoYvVriJhaRVEqSKYnHZXhYhuOSTIqi+levMUWVcxv7xc/W/eFoh35Uqtslbre4XKJQPdc6z07FrED9N3cwAriBHe/UX/6Ct4Kt1JdJpiQRl+G4cd5FKsVQYKoc6Ay+/05zMhHVT0zSW3+NYzMsJZ2WLz+15b4qpoBu5HRPx8e71jmd3CeWyYD8dFAiIUPDkogbVc5Xr9n01NMtXKJJEY1Gfr3FODJPPzZD7/jr0z5C7XTrPC8ud/Wf/Fm3eT6S6Q6Ff+uXNfHhCDe0he5pvV+TP/cunhsKzLireu269uIeeGQD+SPzVFVcmtH318unM+1jLZmMLK9rW/qQieZITRcAJ/8Q7Py4yeHgbrFYDOjHn+rH3eVXhtNpua8qsPZbzAhNxIHO4O4drVevRPQZf73117SR9V5af2s9Iw6nv+EvLpvqU5kuAESk4/WKTDrKzW3RoUAqPxRIGEOBdEZWrGxc+y0qiY5VT3fovW3N5/vCetFgvel3aXT8rf2A1Dywse6JNgLgNg6FW479vpVb3LpDgUwmNxSISyIhyaSkUqJp/sdXbWBh4LZN/64drad6QvmzA925pp8Zf6s/F+bZ/WnqABCRrf9RkU4xCLDwUEDfIJRMSiIh8bgkksaMEDFw26bf6RDFKao+56MZZ2XrRwnyRFj3oVhQ1fjEH5luEGzSAPjkw6YzPUFud0vf8foGoVRakglJJEdiIJMRTfM/XNf4xJMbWBu4vulXVGPGX2/69TkfOv6Wlk7Lc+u6feWmu9tNGgCxq5FtvBRmoxjQ9wjpP5JJSaaMmaIVtY0r6taX7E6hA53B3dtb+69ERpp+1ajooDf9zPnY4ymovKfhq/VbTPjZTBoAIvLJR01nIgwCbPIA6HuEUiljbSCRkGRKUilJpyWTlbmVtU88uWFlXWOJXJBoNPLJnhcOdgbj8ajj+qZfEaeTfT626v6v/tqOyvlm7OWYNwBiA5FtW2p4Kcw2GSByTQwkk8bPRgxkxOXyL1nW8PiTG+bNt21t8AOdwa7OV05FQvqcvqIYK70ujabftnf+3bMDgW/sMOfHM28AMAiweQykJZXLAH00kMrNC82cWb3kSw0ratfbJgmOHu44dnjr0cMd8UTUUSZOfYePYkz1aKooNP02lcnIHz1j0u6/2QOAQYC9YyCTkVRaUilJJnM/UpJOGwOCbNbySXCgM9jTvfNYrt13OIymX1FEU3MT/Yo4czt8aPrp/hMADAJK6PHQlwdSaUmnjekgIwZSks6MJIHL5V/yYENVzZqqmoDJNw6d6w33dIeOHdna0x0qc4jR7jvEqYjiHGn0FcVY42WHj727/6uf2THXrN1/CwQAg4DSGRCk05LOGHNBehKk0iNJkM1KJiuSlbnzaqtqApXzVponDHq6Q+d6wz2Rnae6Q/F4VO/L59v9/ISPkvuhd/lp+un+EwAMAjASA8Z+oYwxEZQPg1Rq5A/1v5MVyWbE7fbPnV9bVb1m3vzamf7qaZsp0lv8/v6ec73hU92hsjKRMnHk232nOAtme4zOvjJSxYHZHrr/BACDANxqQJDNjjT66ZSxWqCPEtJpyaQlkzX+WjZr5IGIVM6vdbn9VdVrRKS6JiAiMyuqJzxQONcbjg9Ho9FI9HKkP9oTjUb6esPx4aje4pfljsnM/9Dbfafe33eKw2k0+oXv8dL00/0nABgEYBxJoK8YpzMjM0L6mCCTNv5TJiOZ3IqC/r/Niki2YGwh4nb7K8c2ROjpDomIfrsVtvX6b/VGv7Dpz0/x6zt5nA5xOEcv7XL3llr3/5sNZnz115IBICJb/6Mik45yY5Xy7JCRBPk8SI/8Qh8Z6L/NZiWbmyPSUyH/Px/rU1HQZBdO2jhyTb++eJv/2em4ZhygZwONfinfsQuqG5/4qgXK3ypWuab3L91wlBKhJWlUc5xvzUflQX6gkB8QZDKSzYysHmf1LLltDOjNvd7Zd4w0+oVNvPGHuV/nhwU0+tDvz4dWbrLGw2WVEYBQIhS3HBwYkZD/dcZo90da/0wuA26XN9f8EClzGN3/wpXe/N+k0ceoe3LpQ5seqm0hACZZ9/Fg58dNPGy4dR5IwYTPqJ+z1/61m402HGXXhMGoX3MH4hZ3oFPxP/+fL1vlA1spAERk25aaoUFODMYdxcOYHgzuMUzoHlte17bkSxut8oEtdvbuo09yrCAm2tkpG8cPYAKtv8dbbaHW33oBMHde4O45AUsNWgCUCsv1UB2Wu8SPf6WdAABgtu7/rDmBufMCBMDU8pVXL1u+iQwAYKoAeOwr1pugdljxWj9U2+LxVpMBAEzS+i9bvsn87/3aJABEZMWjbdx2AMzQ+nu81VbZ+G+TALh3YcMsVoMB0B8twQAQkcdsuho8f0EDTxTsZ2ZFrddXbb/u/6w5gXsXWvWZtXAA+Mqrlz1sq9Xg2ZWBp5/rXPXUlkdW8boDbOUuf+3Tz3V+4/nuZQ9vUjW/bf5diuq34tpvnsXeBL7e+2/VXYmGrf7mjtdXvezhTVWLGvN/0nMyuG8PdS9gk9b/mT/uzP92MBY53NV6qjtog+6/td77tWEAnD8X+vCDeus2lKrmX7xkw4MrWq7/Tz0ngvv2kgGwVeufd6EvdORQ68W+kHVb/7v8tV/7k05LfzuWDwAROfC75hNHN1uxoVxY0/jgik23mBglA2DL1r9wpHvkYOtgLGLFAHj6uU7/3bWW/oLsEAAisq2jZnjQSvfQzIrahx9pm1MZuO3fjF4O736/PpXkMBzYrfXPO9zVcuRQq7Va/6XLNz20ssXq35FNAsBCE0Gq5n/4kbbC6X4yAPYzf0HDqqe2jP3vD8YiXfuae890WKL1n+mvfcbikz+2CgCxyETQsuWbbjjdf/sMuBTeu2vdkKVGOShZC2saJ1YW7UJf6OD+5v7LYZMHgA0mf+wWAGLuiaD5CxpWPNp2h/ugP3i77ko0LICJLV668Q5fjOo5GTy4vzmZMOOQ1zaTPzYMAHNOBI19un8sdr9ff/F8iFYG5vTIqvZxTW/eggkXBuw0+WPDABCTTQSpmn/Z8k33L5vkbcL79jTZYA81bEZR/Y+uar/nvsl8J3YwFtm3p8k8PR47Tf7YMwBE5IO36q70F3+e5M4Hwrdw/Mjmg/ubaXRgEh5v9ao1W/wVU9IyXugL7d/bVPStotmsPPxI2wMPbrTTF2fDAIheCm/fVlfEQcDsysCjq9qnuuzJ56c79u1tYmsQim7s2z3vsNNz5FBrsRYG9Jo/a76+w2bfnQ0DQET+cHjzwf3N058BXl/1I6vaJ2u6//ZRdzm8b08Ty8Iooglv+JmYrn3NJ45unv5/pqL61377sv2+PnsGgIjsfLf+iwuhacuAW1R0mGp7d62zxO5p2M8kLvmOXf/lcNf+5umsIZHNypef2nLvfTYs02vbABCRN39eMT0zJNPcCbqe5V6khNV5vNVPrtkys6Joy6Gfn+44uL95GhYGsllZvHTjysfseQKVnQPgwrnQ7ineFTq7MrDikbYiPgYj/9i+0N5d61gSwDSYPTew+mummA0/3NVy4tgLU7owcNdMW+37LKEAEJHPDrQcOdQ6FRng9VU//EjbPSYbFfKWAKbahN9mnzpTtzFaUf2rn9lhp32fpRUAIrLrvfqL5ydzMaCI0/1j7BMxHYSp4PFWP/rk9O1xGJepWBiw8dR/CQWATOpiwG0LOJvBhb7Qvj1NFA7CJBpvcbeimMTi0vae+i+tAJiUNwNmVwaWLd9kzu7PDbE7CJM15J2KF9qndBB85wsD9p76L60AkDt7M+D68xqt4vPTHfs/bjJnUS1Ywuy5gUefbLfcYe53eOqkXXf9l24AiMjv9jSdOhkcbwaYcMlrfE/CQGTf3iZWhmH7jv/1JlZcOpuV1c/smDMvUArfcgkFgIyznPKkFHA2ieK+Rg86/kU0ruLStiz4QwAYYgOR7dvqbrsgPLkFnM2DVQGUQsf/hsayOy6blYWLGh8r6kudBMDUuvWC8ATOa7SWaXt/ElZkp1Hv9W576uT0VLUjAIosciK4f2/T9RkwpQWcTaVYFbVgWuZ8sXEq3Ky4tMdb/c2G7lL73ksxAOS6c2Omp4CzqUx/RS2YltV3OkzAqFUx27/xSwCM9rs9Tae7g9NcwNlsmBEqcfae8xnjUDiblVVPbSmF0Q8BcI2eE8GqxY20AtNQUQtmY9edDuM1GItEL4VLs/Uv9QBAIY4aLhHWfbERBACmtjd0+GDrqZPEgD2ZvI4hCAAU34W+0JFDrawP0/SDAAAxAJp+EAAgBkDTDwIAJYW1AWvx+qoX1qyn6QcBgMmMgRNHX+g5GWTDqJmbfnb4gADAFDp+ZPOJoy/w+pipzF/QsHjpBvb1gwDAdPj8dMep7lcoL1pcquavWtS4eOmGkn2bFwQAimYwFuk5GTx18hUGBNNsdmVgYc16ZntAAMAUA4Les1tZKJ5qXl/1wkXrqxY10uUHAQDTOXUy2NP9CjtHJ5eq+ecvaFhYs55ZfhAAMLvBWERfJBjviay4vt2ff+/zJVutDAQALJ8EF8/vZLmYdh8EAErXqZPBC+d39p7p4E2CG5pZUTunMrCwZv3MilquBggA2FP/5fCFvlDv2a0sFXh91bMrA3PmrpldGWBdFwQASsvFvtCF86GL53eWThjojf5M/8o5lQE6+yAAACMMopfD/dEDF/tCNnuxYHZlwF9RO9O/kp4+CABgrIODwVhP/+WwtXYTqZp/ZkWt3uLPrKilmw8CALgj/ZfDyURUj4TBWET/rRk+2MyKWlXzz567RlX9/ora2WzVBwEATFsqDMYisVhERC6e3ykiyUR0ckcMeo9eRFTVP7NipYjMmRsQEdp6EACAqd16efnC+ZDPV33DeXnadxAAgM1TgYYeBAAAoIQ4uAQAQAAAAAgAAAABAAAgAAAABAAAgAAAABAAAAACAABAAAAACAAAAAEAACAAAAAEAACAAAAAEAAAAAIAAEAAAAAIAAAAAQAAIAAAAAQAAIAAAAAQAABAAAAACAAAAAEAACAAAAAEAACAAAAAEAAAAAIAAEAAAAAIAAAAAQAAIAAAAAQAAIAAAAAQAAAAAgAAQAAAAAgAAAABAAAgAAAABAAAgAAAABAAAEAAAAAIAAAAAQAAIAAAAAQAAIAAAAAQAAAAAgAAQAAAAAgAAAABAAAgAAAABAAAgAAAABAAAAACAABAAAAACAAAAAEAACAAAAAEAACAAAAAEAAAAAIAAAgAAAABAAAgAAAABAAAgAAAABAAAAACAABAAAAACAAAAAEAACAAAABF9/8BWP7L9djRUmIAAAAASUVORK5CYII=",

        fileName="modelica://TILMedia/Images/TILMedia.png")}),
  conversion(
    from(version="2.0.4"),
    from(version="2.1.0", script=
          "modelica://TILMedia/Scripts/ConvertTILMedia_to_3.0.0.mos"),
    from(version="2.1.1", script=
          "modelica://TILMedia/Scripts/ConvertTILMedia_to_3.0.0.mos"),
    from(version="2.1.2", script=
          "modelica://TILMedia/Scripts/ConvertTILMedia_to_3.0.0.mos"),
    from(version="3.0.0", script=
          "modelica://TILMedia/Scripts/ConvertTILMedia_from_3.2.1andEarlier.mos"),

    from(version="3.0.1", script=
          "modelica://TILMedia/Scripts/ConvertTILMedia_from_3.2.1andEarlier.mos"),

    from(version="3.0.2", script=
          "modelica://TILMedia/Scripts/ConvertTILMedia_from_3.2.1andEarlier.mos"),

    from(version="3.1.0", script=
          "modelica://TILMedia/Scripts/ConvertTILMedia_from_3.2.1andEarlier.mos"),

    from(version="3.2.0", script=
          "modelica://TILMedia/Scripts/ConvertTILMedia_from_3.2.1andEarlier.mos"),

    from(version="3.2.1", script=
          "modelica://TILMedia/Scripts/ConvertTILMedia_from_3.2.1andEarlier.mos"),

    from(version="3.2.2", script=
          "modelica://TILMedia/Scripts/ConvertTILMedia_from_3.2.2.mos")));
end TILMedia;
