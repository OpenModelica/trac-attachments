
for i=1,1,1 do

    print("Run number ", i)

    oms_setCommandLineOption("--deleteTempFiles=true")
    oms_setTempDirectory("./temp/")
    oms_newModel("model")
    oms_addSystem("model.root", oms_system_sc)
    -- instantiate FMUs
    oms_addSubModel("model.root.system1", "simple.fmu")
    -- simulation settings
    oms_setResultFile("model", "results.mat")
    oms_setStopTime("model", 0.1)
    oms_setFixedStepSize("model.root", 1e-4)
    oms_instantiate("model")
    oms_initialize("model")
    oms_simulate("model")
    oms_terminate("model")
    oms_delete("model")

end