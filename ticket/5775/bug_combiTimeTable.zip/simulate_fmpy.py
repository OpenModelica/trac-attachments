# -*- coding: utf-8 -*-
# @Author: Claire-Eleutheriane Gerrer
# @Date:   2019-09-10 13:58:45
# @Last Modified by:   Claire-Eleuthèriane Gerrer
# @Last Modified time: 2020-01-09 11:31:23

""" Simulate a simple model many times.
"""

import fmpy

sample_size = 2000
for ii in range(sample_size):
    print("Run number {}".format(ii))
    tmp = fmpy.simulate_fmu(
        filename="simple.fmu",
        validate=False)