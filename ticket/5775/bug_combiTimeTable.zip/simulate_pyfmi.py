# -*- coding: utf-8 -*-
# @Author: Claire-Eleuthèriane Gerrer
# @Date:   2020-01-08 18:32:13
# @Last Modified by:   Claire-Eleuthèriane Gerrer
# @Last Modified time: 2020-01-09 11:31:04

import pyfmi
fmu = pyfmi.load_fmu("simple.fmu")

sample_size = 20000
for ii in range(sample_size):
    print("Run number {}".format(ii))
    fmu.reset()
    # fmu.instantiate()
    fmu.initialize()