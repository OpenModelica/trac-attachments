model simple
  parameter String nomTable = "profiltest";
  parameter String nomFichier = "/home/gerrer/project/diverse/signal_bug_openmodelica/profil.txt";
  Modelica.Blocks.Sources.CombiTimeTable combiTimeTable(fileName = nomFichier, smoothness = Modelica.Blocks.Types.Smoothness.LinearSegments, tableName = nomTable, tableOnFile = true)  annotation(
    Placement(visible = true, transformation(origin = {-52, 46}, extent = {{-14, -14}, {14, 14}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput real_output annotation(
    Placement(visible = true, transformation(origin = {50, 46}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {50, 46}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(combiTimeTable.y[10], real_output) annotation(
    Line(points = {{-36, 46}, {40, 46}, {40, 46}, {50, 46}}, color = {0, 0, 127}));
  annotation(
    uses(Modelica(version = "3.2.2")));
end simple;