# -*- coding: utf-8 -*-
# @Author: Claire-Eleuthèriane Gerrer
# @Date:   2020-01-09 10:57:33
# @Last Modified by:   Claire-Eleuthèriane Gerrer
# @Last Modified time: 2020-01-09 11:29:45

import numpy as np 

time = np.linspace(0, 60000, num=60000)
value = np.sin(time)
arr = np.column_stack([time, value])

with open("profil.txt", "w") as f:
    f.write("#1 \n")
    f.write("double profiltest{} \n".format(arr.shape))
    np.savetxt(f, arr, delimiter=",") 

# add #1 \n double profil(6001,2) \n as the two first lines