within ;
model testModell2
  BugProtectionAnno.testmodel testmodel annotation (Placement(transformation(extent={{-22,-6},{-2,14}})));
  BugProtectionAnno.testmodel testmodel1 annotation (Placement(transformation(extent={{12,-2},{32,18}})));
equation
  connect(testmodel.fluidPortB, testmodel1.fluidPort) annotation (Line(points={{-2,4},{6,4},{6,8},{12,8}}, color={0,128,255}));
  connect(testmodel1.fluidPortB, testmodel.fluidPort) annotation (Line(points={{32,8},{38,8},{38,46},{-18,46},{-18,28},{-36,28},{-36,4},{-22,4}}, color={0,128,255}));
  annotation (Icon(coordinateSystem(preserveAspectRatio=false)), Diagram(coordinateSystem(preserveAspectRatio=false)));
end testModell2;
