﻿within BugProtectionAnno.Internal;
package Interfaces "Standard interfaces for the library"

//////////////////////////// header /////////////////////////////////
// © Bosch Rexroth AG 2019. All rights reserved,                   //
// also regarding any disposal, exploitation, reproduction,        //
// editing, distribution, as well as in the event of applications  //
// for industrial property rights.                                 //
/////////////////////////////////////////////////////////////////////


  extends Modelica.Icons.InterfacesPackage;

















  annotation (Icon(graphics),Documentation(info="<html><p> 
</table> 
 </p></html>"));
end Interfaces;
