within BugProtectionAnno;
package Internal "Internal"
  extends Modelica.Icons.InternalPackage;


  annotation(Protection(access = Access.documentation),Documentation(info="<html> 
 <!--No Standard  Docu--><p> 
</table> 
 </p>
 </html>"));
end Internal;
