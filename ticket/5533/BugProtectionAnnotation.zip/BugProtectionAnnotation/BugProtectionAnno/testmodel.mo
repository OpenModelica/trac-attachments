within BugProtectionAnno;
model testmodel
  Internal.Interfaces.FluidPort fluidPort annotation (Placement(transformation(extent={{-110,-10},{-90,10}})));
  Internal.Interfaces.FluidPortB fluidPortB annotation (Placement(transformation(extent={{90,-10},{110,10}})));
  annotation (Icon(coordinateSystem(preserveAspectRatio=false)), Diagram(coordinateSystem(preserveAspectRatio=false)));
end testmodel;
