within ;
package BugProtectionAnno
  annotation (uses(Modelica(version="3.2.2"), RexrothGeneric(version="1.0")),Protection(access = Access.documentation));
end BugProtectionAnno;
