within FunctionPass3.Functions;
function InnerFun
  extends FunctionPass3.Functions.InnerFunRef;
algorithm
  f := inVal;
end InnerFun;
