within FunctionPass3.Functions;
function OuterFun
  input FunctionPass3.Functions.InnerFunRef myInnerFun;
  input Real def;
  output Real f;
algorithm
  f:= myInnerFun(inVal=def);
end OuterFun;
