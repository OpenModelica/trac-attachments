within FunctionPass3;
model PassArgumentToInnerFunction_FAIL
  function myOuterFun = FunctionPass3.Functions.OuterFun (myInnerFun=FunctionPass3.Functions.InnerFun());
  Modelica.Blocks.Interfaces.RealOutput y annotation (Placement(transformation(extent={{90,-10},{110,10}})));
equation
  y = myOuterFun(def=time);
  annotation (Icon(coordinateSystem(preserveAspectRatio=false)), Diagram(coordinateSystem(preserveAspectRatio=false)),
Documentation(info = "<html><head></head><body>Bushing with double-cubic function for stiffness forces</body></html>"));
end PassArgumentToInnerFunction_FAIL;
