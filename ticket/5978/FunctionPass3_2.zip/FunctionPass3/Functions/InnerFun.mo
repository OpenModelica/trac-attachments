within FunctionPass3.Functions;
function InnerFun
  extends FunctionPass3.Functions.InnerFunRef;
  input Real k;
algorithm
  f := k*inVal;
end InnerFun;
