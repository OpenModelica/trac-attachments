within FunctionPass3.Functions;
partial function InnerFunRef
  input Real inVal;
  output Real f;
end InnerFunRef;
