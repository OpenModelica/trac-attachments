within FunctionPass3;
model PassArgumentToInnerFunctionExt_OK
  Modelica.Blocks.Interfaces.RealOutput y annotation (Placement(transformation(extent={{90,-10},{110,10}})));
equation
  y = FunctionPass3.myOuterFunExt(def=time);
  annotation (Icon(coordinateSystem(preserveAspectRatio=false)), Diagram(coordinateSystem(preserveAspectRatio=false)),
Documentation(info = "<html><head></head><body>Bushing with double-cubic function for stiffness forces</body></html>"));
end PassArgumentToInnerFunctionExt_OK;
