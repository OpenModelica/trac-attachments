within FunctionPass3;
function myOuterFunExt = FunctionPass3.Functions.OuterFun(myInnerFun=FunctionPass3.Functions.InnerFun);
