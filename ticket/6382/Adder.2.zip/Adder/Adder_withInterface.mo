within Adder;

model Adder_withInterface
  Modelica.Blocks.Math.Add add annotation(
    Placement(visible = true, transformation(origin = {10, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Adder.Interface interface annotation(
    Placement(visible = true, transformation(origin = {-50, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(interface.Output2, add.u1) annotation(
    Line(points = {{-38, 8}, {-20, 8}, {-20, 6}, {-2, 6}}, color = {0, 0, 127}));
  connect(interface.Output1, add.u2) annotation(
    Line(points = {{-38, -8}, {-20, -8}, {-20, -6}, {-2, -6}}, color = {0, 0, 127}));
  connect(add.y, interface.Input1) annotation(
    Line(points = {{22, 0}, {40, 0}, {40, -40}, {-80, -40}, {-80, 0}, {-62, 0}}, color = {0, 0, 127}));
end Adder_withInterface;
