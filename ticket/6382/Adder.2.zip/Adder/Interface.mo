within Adder;

block Interface


  input Real a;
  input Real b;
  output Real c;
  Modelica.Blocks.Interfaces.RealOutput Output2 annotation(
    Placement(visible = true, transformation(origin = {120, 90}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {120, 80}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput Output1 annotation(
    Placement(visible = true, transformation(origin = {120, -90}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {120, -80}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealInput Input1 annotation(
    Placement(visible = true, transformation(origin = {-100, 0}, extent = {{20, -20}, {-20, 20}}, rotation = 0), iconTransformation(origin = {-120, 0}, extent = {{20, -20}, {-20, 20}}, rotation = 0)));
equation
  Input1 = c;
  Output1 = a;
  Output2 = b;
  annotation(
    Icon(graphics = {Rectangle(extent = {{-100, 100}, {100, -100}})}));
end Interface;
