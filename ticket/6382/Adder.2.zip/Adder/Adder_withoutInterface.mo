within Adder;

model Adder_withoutInterface
    input Real x;
    input Real y;
    output Real s;

 
    Modelica.Blocks.Math.Add add annotation(
    Placement(visible = true, transformation(origin = {-34, 4}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
x = add.u1;
y = add.u2;
s = add.y;
end Adder_withoutInterface;
