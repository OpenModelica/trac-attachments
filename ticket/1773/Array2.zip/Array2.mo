package Array2

function toList
  input Array<Integer> array;
  output List<Integer> list;
algorithm
  list := arrayList(array);
end toList;

// Segfaults
function test3
  output List<Integer> olist;
protected
  Array<Integer> arr := {1,2,3};
algorithm
  olist := toList(arr);
end test3;

end Array2;
