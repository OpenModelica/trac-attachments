package FmiTest
  model Model
    //    extends Modelica.Electrical.Analog.Interfaces.OnePort;
    Modelica.Electrical.Analog.Basic.Resistor R1(R = 1) annotation(
      Placement(visible = true, transformation(origin = {-20, 30}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
    Modelica.Electrical.Analog.Basic.Ground GND annotation(
      Placement(visible = true, transformation(origin = {0, -30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    Modelica.Electrical.Analog.Basic.Capacitor C1(C = 2, v(fixed = true, start = 0)) annotation(
      Placement(visible = true, transformation(origin = {0, 10}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
    Modelica.Electrical.Analog.Sources.ConstantVoltage Vin(V = 12) annotation(
      Placement(visible = true, transformation(origin = {-50, 10}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
    //    AdaptorIV ada;
  equation
    connect(C1.p, R1.p) annotation(
      Line(points = {{0, 20}, {0, 30}, {-10, 30}}, color = {0, 0, 255}));
    connect(C1.n, GND.p) annotation(
      Line(points = {{0, 0}, {0, -20}}, color = {0, 0, 255}));
//  i = R2.p.i;
//  v = R2.p.v;
//    connect(n, GND.p);
//    connect(R2.p, ada.pin);
//  connect(R1.n, ada.pin1) annotation(
//      Line(points = {{-60, 30}, {-68, 30}, {-68, -20}, {-30, -20}, {-30, -20}}, color = {0, 0, 255}));
    connect(R1.n, Vin.p) annotation(
      Line(points = {{-30, 30}, {-50, 30}, {-50, 20}, {-50, 20}}, color = {0, 0, 255}));
    connect(Vin.n, GND.p) annotation(
      Line(points = {{-50, 0}, {-50, 0}, {-50, -8}, {0, -8}, {0, -20}, {0, -20}}, color = {0, 0, 255}));
    annotation(
      experiment(StartTime = 0, StopTime = 1, Tolerance = 1e-06, Interval = 0.00333333),
      __OpenModelica_commandLineOptions = "--matchingAlgorithm=PFPlusExt --indexReductionMethod=dynamicStateSelection -d=initialization,NLSanalyticJacobian,newInst -d=initialization ",
      __OpenModelica_simulationFlags(lv = "LOG_STATS", outputFormat = "mat", s = "impeuler"));
  end Model;
  annotation(
    uses(Modelica(version = "3.2.3")));
end FmiTest;