
#include <iostream>
#include "fmi_interface.h"

using namespace std;

int main()
{
    FmiInterface fmi("FmiTest.Model", "./", LogLevel::Normal, fmi2ModelExchange);

    return 0;

}
