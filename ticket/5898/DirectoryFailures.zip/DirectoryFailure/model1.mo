within DirectoryFailure;
function model1
  input Real inVal;
  output Real outVal;
end model1;

model Model1

end Model1;
