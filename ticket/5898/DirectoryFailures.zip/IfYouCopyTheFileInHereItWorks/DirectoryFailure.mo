within ;
package DirectoryFailure

  import SI = Modelica.SIunits;

  function model1
    input Real inVal;
    output Real outVal;
  end model1;

  model Model1

  end Model1;
  annotation (
    Protection(
      showDiagram=true,
      showText=true,
      showVariables=true,
      showDiagnostics=true,
      showStatistics=true,
      allowDuplicate=true),
    preferredView="info",
    version="0.1.0",
    versionDate="2017-11-01",
    versionBuild=1,
    dateModified="2018-01-01",
    uses(Modelica(version="3.2.3"), Complex(version="3.2.3")),
    Documentation(info="<html>
      <p>CrtVehicle Library documentation</p>
      </html>"));
end DirectoryFailure;
