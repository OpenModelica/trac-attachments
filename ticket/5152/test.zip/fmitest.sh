
# TODO: understand why a semicolon is needed in -l:FmiTest_Model.so
# TODO: how to embed full path so as to avoid th export

g++ -std=c++11 -O0 -g -o fmitest fmitest.cpp -I FmiTest.Model/sources/include/fmi2 -LFmiTest.Model/binaries/linux64 -l:FmiTest_Model.so
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:`pwd`/FmiTest.Model/binaries/linux64
./fmitest
