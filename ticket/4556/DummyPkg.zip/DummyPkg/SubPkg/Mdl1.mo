within DummyPkg.SubPkg;

model Mdl1
end Mdl1;
