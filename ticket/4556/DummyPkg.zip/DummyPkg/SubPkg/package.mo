within DummyPkg;

package SubPkg
  model Mdl1Copy
  end Mdl1Copy;





  model Mdl3
  end Mdl3;
end SubPkg;
