within DummyPkg.SubPkg;

model Mdl2
end Mdl2;
