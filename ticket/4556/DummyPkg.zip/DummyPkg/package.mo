package DummyPkg
  package SubPkgCopy
    model Mdl1
    end Mdl1;

    model Mdl2
    end Mdl2;

    model Mdl3
    end Mdl3;
  end SubPkgCopy;





  package SubPkg2Copy
    model Mdl3
    end Mdl3;

    model Mdl4
    end Mdl4;
  end SubPkg2Copy;
end DummyPkg;
