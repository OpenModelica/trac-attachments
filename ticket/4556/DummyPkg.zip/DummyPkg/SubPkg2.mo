within DummyPkg;

package SubPkg2
  model Mdl3
  end Mdl3;

  model Mdl4
  end Mdl4;
end SubPkg2;
