within ReplaceableInput;
model testmodel
    replaceable input Real A;
    replaceable input Real B;
    replaceable input Real C;

    Real D;

equation

  A + B + C = D;

  annotation (Icon(coordinateSystem(preserveAspectRatio=false)), Diagram(coordinateSystem(preserveAspectRatio=false)));
end testmodel;
