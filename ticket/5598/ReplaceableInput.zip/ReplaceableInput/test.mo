within ReplaceableInput;
model test

  output Real A;
  parameter Real E = 1;

  ReplaceableInput.testmodel getA(redeclare output Real A,B=1,C=2);

equation
  getA.D = E;
  A = getA.A;

  annotation (Icon(coordinateSystem(preserveAspectRatio=false)), Diagram(coordinateSystem(preserveAspectRatio=false)));
end test;
