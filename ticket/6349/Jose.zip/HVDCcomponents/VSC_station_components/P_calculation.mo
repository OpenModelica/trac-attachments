within HVDCcomponents.VSC_station_components;

model P_calculation

Modelica.Blocks.Interfaces.RealInput igd annotation(
    Placement(visible = true, transformation(origin = {-117, 19}, extent = {{-17, -17}, {17, 17}}, rotation = 0), iconTransformation(origin = {-117, 61}, extent = {{-17, -17}, {17, 17}}, rotation = 0)));
Modelica.Blocks.Interfaces.RealInput igq annotation(
    Placement(visible = true, transformation(origin = {-117, -153}, extent = {{-17, -17}, {17, 17}}, rotation = 0), iconTransformation(origin = {-117, 19}, extent = {{-17, -17}, {17, 17}}, rotation = 0)));
Modelica.Blocks.Interfaces.RealInput vgd annotation(
    Placement(visible = true, transformation(origin = {107, 119}, extent = {{-17, -17}, {17, 17}}, rotation = -90), iconTransformation(origin = {-117, -21}, extent = {{-17, -17}, {17, 17}}, rotation = 0)));
Modelica.Blocks.Interfaces.RealInput vgq annotation(
    Placement(visible = true, transformation(origin = {109, -217}, extent = {{-17, -17}, {17, 17}}, rotation = 90), iconTransformation(origin = {-117, -61}, extent = {{17, -17}, {-17, 17}}, rotation = 180)));
Modelica.Blocks.Interfaces.RealOutput p_calc annotation(
    Placement(visible = true, transformation(origin = {300, 22}, extent = {{-16, -16}, {16, 16}}, rotation = 0), iconTransformation(origin = {116, 18}, extent = {{-16, -16}, {16, 16}}, rotation = 0)));
Modelica.Blocks.Interfaces.RealOutput q_calc annotation(
    Placement(visible = true, transformation(origin = {300, -102}, extent = {{-16, -16}, {16, 16}}, rotation = 0), iconTransformation(origin = {116, -68}, extent = {{-16, -16}, {16, 16}}, rotation = 0)));

equation
p_calc = igd*vgd + igq*vgq;
q_calc = igd*vgq - igq*vgd;



end P_calculation;
