within HVDCcomponents.VSC_station_components;

model pwCurrentSensor

  Modelica.Blocks.Interfaces.RealOutput ir
    annotation (Placement(visible = true, transformation(origin = {-34, 110}, extent = {{-10, -10}, {10, 10}}, rotation = 90), iconTransformation(origin = {-34, 110}, extent = {{-10, -10}, {10, 10}}, rotation = 90)));
  Modelica.Blocks.Interfaces.RealOutput ii
    annotation (Placement(visible = true, transformation(origin = { 40, 110}, extent = {{-10, -10}, {10, 10}}, rotation = 90), iconTransformation(origin = { 40, 110}, extent = {{-10, -10}, {10, 10}}, rotation = 90)));
  OpenIPSL.Interfaces.PwPin p annotation(
    Placement(visible = true, transformation(origin = {-100, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-100, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  OpenIPSL.Interfaces.PwPin n annotation(
    Placement(visible = true, transformation(origin = {104, -2}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {100, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  equation
  p.vr = n.vr;
  p.vi = n.vi;
  p.ir + n.ir = 0;
  p.ii + n.ii = 0;
  ir = p.ir;
  ii = p.ii;
  
  
  annotation (Icon(graphics = {Rectangle(lineColor = {0, 0, 255}, extent = {{-100, 100}, {100, -100}}), Rectangle(lineColor = {0, 0, 255}, extent = {{-80, 80}, {80, -80}}), Rectangle(lineColor = {0, 0, 255}, extent = {{-60, 60}, {60, 0}}), Text(lineColor = {0, 0, 255}, extent = {{-20, -20}, {20, -60}}, textString = "I", textStyle = {TextStyle.Bold}), Line(points = {{0, 0}, {40, 40}}, color = {0, 0, 255}), Text(origin = {-120, 30},lineColor = {0, 0, 255}, extent = {{80, 70}, {100, 50}}, textString = "ir"), Text(origin = {-48, 90},lineColor = {0, 0, 255}, extent = {{80, 10}, {100, -10}}, textString = "ii"), Text(lineColor = {0, 0, 255}, extent = {{80, -50}, {100, -70}}, textString = ""), Text(lineColor = {0, 0, 255}, extent = {{-100, -100}, {100, -160}}, textString = "%name")}, coordinateSystem(initialScale = 0.1)), Documentation);


end pwCurrentSensor;
