model Pac_OnlyFunction_2
  block Shapes
    parameter Real Lz = 40;
    parameter Real ThetaDegree(unit = "degree") = 1;
    constant Real Pi = 3.1415926535;
    Real ThetaRad(unit = "rad");
    extends Modelica.Blocks.Interfaces.MO(nout = 2);
  algorithm
    ThetaRad := ThetaDegree / 180 * Pi;
    y[1] := Lz;
    y[2] := ThetaRad;
    annotation(
      Icon(graphics = {Text(origin = {2, 8}, extent = {{-88, 50}, {88, -50}}, textString = "Shape")}));
  end Shapes;

  model ExternalForce
    parameter Real F1 = 1;
    Port port1 annotation(
      Placement(visible = true, transformation(origin = {104, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  algorithm
    port1.F := F1;
    annotation(
      Icon(graphics = {Rectangle(extent = {{-100, 100}, {100, -100}}), Text(origin = {3, 9}, extent = {{-91, 67}, {91, -67}}, textString = "F1")}));
  end ExternalForce;

  connector Port
    Real F;
    annotation(
      Icon(graphics = {Rectangle(fillColor = {255, 0, 0}, fillPattern = FillPattern.Solid, extent = {{-100, 100}, {100, -100}})}));
  end Port;

  block stiffness
    parameter Real E1 = 206, E2 = 68;
    parameter Real L = 40;
    parameter Integer Nz = 3, Ny = 3;
    Real A;
    Real K, K1, K2;
    Modelica.Blocks.Interfaces.RealOutput y annotation(
      Placement(visible = true, transformation(origin = {110, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  algorithm
    A := 80 / Nz * 90 / Ny;
    K1 := E1 * A / L;
    K2 := E2 * A / L;
  equation
    1 / K = 1 / K1 + 1 / K2;
    y = K;
    annotation(
      Icon(graphics = {Rectangle(extent = {{-100, 100}, {100, -100}}), Text(origin = {3, 8}, extent = {{-91, 46}, {91, -46}}, textString = "Stiffness")}));
  end stiffness;

  block InitialXCoordinateValue_2
    parameter Integer Ny, Nz;
    Real Lz;
    Real Theta(unit = "rad");
    Real b0[Nz, Ny];
    //Input,Output
    Modelica.Blocks.Interfaces.RealInput u[2] annotation(
      Placement(visible = true, transformation(origin = {-108, -80}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-120, -80}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
    Modelica.Blocks.Interfaces.RealOutput y[Nz, Ny] annotation(
      Placement(visible = true, transformation(origin = {108, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  algorithm
//Input
    Lz := u[1];
    Theta := u[2];
//Calculate
    for i in 1:Nz loop
      for j in 1:Ny loop
        b0[i, j] := -(i - 1) * Lz * Theta / (Nz - 1);
        y[i, j] := b0[i, j];
      end for;
    end for;
    annotation(
      Icon(graphics = {Rectangle(origin = {1, -1}, extent = {{-101, 101}, {99, -99}}), Text(origin = {0, 9}, extent = {{-86, 49}, {86, -49}}, textString = "Initial_Xp")}, coordinateSystem(initialScale = 0.1)));
  end InitialXCoordinateValue_2;

  model Cal_loop_FunctionOnly_2
    function Cal_d0
      /* Calculate initial X position d0 */
      input Integer Nz;
      input Integer Ny;
      input Real In_Xp0[:, :];
      output Real d0[Nz, Ny];
    algorithm
/*make array d0[:,:]*/
      for i in 1:Nz loop
        for j in 1:Ny loop
          d0[i, j] := In_Xp0[i, j];
        end for;
      end for;
    end Cal_d0;

    function Cal_ux
      /*Calculate displacement ux*/
      input Real Func_F1;
      input Real Func_K;
      input Real Func_Xp[:, :];
      input Integer Nz;
      input Integer Ny;
      output Real Func_ux;
    protected
      Real epsilon1;
      Real epsilon2;
      Real epsilon3;
      Real derf;
      parameter Integer n = 10;
      parameter Real step = 0.000000001;
      Real deltah1, deltah2;
    algorithm
      Func_ux := 5;
      epsilon1 := 1;
/*Iteration using Newton's method*/
      for k in 1:n loop
        if epsilon1 > 0.000001 then
          epsilon1 := eq(Func_ux, Func_F1, Func_Xp, Func_K, Nz, Ny);
          deltah1 := Func_ux - step;
          deltah2 := Func_ux + step;
          epsilon2 := eq(deltah1, Func_F1, Func_Xp, Func_K, Nz, Ny);
          epsilon3 := eq(deltah2, Func_F1, Func_Xp, Func_K, Nz, Ny);
          derf := (epsilon3 - epsilon2) / (2 * step);
          Func_ux := Func_ux - epsilon1 / derf;
          epsilon1 := eq(Func_ux, Func_F1, Func_Xp, Func_K, Nz, Ny);
        end if;
      end for;
    end Cal_ux;

    function eq
      /*Calculate residual eq*/
      input Real eq_ux;
      input Real eq_F1;
      input Real eq_d0[:, :];
      input Real eq_K_stif;
      input Integer Nz;
      input Integer Ny;
      output Real eq_eq;
    protected
      Real d[Nz, Ny];
      Real F2[Nz, Ny];
      Real F1_ita;
    algorithm
      F1_ita := 0;
      for i in 1:Nz loop
        for j in 1:Ny loop
          d[i, j] := eq_d0[i, j] + eq_ux;
          if d[i, j] > 0 then
            F2[i, j] := -eq_K_stif * d[i, j];
          else
            F2[i, j] := 0;
          end if;
          F1_ita := F1_ita - F2[i, j];
        end for;
      end for;
      eq_eq := abs(eq_F1 - F1_ita) / eq_F1;
    end eq;

    /*parameter*/
    Real ux;
    parameter Integer Nz, Ny;
    Real d0[Nz, Ny];
    /*port*/
    Modelica.Blocks.Interfaces.RealInput In_K annotation(
      Placement(visible = true, transformation(origin = {-106, 80}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-115, 79}, extent = {{-15, -15}, {15, 15}}, rotation = 0)));
    Modelica.Blocks.Interfaces.RealInput In_Xp0[Nz, Ny] annotation(
      Placement(visible = true, transformation(origin = {-96, 90}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-115, 21}, extent = {{-15, -15}, {15, 15}}, rotation = 0)));
    Port In_F1 annotation(
      Placement(visible = true, transformation(origin = {-106, -64}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-110, -100}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  equation
    d0 = Cal_d0(Nz, Ny, In_Xp0);
    ux = Cal_ux(In_F1.F, In_K, d0, Nz, Ny);
    annotation(
      Icon(graphics = {Rectangle(extent = {{-100, 100}, {100, -100}}), Text(origin = {2, 8}, extent = {{-94, 48}, {94, -48}}, textString = "Cal_loop"), Text(origin = {-122, -21}, extent = {{-50, 21}, {16, -5}}, textString = "Initial_Xl"), Text(origin = {-120, 99}, extent = {{-50, 21}, {16, -5}}, textString = "Stiffness"), Text(origin = {-120, 43}, extent = {{-50, 21}, {16, -5}}, textString = "Initial_Xp"), Text(origin = {-102, -87}, extent = {{-50, 21}, {16, -5}}, textString = "F1")}, coordinateSystem(initialScale = 0.1)));
  end Cal_loop_FunctionOnly_2;

  model Calculate_Test_1
    parameter Integer Nz_sys = 36, Ny_sys = 72;
    Pac_OnlyFunction_2.stiffness stiffness1(Ny = Ny_sys, Nz = Nz_sys) annotation(
      Placement(visible = true, transformation(origin = {-40, 52}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    Pac_OnlyFunction_2.ExternalForce externalForce1(F1 = 10) annotation(
      Placement(visible = true, transformation(origin = {-40, -24}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    Pac_OnlyFunction_2.Cal_loop_FunctionOnly_2 cal_loop_FunctionOnly_21(Ny = Ny_sys, Nz = Nz_sys) annotation(
      Placement(visible = true, transformation(origin = {54, 12}, extent = {{-36, -36}, {36, 36}}, rotation = 0)));
    Shapes shapes1 annotation(
      Placement(visible = true, transformation(origin = {-80, 16}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    InitialXCoordinateValue_2 initialXCoordinateValue_21(Ny = Ny_sys, Nz = Nz_sys) annotation(
      Placement(visible = true, transformation(origin = {-40, 16}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  equation
    connect(initialXCoordinateValue_21.y, cal_loop_FunctionOnly_21.In_Xp0) annotation(
      Line(points = {{-28, 16}, {10, 16}, {10, 20}, {12, 20}}, color = {0, 0, 127}, thickness = 0.5));
    connect(shapes1.y, initialXCoordinateValue_21.u) annotation(
      Line(points = {{-68, 16}, {-54, 16}, {-54, 8}, {-52, 8}}, color = {0, 0, 127}, thickness = 0.5));
    connect(externalForce1.port1, cal_loop_FunctionOnly_21.In_F1) annotation(
      Line(points = {{-28, -24}, {12, -24}, {12, -24}, {14, -24}}));
    connect(stiffness1.y, cal_loop_FunctionOnly_21.In_K) annotation(
      Line(points = {{-28, 52}, {10, 52}, {10, 40}, {12, 40}}, color = {0, 0, 127}));
  end Calculate_Test_1;
  annotation(
    uses(Modelica(version = "3.2.2")));
end Pac_OnlyFunction_2;
