About the two models:

Pac_OnlyFunction_1.mo:
 array numbers = 18 x 36
  -> successfully executed
Pac_OnlyFunction_2.mo:
 array numbers = 36 x 72
 -> error in gcc
    error message is in file "ErrorMessage_Nz-36_Ny-72.txt"


Change the following values to change numbers of array Nz, Ny:

Nz_sys, Ny_sys  in Calculate_Test_1


