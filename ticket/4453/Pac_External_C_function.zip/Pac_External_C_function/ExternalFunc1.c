
//Division number 
int Nz = 36;
int Ny = 72;

//Size of wall
double Lz = 40;

//Residual
double epsilon1 = 1;
//Initial x position
double Xp0[100][100] = {};

double eq(double ux, double F1, double func_d0[100][100], double K_stif) {
	/*Function to calculate the residual*/
	int a = 0, b = 0;
	double F2[100][100] = {};
	double d[100][100] = {};
	double F1_ita = 0;
	double eq = 0;

	/*Calculate final position*/
	for (a = 0; a < Nz; a++) {
		for (b = 0; b < Ny; b++) {
			d[a][b] = func_d0[a][b] + ux;
			if (d[a][b] > 0) {
				F2[a][b] = -K_stif*d[a][b];
			}
			else {
				F2[a][b] = 0;
			}
			F1_ita = F1_ita - F2[a][b];
		};
	};
	eq = fabs(F1 - F1_ita) / F1;
	return eq;
}


double ExternalFunc1_ext(double F1, double K)
{
	/* Declaration ******************************************/
	//Initial value
	double ux = 5;
	double output_ux;

	/*Variable used for calculating initial x position*/
	int i = 0, j = 0;
	double XI[100][100] = {};
	double deltax = 0;
	double Pi = 3.141592653589;
	double theta = 0, thetaRad = 0;

	//Initial position d0
	double d0[100][100] = {};

	double step = 0.000000001;

	//n is the max loop number of iteration
	int n = 10;
	int p = 0, k = 0;

	//Residual ��2,��3
	double epsilon2 = 0, epsilon3 = 0;

	double deltah1 = 0, deltah2 = 0;
	double derf = 0;
	/*******************************************************/

	/* Calculate initial x position ******************************************/
	theta = 1;
	thetaRad = theta / 180 * Pi;
	deltax = Lz*thetaRad / (Nz - 1);

	for (i = 0; i < Nz; i++) {
		for (j = 0; j < Ny; j++) {
			Xp0[i][j] = -(i)*deltax;
			d0[i][j] = Xp0[i][j] - XI[i][j];
		};
	};
	/*******************************************************/

	/* Newton's method ******************************************/
	for (p = 0; p < m; p++) {

		//Start iteration
		for (k = 0; k < n; k++) {
			if (epsilon1 > 0.0000001) {
				epsilon1 = eq(ux, F1, d0, K);
				deltah1 = ux - step;
				deltah2 = ux + step;
				epsilon2 = eq(deltah1, F1, d0, K);
				epsilon3 = eq(deltah2, F1, d0, K);
				derf = (epsilon3 - epsilon2) / (2 * step);
				ux = ux - epsilon1 / derf;
				epsilon1 = eq(ux, F1, d0, K);
			};
		};
		/*******************************************************/
	};
	/*******************************************************/

	epsilon1 = 1;
	output_ux = ux;
	return output_ux;
}

