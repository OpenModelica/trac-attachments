﻿model Pac_ExC_2

  model ExternalForce
    parameter Real F1 = 1;
    Port port1 annotation(
      Placement(visible = true, transformation(origin = {104, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  algorithm
    port1.F := F1;
    annotation(
      Icon(graphics = {Rectangle(extent = {{-100, 100}, {100, -100}}), Text(origin = {3, 9}, extent = {{-91, 67}, {91, -67}}, textString = "F1")}));
  end ExternalForce;

  connector Port
    Real F;
    annotation(
      Icon(graphics = {Rectangle(fillColor = {255, 0, 0}, fillPattern = FillPattern.Solid, extent = {{-100, 100}, {100, -100}})}));
  end Port;

  block stiffness

    parameter Real E1 = 206, E2 = 68;
    parameter Real L = 40;
    parameter Integer Nz = 3, Ny = 3;
    Real A;
    Real K, K1, K2;
    Modelica.Blocks.Interfaces.RealOutput y annotation(
      Placement(visible = true, transformation(origin = {110, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {110, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));

  algorithm
    A := 80 / Nz * 90 / Ny;
    K1 := E1 * A / L;
    K2 := E2 * A / L;
  equation
    1 / K = 1 / K1 + 1 / K2;
    y = K;
    annotation(
      Icon(graphics = {Rectangle(extent = {{-100, 100}, {100, -100}}), Text(origin = {3, 8}, extent = {{-91, 46}, {91, -46}}, textString = "Stiffness")}));
  end stiffness;

  model Ex_Cal_loop_1

    function ExternalFunc1
      input Real Func_F1;
      input Real Func_K;
      output Real Func_ux;
    
      external Func_ux = ExternalFunc1_ext(Func_F1, Func_K) annotation(
        Library = "ExternalFunc1.o");
    end ExternalFunc1;
  
    Real ux;
    Real F1;
    Real K;
    //Port
    Modelica.Blocks.Interfaces.RealInput In_K annotation(
      Placement(visible = true, transformation(origin = {-106, 80}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-115, 79}, extent = {{-15, -15}, {15, 15}}, rotation = 0)));
    Port In_F1 annotation(
      Placement(visible = true, transformation(origin = {-106, -64}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-110, -100}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  
  algorithm
  //Set stiff K
    K := In_K;
  equation
    F1 = In_F1.F;
    ux = ExternalFunc1(F1, K);
    annotation(
      Icon(graphics = {Rectangle(extent = {{-100, 100}, {100, -100}}), Text(origin = {2, 8}, extent = {{-94, 48}, {94, -48}}, textString = "Cal_loop"), Text(origin = {-122, -21}, extent = {{-50, 21}, {16, -5}}, textString = "Initial_Xl"), Text(origin = {-120, 99}, extent = {{-50, 21}, {16, -5}}, textString = "Stiffness"), Text(origin = {-120, 43}, extent = {{-50, 21}, {16, -5}}, textString = "Initial_Xp"), Text(origin = {-102, -87}, extent = {{-50, 21}, {16, -5}}, textString = "F1")}, coordinateSystem(initialScale = 0.1)));
  end Ex_Cal_loop_1;


  model ExC_Calculate_1

    Pac_ExC_2.ExternalForce externalForce1(F1 = 10) annotation(
      Placement(visible = true, transformation(origin = {-40, -24}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    Pac_ExC_2.Ex_Cal_loop_1 ex_Cal_loop_11 annotation(
      Placement(visible = true, transformation(origin = {52, 10}, extent = {{-22, -22}, {22, 22}}, rotation = 0)));
    Pac_ExC_2.stiffness stiffness1(Ny = 72, Nz = 36) annotation(
      Placement(visible = true, transformation(origin = {-40, 38}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  equation
    connect(stiffness1.y, ex_Cal_loop_11.In_K) annotation(
      Line(points = {{-28, 38}, {26, 38}, {26, 28}, {26, 28}}, color = {0, 0, 127}));
    connect(externalForce1.port1, ex_Cal_loop_11.In_F1) annotation(
      Line(points = {{-28, -24}, {28, -24}, {28, -12}, {28, -12}}));
  end ExC_Calculate_1;
  annotation(
    uses(Modelica(version = "3.2.2")));
end Pac_ExC_2;
