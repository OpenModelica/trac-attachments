External C function

Change the following values to change numbers of array Nz, Ny:

Nz, Ny in stiffness1 instance in ExC_Calculate_1
Nz, Ny in ExternalFunc1.c

