package BugInheritence

model A
parameter Real A;
end A;

model B
extends A;
end B;

  model C
  extends A;
  extends B;
  parameter Real A;
  equation

  end C;

  model test
  C c1 annotation(
      Placement(visible = true, transformation(origin = {-18, -4}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  equation

  end test;
end BugInheritence;
