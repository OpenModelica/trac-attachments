within ;
package TestTILMediaOSMC 
  import SI = Modelica.SIunits;







  annotation (uses(Modelica(version="3.2")));
end TestTILMediaOSMC;
