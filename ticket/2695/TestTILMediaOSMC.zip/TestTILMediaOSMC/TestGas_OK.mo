within TestTILMediaOSMC;
model TestGas_OK "this tester works"

  // In the gasType VDIWA_MoistAir_nc3 there are 3 components (nc=3) -> size of xi is nc-1 -> xi[2]
  Modelica.SIunits.MassFraction  xi1[gas_pT1.gasType.nc-1];
  Modelica.SIunits.MassFraction  xi2[gas_pT2.gasType.nc-1];
  gas_pT gas_pT1(p=10,T=10,xi = {0.001},redeclare TestTILMediaOSMC.MoistAir_nc2
                                                                                gasType)
    annotation (Placement(transformation(extent={{-28,-10},{-8,10}})));

  gas_pT gas_pT2(p=10,T=10,redeclare TestTILMediaOSMC.DryAir gasType)
   annotation (Placement(transformation(extent={{-28,-52},{-8,-32}})));

equation
  xi1=gas_pT1.gasType.xi_default;
  xi2=gas_pT2.gasType.xi_default;

end TestGas_OK;
