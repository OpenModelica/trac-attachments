within TestTILMediaOSMC;
record DryAir "TILMedia.DryAir"
  extends TestTILMediaOSMC.BaseGas(
    final fixedMixingRatio=false,
    final nc_propertyCalculation=1,
    final gasNames={""},
    final mixingRatio_propertyCalculation={1},
    final condensingIndex=0);
end DryAir;
