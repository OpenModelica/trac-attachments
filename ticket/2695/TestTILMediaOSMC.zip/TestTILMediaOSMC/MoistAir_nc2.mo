within TestTILMediaOSMC;
record MoistAir_nc2 "Simple moist air based using VDIWA"
  extends TestTILMediaOSMC.BaseGas(
    final fixedMixingRatio=false,
    final nc_propertyCalculation=2,
    final gasNames={"VDIWA.Water","VDIWA.DryAir"},
    final condensingIndex=1,
    final mixingRatio_propertyCalculation={0.001,1});
end MoistAir_nc2;
