within ;
package Demo2P_modelica
annotation (uses(Modelica(version="3.2.3"), PhotoVoltaics(version="1.6.0")));
end Demo2P_modelica;
