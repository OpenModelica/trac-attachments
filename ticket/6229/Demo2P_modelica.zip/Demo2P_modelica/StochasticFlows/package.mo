within Demo2P_modelica;
package StochasticFlows "Larger simulator, less modelling details"

end StochasticFlows;
