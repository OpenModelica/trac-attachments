within Demo2P_modelica.StochasticFlows.Support;
record CarData
  parameter Real chargePower=22000;
  parameter Real probability=0.1 "probability of arrival at the given minute";
  parameter Modelica.SIunits.Time y_min=600 "durata minima della sosta";
  parameter Modelica.SIunits.Time y_max=1800 "durata massima della sosta";
    annotation (Icon(coordinateSystem(preserveAspectRatio=false), graphics={
        Text(
          extent={{-108,144},{110,118}},
          lineColor={0,0,255},
          textString="%name"),
        Rectangle(
          extent={{-100,100},{100,-98}},
          lineColor={244,125,35},
          fillColor={255,255,255},
          fillPattern=FillPattern.Solid,
          lineThickness=1),
        Text(
          extent={{-46,40},{52,-40}},
          lineColor={0,0,0},
          fillColor={255,255,255},
          fillPattern=FillPattern.None,
          textString="Car
Data")}),                                                          Diagram(
        coordinateSystem(preserveAspectRatio=false)));
end CarData;
