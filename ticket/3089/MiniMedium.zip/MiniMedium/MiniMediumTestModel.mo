model MiniMediumTestModel
  package Medium = MiniMedium;
  Medium.SaturationProperties TestSat;
equation
  TestSat = Medium.setSat_p(p = 1e5);
  annotation(uses(Modelica(version = "3.2.1")), preferredView = "text");
end MiniMediumTestModel;