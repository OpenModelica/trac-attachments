g++ -c ../recordFkt.cpp -DRECORDEXT_dll
g++ -shared -o recordExterFkt.dll recordFkt.o -Wl,--out-implib,librecordExterFkt.a
rm -f *.o