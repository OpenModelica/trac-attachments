#include "recordFkt.h"

int addLibComplexNum(double realX1, double imgX1,double realX2, double imgX2,double* realY,double* imgY)
{
	*realY = realX1 + realX2;
	*imgY = imgX1 + imgX2;
	return 1;
}