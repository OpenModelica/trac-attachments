#ifndef _RECORDFKT_H
#define _RECORDFKT_H

#ifdef RECORDEXT_dll
	#define RECORDEXT_Export __declspec(dllexport)
#else
	#ifdef __cplusplus
		#define RECORDEXT_Export __declspec(dllimport)
	#else
		#define RECORDEXT_Export
	#endif
#endif

#ifdef __cplusplus
	#define EXTERN extern "C"
#else
	#define EXTERN extern
#endif 


EXTERN RECORDEXT_Export int addLibComplexNum(double realX1, double imgX1,double realX2, double imgX2,double* realY,double* imgY);


#endif //_RECORDFKT_H