model DAE
  Modelica.Blocks.Sources.Sine sine(freqHz = 20)  annotation(
    Placement(visible = true, transformation(origin = {-70, 30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Continuous.FirstOrder firstOrder(T = 0.4, initType = Modelica.Blocks.Types.Init.SteadyState, k = 1)  annotation(
    Placement(visible = true, transformation(origin = {-22, 30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Continuous.SecondOrder secondOrder(D = 3, initType = Modelica.Blocks.Types.Init.SteadyState, k = 1, w = 30)  annotation(
    Placement(visible = true, transformation(origin = {36, 30}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(sine.y, firstOrder.u) annotation(
    Line(points = {{-59, 30}, {-34, 30}}, color = {0, 0, 127}));
  connect(firstOrder.y, secondOrder.u) annotation(
    Line(points = {{-10, 30}, {24, 30}}, color = {0, 0, 127}));

annotation(
    uses(Modelica(version = "3.2.3")));
end DAE;