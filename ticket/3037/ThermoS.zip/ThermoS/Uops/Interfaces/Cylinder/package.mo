within ThermoS.Uops.Interfaces;
  package Cylinder  "A Cylinder Shape"
        
        function vol
            input  Length  D   = 1.0 ;
            input  Length  H   = 1.0 ;
            output Volume v ;
          algorithm
             v := 3.147 * D * D  * H / 4 ;
        end  vol;
        
        function  level 
           input  Length  D   = 1.0 ;
           input   Volume v ;
           output  Length h ;
          algorithm
             h := 4 * v / (3.147 * D * D) ; 
        end level;
end Cylinder ;
