file(REMOVE_RECURSE
  "CMakeFiles/proc3d.dir/src/proc3d.cpp.o"
  "libproc3d.pdb"
  "libproc3d.dylib"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/proc3d.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
