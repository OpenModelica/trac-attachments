within initializeParameterArray;
function callInit
  //OUTPUTS

   input Real value;
   output Real[10,3] y;
algorithm
  y:=initializeParameterArray.externC.initializeArray(value);

end callInit;
