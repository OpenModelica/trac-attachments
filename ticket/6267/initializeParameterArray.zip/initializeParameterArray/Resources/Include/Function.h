


#ifdef _WIN32
#ifdef BUILDING_OMC_DLL
    #define OMC_DLL __declspec(dllexport)
#else
#define OMC_DLL __declspec(dllimport)
#endif
#else
  #define OMC_DLL
#endif

#ifdef __cplusplus
extern "C" {
#endif

	OMC_DLL void initializeArray(double value,double* array,size_t a ,size_t b);


#ifdef __cplusplus
}
#endif