#include <stdlib.h>
#include <stdio.h>
#include "Function.h"


#include <iostream>

void initializeArray(double value,double* array,size_t a ,size_t b)
{
  if(array)
  {
      if(a >0 &&  b>0 )
      {
        int i;
        for(i=0;i<a*b;++i)
          array[i]=value;
      }
  }
  
        
}