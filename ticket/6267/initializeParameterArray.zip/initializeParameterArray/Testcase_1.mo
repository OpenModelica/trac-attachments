within initializeParameterArray;
model Testcase_1

  parameter Real t = 1.1;
  parameter Real array[10,3] = callInit(t);

end Testcase_1;
