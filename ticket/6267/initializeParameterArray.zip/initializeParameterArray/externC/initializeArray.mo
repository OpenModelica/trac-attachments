within initializeParameterArray.externC;
function initializeArray

  //EXTENDS
  extends Modelica.Icons.Function;


   input Real value;
   output Real[10,3] y;
  //EXTERNALS
  external "C" annotation(Library="initializeParameterArray",Include="#include \"Function.h\"");

end initializeArray;
