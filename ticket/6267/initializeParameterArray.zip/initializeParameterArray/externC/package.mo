within initializeParameterArray;
package externC

end externC;
