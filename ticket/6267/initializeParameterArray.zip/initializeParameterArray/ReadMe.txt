Build:
g++ -c [ windows only: -D BUILDING_OMC_DLL] Function.c
g++  -o initializeParameterArray.[dll,so] Function.o -s -shared [ windows only: -Wl,--subsystem,windows,--out-implib,libinitializeParameterArray.a]
Install:
copy shared library to initializeParameterArray\Resources\Library corresponding folder
