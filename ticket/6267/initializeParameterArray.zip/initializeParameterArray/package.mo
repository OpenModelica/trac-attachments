within ;
package initializeParameterArray
annotation (uses(Modelica(version="3.2.3")));
end initializeParameterArray;
