within BugParamIcon;
model Modell1

  parameter Modelica.SIunits.Mass param1 = 10;
  parameter Modelica.SIunits.Position param2 = 10;
  parameter Modelica.SIunits.Position param3 = 10;

  annotation (Icon(coordinateSystem(preserveAspectRatio = false, initialScale = 0.1), graphics={Text(origin = {-13, 14}, extent = {{0, 50}, {0, 90}}, textString = "a = %param1
b = %param2
c = %param3",fillPattern=FillPattern.None), Text(extent = {{-23, 10}, {51, -22}}, textString = "%param1 / %param2 - %param2",fillPattern=FillPattern.None)}),                                                      Diagram(coordinateSystem(preserveAspectRatio=false)));
end Modell1;
