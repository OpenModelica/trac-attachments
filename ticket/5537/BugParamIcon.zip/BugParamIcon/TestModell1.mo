within BugParamIcon;
model TestModell1
  BugParamIcon.Modell1 modell1_1(a=10, b=10, c = 10) annotation (Placement(visible = true, transformation(extent = {{-20, -12}, {0, 8}}, rotation = 0)));
  Model2 model21(p1 = 10, p2 = 10, p3 = 10)  annotation(
    Placement(visible = true, transformation(origin = {16, -2}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  annotation (Icon(coordinateSystem(preserveAspectRatio=false)), Diagram(coordinateSystem(preserveAspectRatio=false)));
end TestModell1;
