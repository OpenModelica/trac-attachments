within BugParamIcon;
model Model2

  parameter Modelica.SIunits.Mass par1 = 10;
  parameter Modelica.SIunits.Position p2 = 10;
  parameter Modelica.SIunits.Position p3 = 10;

  annotation (Icon(coordinateSystem(preserveAspectRatio = false, initialScale = 0.1), graphics={Text(origin = {-13, 14}, extent = {{0, 50}, {0, 90}}, textString = "a = %par1
b = %p2
c = %p3",fillPattern=FillPattern.None), Text(extent = {{-23, 10}, {51, -22}}, textString = "%par1 / %p2 - %p3",fillPattern=FillPattern.None)}),                                                      Diagram(coordinateSystem(preserveAspectRatio=false)));
end Model2;
