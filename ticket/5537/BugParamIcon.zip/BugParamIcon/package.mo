within ;
package BugParamIcon
annotation (uses(Modelica(version = "3.2.2"), RexrothGeneric(version = "1.0")));
end BugParamIcon;
