model fmuSimple
  Modelica.Blocks.Interfaces.RealInput u annotation(
    Placement(visible = true, transformation(origin = {-85, 6}, extent = {{-20, -20}, {20, 20}}, rotation = 0), iconTransformation(origin = {-85, 6}, extent = {{-20, -20}, {20, 20}}, rotation = 0)));
  Modelica.Blocks.Interfaces.RealOutput y annotation(
    Placement(visible = true, transformation(origin = {69, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {69, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Continuous.LimIntegrator limIntegrator1(initType = Modelica.Blocks.Types.Init.InitialOutput, outMax = 1, outMin = 0, y_start = 0.5)  annotation(
    Placement(visible = true, transformation(origin = {33, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Math.Add add1(k1 = +1, k2 = -1)  annotation(
    Placement(visible = true, transformation(origin = {-39, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  Modelica.Blocks.Nonlinear.Limiter limiter1(limitsAtInit = true, uMax = 0.1, uMin = -0.1)  annotation(
    Placement(visible = true, transformation(origin = {-4, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  connect(limIntegrator1.y, add1.u2) annotation(
    Line(points = {{44, 0}, {49, 0}, {49, -29}, {-63, -29}, {-63, -6}, {-51, -6}, {-51, -6}}, color = {0, 0, 127}));
  connect(add1.y, limiter1.u) annotation(
    Line(points = {{-28, 0}, {-16, 0}, {-16, 0}, {-16, 0}}, color = {0, 0, 127}));
  connect(u, add1.u1) annotation(
    Line(points = {{-85, 6}, {-52, 6}, {-52, 6}, {-51, 6}}, color = {0, 0, 127}));
  connect(limiter1.y, limIntegrator1.u) annotation(
    Line(points = {{7, 0}, {21, 0}, {21, 0}, {21, 0}}, color = {0, 0, 127}));
  connect(limIntegrator1.y, y) annotation(
    Line(points = {{44, 0}, {69, 0}}, color = {0, 0, 127}));
  annotation(
    Icon(coordinateSystem(grid = {1, 1})),
    Diagram(coordinateSystem(grid = {1, 1})),
    uses(Modelica(version = "3.2.3")));
end fmuSimple;
