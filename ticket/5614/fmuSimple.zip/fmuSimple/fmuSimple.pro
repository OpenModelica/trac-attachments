message("$$_DATE_: Building source directory $$IN_PWD")

QT += core
QT -= gui

CONFIG += c++11

TARGET = fmuSimple
CONFIG += console
CONFIG -= app_bundle

TEMPLATE = app

DEFINES += STANDALONE_XML_PARSER LIBXML_STATIC FMUXML
DEFINES -= UNICODE
windows: DEFINES += _MSCVER

unix:!macx: LIBS += -ldl -lrt

target.path = $$PRJBIN
INSTALLS += target

!include(../fmu20/fmu20.pri) {
  error($$_PRO_FILE_": ../fmu20/fmu20.pri not found!")
}

SOURCES += main.c \
           sim_support.c

HEADERS += sim_support.h

DISTFILES +=

