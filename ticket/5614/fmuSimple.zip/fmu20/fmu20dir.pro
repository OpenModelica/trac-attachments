
message("$$_DATE_: Building source directory $$IN_PWD")

TEMPLATE = aux
CONFIG -= debug_and_release

bindir.target =                  $$shell_path($$PRJBIN)
binbdir.commands = $$QMAKE_MKDIR $$shell_path($$PRJBIN)

fmu20dir.target =                                               $$shell_path($$PRJBIN/fmu20/bin)
fmu20dir.commands = $$QMAKE_COPY_DIR $$shell_path($$IN_PWD/bin) $$shell_path($$PRJBIN/fmu20/bin)
fmu20dir.depends =  bindir

first.depends = fmu20dir

install.depends = first

QMAKE_EXTRA_TARGETS += bindir fmu20dir first install
