message("$$_DATE_: Building source directory $$IN_PWD")

QT += core
QT -= gui

TARGET = parserxml
TEMPLATE = lib

CONFIG += staticlib
CONFIG -= app_bundle
CONFIG += c++11


INCLUDEPATH += ../

DEFINES += _LIB _NDEBUG STANDALONE_XML_PARSER LIBXML_STATIC
windows: DEFINES += WIN32


target.path = $$PRJLIB
INSTALLS += target

SOURCES += ../xmlVersionParser.c\
           XmlElement.cpp \
           XmlParser.cpp \
           XmlParserCApi.cpp \


HEADERS += ../xmlVersionParser.h \
           XmlElement.h \
           XmlParser.h \
           XmlParserCApi.h \
           XmlParserException.h \

DISTFILES +=

