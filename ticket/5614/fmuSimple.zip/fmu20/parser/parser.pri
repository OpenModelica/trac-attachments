#win32:CONFIG(release, debug|release): LIBS += -L$$PWD/../fmu20/src/shared/parser/win32 -lxml2
#else:win32:CONFIG(debug, debug|release): LIBS += -L$$PWD/../fmu20/src/shared/parser/win32 -lxml2
#else:unix: LIBS += -L$$PWD/../fmu20/src/shared/parser -lxml2

# TODO: da vedere per Linux e MAC-OS
# NOTA: per ora e' compilato col progetto, valutare se e' da fare una libreria a parte

INCLUDEPATH += $$PWD/../fmu20/src/shared $$PWD/../fmu20/src/shared/include $$PWD/../fmu20/src/shared/parser


#LIBS += -L../fmu20/src/shared/parser -lxml2
