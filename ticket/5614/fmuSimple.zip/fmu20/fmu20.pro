message("$$_DATE_: Building source directory $$IN_PWD")

TEMPLATE = subdirs

CONFIG += c++11

SUBDIRS = parser

