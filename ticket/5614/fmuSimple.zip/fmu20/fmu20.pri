     win32:CONFIG(release, debug|release): LIBS += -L$$top_builddir/fmu20/parser/release -lparserxml -lxml2
else:win32:CONFIG(debug,   debug|release): LIBS += -L$$top_builddir/fmu20/parser/debug   -lparserxml -lxml2
else:unix:                                 LIBS += -L$$top_builddir/fmu20/parser         -lparserxml -lxml2



INCLUDEPATH += $$PWD/../fmu20 $$PWD/../fmu20/include $$PWD/../fmu20/parser


     win32:CONFIG(release, debug|release): PRE_TARGETDEPS += $$PRJBLDROOT/fmu20/parser/release/libparserxml.a
else:win32:CONFIG(debug, debug|release):   PRE_TARGETDEPS += $$PRJBLDROOT/fmu20/parser/debug/libparserxml.a
else:unix:!macx:                           PRE_TARGETDEPS += $$dirname(OUT_PWD)/fmu20/parser/libparserxml.a
else:macx:                                 PRE_TARGETDEPS += $$PRJBLDROOT/fmu20/parser/libparserxml.a
