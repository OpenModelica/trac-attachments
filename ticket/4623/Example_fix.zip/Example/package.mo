package Example
extends Modelica.Icons.Package;

end Example;
