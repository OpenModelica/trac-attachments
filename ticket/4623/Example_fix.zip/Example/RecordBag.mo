within Example;
package RecordBag
extends Modelica.Icons.Package;

record A
  parameter Modelica.SIunits.Voltage x = 0;
  parameter Modelica.SIunits.Resistance y = 0;
end A;

record B
  parameter Integer dim0 = 3;
  parameter Integer dim1 = 2;
  parameter A z[dim0, dim1] = fill(A(), dim0, dim1);
end B;


end RecordBag;
