within RecordBag;

record A
  parameter Modelica.SIunits.Voltage some_parameter = 0;
  parameter Modelica.SIunits.Resistance some_other_parameter = 0;
end A;