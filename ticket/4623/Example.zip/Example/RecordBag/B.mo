within RecordBag;

record B
  parameter Integer blocks_of_a_dim0 = 3;
  parameter Integer blocks_of_a_dim1 = 2;
  parameter A var_blocks[blocks_of_a_dim0, blocks_of_a_dim1] = fill(A(), blocks_of_a_dim0, blocks_of_a_dim1);
end B;