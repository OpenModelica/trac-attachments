package RecordUse
extends Modelica.Icons.Package;

 model Verbose
   parameter RecordBag.B params();
   
   protected
     parameter RecordBag.A hack = params.z[1,1];
     parameter Modelica.SIunits.Voltage v = hack.x;
 end Verbose;

 
 model Bug
   parameter RecordBag.B params();
   
   protected
     parameter Modelica.SIunits.Voltage v = params.z[1,1].x;
 
 end Bug;


end RecordUse;
