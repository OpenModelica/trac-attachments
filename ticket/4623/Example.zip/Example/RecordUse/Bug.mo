within RecordUse;

model Bug
end Bug;