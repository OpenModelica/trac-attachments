within MyLibrary ;

model IconExample
  parameter Real a = 2;
  Real y;
  FluidInlet fluidInlet annotation(
    Placement(visible = true, transformation(origin = {-120, 10}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-120, 10}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
  FluidOutlet fluidOutlet annotation(
    Placement(visible = true, transformation(origin = {134, 14}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {134, 14}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
equation
  y = a + 1;
  annotation(
    Icon(graphics = {Polygon(origin = {0, 2}, lineColor = {0, 0, 255}, fillColor = {127, 255, 0}, fillPattern = FillPattern.Solid, points = {{-100, 40}, {-100, -40}, {100, -100}, {100, 100}, {-100, 40}}), Line(origin = {0.431211, 2.15606}, points = {{0, -70}, {0, -90}}, thickness = 0.5), Polygon(origin = {-32, -85}, points = {{26, 3}, {46, -15}, {-8, -11}, {-8, -11}, {-46, 15}, {26, 3}}), Line(origin = {-105, 11}, points = {{-5, -1}, {5, -1}, {5, 1}}), Line(origin = {113, 14}, points = {{13, 0}, {-13, 0}})}));
end IconExample;