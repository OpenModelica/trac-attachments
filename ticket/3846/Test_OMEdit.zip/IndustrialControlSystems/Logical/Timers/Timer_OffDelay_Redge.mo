within IndustrialControlSystems.Logical.Timers;
model Timer_OffDelay_Redge "OFF delay timer model, active on rising edge"
  extends IndustrialControlSystems.Logical.Timers.Interfaces.BaseResidualTimer;
  discrete Boolean run "Flag: true while the timer is counting";
  Real startTime "start time of the timer counting";
  discrete Boolean Sd;
initial equation
  startTime = 0;
  run = false;
equation
  when sample(0,Ts) then
    Sd = S;
    (startTime,run) =
      IndustrialControlSystems.Logical.Timers.Functions.risingEdge(
        pre(Sd),
        Sd,
        R,
        startTime,
        time,
        pre(run));
    Q = IndustrialControlSystems.Logical.Timers.Functions.odts(
        R,
        PV,
        time,
        startTime,
        run);
    tr = if (not Q) and run then PV - (time - startTime) else PV;
  end when;
annotation(Icon(graphics={Line(
          points={{40,24},{62,24},{62,82},{84,82}},
          color={0,0,0},
          smooth=Smooth.None), Polygon(
          points={{56,50},{62,64},{68,50},{56,50}},
          lineColor={0,0,0},
          smooth=Smooth.None,
          fillColor={0,0,0},
          fillPattern=FillPattern.Solid),
        Text(
          extent={{-78,56},{80,34}},
          lineColor={0,0,0},
          fillColor={213,255,170},
          fillPattern=FillPattern.Solid,
          textString="Off")}),
Documentation(
info="
  <HTML>
  <h4>Description</h4>
    <p>
    The timer is active after a rising edge of the set signal ( <FONT FACE=Courier>S</FONT> ).<br>
    The output ( <FONT FACE=Courier>Q</FONT> ) of the timer rises up <FONT FACE=Courier>PV</FONT> seconds after the Set ( <FONT FACE=Courier>S</FONT> )
    becomes true.<br>
    If the Set signal become false while counting, the timer does not stop.<br>
    If the Reset signal ( <FONT FACE=Courier>R</FONT> ) becomes true, the output remains false and the timer stops.<br><br>
    
    Images show:
    <ul>
    <li>Set <FONT FACE=Courier>S</FONT> and Reset <FONT FACE=Courier>R</FONT> signals,</li>
    <li>Output <FONT FACE=Courier>Q</FONT>,</li>
    <li>and the remaining time <FONT FACE=Courier>tr</FONT></li>
    </ul>
    
    <img src=\"modelica://IndustrialControlSystems/help/images/Logical/Timers/T_OffDelay_Redge_1.png\"><br>
    <img src=\"modelica://IndustrialControlSystems/help/images/Logical/Timers/T_OffDelay_Redge_2.png\"><br>
    <img src=\"modelica://IndustrialControlSystems/help/images/Logical/Timers/T_OffDelay_Redge_3.png\">
    </p>
  </HTML>", revisions="<html>
<dl><dt>First release of the Industrial Control Systems: April-May 2012</dt>
<dl><dt>List of revisions:</dt>
<p><ul>
<li>11 May 2012 (author: Marco Bonvini)</li>
</ul></p>
<dl><dt><b>Main Authors:</b> <br/></dt>
<dd>Marco Bonvini; &LT;<a href=\"mailto:bonvini@elet.polimi.it\">bonvini@elet.polimi.it</a>&GT;</dd>
<dd>Alberto Leva &LT;<a href=\"mailto:leva@elet.polimi.it\">leva@elet.polimi.it</a>&GT;<br/></dd>
<dd>Politecnico di Milano</dd>
<dd>Dipartimento di Elettronica e Informazione</dd>
<dd>Via Ponzio 34/5</dd>
<dd>20133 Milano - ITALIA -<br/></dd>
<dt><b>Copyright:</b> </dt>
<dd>Copyright &copy; 2010-2012, Marco Bonvini and Alberto Leva.<br/></dd>
<dd><i>The IndustrialControlSystems package is <b>free</b> software; it can be redistributed and/or modified under the terms of the <b>Modelica license</b>, see the license conditions and the accompanying <b>disclaimer</b> in the documentation of package Modelica in file &QUOT;Modelica/package.mo&QUOT;.</i><br/></dd>
</dl></html>"));
end Timer_OffDelay_Redge;
