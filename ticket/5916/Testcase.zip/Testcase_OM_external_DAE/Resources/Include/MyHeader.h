extern void add(double a, double b, double* c){*c = a+b;};
