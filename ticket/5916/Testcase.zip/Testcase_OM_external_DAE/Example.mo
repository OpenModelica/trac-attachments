model Example
  function addReal
    input Real a;
    input Real b;
    output Real c;
    external "C" add(a, b, c) annotation(Include = "#include \"MyHeader.h\"");
  end addReal;

  Real a;
  Real b;
  Real c;
equation
  der(a) = 2;
  der(b) = 4;
  c = addReal(a, b);
annotation(
    __OpenModelica_commandLineOptions = "--matchingAlgorithm=PFPlusExt --indexReductionMethod=dynamicStateSelection -d=initialization,NLSanalyticJacobian,newInst -d=initialization ");
end Example;