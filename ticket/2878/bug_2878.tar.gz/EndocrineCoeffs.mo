model EndocrineCoeffs
  parameter Real K1 = 1;
  parameter Real K2 = 1;
  parameter Real K3 = 1;
  parameter Real K4 = 0.1;
  parameter Real K5 = 1;
  parameter Real K6 = 1;
  parameter Real K7 = 1;
  parameter Real K8 = 1;
  parameter Real K9 = 1;
  parameter Real K10 = 1;
  parameter Real K11 = 1;
  parameter Real K12 = 1;
  parameter Real K13 = 1;
  parameter Real K14 = 1;
  parameter Real K15 = 1;
  annotation(Icon(coordinateSystem(extent = {{-100, -100}, {100, 100}}, preserveAspectRatio = true, initialScale = 0.1, grid = {2, 2})), Diagram(coordinateSystem(extent = {{-100, -100}, {100, 100}}, preserveAspectRatio = true, initialScale = 0.1, grid = {2, 2})));
end EndocrineCoeffs;