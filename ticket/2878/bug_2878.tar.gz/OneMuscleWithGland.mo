model OneMuscleWithGland
  Muscle m;
  EndocrineSystem gland;
equation
  m.G = gland.B;
  //gormon in muscle equals to gormon in body . Is that correct?
  annotation(Diagram(coordinateSystem(extent = {{-100, -100}, {100, 100}}, preserveAspectRatio = true, initialScale = 0.1, grid = {2, 2})), Icon(coordinateSystem(extent = {{-100, -100}, {100, 100}}, preserveAspectRatio = true, initialScale = 0.1, grid = {2, 2}), graphics = {Rectangle(origin = {-5.42005, -4.87805}, extent = {{-60.7046, 44.4444}, {60.7046, -44.4444}})}), experiment(StartTime = 0, StopTime = 1000, Tolerance = 1e-06, Interval = 0.2));
end OneMuscleWithGland;