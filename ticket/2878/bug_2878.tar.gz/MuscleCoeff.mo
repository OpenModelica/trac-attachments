model MuscleCoeff
  parameter Real f5 = 1;
  parameter Real f6 = 1;
  parameter Real f7 = 1;
  parameter Real f8 = 1;
  parameter Real f9 = 1;
  parameter Real f10 = 1;
  parameter Real f11 = 1;
  parameter Real f1 = 1;
  parameter Real f2 = 1;
  parameter Real f3 = 1;
  parameter Real f4 = 1;
  annotation(Icon(coordinateSystem(extent = {{-100, -100}, {100, 100}}, preserveAspectRatio = true, initialScale = 0.1, grid = {2, 2})), Diagram(coordinateSystem(extent = {{-100, -100}, {100, 100}}, preserveAspectRatio = true, initialScale = 0.1, grid = {2, 2})));
end MuscleCoeff;