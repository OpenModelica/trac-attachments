within BIL100_Demo.BIL100_Modules;
model SensorAPP1d
  ThermoSysPro.WaterSteam.Connectors.FluidInletI fluidInletI
    annotation (Placement(transformation(extent={{-110,-90},{-90,-70}},
          rotation=0)));
  ThermoSysPro.WaterSteam.Connectors.FluidOutletI fluidOutletI
    annotation (Placement(transformation(extent={{90,-90},{110,-70}},
          rotation=0)));
  ThermoSysPro.WaterSteam.Sensors.SensorP N061MP
    annotation (Placement(transformation(extent={{20,-62},{40,-42}}, rotation=
           0)));
equation
  connect(N061MP.C2, fluidOutletI)
                                  annotation (Line(points={{40.2,-60},{80,-60},
          {80,-80},{100,-80}}, color={0,0,255}));
  connect(N061MP.C1, fluidInletI)
    annotation (Line(points={{20,-60},{-80,-60},{-80,-80},{-100,-80}}));
  annotation (Diagram(graphics),
                       Icon(graphics={
        Ellipse(
          extent={{-60,90},{60,-30}},
          lineColor={0,0,255},
          fillColor={170,85,255},
          fillPattern=FillPattern.Solid),
        Line(points={{0,-30},{0,-80}}),
        Line(points={{-100,-80},{100,-80}}),
        Text(extent={{-60,58},{60,-2}}, textString=
                                          "P, ...")}));
end SensorAPP1d;
