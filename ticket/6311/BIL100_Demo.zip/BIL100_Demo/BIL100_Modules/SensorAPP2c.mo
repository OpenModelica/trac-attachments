within BIL100_Demo.BIL100_Modules;
model SensorAPP2c
  ThermoSysPro.WaterSteam.Connectors.FluidInletI fluidInletI
    annotation (Placement(transformation(extent={{-110,-90},{-90,-70}},
          rotation=0)));
  ThermoSysPro.WaterSteam.Connectors.FluidOutletI fluidOutletI
    annotation (Placement(transformation(extent={{90,-90},{110,-70}},
          rotation=0)));
  ThermoSysPro.WaterSteam.Sensors.SensorQ N512YD
    annotation (Placement(transformation(extent={{20,-62},{40,-42}}, rotation=
           0)));
  ThermoSysPro.WaterSteam.Sensors.SensorQ N012MD
    annotation (Placement(transformation(extent={{-40,-62},{-20,-42}},
          rotation=0)));
equation
  connect(N512YD.C2, fluidOutletI)
                                  annotation (Line(points={{40.2,-60},{80,-60},
          {80,-80},{100,-80}}, color={0,0,255}));
  connect(N512YD.C1, N012MD.C2) annotation (Line(points={{20,-60},{-19.8,-60}}));
  connect(N012MD.C1, fluidInletI)
    annotation (Line(points={{-40,-60},{-80,-60},{-80,-80},{-100,-80}}));
  annotation (Diagram(graphics),
                       Icon(graphics={
        Ellipse(
          extent={{-60,90},{60,-30}},
          lineColor={0,0,255},
          fillColor={170,85,255},
          fillPattern=FillPattern.Solid),
        Line(points={{0,-30},{0,-80}}),
        Line(points={{-100,-80},{100,-80}}),
        Text(extent={{-60,58},{60,-2}}, textString=
                                          "P, ...")}));
end SensorAPP2c;
