within BIL100_Demo.BIL100_Modules;
model simpleStaticCondenserVALI
  ThermoSysPro.WaterSteam.HeatExchangers.StaticWaterWaterExchanger
    staticWaterWaterExchanger1
    annotation (Placement(transformation(
        origin={0,55},
        extent={{-10,-10},{10,10}},
        rotation=270)));
  ThermoSysPro.WaterSteam.HeatExchangers.StaticWaterWaterExchanger
    staticWaterWaterExchanger2
    annotation (Placement(transformation(
        origin={0,15},
        extent={{-10,-10},{10,10}},
        rotation=270)));
  ThermoSysPro.WaterSteam.HeatExchangers.StaticWaterWaterExchanger
    staticWaterWaterExchanger3
    annotation (Placement(transformation(
        origin={0,-25},
        extent={{-10,-10},{10,10}},
        rotation=270)));
  SingularPressureLossVALI DP_gre1l annotation (Placement(transformation(
          extent={{-60,50},{-40,70}}, rotation=0)));
  SingularPressureLossVALI DP_gre3l annotation (Placement(transformation(
          extent={{-60,10},{-40,30}}, rotation=0)));
  SingularPressureLossVALI singularPressureLossVALI3
    annotation (Placement(transformation(extent={{-60,-10},{-40,10}},
          rotation=0)));
  SingularPressureLossVALI DP_gre5l annotation (Placement(transformation(
          extent={{-60,-30},{-40,-10}}, rotation=0)));
  SingularPressureLossVALI singularPressureLossVALI5
    annotation (Placement(transformation(extent={{-60,-50},{-40,-30}},
          rotation=0)));
equation
  connect(staticWaterWaterExchanger1.Sc, staticWaterWaterExchanger2.Ec)
    annotation (Line(points={{0.2,45},{0.2,34.5},{-6.12303e-016,34.5},{
          -6.12303e-016,25}}, color={0,0,255}));
  connect(staticWaterWaterExchanger2.Sc, staticWaterWaterExchanger3.Ec)
    annotation (Line(points={{0.2,5},{0.2,-5.5},{-6.12303e-016,-5.5},{
          -6.12303e-016,-15}}, color={0,0,255}));
  annotation (Diagram(graphics));
end simpleStaticCondenserVALI;
