within BIL100_Demo.BIL100_Modules;
model Boundaries

  ThermoSysPro.InstrumentationAndControl.Connectors.OutputReal QGRE0
    annotation (Placement(transformation(extent={{10,-10},{-10,10}},
          rotation=180,
        origin={98,0})));
  ThermoSysPro.InstrumentationAndControl.Connectors.InputReal QGSS0
    annotation (Placement(transformation(extent={{10,10},{-10,-10}}, rotation=180,
        origin={-100,80})));
  ThermoSysPro.InstrumentationAndControl.Connectors.InputReal QPUR1
    annotation (Placement(transformation(extent={{10,10},{-10,-10}}, rotation=180,
        origin={-100,40})));
  ThermoSysPro.InstrumentationAndControl.Connectors.InputReal QPUR2
    annotation (Placement(transformation(extent={{10,10},{-10,-10}}, rotation=180,
        origin={-100,20})));
  ThermoSysPro.InstrumentationAndControl.Connectors.InputReal QPUR3
    annotation (Placement(transformation(extent={{10,10},{-10,-10}}, rotation=180,
        origin={-100,0})));
  ThermoSysPro.InstrumentationAndControl.Connectors.InputReal QPUR4
    annotation (Placement(transformation(extent={{10,10},{-10,-10}}, rotation=180,
        origin={-100,-20})));
  ThermoSysPro.InstrumentationAndControl.Connectors.InputReal QARE0
    annotation (Placement(transformation(extent={{10,10},{-10,-10}}, rotation=180,
        origin={-100,-60})));
equation
  QGRE0.signal=QARE0.signal-QPUR1.signal-QPUR2.signal-QPUR3.signal-QPUR4.signal-QGSS0.signal;
  annotation (Diagram(graphics),
                       Icon(graphics={Rectangle(extent={{-100,100},{100,-100}},
            lineColor={0,0,255}), Text(
          extent={{-50,18},{50,-12}},
          lineColor={0,0,255},
          textString="%name")}));
end Boundaries;
