within BIL100_Demo.BIL100_Modules;
model SensorAHP1d
  ThermoSysPro.WaterSteam.Connectors.FluidInletI fluidInletI
    annotation (Placement(transformation(extent={{-110,-90},{-90,-70}},
          rotation=0)));
  ThermoSysPro.WaterSteam.Connectors.FluidOutletI fluidOutletI
    annotation (Placement(transformation(extent={{90,-90},{110,-70}},
          rotation=0)));
  ThermoSysPro.WaterSteam.Sensors.SensorT N461YT
    annotation (Placement(transformation(extent={{-60,-62},{-40,-42}},
          rotation=0)));
  ThermoSysPro.WaterSteam.Sensors.SensorP N003MP
    annotation (Placement(transformation(extent={{20,-62},{40,-42}}, rotation=
           0)));
  ThermoSysPro.WaterSteam.Sensors.SensorT N031MT
    annotation (Placement(transformation(extent={{-20,-62},{0,-42}}, rotation=
           0)));
equation
  connect(N003MP.C2, fluidOutletI)
                                  annotation (Line(points={{40.2,-60},{80,-60},
          {80,-80},{100,-80}}, color={0,0,255}));
  connect(fluidInletI,N461YT. C1)
    annotation (Line(points={{-100,-80},{-80,-80},{-80,-60},{-60,-60}}));
  connect(N461YT.C2,N031MT. C1) annotation (Line(points={{-39.8,-60},{-20,-60}},
        color={0,0,255}));
  connect(N031MT.C2,N003MP. C1) annotation (Line(points={{0.2,-60},{20,-60}},
        color={0,0,255}));
  annotation (Diagram(graphics),
                       Icon(graphics={
        Ellipse(
          extent={{-60,90},{60,-30}},
          lineColor={0,0,255},
          fillColor={170,85,255},
          fillPattern=FillPattern.Solid),
        Line(points={{0,-30},{0,-80}}),
        Line(points={{-100,-80},{100,-80}}),
        Text(extent={{-60,58},{60,-2}}, textString=
                                          "P, ...")}));
end SensorAHP1d;
