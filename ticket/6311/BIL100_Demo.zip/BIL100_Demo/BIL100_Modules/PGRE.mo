within BIL100_Demo.BIL100_Modules;
model PGRE
  parameter Real A=0.629;
  parameter Real B=-2;
  parameter Real PGRE_VAR1=1;

  ThermoSysPro.InstrumentationAndControl.Connectors.InputReal PourcentagePN
    annotation (Placement(transformation(extent={{-108,-10},{-88,10}},
          rotation=0)));
  ThermoSysPro.InstrumentationAndControl.Connectors.OutputReal PGRE
    annotation (Placement(transformation(extent={{92,-10},{112,10}}, rotation=
           0)));
  ThermoSysPro.InstrumentationAndControl.Blocks.Math.Gain gain(Gain=A)
    annotation (Placement(transformation(extent={{-60,-10},{-40,10}},
          rotation=0)));
  ThermoSysPro.InstrumentationAndControl.Blocks.Math.Add add
    annotation (Placement(transformation(extent={{0,-30},{20,-10}}, rotation=
            0)));
  ThermoSysPro.InstrumentationAndControl.Blocks.Sources.Constante constante(k=
       B) annotation (Placement(transformation(extent={{-60,-40},{-40,-20}},
          rotation=0)));
  ThermoSysPro.InstrumentationAndControl.Blocks.Math.Gain gain1(Gain=
        PGRE_VAR1) annotation (Placement(transformation(extent={{40,-30},{60,
            -10}}, rotation=0)));
equation
  connect(PourcentagePN, gain.u) annotation (Line(points={{-98,0},{-61,0}}));
  connect(constante.y, add.u2)
    annotation (Line(points={{-39,-30},{-20,-30},{-20,-26},{-1,-26}}));
  connect(gain.y, add.u1) annotation (Line(points={{-39,0},{-20,0},{-20,-14},
          {-1,-14}}));
  connect(add.y, gain1.u) annotation (Line(points={{21,-20},{39,-20}}));
  connect(gain1.y, PGRE) annotation (Line(points={{61,-20},{80,-20},{80,0},{
          102,0}}));
  annotation (Diagram(graphics),
                       Icon(graphics={Rectangle(
          extent={{-100,100},{100,-100}},
          lineColor={0,0,255},
          fillColor={170,85,255},
          fillPattern=FillPattern.Solid), Text(
          extent={{-57,36},{49,-38}},
          lineColor={0,0,255},
          textString=
               "PGRE")}));
end PGRE;
