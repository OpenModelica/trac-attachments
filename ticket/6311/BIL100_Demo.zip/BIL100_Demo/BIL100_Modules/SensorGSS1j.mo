within BIL100_Demo.BIL100_Modules;
model SensorGSS1j
  ThermoSysPro.WaterSteam.Connectors.FluidInletI fluidInletI
    annotation (Placement(transformation(extent={{-110,-90},{-90,-70}},
          rotation=0)));
  ThermoSysPro.WaterSteam.Connectors.FluidOutletI fluidOutletI
    annotation (Placement(transformation(extent={{90,-90},{110,-70}},
          rotation=0)));
  ThermoSysPro.WaterSteam.Sensors.SensorT N341MT
    annotation (Placement(transformation(extent={{-40,58},{-20,78}}, rotation=
           0)));
  ThermoSysPro.WaterSteam.Sensors.SensorQ N353MD
    annotation (Placement(transformation(extent={{-40,-2},{-20,18}}, rotation=
           0)));
  ThermoSysPro.WaterSteam.Sensors.SensorQ N355YD
    annotation (Placement(transformation(extent={{0,-2},{20,18}}, rotation=0)));
  ThermoSysPro.WaterSteam.Sensors.SensorP N355YP
    annotation (Placement(transformation(extent={{-40,-82},{-20,-62}},
          rotation=0)));
  ThermoSysPro.WaterSteam.Sensors.SensorT N357YT
    annotation (Placement(transformation(extent={{0,-82},{20,-62}}, rotation=
            0)));
equation
  connect(fluidInletI, N341MT.C1)
    annotation (Line(points={{-100,-80},{-80,-80},{-80,60},{-40,60}}));
  connect(N341MT.C2, N353MD.C1) annotation (Line(points={{-19.8,60},{0,60},{0,
          40},{-60,40},{-60,0},{-40,0}}, color={0,0,255}));
  connect(N353MD.C2, N355YD.C1)
    annotation (Line(points={{-19.8,0},{0,0}}, color={0,0,255}));
  connect(N355YD.C2, N355YP.C1) annotation (Line(points={{20.2,0},{40,0},{40,
          -20},{-60,-20},{-60,-80},{-40,-80}}, color={0,0,255}));
  connect(N355YP.C2, N357YT.C1) annotation (Line(points={{-19.8,-80},{0,-80}},
        color={0,0,255}));
  connect(N357YT.C2, fluidOutletI) annotation (Line(points={{20.2,-80},{100,
          -80}}, color={0,0,255}));
  annotation (Diagram(graphics),
                       Icon(graphics={
        Ellipse(
          extent={{-60,90},{60,-30}},
          lineColor={0,0,255},
          fillColor={170,85,255},
          fillPattern=FillPattern.Solid),
        Line(points={{0,-30},{0,-80}}),
        Line(points={{-100,-80},{100,-80}}),
        Text(extent={{-60,58},{60,-2}}, textString=
                                          "P, ...")}));
end SensorGSS1j;
