within BIL100_Demo.BIL100_Modules;
model SensorAPP1c
  ThermoSysPro.WaterSteam.Connectors.FluidInletI fluidInletI
    annotation (Placement(transformation(extent={{-110,-90},{-90,-70}},
          rotation=0)));
  ThermoSysPro.WaterSteam.Connectors.FluidOutletI fluidOutletI
    annotation (Placement(transformation(extent={{90,-90},{110,-70}},
          rotation=0)));
  ThermoSysPro.WaterSteam.Sensors.SensorQ N011MD
    annotation (Placement(transformation(extent={{-40,38},{-20,58}}, rotation=
           0)));
  ThermoSysPro.WaterSteam.Sensors.SensorP N507YP
    annotation (Placement(transformation(extent={{20,38},{40,58}}, rotation=0)));
  ThermoSysPro.WaterSteam.Sensors.SensorT N509YT
    annotation (Placement(transformation(extent={{-40,-62},{-20,-42}},
          rotation=0)));
  ThermoSysPro.WaterSteam.Sensors.SensorQ N511YD
    annotation (Placement(transformation(extent={{20,-62},{40,-42}}, rotation=
           0)));
equation
  connect(fluidInletI, N011MD.C1)
    annotation (Line(points={{-100,-80},{-80,-80},{-80,40},{-40,40}}));
  connect(N011MD.C2, N507YP.C1) annotation (Line(points={{-19.8,40},{20,40}},
        color={0,0,255}));
  connect(N507YP.C2, N509YT.C1) annotation (Line(points={{40.2,40},{80,40},{
          80,0},{-60,0},{-60,-60},{-40,-60}}, color={0,0,255}));
  connect(N509YT.C2, N511YD.C1) annotation (Line(points={{-19.8,-60},{20,-60}},
        color={0,0,255}));
  connect(N511YD.C2, fluidOutletI) annotation (Line(points={{40.2,-60},{80,
          -60},{80,-80},{100,-80}}, color={0,0,255}));
  annotation (Diagram(graphics),
                       Icon(graphics={
        Ellipse(
          extent={{-60,90},{60,-30}},
          lineColor={0,0,255},
          fillColor={170,85,255},
          fillPattern=FillPattern.Solid),
        Line(points={{0,-30},{0,-80}}),
        Line(points={{-100,-80},{100,-80}}),
        Text(extent={{-60,58},{60,-2}}, textString=
                                          "P, ...")}));
end SensorAPP1c;
