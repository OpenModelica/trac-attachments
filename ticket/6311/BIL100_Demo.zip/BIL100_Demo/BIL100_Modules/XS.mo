within BIL100_Demo.BIL100_Modules;
model XS
  parameter Real K=1;

  ThermoSysPro.InstrumentationAndControl.Connectors.OutputReal Xsout
    annotation (Placement(transformation(extent={{92,-10},{112,10}}, rotation=
           0)));
  ThermoSysPro.InstrumentationAndControl.Connectors.InputReal Xturb
    annotation (Placement(transformation(extent={{-108,-10},{-88,10}},
          rotation=0)));
equation
  K = (1-Xsout.signal)/(1-Xturb.signal);
  annotation (Diagram(graphics={Rectangle(
          extent={{-100,100},{100,-100}},
          lineColor={0,0,255},
          fillColor={170,85,255},
          fillPattern=FillPattern.Solid), Text(
          extent={{-66,54},{70,-58}},
          lineColor={0,0,255},
          textString=
               "XS")}),Icon(graphics={Rectangle(
          extent={{-100,100},{100,-100}},
          lineColor={0,0,255},
          fillColor={170,85,255},
          fillPattern=FillPattern.Solid), Text(
          extent={{-66,54},{70,-58}},
          lineColor={0,0,255},
          textString=
               "XS")}));
end XS;
