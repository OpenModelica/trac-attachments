within BIL100_Demo.BIL100_Modules;
model SensorGSS1
  ThermoSysPro.WaterSteam.Connectors.FluidInletI fluidInletI
    annotation (Placement(transformation(extent={{-110,-90},{-90,-70}},
          rotation=0)));
  ThermoSysPro.WaterSteam.Connectors.FluidOutletI fluidOutletI
    annotation (Placement(transformation(extent={{90,-90},{110,-70}},
          rotation=0)));
  ThermoSysPro.WaterSteam.Sensors.SensorQ N011MD
    annotation (Placement(transformation(extent={{-60,-62},{-40,-42}},
          rotation=0)));
  ThermoSysPro.WaterSteam.Sensors.SensorP N411YP
    annotation (Placement(transformation(extent={{20,-62},{40,-42}}, rotation=
           0)));
  ThermoSysPro.WaterSteam.Sensors.SensorQ N011YD
    annotation (Placement(transformation(extent={{-20,-62},{0,-42}}, rotation=
           0)));
equation
  connect(N411YP.C2, fluidOutletI)
                                  annotation (Line(points={{40.2,-60},{80,-60},
          {80,-80},{100,-80}}, color={0,0,255}));
  connect(fluidInletI, N011MD.C1)
    annotation (Line(points={{-100,-80},{-80,-80},{-80,-60},{-60,-60}}));
  connect(N011MD.C2, N011YD.C1) annotation (Line(points={{-39.8,-60},{-20,-60}},
        color={0,0,255}));
  connect(N011YD.C2, N411YP.C1) annotation (Line(points={{0.2,-60},{20,-60}},
        color={0,0,255}));
  annotation (Diagram(graphics),
                       Icon(graphics={
        Ellipse(
          extent={{-60,90},{60,-30}},
          lineColor={0,0,255},
          fillColor={170,85,255},
          fillPattern=FillPattern.Solid),
        Line(points={{0,-30},{0,-80}}),
        Line(points={{-100,-80},{100,-80}}),
        Text(extent={{-60,58},{60,-2}}, textString=
                                          "P, ...")}));
end SensorGSS1;
