within BIL100_Demo;
model SG_Unit_ReconciliationPQT
  /* WARNING: This model illustrates parts of an industrial use-case but the associated numerical values do not correspond to the reality of the industrial process */
  GV_Unit  SG_Unit(
   sensorARE1(
     N01MD(Q(uncertain=Uncertainty.refine)),
     N02MD(Q(uncertain=Uncertainty.refine)),
     N20YD(Q(uncertain=Uncertainty.refine)),
     N10MT(T(uncertain=Uncertainty.refine)),
     N11YT(T(uncertain=Uncertainty.refine)),
     N20YP(Measure(signal(uncertain=Uncertainty.refine)))),
   sensorARE2(
     N01MD(Q(uncertain=Uncertainty.refine)),
     N02MD(Q(uncertain=Uncertainty.refine)),
     N20YD(Q(uncertain=Uncertainty.refine)),
     N10MT(T(uncertain=Uncertainty.refine)),
     N11YT(T(uncertain=Uncertainty.refine))),
   sensorARE3(
     N01MD(Q(uncertain=Uncertainty.refine)),
     N02MD(Q(uncertain=Uncertainty.refine)),
     N20YD(Q(uncertain=Uncertainty.refine)),
     N10MT(T(uncertain=Uncertainty.refine)),
     N11YT(T(uncertain=Uncertainty.refine))),
   sensorARE4(
     N01MD(Q(uncertain=Uncertainty.refine)),
     N02MD(Q(uncertain=Uncertainty.refine)),
     N20YD(Q(uncertain=Uncertainty.refine)),
     N10MT(T(uncertain=Uncertainty.refine)),
     N11YT(T(uncertain=Uncertainty.refine))),
   sensorVVP1(
     N01MD(Q(uncertain=Uncertainty.refine)),
     N02MD(Q(uncertain=Uncertainty.refine)),
     N08MT(T(uncertain=Uncertainty.refine)),
     N04MP(Measure(signal(uncertain=Uncertainty.refine))),
     N05MP(Measure(signal(uncertain=Uncertainty.refine))),
     N06MP(Measure(signal(uncertain=Uncertainty.refine))),
     N07MP(Measure(signal(uncertain=Uncertainty.refine))),
     N09YP(Measure(signal(uncertain=Uncertainty.refine)))),
   sensorVVP2(
     N01MD(Q(uncertain=Uncertainty.refine)),
     N02MD(Q(uncertain=Uncertainty.refine)),
     N08MT(T(uncertain=Uncertainty.refine)),
     N04MP(Measure(signal(uncertain=Uncertainty.refine))),
     N05MP(Measure(signal(uncertain=Uncertainty.refine))),
     N06MP(Measure(signal(uncertain=Uncertainty.refine))),
     N07MP(Measure(signal(uncertain=Uncertainty.refine))),
     N09YP(Measure(signal(uncertain=Uncertainty.refine)))),
   sensorVVP3(
     N01MD(Q(uncertain=Uncertainty.refine)),
     N02MD(Q(uncertain=Uncertainty.refine)),
     N08MT(T(uncertain=Uncertainty.refine)),
     N04MP(Measure(signal(uncertain=Uncertainty.refine))),
     N05MP(Measure(signal(uncertain=Uncertainty.refine))),
     N06MP(Measure(signal(uncertain=Uncertainty.refine))),
     N07MP(Measure(signal(uncertain=Uncertainty.refine))),
     N09YP(Measure(signal(uncertain=Uncertainty.refine)))),
   sensorVVP4(
     N01MD(Q(uncertain=Uncertainty.refine)),
     N02MD(Q(uncertain=Uncertainty.refine)),
     N08MT(T(uncertain=Uncertainty.refine)),
     N04MP(Measure(signal(uncertain=Uncertainty.refine))),
     N05MP(Measure(signal(uncertain=Uncertainty.refine))),
     N06MP(Measure(signal(uncertain=Uncertainty.refine))),
     N07MP(Measure(signal(uncertain=Uncertainty.refine))),
     N09YP(Measure(signal(uncertain=Uncertainty.refine)))),
   sensorGCT(
     N001MP(Measure(signal(uncertain=Uncertainty.refine))),
     N002MP(Measure(signal(uncertain=Uncertainty.refine)))),
   sensorGRE(
     N001MT(T(uncertain=Uncertainty.refine)),
     N776MT(T(uncertain=Uncertainty.refine)),
     N777MT(T(uncertain=Uncertainty.refine))))
    annotation (Placement(transformation(extent={{-72,-18},{44,48}})));
//    sourcePQARE(
//      Q0(start=2142.972222,fixed=true,uncertain=Uncertainty.refine),
//      T0(start=500.2497543,fixed=true,uncertain=Uncertainty.refine),
//      P0(start=7032392.1,fixed=true,uncertain=Uncertainty.refine)),
//    sinkQGSS(
//      Q0(start=183.713226,fixed=true,uncertain=Uncertainty.refine),
//      T0(start=552.6833333,fixed=true,uncertain=Uncertainty.refine)),
//    sinkQGRE(
//      Q0(start=1922.331218,fixed=true,uncertain=Uncertainty.refine),
//      T0(start=552.6833333,fixed=true,uncertain=Uncertainty.refine)),
//    sinkQSTR(
//      T0(start=552.6833333,fixed=true,uncertain=Uncertainty.refine)),
//    sinkQPUR1(
//      T0(start=500.2497543,fixed=true,uncertain=Uncertainty.refine)),
//    sinkQPUR2(
//      T0(start=500.2497543,fixed=true,uncertain=Uncertainty.refine)),
//    sinkQPUR3(
//      T0(start=500.2497543,fixed=true,uncertain=Uncertainty.refine)),
//    sinkQPUR4(
//      T0(start=500.2497543,fixed=true,uncertain=Uncertainty.refine)),
end SG_Unit_ReconciliationPQT;
