within ;
package BIL100_Demo 
  /* WARNING: All of this package illustrates parts of an industrial use-case but the associated numerical values do not correspond to the reality of the industrial process */


annotation (uses(
    ThermoSysPro(version="1"),
    Modelica(version="3.2")),
  version="1",
  conversion(noneFromVersion=""));
end BIL100_Demo;
