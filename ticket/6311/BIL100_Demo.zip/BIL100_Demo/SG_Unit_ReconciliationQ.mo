within BIL100_Demo;
model SG_Unit_ReconciliationQ
  /* WARNING: This model illustrates parts of an industrial use-case but the associated numerical values do not correspond to the reality of the industrial process */
  GV_Unit  SG_Unit(
   sensorARE1(
     N01MD(Q(uncertain=Uncertainty.refine, start = 1940.2)),
     N02MD(Q(uncertain=Uncertainty.refine, start = 1934.85)),
     N20YD(Q(uncertain=Uncertainty.refine, start = 536.551575))),
   sensorARE2(
     N01MD(Q(uncertain=Uncertainty.refine, start = 1921.85)),
     N02MD(Q(uncertain=Uncertainty.refine, start = 1917)),
     N20YD(Q(uncertain=Uncertainty.refine, start = 526.24884))),
   sensorARE3(
     N01MD(Q(uncertain=Uncertainty.refine, start = 1925.05)),
     N02MD(Q(uncertain=Uncertainty.refine, start = 1919.45)),
     N20YD(Q(uncertain=Uncertainty.refine, start = 534.390869))),
   sensorARE4(
     N01MD(Q(uncertain=Uncertainty.refine, start = 1927.6)),
     N02MD(Q(uncertain=Uncertainty.refine, start = 1917.05)),
     N20YD(Q(uncertain=Uncertainty.refine, start = 530.178223))),
   sensorVVP1(
     N01MD(Q(uncertain=Uncertainty.refine, start = 1944.3)),
     N02MD(Q(uncertain=Uncertainty.refine, start = 1864.16))),
   sensorVVP2(
     N01MD(Q(uncertain=Uncertainty.refine, start = 1935.975)),
     N02MD(Q(uncertain=Uncertainty.refine, start = 1939.8))),
   sensorVVP3(
     N01MD(Q(uncertain=Uncertainty.refine, start = 1959.2)),
     N02MD(Q(uncertain=Uncertainty.refine, start = 1941.3))),
   sensorVVP4(
     N01MD(Q(uncertain=Uncertainty.refine, start = 1957.7)),
     N02MD(Q(uncertain=Uncertainty.refine, start = 1926.3))))
    annotation (Placement(transformation(extent={{-72,-18},{44,48}})));
//    sourcePQARE(
//      Q0(start=2142.972222,fixed=true,uncertain=Uncertainty.refine)),
//    sinkQGSS(
//      Q0(start=183.713226,fixed=true,uncertain=Uncertainty.refine)),
//    sinkQGRE(
//      Q0(start=1922.331218,fixed=true,uncertain=Uncertainty.refine)),
end SG_Unit_ReconciliationQ;
